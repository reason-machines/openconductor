# COMPOSER-ATTACH-FOCUS-135

Conductor Rebuild, 2026-11-17. Bounded source/callback qualification; no product edits or new runtime/native/package admission. Current `main` fetched twice, most recently at 15:28 UTC: `217498aae38dfd63b97919b1a0ab4097462c691e`. #1432's branch remains unchanged. #1447 has separate CI-to-merge custody in existing successor 7b36.

## Qualified difference

The complete REA-retained actual Composer `ITo` closes picker success to live-editor focus: `W9` rejects disabled state, awaits `PNi`, and for nonempty picked paths awaits bound `IIr.mutateAsync` before calling captured `de`. `de` focuses captured editor `B` only while it is not destroyed. The same W9 is bound to the Add attachment controls and shortcut. `PNi` calls the host's multiple-file picker and maps null/absent picker results to an empty array. Complete a7i retains the add-menu consumer. Complete lHt/n4o/t4o retain the editor-ready and managed editor lifetime closure.

**Timing restriction:** complete IIr's local branch calls Yoi and returns `Promise.resolve()` without waiting for processing. Complete Yoi/SIr close that local dispatcher, whose async native processing is fire-and-forget. This is a focus-after-nonempty-selection/mutation-settlement contract. It is NOT proof of focus after successful native staging, a native-write error focus policy, or exact native timing. No vendor JavaScript is executed.

Fresh OpenConductor `WorkspaceView.attachFiles` awaits `session.attach` and then returns without focusing any editor. Actual `Composer.onAttachFiles` passes nonempty files but erases the async return; focusing eagerly in Composer would therefore not be the qualified boundary. Real `ComposerSession` handles read errors in its state and preserves pending attachments with the original session. The bounded candidate is solely the parent's attachment callback: capture its initial editor, retain existing attachment work, then focus only for a nonempty attempt whose editor ref still matches the captured handle. Do not change the onAttachFiles API or clipboard reader.

## Complete original closure

`node .qa/composer-refill-1514/qualify-reference.mjs` passed:

- Complete parent renderer: 11,600,457 bytes; SHA256 `5199d392ef2dec92886393f181bc98531efc6251f75b9effecd9f60dc9515dde`.
- Nine complete exact-parent declarations/expressions: ITo, PNi, IIr, SIr, Yoi, a7i, lHt, n4o, t4o.
- Exact UTF8/UTF16 ranges, declaration syntax, lengths and hashes retained in qualification.json and reference/.
- Seventeen explicit original/current binding assertions passed, including real current callback/consumer/error/lifetime joins.
- The initial extractor assumed Yoi was a function; the complete retained parent instead has a SIr factory binding. That local extractor error is preserved as source-verifier-v1-extractor-error.txt; correction added the complete binding/factory. This was not a REA acquisition failure. No new REA acquisition or tool operation occurred.

## Frozen actual callback reproduction

The fixture extracts and runs the unique actual WorkspaceView.attachFiles declaration. It uses real ComposerSession, inert deferred file reads, inert memory storage, and inert editor ports. It does not mount WorkspaceView or drive a browser/OS picker. No native IPC, provider, filesystem staging, or real-user data mutation.

- Final fixture: src/features/chat/composerAttachmentFocus.test.ts, SHA256 `abd563456f9d1013f73f82fdf370d4efade85a689bbeb12318cbc1f738b44c56`.
- Before any product edit, the fixture and actual callback/session source were frozen in frozen-before-run.sha256.
- `node --experimental-strip-types --test src/features/chat/composerAttachmentFocus.test.ts`: **7 PASS / 1 intended assertion failure / 8 total**, exit 1; zero skips/cancellations.
- The intended failure observes `[]` instead of the original live editor focus event after the nonempty local read/attachment settles; one attachment and the retained draft are otherwise present.
- Seven passing controls: empty selection; swallowed read-error and draft retained; detachment during pending read; handle replacement; absent initial editor; another composer isolated; adapter rejection not treated as success. Pending work stays with its original session. The first/isolation controls reject eager focus. The swallowed-error control deliberately does not assert a native write-error focus policy.
- Fixture and production-source frozen hashes rechecked unchanged after final RED.
- Whole snapshot `npm run typecheck`: **PASS** with the new fixture. The snapshot includes exact-main tools/chat and the three required JSON evidence imports.

The first fixture version had the unused memory-store `clear()` return boolean instead of required void. v1/ preserves its original fixture, freeze, 7P/1F output and failing typecheck. Only that unused return was corrected. All eight complete test-case ASTs were compared byte-for-byte and remained identical. The corrected fixture was refrozen and the same 7P/1 intended failure reproduced before any product edit. No assertion or production code was changed to hide a failure.

## Proposed scope, not applied

Only `src/components/WorkspaceView.tsx` function attachFiles:

```diff
 async function attachFiles(files: File[]) {
+  const box = inputRef.current;
   await session.attach(files, reason ? (relativePath, data) => draftAttachmentsApi.write({ draftWorkspaceId: workspace.id, relativePath, data }) : undefined);
+  if (files.length > 0 && inputRef.current === box) box?.focus();
 }
```

New dedicated fixture plus new evidence/chat/composer/attachment-focus/**. Necessary adjacent harness-only change: existing composerAttachmentSettlement.test.ts extracts the parent callbacks and supplies their ports; add `inputRef: { current: null }` to those ports. Preserve all its assertions. Do not put test-only `typeof inputRef` branches in production.

Ledger collision-cleared qualification, not product edits yet. Root approved the bounded proposed callback/new fixture/evidence/single inert adjacent port, conditional on exact ledger source lease. Reuse existing successor 7b36 for fresh-main implementation/publication; do not append to #1432 or commit into still-open #1447. No second writer or duplicate PR/runtime dispatch.

## Remaining verification

Treatment, adjacent tests, product build and published-head CI are **NOT RUN for this new candidate**. Native picker, actual macOS focus, original staging timing, native reader/normalizer/final agent input, installed package containment and side-by-side behavior are **UNVERIFIED** and remain with existing exclusive custodians. The source RED does not establish those acceptances.

Separate #1447 parent integration at e6440c308db5e0937d46e670147107d080fc810c passed: frozen baseline 6P/1 intended failure; treatment+11 adjacent 131/131; source9/15/exact full-parent ranges, hashes, typecheck/build/colors/scope passed. See PR comment https://github.com/reason-machines/openconductor/pull/1447#issuecomment-6952464901 and parent integrated log attachment. No browser/native/package test was run for that integration either.
