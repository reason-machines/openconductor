import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { test } from "node:test";
import { runInNewContext } from "node:vm";

import { effectiveShortcuts as realEffectiveShortcuts } from "../../src/keybindings/overrides.ts";
import { glyphs as realGlyphs, matchesEvent as realMatchesEvent } from "../../src/keybindings/shortcut.ts";

const dependencies = createRequire(import.meta.url);
const React = dependencies("react");
const { act, create } = dependencies("react-test-renderer");
const ts: typeof import("typescript") = dependencies("typescript");
const root = resolve(import.meta.dirname, "../..");
type Host = { props: Record<string, unknown> };

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

async function fixture({ agent = "reason", page = false, path = "/synthetic/project", repos = true, setup = false, setupFails = false, section = false, writeFails = false, copyFails = false, holdCopy = false, holdWrite = false, missingCopy = false, copyThrows = false, overrides = {} } = {}) {
  const keys = new Map<string, (() => unknown) | undefined>();
  let editorFocused = false;
  let newlines = 0;
  const events: string[] = [];
  const warnings: string[] = [];
  const actions: { type: string; workspace?: { id: string }; sectionId?: string }[] = [];
  const pending = new Set<string>();
  const staged = new Map<string, number[]>();
  const copied = new Map<string, number[]>();
  const queued: { kind: string; text: string; attachments?: { name: string; text: string }[] }[] = [];
  const copyGate = deferred<void>();
  const writeGate = deferred<void>();
  const creation = deferred<{ workspace: { id: string; directoryName: string; branchName: string; path: string } }>();
  const registration = deferred<{ id: string; root: string; defaultBranch: string }>();
  const modules = new Map<string, Record<string, unknown>>();
  let submitting = false;
  let requests = 0;
  let closes = 0;
  let setScreen: (value: string) => void = () => {};
  let renderer: ReturnType<typeof create>;
  const passthrough = ({ children }: { children: unknown }) => children;
  function load(file: string): Record<string, unknown> {
    const cached = modules.get(file);
    if (cached) return cached;
    const exports = {};
    modules.set(file, exports);
    const sourceRoot = file === "src/components/CreateWorkspaceDialog.tsx" || file === "src/components/CreateWorkspaceComposer.tsx"
      ? process.env.OC_LAUNCH_CLOSE_SOURCE_ROOT ?? root : root;
    const source = readFileSync(resolve(sourceRoot, file), "utf8");
    runInNewContext(ts.transpileModule(source, {
      fileName: file,
      compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
    }).outputText, {
      exports, console, TextDecoder, TextEncoder, Uint8Array, crypto: { randomUUID: () => "pending-launch" },
      document: { activeElement: null }, HTMLElement: class {},
      require(name: string) {
        if (name === "react" || name === "react/jsx-runtime") return dependencies(name);
        if (name === "./CreateWorkspaceComposer") return load("src/components/CreateWorkspaceComposer.tsx");
        if (name === "./CreateWorkspaceDialog") return load("src/components/CreateWorkspaceDialog.tsx");
        if (name === "../workspace/createFlow") return load("src/workspace/createFlow.ts");
        if (name === "../workspace/createInSection") return load("src/workspace/createInSection.ts");
        if (name === "./naming.ts" || name === "../workspace/naming") return load("src/workspace/naming.ts");
        if (name === "@base-ui/react/dialog") return { Dialog: { Root: passthrough, Portal: passthrough, Popup: ({ children }: { children: unknown }) => React.createElement("section", { role: "dialog" }, children) } };
        if (name === "./motion/dialogMotion") return { useDialogMotion: () => React.useRef(null) };
        if (name === "./motion/usePresence") return { usePresence: () => ({ mounted: true, attrs: {} }) };
        if (name === "./ui/Tooltip") return { Tooltip: ({ children }: { children: unknown }) => children };
        if (name === "../features/chat/ComposerAttachmentChip") return { ComposerAttachmentChip: () => null };
        if (name === "../features/chat/composerAttachments") return load("src/features/chat/composerAttachments.ts");
        if (name === "../draft-attachments/staging.ts") return load("src/features/draft-attachments/staging.ts");
        if (name === "../features/draft-attachments/api.ts") return { draftAttachmentsApi: {
          async write({ draftWorkspaceId, relativePath, data }: { draftWorkspaceId: string; relativePath: string; data: Uint8Array }) {
            events.push("stage");
            if (holdWrite) await writeGate.promise;
            if (writeFails) throw new Error("Fixture staging failed");
            staged.set(`${draftWorkspaceId}/${relativePath}`, Array.from(data));
          },
          async materialize({ localWorkspaceId, workspacePath }: { localWorkspaceId: string; workspacePath: string }) {
            events.push("copy-start");
            if (holdCopy) await copyGate.promise;
            if (copyThrows) throw new Error("Fixture IPC copy refused");
            if (missingCopy) return { attachments: [], stagingRemoved: false };
            const attachments = Array.from(staged).filter(([key]) => key.startsWith(`${localWorkspaceId}/`)).map(([key, bytes]) => {
              const relativePath = key.slice(localWorkspaceId.length + 1);
              if (!copyFails) copied.set(`${workspacePath}/${relativePath}`, bytes);
              return { relativePath, error: copyFails ? "Fixture copy failed" : null };
            });
            if (!copyFails) staged.clear();
            events.push("copy-end");
            return { attachments, stagingRemoved: !copyFails };
          },
          async remove({ localWorkspaceId, relativePath }: { localWorkspaceId: string; relativePath: string }) {
            return staged.delete(`${localWorkspaceId}/${relativePath}`);
          },
        } };
        if (name === "../features/diff/ReviewButton") return { queuePending: (_id: string, message: typeof queued[number]) => { queued.push(message); events.push("queue"); } };
        if (name === "../features/chat/composerIcons") return { PaperclipIcon: () => null, PlusIcon: () => null };
        if (name === "../features/chat/composer.css") return {};
        if (name === "@tauri-apps/api/core") return { invoke: async () => {} };
        if (name === "../workspace/api") return {
          ensureRepository() {
            if (submitting) { events.push("register"); return registration.promise; }
            return Promise.resolve({ id: "repo", root: path, defaultBranch: "main" });
          },
          listBranches: async () => [{ name: "main", remote: null, commit: "", isHead: true, committedAt: 0 }],
          createWorkspace() { requests++; events.push("create"); return creation.promise; },
          errorText: (error: Error) => error.message,
        };
        if (name === "../workspace/pendingLaunches") return {
          addPendingLaunch(id: string) { pending.add(id); events.push("pending"); },
          removePendingLaunch(id: string) { pending.delete(id); events.push("remove-pending"); },
        };
        if (name === "../scripts/api") return {
          scriptsConfig: async () => ({ setup: setup ? "echo setup" : null }),
          async startSetup() { events.push("setup"); if (setupFails) throw new Error("Setup failed"); return true; },
        };
        if (name === "../scripts/model") return { workspaceRef: () => ({ repositoryId: "repo", workspaceId: "created", path: "/synthetic/created" }) };
        if (name === "../workspace/setupWatch") return { watchSetup: () => events.push("watch"), unwatchSetup: () => events.push("unwatch") };
        if (name === "./WorkspaceView") return { seedTranscript: () => events.push("seed") };
        if (name === "../features/chat/reasonChat") return { configureReason: () => events.push("configure") };
        if (name === "../features/chat/chatModel") return { sessionConfig: () => ({}) };
        if (name === "../workspace/firstMessage") return { renameAfterFirstMessage: () => events.push("rename") };
        if (name === "../features/chat/chatModelChoice") return { saveModelChoice: () => events.push("model") };
        if (name === "../features/chat/agentChoice") return { saveAgent: () => events.push("agent") };
        if (name === "../workspace/launchModel") return { launchDefaults: () => ({ agent, model: "fixture", effort: "" }), loadoutPicks: () => [] };
        if (name === "../settings/agents/useLoadout") return { useLoadout: () => null };
        if (name === "../features/chat/loadoutChoices") return { loadoutChoices: () => [] };
        if (name === "../features/chat/ModelPicker") return { ModelPicker: () => null };
        if (name === "../features/chat/ChatModelPicker") return {};
        if (name === "../settings/models") return { modelLabel: (value: string) => value };
        if (name === "./create/RepoSelect") return { RepoSelect: () => null };
        if (name === "./create/TargetBranchButton") return { TargetBranchButton: ({ onChange }: { onChange: (value: string) => void }) => React.createElement("input", { "aria-label": "Target branch", onChange }) };
        if (name === "./CreateFromPicker") return { CreateFromPicker: () => null };
        if (name === "../keybindings/KeybindingsProvider") return { useKeybindingOverrides: () => ({ overrides }), useKeybindings: (handlers: Record<string, (() => unknown) | undefined>) => { for (const [id, handler] of Object.entries(handlers)) keys.set(id, handler); } };
        if (name === "../keybindings/overrides") return { effectiveShortcuts: realEffectiveShortcuts };
        if (name === "../keybindings/shortcut") return { glyphs: realGlyphs, matchesEvent: realMatchesEvent };
        if (name.endsWith("/ComposerEditor.tsx") || name.endsWith("/ComposerEditor")) {
          return {
            ComposerEditor({ inputRef, value, onChange, onKeyDown }: Record<string, ((...a: unknown[]) => unknown) & string>) {
              React.useLayoutEffect(() => {
                const handle = {
                  focus: () => { editorFocused = true; }, blur: () => { editorFocused = false; }, visible: () => true,
                  focused: () => editorFocused, composing: () => false,
                  selection: () => ({ text: String(value), start: 0, end: 0 }),
                  replaceRange: () => false, insertFile: () => {}, deleteRange: () => false, newline: () => { newlines++; },
                };
                Object.assign(inputRef, { current: handle });
                return () => Object.assign(inputRef, { current: null });
              }, []);
              return React.createElement("textarea", {
                "aria-label": "First message",
                value,
                onChange: (e: { target: { value: string } }) => onChange(e.target.value),
                onKeyDown: (e: { nativeEvent: KeyboardEvent }) => onKeyDown(e.nativeEvent),
              });
            },
          };
        }
        throw new Error(`Unexpected launch-close dependency ${name}`);
      },
    });
    return exports;
  }
  const Component = load(page ? "src/components/CreateWorkspaceComposer.tsx" : "src/components/CreateWorkspaceDialog.tsx")[page ? "CreateWorkspaceComposer" : "CreateWorkspaceDialog"];
  assert.equal(typeof Component, "function");
  function Shell() {
    const [screen, update] = React.useState("create");
    setScreen = update;
    return screen === "create" ? React.createElement(Component, {
      repos: repos ? [{ id: "repo", name: "Project", path, defaultBranch: "main", workspaces: [] }] : [],
      initialRepoId: "repo", prefixSettings: { branch_prefix_type: "none" }, githubUsername: null,
      eyebrowVariant: "floating", sections: section ? [{ id: "section", name: "Work", workspaceIds: [] }] : [],
      initialSectionId: section ? "section" : undefined,
      onClose() { closes++; events.push("close"); update("home"); },
      dispatch(action: { type: string }) { actions.push(action); events.push(action.type); },
      onWarning(message: string) { warnings.push(message); },
      addActions: {},
    }) : React.createElement("output", { "data-screen": screen }, screen);
  }
  await act(async () => { renderer = create(React.createElement(Shell)); });
  function send(host: Host, event: string, value: unknown) {
    const handler = host.props[event];
    assert.equal(typeof handler, "function");
    if (typeof handler === "function") return handler(value);
  }
  return {
    events, warnings, actions, pending, staged, copied, queued, keys,
    get newlines() { return newlines; },
    async key(event: Partial<KeyboardEvent> = {}) {
      const result = { prevented: false, stopped: false };
      const nativeEvent = { key: "Enter", code: "Enter", metaKey: false, ctrlKey: true, altKey: false, shiftKey: true, isComposing: false, ...event,
        preventDefault() { result.prevented = true; }, stopPropagation() { result.stopped = true; } };
      await act(async () => { send(renderer.root.findByType("textarea"), "onKeyDown", { nativeEvent }); });
      return result;
    },
    focusEditor(focused: boolean) { editorFocused = focused; },
    async shortcut() {
      const handler = keys.get("chat.togglePlanMode");
      assert.equal(typeof handler, "function", "Create must register the displayed Plan mode command");
      let result: unknown;
      await act(async () => { result = handler?.(); });
      return result;
    },
    async finishCopy() { await act(async () => copyGate.resolve()); },
    async finishWrite() { await act(async () => writeGate.resolve()); },
    chips: () => renderer.root.findAll((node: { type: unknown }) => typeof node.type === "function" && node.type.name === "ComposerAttachmentChip"),
    async removeFirst() {
      await act(async () => {
        const chip = renderer.root.findAll((node: { type: unknown }) => typeof node.type === "function" && node.type.name === "ComposerAttachmentChip")[0];
        assert.ok(chip);
        chip.props.onRemove();
      });
    },
    get requests() { return requests; }, get closes() { return closes; },
    isOpen: () => renderer.root.findAllByType("form").length === 1,
    replacement: () => renderer.root.findAllByProps({ "data-screen": "replacement" }).length === 1,
    rendered: () => JSON.stringify(renderer.toJSON()),
    async submit() { submitting = true; await act(async () => { void send(renderer.root.findByType("form"), "onSubmit", { preventDefault() {} }); }); },
    async registered() { await act(async () => registration.resolve({ id: "repo", root: path, defaultBranch: "main" })); },
    async succeed() { await act(async () => creation.resolve({ workspace: { id: "created", directoryName: "oslo", branchName: "oslo", path: "/synthetic/created" } })); },
    async fail() { await act(async () => creation.reject(new Error("Fixture creation failed"))); },
    replace() { act(() => setScreen("replacement")); },
    invalid() { act(() => send(renderer.root.findByProps({ "aria-label": "Target branch" }), "onChange", "bad..branch")); },
    message() { act(() => send(renderer.root.findByType("textarea"), "onChange", { target: { value: "First request" } })); },
    async pasteFiles(files: Pick<File, "name" | "size" | "arrayBuffer">[]) {
      let handled = false;
      await act(async () => {
        const editor = renderer.root.find((node: { type: unknown }) => typeof node.type === "function" && node.type.name === "ComposerEditor");
        handled = editor.props.onPasteFiles(files as unknown as FileList);
      });
      return handled;
    },
    dispose() { act(() => renderer.unmount()); },
  };
}


const chord = [{ key: { kind: "logical" as const, value: "Enter" }, modifiers: ["ctrl" as const, "shift" as const] }];
for (const page of [false, true]) {
  test(`configured newline invokes the actual Create editor handle exactly once (page=${page})`, async () => {
    const view = await fixture({ page, overrides: { "chat.newLine": chord } });
    try {
      view.message();
      assert.deepEqual(await view.key(), { prevented: true, stopped: false });
      assert.equal(view.newlines, 1);
      assert.equal(view.requests, 0); assert.equal(view.closes, 0);
      assert.deepEqual(view.events, []); assert.equal(view.queued.length, 0);
    } finally { view.dispose(); }
  });
  for (const command of ["chat.submitMessage", "chat.submitOppositeFollowUp", "workspace.addToBacklogFromComposer"]) {
    test(`configured ${command} wins a newline collision (page=${page})`, async () => {
      const view = await fixture({ page, overrides: { "chat.newLine": chord, [command]: chord } });
      try {
        view.message();
        const result = await view.key();
        assert.equal(result.prevented, true);
        assert.equal(result.stopped, command === "workspace.addToBacklogFromComposer");
        assert.equal(view.newlines, 0); assert.equal(view.requests, 1);
      } finally { view.dispose(); }
    });
  }
  test(`composition and unrelated chords remain unhandled (page=${page})`, async () => {
    const view = await fixture({ page, overrides: { "chat.newLine": chord } });
    try {
      view.message();
      assert.deepEqual(await view.key({ isComposing: true }), { prevented: false, stopped: false });
      assert.deepEqual(await view.key({ key: "j", code: "KeyJ" }), { prevented: false, stopped: false });
      assert.equal(view.newlines, 0); assert.equal(view.requests, 0);
      assert.deepEqual(view.events, []);
    } finally { view.dispose(); }
  });
}
