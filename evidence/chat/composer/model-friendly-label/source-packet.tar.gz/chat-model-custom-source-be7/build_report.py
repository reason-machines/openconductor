from pathlib import Path
import hashlib
import html
import json

root = Path(__file__).resolve().parent
s = json.loads((root / 'source.json').read_text())
d = json.loads((root / 'fixture-design.json').read_text())
main = s['main']
esc = html.escape
base = 'https://github.com/reason-machines/openconductor/blob/' + main + '/'

def link(path, label):
    return '<a href="'+base+esc(path)+'">'+esc(label)+'</a>'

cases = ''.join('<li><p><code>'+esc(c['id'])+'</code></p><p>'+esc(c['source_basis'])+'</p><p class="muted">'+esc(c['predicted_baseline'])+'</p></li>' for c in d['cases'])
ranges = ''.join('<li><code>'+esc(p['label'])+'</code> · '+esc(p['asset'])+' · bytes '+str(p['utf8_half_open'][0])+':'+str(p['utf8_half_open'][1])+'<br><small>'+esc(p['sha256'])+'</small></li>' for p in s['spans'])
key_spans = ['ITo complete composer caller','ugo','RNi','qZe','model labels and selected-option inclusion','model validity and chat model normalization']
excerpts = ''
for label in key_spans:
    entry = next(p for p in s['spans'] if p['label'] == label)
    raw = (root / entry['file']).read_text()
    excerpts += '<details><summary>'+esc(label)+' · exact retained source</summary><p class="muted">'+esc(entry['boundary'])+'</p><pre>'+esc(raw)+'</pre></details>'
page = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Local model labels</title><style>
body{margin:0;color:var(--foreground);font:14px/20px var(--font-sans,system-ui)}
h1{font-size:22px;line-height:28px;font-weight:500;margin:0 0 12px}h2{font-size:17px;line-height:24px;font-weight:500;margin:24px 0 12px}h3{font-size:14px;line-height:20px;font-weight:500}p{margin:8px 0 12px}.muted,small{color:var(--muted-foreground)}small{font-size:12px;overflow-wrap:anywhere}code,pre{font-family:var(--font-mono,monospace)}code{font-size:12px;overflow-wrap:anywhere}pre{font-size:12px;line-height:18px;white-space:pre-wrap;overflow-wrap:anywhere;padding:12px;background:var(--code-background,var(--muted));border-radius:8px}a{color:var(--accent);text-decoration:underline}table{border-collapse:collapse;width:100%;margin:12px 0}th,td{text-align:left;vertical-align:top;padding:10px 8px;border-bottom:1px solid var(--border)}th{font-weight:500}td:first-child{padding-left:0}ul,ol{padding-left:20px}li{margin:8px 0 12px}.case{padding:12px;border:1px solid var(--border);border-radius:8px;margin:16px 0}details{border-top:1px solid var(--border);padding:12px 0}summary{cursor:pointer}section{margin-top:24px}.tag{font-size:12px;line-height:18px;letter-spacing:.03em;color:var(--muted-foreground);margin-bottom:8px}
</style></head><body>
<div class="tag">SOURCE REVIEW · CONDUCTOR REBUILD · MAIN '''+esc(main[:8])+'''</div>
<h1>The current model stays listed; one local Claude label differs.</h1>
<p>Both sources retain a supported local model omitted from the offered catalog. The narrow lead is its friendly label, not a missing option or an arbitrary custom-ID rule.</p>
<div class="case"><p>Same accepted input. Local Claude, stored model <code>opus-4-8</code>, effort <code>high</code>, absent offered model entry.</p>
<table><thead><tr><th>Retained Conductor source</th><th>OpenConductor source</th></tr></thead><tbody><tr><td>Current option stays included.<br>Label is <strong>Opus 4.8</strong>.</td><td>Current option stays included.<br>Supplied formatter returns <code>opus-4-8</code>.</td></tr></tbody></table>
<p class="muted">Static source counterexample only. No JavaScript, mounted DOM, or native check ran.</p></div>
<h2>Why the labels separate</h2>
<ol><li>The original composer <code>ITo</code> reads the session, validates its model through <code>rwr=fNe</code>, and passes <code>ugo</code>'s configuration into <code>RNi</code>. This trace covers its explicit local branch.</li>
<li><code>qZe</code> uses <code>tSt</code> and <code>K6t=Pqt</code> to append the selected supported model when the current catalog omits it. The trigger and selected non-loadout row use <code>x9=lv</code>, whose label for this ID is <code>Opus 4.8</code>.</li>
<li>Current '''+link('src/features/chat/ChatModelPicker.tsx','ChatModelPicker')+''' preserves the explicit local choice but passes <code>reasonModelName</code> for every agent. '''+link('src/features/chat/ModelPicker.tsx','ModelPicker')+''' gives that supplied formatter precedence over <code>modelDisplayName</code>.</li>
<li>For this local Claude ID without a matching offered entry, '''+link('src/features/chat/reasonModels.ts','reasonModelName')+''' returns the raw ID. The existing '''+link('src/features/chat/composerModels.ts','display table')+''' already has the correct friendly label, but that fallback is not reached.</li></ol>
<h2>What this does not establish</h2>
<ul><li>No option-inclusion defect was found for the supported-model input domain.</li><li>Arbitrary unknown IDs are different inputs. Original <code>fNe</code> substitutes its default before this picker. The packet does not justify changing OpenConductor's custom local-model extension.</li><li>Known Codex IDs use the existing <code>gpt-</code> friendly-label branch. No Codex label defect is asserted.</li><li>No Settings defaults, provider-switch gates, Plan behavior, Reason custom providers, WorkspaceView, recent-chat work, or frozen #847 change belongs to this lead.</li></ul>
<h2>Five mounted checks, designed but not run</h2><p>The existing composer publisher owns any future narrow label repair. The test must first fail on the actual baseline, then pass unchanged on the repair. No new runner or dispatch was started.</p><ol>'''+cases+'''</ol>
<h2>Verification</h2><ul>
<li>Passed. Both complete retained Conductor asset hashes and 28 exact source-range rebindings.</li>
<li>Passed. Ten source snapshots at current main <code>'''+esc(main)+'''</code> and the caller/import/export joins.</li>
<li>Passed. Assigned branch, frozen HEAD, tracked tree, and index stayed unchanged.</li>
<li>Not run. Original JavaScript, product JavaScript, mounted DOM, native app, provider operations, build, CI dispatch, or behavioral RED/GREEN.</li></ul>
<p class="muted">Earlier REA acquisition <code>'''+esc(s['rea_evidence_id'])+'''</code>, Conductor 0.87.6. The retained bytes were rehashed here; this was not a new acquisition from the installed app.</p>
<p>Build the Lever produced <code>verify_source.py</code>, a reusable source identity and join check. Its result is not a simulation of rendered behavior.</p>
<pre>python3 artifacts/chat-model-custom-source-be7/verify_source.py --original .rea-work/retained-reference --checkout .</pre>
<details><summary>Exact retained source boundaries and hashes</summary><ul>'''+ranges+'''</ul></details>
'''+excerpts+'''
<p class="muted">Minimal selected evidence only. The oversized whole-workspace checkpoint was not retried; this packet is not a backup or rewind point.</p>
</body></html>'''
(root / 'review.html').write_text(page)
manifest = []
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name not in ['manifest.json','verification.json','page-receipt.json','attachment-receipt.json']:
        raw = path.read_bytes()
        manifest.append({'path':path.relative_to(root).as_posix(), 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()})
(root / 'manifest.json').write_text(json.dumps({'scope':'Selected source evidence only; no product or runtime proof', 'main':main, 'files':manifest},indent=2)+'\n')
print(json.dumps({'page_bytes':len(page.encode()),'manifest_files':len(manifest),'status':'BUILT_NOT_RENDERED'}))
