from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

parser = argparse.ArgumentParser(description='Verify source bytes and static caller joins only. Never execute original or product JavaScript.')
parser.add_argument('--original', type=Path)
parser.add_argument('--checkout', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
source = json.loads((root / 'source.json').read_text())
manifest = json.loads((root / 'manifest.json').read_text())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

for entry in manifest['files']:
    raw = (root / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['path']
spans = {}
originals = {}
if args.original:
    for entry in source['assets']:
        raw = (args.original / entry['name']).read_bytes()
        assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['name']
        originals[entry['name']] = raw
for entry in source['spans']:
    raw = (root / entry['file']).read_bytes()
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['label']
    if args.original:
        lo, hi = entry['utf8_half_open']
        assert originals[entry['asset']][lo:hi] == raw, entry['label']
    spans[entry['label']] = raw.decode()
for entry in source['current']:
    raw = (root / entry['file']).read_bytes()
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['path']
    if args.checkout:
        current = subprocess.check_output(['git', '-C', str(args.checkout), 'show', source['main']+':'+entry['path']])
        assert current == raw, entry['path']
checks = [
    ('ITo complete composer caller', 'Ws=pl!==void 0?rwr(pl):void 0'),
    ('ITo complete composer caller', 'configuration:gr,isModelPickerBusy:Yr'),
    ('ITo complete composer caller', 'configuration:gr,currentAgentType:bt'),
    ('ITo complete composer caller', 'agentEnvironment:a===gn?"local":"cloud"'),
    ('ugo', 'fUt({model:a,thinkingLevel:r?.thinkingLevel,fastMode:r?.fastMode??!1})'),
    ('fUt', 'return eD({model:t,thinkingLevel:e,fastMode:n})'),
    ('model validity and chat model normalization', 'function fNe(t){const e=vZ(t);return e!==void 0?e:Qs(t)?t:fZ()}'),
    ('canonical aliases and model sets', 'case"opus":return"opus-4-8"'),
    ('default model binding', 'pZ="opus-5-1m";function fZ(){return pZ}'),
    ('RNi', 'const I=NH(e?.model)'),
    ('RNi', 'He=qZe({selectedModel:I,agentEnvironment:_'),
    ('RNi', 'de==="acp"&&i?NX({providerId:i,modelId:r,models:ae}):I?x9[I]:"Model"'),
    ('RNi', 'selectedModel:I,selectedAgentType:de'),
    ('tSt', 'return e===void 0||t.includes(e)?t:[...t,e]'),
    ('qZe', 'K6t({models:nAn,visibleModelIds:tSt(nAn,d),selectedModel:d})'),
    ('qZe', 'K6t({models:B,visibleModelIds:tSt(B,m),selectedModel:m})'),
    ('model labels and selected-option inclusion', 's!==void 0&&n.has(s)&&!r.includes(s)?[...r,s]:r'),
    ('model labels and selected-option inclusion', '"opus-4-8":"Opus 4.8"'),
    ('L7o', 'label:x9[Li]'),
    ('L7o', 'selectedNonLoadoutModel:_t'),
    ('E7o', 'x!==void 0&&p.jsx("div"'),
    ('E7o', 'label:x.label'),
    ('j7o', 'children:n'),
]
for label, snippet in checks:
    assert snippet in spans[label], (label, snippet)
imports = spans['complete index import bindings']
for local, exported, imported in [('TN','g','NH'),('fs','b','gu'),('lv','bo','x9'),('Yy','kC','tAn'),('Pqt','kD','K6t'),('Jf','kE','nAn'),('fNe','lj','rwr'),('uh','j5','eD'),('Qs','j6','tF'),('eg','e','bCt')]:
    assert re.search(r'(?:\{|,)'+re.escape(exported+' as '+imported)+r'(?=,|\})', imports), (exported, imported)
    assert spans[f'export {local} to renderer {imported}'] == f'{local} as {exported}'

def current(path):
    return (root / 'main' / path).read_text()

picker = current('src/features/chat/ChatModelPicker.tsx')
menu = current('src/features/chat/ModelPicker.tsx')
reason = current('src/features/chat/reasonModels.ts')
assert 'agent === "reason" ? { ...shownModel(running, picked, models), agent } : picked' in picker
assert 'modelName={(m) => reasonModelName(m, models)}' in picker
assert 'const local = reasonModel.agent === agent ? reasonModel : CLI_AGENTS[agent].entry;' in current('src/features/chat/chatAgentChoice.ts')
assert 'const listed = [...favorites, value, ...models];' in current('src/features/chat/loadoutChoices.ts')
assert 'modelChoiceChip(value, modelName?.(value.model))' in menu
assert 'itemLabel?.(f) ?? modelName?.(f.model) ?? modelDisplayName(f.model)' in menu
assert 'const claude = /^(?:byok:)?anthropic[:/]claude-(.+)$/.exec(model)' in reason
assert 'const id = model.split(/[:/]/).at(-1) ?? model;' in reason
assert 'return id.startsWith("gpt-") ? modelLabel(id) : id;' in reason
assert '"opus-4-8": "Opus 4.8"' in current('src/features/chat/composerModels.ts')
assert '"gpt-5.2-codex": "GPT-5.2 Codex"' in current('src/settings/models.ts')
assert 'c.agent === "claude" || c.agent === "codex" || c.agent === "reason"' in current('src/features/chat/chatModelChoice.ts')
design = json.loads((root / 'fixture-design.json').read_text())
assert design['status'] == 'DESIGN_ONLY_NOT_IMPLEMENTED_NOT_RUN'
assert len(design['cases']) == 5
assert 'not-original-parity' in design['cases'][3]['id']
assert source['bounded_counterexample']['saved_choice']['model'] == 'opus-4-8'
assert source['verification']['mounted_dom'] == 'NOT_RUN'
print(json.dumps({'status':'PASS_STATIC_ONLY', 'main':source['main'], 'manifest_files':len(manifest['files']), 'source_spans':len(spans), 'main_files':len(source['current']), 'source_range_rebinding':'PASS' if args.original else 'NOT_RUN', 'checkout_rebinding':'PASS' if args.checkout else 'NOT_RUN', 'fixture_cases_designed':len(design['cases']), 'javascript_and_dom':'NOT_RUN', 'native':'NOT_RUN'}, indent=2))
