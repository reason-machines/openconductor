# Local current-model labels

Conductor Rebuild reviewed the workspace chat picker against main `838ab2a1c76d11f8048a89c9d4c01ba822db2204`.

## Result

Option inclusion is not a discrepancy for supported local model IDs. Both implementations retain the current model when the offered catalog omits it.

One narrow source-only label lead remains. Given an explicit local Claude choice `{ agent: "claude", model: "opus-4-8", effort: "high" }` absent from offered model options, Conductor's complete caller retains the known ID and labels it `Opus 4.8`. OpenConductor retains the choice but supplies `reasonModelName` to the picker for every agent. That formatter returns `opus-4-8`, overriding the existing friendly display table.

This is a static source counterexample. No mounted failure, candidate repair, JavaScript execution, provider request, or native observation occurred.

Arbitrary unknown IDs are a different case. Conductor normalizes those before this picker. This packet does not establish a parity requirement to preserve arbitrary raw IDs or authorize a model/default/provider change.

## Evidence

`source.json` names both retained asset hashes, the earlier REA acquisition, 28 exact UTF-8 byte ranges, import/export joins, ten current source snapshots, and the complete local composer caller. `fixture-design.json` contains five mounted test designs, not executable tests. `review.html` is the human-readable report.

The existing composer owner `13576d11-76fb-4842-aa9b-c398f9ca26f3` owns any future bounded label repair. This packet reserves no product files for BE7 and does not change #847, E09 work, Settings defaults, Plan gates, provider switching, or Reason custom providers.

## Verify source identity only

Run these commands from the repository root with the retained asset directory present.

```bash
python3 artifacts/chat-model-custom-source-be7/verify_source.py --original .rea-work/retained-reference --checkout .
```

Without the originals or checkout, the script still checks the sealed packet's identities and static joins. Omitted external rebindings are reported as not run.

The verifier applies Build the Lever by checking exact source ranges and hashes with one reusable command. It does not simulate the JavaScript or claim rendered behavior.

This is a minimal selected source packet. The oversized whole-workspace checkpoint was not retried, and this packet is not a portable checkout or rewind point.
