from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent.parent / '.rea-work/retained-reference'
EXPECTED = {
    'renderApp-D_fmY7hW.js': '5199d392ef2dec92886393f181bc98531efc6251f75b9effecd9f60dc9515dde',
    'index-BGEQ8YjU.js': 'b5b01f33fbbef68adcdda0de828a7735aebbf7f05f66f37e25333f3e1ed7dbf3',
}
assets = {}
for name, sha in EXPECTED.items():
    raw = (REFERENCE / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == sha, name
    assets[name] = raw
main = subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '0a726488eb8ad2e4a7acafc090d1541e73289500'
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'])
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'])
spans = []

def keep(label, asset, start, end, boundary):
    raw = assets[asset]
    assert raw.count(start) == 1, (label, start)
    lo = raw.index(start)
    hi = raw.index(end, lo + len(start))
    target = f'spans/{len(spans)+1:02d}.txt'
    path = ROOT / target
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw[lo:hi])
    spans.append({'label': label, 'asset': asset, 'file': target, 'utf8_half_open': [lo, hi], 'bytes': hi-lo, 'sha256': hashlib.sha256(raw[lo:hi]).hexdigest(), 'boundary': boundary, 'next_boundary': end.decode()})

renderer = 'renderApp-D_fmY7hW.js'
index = 'index-BGEQ8YjU.js'
for name, end in [
    ('RNi', b'function B7o('),
    ('zHt', b'const Zoe='),
    ('L7o', b'function M7o('),
    ('E7o', b'const SRt='),
    ('j7o', b'function F7o('),
    ('qZe', b'function WSo('),
    ('tSt', b'function qZe('),
    ('ugo', b'const mUt='),
    ('fUt', b'function Wj('),
    ('B7o', b'function $7o('),
]:
    keep(name, renderer, ('function '+name+'(').encode(), end, 'Complete shipped function declaration to next top-level declaration.')
keep('ITo complete composer caller', renderer, b'const ATo=', b',RTo=[hNi,mNi];', 'Complete ITo memo initializer including the preceding ATo binding; excerpt of a const statement ending before its following RTo binding.')
keep('model catalogs', index, b'const Jf=[', b'function uh(', 'Complete shipped built-in catalog declarations.')
keep('configuration constructor uh', index, b'function uh(', b'function Iqt(', 'Complete shipped configuration constructor.')
keep('canonical aliases and model sets', index, b'function TN(', b'function A0(', 'Complete alias normalizer and catalog-set bindings.')
keep('model validity and chat model normalization', index, b'function Qs(', b'function xN(', 'Complete Qs/HE/eg/Zy/fs/vZ/fNe/Ra declarations.')
keep('model labels and selected-option inclusion', index, b'const lv={', b'const dNe=', 'Complete label table, provider labels and Pqt inclusion helper.')
keep('default model binding', index, b'pZ="opus-5-1m";', b'const lv=', 'Default binding excerpt plus complete fZ declaration, not a standalone const declaration.')

text = assets[renderer].decode()
imports = list(re.finditer(r'import\{([^}]+)\}from[\"\']([^\"\']+)[\"\'];?', text[:120000]))
imp = next(m for m in imports if m.group(2) == './index-BGEQ8YjU.js')
raw = imp.group().encode()
lo = len(text[:imp.start()].encode())
assert assets[renderer][lo:lo+len(raw)] == raw
path = ROOT / 'spans/18.txt'
path.write_bytes(raw)
spans.append({'label':'complete index import bindings', 'asset':renderer, 'file':'spans/18.txt', 'utf8_half_open':[lo,lo+len(raw)], 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(), 'boundary':'Complete import from index-BGEQ8YjU.js.'})
exports = assets[index]
for local, exported, imported in [('TN','g','NH'),('fs','b','gu'),('lv','bo','x9'),('Yy','kC','tAn'),('Pqt','kD','K6t'),('Jf','kE','nAn'),('fNe','lj','rwr'),('uh','j5','eD'),('Qs','j6','tF'),('eg','e','bCt')]:
    token = f'{local} as {exported}'.encode()
    matches = list(re.finditer(re.escape(token)+rb'(?=,|})', exports))
    assert len(matches) == 1, token
    lo = matches[0].start()
    target = f'spans/{len(spans)+1:02d}.txt'
    (ROOT / target).write_bytes(token)
    spans.append({'label':f'export {local} to renderer {imported}', 'asset':index, 'file':target, 'utf8_half_open':[lo,lo+len(token)], 'bytes':len(token), 'sha256':hashlib.sha256(token).hexdigest(), 'boundary':'Exact named export token; matching complete renderer import is retained separately.'})

files = [
    'src/features/chat/ChatModelPicker.tsx',
    'src/features/chat/ModelPicker.tsx',
    'src/features/chat/chatAgentChoice.ts',
    'src/features/chat/composerModels.ts',
    'src/features/chat/reasonModels.ts',
    'src/features/chat/loadoutChoices.ts',
    'src/features/chat/chatModelChoice.ts',
    'src/settings/models.ts',
    'src/features/chat/loadoutChoices.test.ts',
    'src/features/chat/chatAgentChoice.test.ts',
]
snapshots = []
for name in files:
    raw = subprocess.check_output(['git', 'show', main+':'+name])
    path = ROOT / 'main' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    snapshots.append({'path':name, 'file':'main/'+name, 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()})

source = {
    'author':'Conductor Rebuild',
    'question':'CHAT-MODEL-PICKER-CUSTOM-ID-VISIBILITY-BE7',
    'disposition':'SOURCE_QUALIFIED_LOCAL_CLAUDE_LABEL_LEAD_ONLY; INCLUSION_NON_DISCREPANCY_FOR_SUPPORTED_IDS',
    'main':main,
    'frozen_head':head,
    'tracked_tree_and_index_unchanged':True,
    'rea_evidence_id':'ev_410f83a50764142c952de5f040cde338700477289c1687932071bdc5427c84b2',
    'acquisition':'Conductor 0.87.6 retained extracted frontend assets from earlier REA acquisition. No new native acquisition or original JavaScript execution.',
    'assets':[{'name':name, 'bytes':len(raw), 'sha256':EXPECTED[name]} for name,raw in assets.items()],
    'spans':spans,
    'current':snapshots,
    'observations':[
        'Original ITo reads current session via B7o, applies rwr=fNe before ugo, then passes ugo configuration and currentAgentType to RNi. Its local branch is explicit in agentEnvironment.',
        'fNe accepts known built-in ids or valid qualified built-in ids, else returns fZ()=opus-5-1m. TN normalizes aliases, not arbitrary unknown IDs.',
        'RNi passes NH(configuration.model) to qZe and uses x9=lv for its local built-in trigger label. qZe passes tSt(catalog,selected) to K6t=Pqt, preserving selected supported IDs omitted from current catalog.',
        'L7o builds selected searchable rows from that retained list. A selected non-loadout row is forwarded to E7o. Both trigger and row consume x9=lv human labels.',
        'Current loadModelChoice accepts a saved explicit local agent/model choice. ChatModelPicker uses the picked choice unchanged when agent is not Reason, and pickerState keeps it when its agent matches.',
        'Current orderedModelChoices includes value unconditionally, so omission of the current local choice from the catalog does not remove it.',
        'Current ChatModelPicker passes reasonModelName for every agent. ModelPicker prioritizes it over modelDisplayName on both chip and row. For a local Claude id not in Reason options and without an anthropic prefix, reasonModelName returns the raw id.',
        'For the same supported local current id opus-4-8 absent from offered options, original source labels it Opus 4.8; current formatter overrides the already-correct modelDisplayName and returns opus-4-8. This is a static counterexample, not a mounted observation.',
        'Known Codex ids follow the gpt- modelLabel branch and retain their catalog label. Arbitrary unknown local ids reach a different original normalization domain; no original parity requirement to preserve their raw id was established.',
    ],
    'bounded_counterexample':{
        'agent':'claude',
        'saved_choice':{'agent':'claude','model':'opus-4-8','effort':'high'},
        'offered_models':[],
        'loadout':'May be empty; saved current choice remains explicit.',
        'original_source_label':'Opus 4.8',
        'current_source_derived_label':'opus-4-8',
        'current_option_inclusion':'Preserved, not a discrepancy.',
        'behavioral_red_green':'NOT_RUN',
    },
    'scope':'Read-only ChatModelPicker selected label/options and directly called formatters, original local Claude/Codex current-model caller. No Settings storage changes, provider-switch gates, Reason custom-provider behavior, WorkspaceView, overflow, closed-chat eligibility or frozen #847 edits.',
    'repair_boundary':'No implementation approved or produced in this packet. A future owner must reproduce a mounted label failure before any product repair, keep explicit agent/model/effort/fast identity and option inclusion, and preserve current extension behavior for arbitrary custom local IDs.',
    'verification':{'asset_hashes':'PASS','source_range_rebinding':'PASS','current_main_snapshots':'PASS','product_or_test_edits':'NONE','original_js':'NOT_RUN','mounted_dom':'NOT_RUN','native':'NOT_RUN','dispatch':'NOT_RUN'},
    'preservation':'Minimal selected source packet only. Not a whole-workspace backup or rewind point. Prior oversized checkpoint was not retried.',
}
(ROOT/'source.json').write_text(json.dumps(source,indent=2)+'\n')
print(json.dumps({'main':main,'spans':len(spans),'main_files':len(snapshots),'frozen_head':head,'status':'PASS_STATIC_SEAL_ONLY'}))
