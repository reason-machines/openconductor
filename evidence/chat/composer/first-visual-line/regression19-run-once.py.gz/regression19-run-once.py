import datetime,hashlib,json,os,re,resource,signal,subprocess,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=(ROOT/'preflight.json').read_bytes(); p=json.loads(raw)
route=json.loads((ROOT/'routing.json').read_bytes())
assert p['status']=='STATIC_PREFLIGHT_PASS_NODE_NOT_STARTED'
assert sha((ROOT/'routing.json').read_bytes())==p['routing_sha256']
assert p['routing_verbatim']==route['routing_verbatim']
assert p['command'][:5]==['env','-u','COMPOSER_QUEUE_FOCUS_SOURCE_REF','-u','COMPOSER_RESERVED_SPACE_SOURCE_REF']
assert p['command'][-6:]==['--max-old-space-size=384','--experimental-strip-types','--test','--test-concurrency=1','src/features/chat/composerQueueFocus.test.ts','src/features/chat/composerReservedSpace.test.ts']
assert p['candidate']==route['preparation_commit'] and p['selected_tests']==19
assert not (ROOT/'started.json').exists() and not (ROOT/'receipt.json').exists()
def pins():
 assert sha(Path(p['node_binary']['path']).read_bytes())==p['node_binary']['sha256']
 for n,h in p['physical_pins'].items(): assert sha((REPO/n).read_bytes())==h,'dependency drift: '+n
 for n,h in p['source_pins'].items(): assert sha((ROOT/n).read_bytes())==h,'source drift: '+n
 for n,h in p['packet_pins'].items(): assert sha((REPO/'.source-prep-13576/first-visual-line-setup-v2-3d53af5'/n).read_bytes())==h,'packet drift: '+n
 assert (ROOT/'preflight.json').read_bytes()==raw
 assert sha((ROOT/'routing.json').read_bytes())==p['routing_sha256']
def size(): return sum(f.stat().st_size for f in ROOT.parent.rglob('*') if f.is_file())
def members(group):
 out=[]
 for d in Path('/proc').iterdir():
  if not d.name.isdigit(): continue
  try:
   if os.getpgid(int(d.name))!=group: continue
   out.append({'pid':int(d.name),'name':(d/'comm').read_text().strip()})
  except (ProcessLookupError,FileNotFoundError,PermissionError): pass
 return out
pins()
assert subprocess.check_output(['git','-c','gc.auto=0','status','--porcelain','--untracked-files=no'],cwd=REPO,timeout=15)==b''
for name in ['home','tmp']: (ROOT/name).mkdir()
before=size(); limits=route['limits']; assert before<=limits['private_tree_bytes']
env={k:os.environ[k] for k in ['PATH','LANG','LC_ALL','TZ'] if k in os.environ}
env.update({'HOME':str(ROOT/'home'),'TMPDIR':str(ROOT/'tmp'),'XDG_CONFIG_HOME':str(ROOT/'home/.config'),'XDG_CACHE_HOME':str(ROOT/'home/.cache')})
r={'author':'Conductor Rebuild','unit':route['unit'],'computer':route['computer'],'executor':route['executor'],'original_baseline':p['original_baseline'],'fixture_sha256':p['fixture_sha256'],'manifest_sha256':p['manifest_sha256'],'preflight_sha256':sha(raw),'routing_sha256':p['routing_sha256'],'command':p['command'],'cwd':p['cwd'],'source_resolution':p['source_resolution'],'node_binary':p['node_binary'],'physical_pin_count':len(p['physical_pins']),'source_pins':p['source_pins'],'limits':limits,'environment':env,'source_ref_unset_by_command':True,'candidate':p['candidate'],'product_commit':p['product_commit'],'started_at':now(),'private_bytes_before':before,'peak_private_bytes_observed':before,'samples':[],'sampling_is_not_a_continuous_hard_bound':True,'disposition':'RUNNING','gaps':p['gaps'],'preflight_correction':p['preflight_correction'],'node_started':False}
r['routing_verbatim']=route['routing_verbatim']
def save(): (ROOT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
stop=threading.Event(); errors=[]; process=None
def monitor():
 while not stop.wait(0.25):
  b=size(); r['peak_private_bytes_observed']=max(b,r['peak_private_bytes_observed'])
  r['samples'].append({'seconds':round(time.monotonic()-start,3),'private_bytes':b,'processes':members(process.pid)})
  if b>limits['private_tree_bytes'] or b-before>limits['job_growth_bytes']:
   errors.append('private/growth sampled limit exceeded')
   try: os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError: pass
   return
def child_limits(): resource.setrlimit(resource.RLIMIT_FSIZE,(limits['logs_bytes'],limits['logs_bytes']))
def expired(signum,frame):
 try: os.killpg(process.pid,signal.SIGKILL)
 except ProcessLookupError: pass
 raise TimeoutError('outer 100-second bound')
start=time.monotonic()
try:
 with (ROOT/'started.json').open('x') as f: json.dump({'at':now(),'unit':route['unit'],'once_only':True},f)
 with (ROOT/'regression.tap').open('xb') as log:
  process=subprocess.Popen(p['command'],cwd=p['cwd'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=child_limits)
  r.update({'node_started':True,'process_group':process.pid}); save()
  thread=threading.Thread(target=monitor,daemon=True); thread.start()
  signal.signal(signal.SIGALRM,expired); signal.alarm(100)
  try:
   _,status,usage=os.wait4(process.pid,0); process.returncode=os.waitstatus_to_exitcode(status)
  finally:
   signal.alarm(0); stop.set(); thread.join(timeout=1)
   try: os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError: pass
   if process.returncode is None: process.wait(timeout=5)
 r.update({'exit_code':process.returncode,'terminal_at':now(),'wall_seconds':time.monotonic()-start,'peak_rss_kib':usage.ru_maxrss,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime})
 tapraw=(ROOT/'regression.tap').read_bytes(); tap=tapraw.decode()
 r.update({'tap_bytes':len(tapraw),'tap_sha256':sha(tapraw),'processes_after_terminal':members(process.pid)})
 r['process_group_released']=not r['processes_after_terminal']
 r['summary']={k:int(re.search(r'^# '+k+r' (\d+)$',tap,re.M).group(1)) for k in ['tests','pass','fail','cancelled','skipped','todo']}
 assert not errors and r['process_group_released'] and process.returncode==0,errors
 assert len(tapraw)<=limits['logs_bytes'] and r['wall_seconds']<100
 assert not re.search(r'(?:ERR_MODULE_NOT_FOUND|MODULE_NOT_FOUND|ERR_PACKAGE_PATH_NOT_EXPORTED|TypeError|SyntaxError|ReferenceError)',tap),'setup/import failure'
 summary=r['summary']; assert summary=={'tests':19,'pass':19,'fail':0,'cancelled':0,'skipped':0,'todo':0},summary
 passed=re.findall(r'^ok \d+ - (.*?)$',tap,re.M)
 assert len(passed)==len(set(passed))==19 and not any('# SKIP' in n for n in passed)
 assert len(passed)==19
 r['executed_test_names']=passed
 r['nonmatching_cases_representation']='No filter; all19 cases executed' 
 pins()
 assert subprocess.check_output(['git','-c','gc.auto=0','status','--porcelain','--untracked-files=no'],cwd=REPO,timeout=15)==b''
 r['source_dependency_and_tracked_pins_unchanged']=True
 r['disposition']='QUALIFIED_CURRENT_MAIN_REGRESSION19_PASS'
except BaseException as e:
 r['disposition']='STOP_NO_RETRY'; r['failure']={'type':type(e).__name__,'message':str(e)}
finally:
 stop.set()
 if process is not None:
  try: os.killpg(process.pid,signal.SIGKILL)
  except ProcessLookupError: pass
  r['processes_at_release']=members(process.pid)
  r['process_group_released']=not r['processes_at_release']
 r['release_at']=now(); r['private_bytes_after']=size()
 r['peak_private_bytes_observed']=max(r['peak_private_bytes_observed'],r['private_bytes_after'])
 r['peak_added_bytes_observed']=r['peak_private_bytes_observed']-before
 if r['private_bytes_after']>limits['private_tree_bytes'] or r['peak_added_bytes_observed']>limits['job_growth_bytes']:
  r['disposition']='STOP_NO_RETRY_BUDGET'
 save()
 print(json.dumps(r,indent=2))
