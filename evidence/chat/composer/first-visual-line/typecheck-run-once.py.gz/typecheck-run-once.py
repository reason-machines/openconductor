import datetime, hashlib, json, os, resource, signal, subprocess, threading, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
raw = (ROOT / 'prepared.json').read_bytes()
assert sha(raw) == '21a78ab6281c026815bb2409adfd02df40a61ccc4f3d61972e01b1110b1da513'
p = json.loads(raw)
route = json.loads((ROOT / 'routing.json').read_bytes())
assert p['command'] == route['command']
assert not (ROOT / 'started.json').exists() and not (ROOT / 'receipt.json').exists()
limits = route['limits']

def pins():
    assert (ROOT / 'prepared.json').read_bytes() == raw
    assert sha(Path(p['node_binary']['path']).read_bytes()) == p['node_binary']['sha256']
    for n, h in p['physical_pins'].items():
        assert sha((REPO / n).read_bytes()) == h, 'runtime dependency drift: ' + n
    for n, h in p['additional_type_and_manifest_pins'].items():
        assert sha((REPO / n).read_bytes()) == h, 'type dependency drift: ' + n
    for n, h in p['full_source_pins'].items():
        assert sha((ROOT / n).read_bytes()) == h, 'program source drift: ' + n


def size():
    return sum(f.stat().st_size for f in ROOT.parent.rglob('*') if f.is_file())


def members(group):
    out = []
    for d in Path('/proc').iterdir():
        if not d.name.isdigit():
            continue
        try:
            if os.getpgid(int(d.name)) == group:
                out.append({'pid': int(d.name), 'name': (d / 'comm').read_text().strip()})
        except (ProcessLookupError, FileNotFoundError, PermissionError):
            pass
    return out

pins()
assert subprocess.check_output(['git', '-c', 'gc.auto=0', 'status', '--porcelain', '--untracked-files=no'], cwd=REPO) == b''
for d in Path('/proc').iterdir():
    if d.name.isdigit():
        try:
            assert (d / 'comm').read_text().strip() not in ['node', 'nodejs'], 'visible Node conflict'
        except (FileNotFoundError, PermissionError):
            pass
available = next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
assert available >= 1024 * 1024
for name in ['home', 'tmp']:
    (ROOT / name).mkdir()
env = {k: os.environ[k] for k in ['PATH', 'LANG', 'LC_ALL', 'TZ'] if k in os.environ}
env.update({'HOME': str(ROOT / 'home'), 'TMPDIR': str(ROOT / 'tmp'), 'XDG_CONFIG_HOME': str(ROOT / 'home/.config'), 'XDG_CACHE_HOME': str(ROOT / 'home/.cache')})
before = size()
assert before <= limits['private_tree_bytes']
r = {'author': 'Conductor Rebuild', 'unit': p['unit'], 'command': p['command'], 'cwd': p['cwd'], 'prepared_sha256': sha(raw), 'routing_verbatim': route['routing_verbatim'], 'routing_message': route['source_message'], 'environment': env, 'limits': limits, 'configured_program': 'Complete original tsconfig includes src and vite.config.ts; no emit, no incremental cache', 'program_files': len(p['full_source_pins']), 'runtime_physical_pins': len(p['physical_pins']), 'additional_type_and_manifest_pins': len(p['additional_type_and_manifest_pins']), 'memory_available_kib': available, 'cpu_pressure_before': Path('/proc/pressure/cpu').read_text(), 'private_bytes_before': before, 'peak_private_bytes_observed': before, 'samples': [], 'sampling_is_not_a_continuous_hard_bound': True, 'started_at': now(), 'disposition': 'RUNNING', 'gaps': ['No build/native/browser/realIPC/provider validation', 'Heap setting is not a universal RSS bound']}
stop = threading.Event()
errors = []
process = None

def save():
    (ROOT / 'receipt.json').write_text(json.dumps(r, indent=2) + '\n')


def monitor():
    while not stop.wait(0.25):
        b = size()
        r['peak_private_bytes_observed'] = max(b, r['peak_private_bytes_observed'])
        r['samples'].append({'seconds': round(time.monotonic() - start, 3), 'private_bytes': b, 'processes': members(process.pid)})
        if b > limits['private_tree_bytes'] or b - before > limits['job_growth_bytes']:
            errors.append('private/growth sampled limit exceeded')
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            return


def child_limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (limits['logs_bytes'], limits['logs_bytes']))


def expired(signum, frame):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    raise TimeoutError('outer 100-second bound')

start = time.monotonic()
try:
    with (ROOT / 'started.json').open('x') as f:
        json.dump({'at': now(), 'unit': p['unit'], 'once_only': True}, f)
    with (ROOT / 'typecheck.log').open('xb') as log:
        process = subprocess.Popen(p['command'], cwd=p['cwd'], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=child_limits)
        r['process_group'] = process.pid
        save()
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        signal.signal(signal.SIGALRM, expired)
        signal.alarm(100)
        try:
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
        finally:
            signal.alarm(0)
            stop.set()
            thread.join(timeout=1)
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if process.returncode is None:
                process.wait(timeout=5)
    output = (ROOT / 'typecheck.log').read_bytes()
    r.update({'exit_code': process.returncode, 'terminal_at': now(), 'wall_seconds': time.monotonic() - start, 'peak_rss_kib': usage.ru_maxrss, 'user_cpu_seconds': usage.ru_utime, 'system_cpu_seconds': usage.ru_stime, 'output_bytes': len(output), 'output_sha256': sha(output), 'processes_after_terminal': members(process.pid)})
    assert not errors and not r['processes_after_terminal'] and process.returncode == 0, errors
    assert len(output) <= limits['logs_bytes'] and r['wall_seconds'] < 100
    pins()
    assert subprocess.check_output(['git', '-c', 'gc.auto=0', 'status', '--porcelain', '--untracked-files=no'], cwd=REPO) == b''
    r['source_dependency_and_tracked_pins_unchanged'] = True
    r['disposition'] = 'QUALIFIED_CONFIGURED_TYPECHECK_PASS'
except BaseException as e:
    r['disposition'] = 'STOP_NO_RETRY'
    r['failure'] = {'type': type(e).__name__, 'message': str(e)}
finally:
    stop.set()
    if process is not None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        r['processes_at_release'] = members(process.pid)
        r['process_group_released'] = not r['processes_at_release']
    r['release_at'] = now()
    r['private_bytes_after'] = size()
    r['peak_private_bytes_observed'] = max(r['peak_private_bytes_observed'], r['private_bytes_after'])
    r['peak_added_bytes_observed'] = r['peak_private_bytes_observed'] - before
    if r['private_bytes_after'] > limits['private_tree_bytes'] or r['peak_added_bytes_observed'] > limits['job_growth_bytes']:
        r['disposition'] = 'STOP_NO_RETRY_BUDGET'
    save()
    print(json.dumps({k: r.get(k) for k in ['unit', 'disposition', 'exit_code', 'output_bytes', 'wall_seconds', 'peak_rss_kib', 'process_group_released', 'release_at', 'source_dependency_and_tracked_pins_unchanged', 'failure']}))
