"""Seal a source-identity candidate without executing application JavaScript."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
MAIN = '524c598b34157483e669167ed1f9032cc02fff18'
REFERENCE = Path('.rea-work/retained-reference')
EXPECTED = {
    'renderApp-D_fmY7hW.js': '5199d392ef2dec92886393f181bc98531efc6251f75b9effecd9f60dc9515dde',
    'index-BGEQ8YjU.js': 'b5b01f33fbbef68adcdda0de828a7735aebbf7f05f66f37e25333f3e1ed7dbf3',
}
SOURCES = [
    'src/components/WorkspaceView.tsx',
    'src/features/chat/ChatEmptyState.tsx',
    'src/features/chat/chatEmptyState.ts',
    'src/features/chat/fork.ts',
    'src/features/diff/chatAttachment.ts',
    'src/features/chat/composerSession.ts',
    'src/features/chat/composerAttachments.ts',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args])


assets = {}
for name, expected in EXPECTED.items():
    data = (REFERENCE / name).read_bytes()
    assert sha(data) == expected, name
    assets[name] = data
renderer = assets['renderApp-D_fmY7hW.js']
index = assets['index-BGEQ8YjU.js']
spans = []


def save_span(asset, name, start, stop):
    data = assets[asset]
    a = data.index(start)
    z = data.index(stop, a + len(start))
    selected = data[a:z]
    file = 'reference-' + name + '.txt'
    (HERE / file).write_bytes(selected)
    spans.append({'file': file, 'asset': asset, 'utf8_half_open': [a, z], 'bytes': len(selected), 'sha256': sha(selected), 'next_boundary': stop.decode()})
    return selected.decode()


original = {}
for name, stop in [('nPo', b'function iPo('), ('RIo', b'const dKn='), ('EIo', b'function '), ('uKn', b'const kIo=')]:
    original[name] = save_span('renderApp-D_fmY7hW.js', name, ('function ' + name + '(').encode(), stop)
for name in ['Wpe', 'Bf', 'gpe', 'k1t', 'svt', 'ple', 'au', 'A2', 'A1t', 'I1t', 'Xo', 'C_', 'LFt', 'h9t', 'G4e', 'j4e', 'dqe']:
    match = re.search(rb'(?:async )?function ' + re.escape(name.encode()) + rb'\(', index)
    assert match is not None, name
    following = re.search(rb'(?:async )?function [A-Za-z_$][\w$]*\(', index[match.end():])
    z = match.end() + following.start()
    data = index[match.start():z]
    file = 'reference-index-' + name + '.txt'
    (HERE / file).write_bytes(data)
    spans.append({'file': file, 'asset': 'index-BGEQ8YjU.js', 'utf8_half_open': [match.start(), z], 'bytes': len(data), 'sha256': sha(data), 'next_boundary': following.group().decode()})
    original[name] = data.decode()

import_end = renderer.index(b'from"./index-BGEQ8YjU.js";') + len(b'from"./index-BGEQ8YjU.js";')
import_start = renderer.rfind(b'import{', 0, import_end)
(HERE / 'reference-renderer-import.txt').write_bytes(renderer[import_start:import_end])
export_start = index.rfind(b'export{')
(HERE / 'reference-index-export.txt').write_bytes(index[export_start:])
import_text = renderer[import_start:import_end].decode()
export_text = index[export_start:].decode()
aliases = {'m0': ('h9t', '$ri'), 'm2': ('Wpe', 'Nwr'), 'm3': ('Xo', 'zri'), 'ft': ('A2', 'gSe'), 'al': ('Bf', 'FO'), 'k3': ('C_', 'uVe'), 'lV': ('LFt', 'JYe'), 'aB': ('kt', 'nc')}
for alias, (exported, imported) in aliases.items():
    assert alias + ' as ' + imported in import_text
    assert re.search(r'\b' + re.escape(exported) + ' as ' + re.escape(alias) + r'(?:,|})', export_text)

main = {}
source_receipts = []
for path in SOURCES:
    data = git('show', MAIN + ':' + path)
    (HERE / Path(path).name).write_bytes(data)
    main[Path(path).name] = data.decode()
    source_receipts.append({'path': path, 'snapshot': Path(path).name, 'bytes': len(data), 'sha256': sha(data)})

assert 'g=I=>`session-transcript-${I}.md`' in original['RIo']
assert 'FO(e,D,O,P)' in original['RIo'] and 'const D=g(I),P=m(I)' in original['RIo']
assert 'zri(o).find(O=>v(O)===R)' in original['RIo']
assert 'createTextAttachment({localWorkspaceId:t,fileName:e,content:s,displayName:n})' in original['Bf']
assert 'reserveAttachmentLocation({localWorkspaceId:s,originalName:n})' in original['k1t']
assert 'originalName:i??n,path:o.mentionPath' in original['k1t']
assert 'Qt.posix.join(".context","attachments",r,i)' in original['svt']
assert 'kt.drafts.addTo({sessionId:t,content:' in original['A1t']
assert 'kt.drafts,n' in original['LFt']
assert 'const e=await fe.getMessages(t);return Bpe(e.turns,"concise")' in original['Wpe']
assert 'onAttachTranscript={(c) =>' in main['WorkspaceView.tsx']
assert 'addAttachment(list, { name: forkAttachmentName(c.title), text })' in main['WorkspaceView.tsx']
assert 'x.commentId === undefined && x.name === a.name' in main['chatAttachment.ts']
assert 'const rest = list.filter((x) => !sameAttachment(x, a))' in main['chatAttachment.ts']
assert 'return `Transcript of ${title?.trim() || "chat"}.md`' in main['fork.ts']
assert 'const session = useMemo(() => composerSessionFor(chatId, composerDrafts()), [chatId])' in main['WorkspaceView.tsx']
assert git('rev-parse', 'HEAD').decode().strip() == '0a726488eb8ad2e4a7acafc090d1541e73289500'
assert subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--']).returncode == 0
assert subprocess.run(['git', 'diff', '--cached', '--quiet']).returncode == 0

acceptance = {
    'case_id': 'CHAT.RECENT-TRANSCRIPT-SOURCE-IDENTITY',
    'status': 'PREPARED_NOT_RUN',
    'source_chat_a': {'id': 'source-a', 'title': 'Investigation', 'user_message': 'TRANSCRIPT_A_ONLY'},
    'source_chat_b': {'id': 'source-b', 'title': 'Investigation', 'user_message': 'TRANSCRIPT_B_ONLY'},
    'targets': [{'id': 'target-empty', 'messages': [], 'draft': '', 'attachments': []}, {'id': 'control-empty', 'messages': [], 'draft': '', 'attachments': []}],
    'baseline': 'Mount the real WorkspaceView/ChatEmptyState producer at the pinned main with disposable agent snapshots/draft stores. Do not test a copied callback or a helper the real chip path does not call.',
    'actions': [
        'Show target-empty and select the source-a recent-chat chip. Observe one attachment whose content contains TRANSCRIPT_A_ONLY.',
        'Select source-b, which has the identical display title but different source ID. Observe the attachment list and both bodies.',
        'Switch to control-empty. It must have no attachment from target-empty. Switch back to target-empty and read both attachments again.',
    ],
    'regression_oracle': 'After the second distinct source selection target-empty retains two attachments, one containing only TRANSCRIPT_A_ONLY and one containing only TRANSCRIPT_B_ONLY. The labels may coincide, but storage identities must be distinct. The current source predicts only B survives. This is a source inference until the actual mounted path runs.',
    'controls': [
        'Distinct titles retain both transcripts.',
        'The two inputs have real nonempty transcripts, so the no-messages error must not be the reason a row is absent.',
        'Changing the title of one source must not conflate its source identity with another source.',
        'Control target remains isolated. No provider send, local CLI, attachment copy, native install or real user data is needed for this mounted producer regression.',
    ],
    'separate_unimplemented_parity': 'Original selected-chip click removes the source mention and EIo reflects selection. That behavior and overflow popover/focus are excluded from the narrow identity-loss repair unless separately reserved.',
    'runtime_route': 'Existing serialized owner via ledger ddfc; no executor, observer, fixture or dispatch was created by this packet.',
    'native_acceptance': 'NOT RUN. Native chip appearance, overflow focus, filesystem upload and genuine provider delivery require the existing authorized executor and are not established by mounted producer tests.',
}
(HERE / 'acceptance-case.json').write_text(json.dumps(acceptance, indent=2) + '\n')
receipt = {
    'author': 'Conductor Rebuild',
    'candidate': acceptance['case_id'],
    'disposition': 'SOURCE_COUNTEREXAMPLE_QUALIFIED_RUNTIME_REPRO_PENDING',
    'checked_main': MAIN,
    'frozen_branch_head': git('rev-parse', 'HEAD').decode().strip(),
    'rea_evidence_id': 'ev_410f83a50764142c952de5f040cde338700477289c1687932071bdc5427c84b2',
    'original_version': 'Conductor 0.87.6 retained extracted assets; not new native acquisition',
    'asset_identities': EXPECTED,
    'aliases': aliases,
    'original_spans': spans,
    'main_sources': source_receipts,
    'finding': 'Two valid recent source chats with identical titles reach addAttachment with the same name. Its ordinary-attachment replacement rule removes the first before appending the second. Original RIo uses the source session ID for its transcript filename and separate displayName. This is a concrete source-level identity collision, not executed behavior proof.',
    'smallest_repair': 'At the recent-chat producer only, construct a source-ID-backed attachment storage name with a separate existing ComposerAttachment.label. Main already defines and restores that label. A typed local attachment object can retain it through addAttachment without changing shared TextAttachment or global dedupe. Preserve source text and target session scoping. Do not change comment-ID rules, staged send/copy or provider delivery.',
    'ownership': 'Ledger reserved source acquisition. Shared producer overlap is being reconciled directly with 1f14fa82. Existing e09 isolated delivery path available after dedupe. #847 remains immutable. No product or fixture edits in this packet.',
    'checks_passed': ['Two retained original SHA256 identities', 'Import/export aliases bind the actual renderer callbacks to complete index helper/factory spans', 'Seven pinned-main source snapshots', 'Source-ID filename versus displayName separation in the original factory', 'Actual current chip callback joins title naming to name-based replacement', 'Frozen HEAD, tracked worktree and index unchanged'],
    'not_run': ['Application/reference JavaScript', 'Node/dependencies', 'Mounted baseline RED or candidate GREEN', 'Browser/native/CLI/provider', 'Build/package/install', 'Workflow dispatch/rerun'],
    'limits': ['Original factory/store bodies establish frontend contracts, not successful native file upload or provider consumption.', 'The code-derived input/output prediction is not an executable differential regression.', 'Drafts remain session keyed in current main. No cross-target loss is claimed without the prepared switch-case run.', 'No general selected-chip, overflow-popover, error, empty transcript, backend or composer parity closure is claimed.', 'The 34-part historical preservation manifest and four omissions are unchanged. This packet is not a new full backup.'],
}
(HERE / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
files = []
for path in sorted(HERE.iterdir()):
    if path.is_file() and path.name not in ('manifest.json', 'review.html'):
        data = path.read_bytes()
        files.append({'path': path.name, 'bytes': len(data), 'sha256': sha(data)})
(HERE / 'manifest.json').write_text(json.dumps({'checked_main': MAIN, 'files': files, 'originals_required': EXPECTED, 'originals_included': False}, indent=2) + '\n')
print(json.dumps({'candidate': receipt['candidate'], 'disposition': receipt['disposition'], 'main': MAIN, 'source_spans': len(spans), 'runtime': 'NOT RUN', 'tracked_tree': 'UNCHANGED'}, indent=2))
