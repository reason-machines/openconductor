import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tarfile
import time

RUN = Path('.ara-state/runtime/todoread-body22-20261113T0149')
ROOT = Path.cwd().resolve()
START = json.loads((RUN / 'START.json').read_text())
BEGIN = START['start_monotonic']
DEADLINE = BEGIN + 1200
TOKEN = 'ACC_D7_TODOREAD_BODY22_20261113T0149'
assert START['token'] == TOKEN
assert not (RUN / 'receipt.json').exists(), 'Do not overwrite a released allocation'
ARCHIVE = Path('/home/runner/.reason/workspace/sessions/d7b27c48-81c4-4bc8-9c2c-8eb81996b477/.ara-run-chat-attachments/session/todoread-result-consumer-source-UNAPPLIED-v1.tar.gz')
PREFIX = 'todoread-result-consumer-492bc5c7-be7/'
PRODUCT = Path('src/features/chat/ToolRows.tsx')
TEST = Path('src/features/chat/todoReadResult.test.ts')
INPUTS = Path('src/features/chat/todoReadResult.inputs.json')
ADJACENT = ['src/features/chat/todoMixedRows.test.ts', 'src/features/chat/toolErrorRetry.test.ts', 'src/features/chat/conductorTools.test.ts']
receipt = {'token': TOKEN, 'start': START, 'steps': [], 'state': 'RUNNING', 'runtime_groups': [], 'peak_observed_group_rss_kib': 0, 'rss_observation': 'Partial /proc snapshots at 0.1s. Descendant groups that exit between samples may be missed; not a full-memory proof.'}
applied = False
mounted = []
process = None
baseline_bytes = PRODUCT.read_bytes()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def event(kind, **values):
    with (RUN / 'events.jsonl').open('a') as output:
        output.write(json.dumps({'at': utc(), 'elapsed_seconds': time.monotonic() - BEGIN, 'kind': kind, **values}) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args])


def group_members(pgid):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            stat = (entry / 'stat').read_text()
            fields = stat[stat.rfind(')') + 2:].split()
            if int(fields[2]) != pgid:
                continue
            status = (entry / 'status').read_text()
            rss = re.search(r'^VmRSS:\s+(\d+) kB$', status, re.M)
            members.append({'pid': int(entry.name), 'state': fields[0], 'rss_kib': int(rss.group(1)) if rss else 0})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return members


def stop_group(child):
    if group_members(child.pid):
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        child.wait(timeout=3)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=2)
    leftovers = [p for p in group_members(child.pid) if p['state'] != 'Z']
    if leftovers:
        os.killpg(child.pid, signal.SIGKILL)
    return group_members(child.pid)


def run(name, command, cap, heap):
    global process
    assert time.monotonic() < DEADLINE - 60, 'Total allocation exhausted before stage'
    command = ['nice', '-n', '19', 'env', f'NODE_OPTIONS=--max-old-space-size={heap}', *command]
    start = time.monotonic()
    limit = min(start + cap - 5, DEADLINE - 65)
    record = {'name': name, 'command': command, 'cap_seconds': cap, 'started_at': utc(), 'peak_observed_group_rss_kib': 0}
    receipt['steps'].append(record)
    event('stage-start', **record)
    with (RUN / (name + '.stdout')).open('wb') as stdout, (RUN / (name + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True, env={**os.environ, 'npm_config_cache': str(ROOT / RUN / 'owned-npm-cache')})
        receipt['runtime_groups'].append(process.pid)
        try:
            while process.poll() is None:
                current_rss = sum(p['rss_kib'] for p in group_members(process.pid))
                record['peak_observed_group_rss_kib'] = max(record['peak_observed_group_rss_kib'], current_rss)
                if current_rss > 2048 * 1024:
                    raise RuntimeError(f'{name} observed process-group RSS exceeded 2048MiB target')
                if time.monotonic() >= limit:
                    raise TimeoutError(f'{name} finite time boundary exhausted')
                try:
                    process.wait(timeout=0.1)
                except subprocess.TimeoutExpired:
                    pass
            record['exit_code'] = process.wait()
        finally:
            record['remaining_after_reap'] = stop_group(process)
            record['elapsed_seconds'] = time.monotonic() - start
            record['finished_at'] = utc()
            receipt['peak_observed_group_rss_kib'] = max(receipt['peak_observed_group_rss_kib'], record['peak_observed_group_rss_kib'])
            event('stage-end', **record)
            process = None
        assert record['elapsed_seconds'] <= cap, f'{name} cap exceeded'
        assert not [p for p in record['remaining_after_reap'] if p['state'] != 'Z'], f'{name} owned runtime remains'
    return record


def tap(name, expected_total, expected_pass, expected_fail):
    output = (RUN / (name + '.stdout')).read_text()
    for label, expected in [('tests', expected_total), ('pass', expected_pass), ('fail', expected_fail), ('cancelled', 0), ('skipped', 0), ('todo', 0)]:
        found = re.findall(r'^# ' + label + r' (\d+)\s*$', output, re.M)
        assert found and int(found[-1]) == expected, f'{name} unexpected {label}: {found}'
    return output


try:
    event('source-boundary')
    report = json.loads(Path('.ara-state/todoread-sequence-current-main/current-main-source-report.json').read_text())
    source_end = datetime.datetime.fromisoformat(report['observed_at_utc'])
    source_start = datetime.datetime.fromisoformat(START['started_at_utc'])
    receipt['source_setup_seconds'] = (source_end - source_start).total_seconds()
    assert 0 <= receipt['source_setup_seconds'] <= 120
    assert report['current_main'] == git('rev-parse', 'origin/main').decode().strip()
    assert git('diff', 'origin/main', 'HEAD', '--') == b''
    for pin in report['current_source_pins']:
        assert sha(Path(pin['path']).read_bytes()) == pin['sha256'], pin['path']
    receipt['source_report_sha256'] = sha(Path('.ara-state/todoread-sequence-current-main/current-main-source-report.json').read_bytes())
    receipt['current_main'] = report['current_main']
    receipt['validation_checkout_head'] = git('rev-parse', 'HEAD').decode().strip()
    assert sha(ARCHIVE.read_bytes()) == '88ef09dbaa7a777ce605556b72b2738e56489e0a8d479e1da2730eb98bea04c9'
    with tarfile.open(ARCHIVE) as archive:
        original_test = archive.extractfile(PREFIX + 'todoReadResult.test.ts').read()
        original_input = archive.extractfile(PREFIX + 'todoReadResult.inputs.json').read()
        original_patch = archive.extractfile(PREFIX + 'todoread-result-selection-UNAPPLIED.patch').read()
        candidate = archive.extractfile(PREFIX + 'candidate/ToolRows.tsx').read()
    assert sha(baseline_bytes) == '9ac18f24a874cdfe917b84c4ee4d07cc384db659463c4b1997549bb786033c36'
    assert sha(original_test) == 'bc34a5eaeec73fc04db48aa2a4399905baca03912dd26583b86f4fbbfea3e4fd'
    assert sha(original_input) == '16a3503a1260bf448a01c790e44d7edcbe88a1b6ccf759aac4a3d51bbc16a41a'
    assert sha(original_patch) == '80a2c89f86c1bd55a06a4c09570737323d583f737f67b6a0af4c2efd5c0ca348'
    owned_deps = Path('node_modules')
    assert not owned_deps.is_symlink(), 'Borrowed dependency link refused'
    if not owned_deps.exists():
        install = run('install', ['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], 300, 1024)
        assert install['exit_code'] == 0, 'Locked owned dependency install failed'
    lock = json.loads(Path('package-lock.json').read_text())
    installed = {}
    for package in ['react', 'react-test-renderer', 'typescript']:
        manifest = Path('node_modules') / package / 'package.json'
        assert manifest.resolve().is_relative_to(ROOT), 'Dependency escaped owned checkout'
        data = json.loads(manifest.read_text())
        assert data['version'] == lock['packages']['node_modules/' + package]['version']
        installed[package] = {'version': data['version'], 'package_manifest_sha256': sha(manifest.read_bytes())}
    receipt['owned_dependencies'] = installed
    receipt['package_lock_sha256'] = sha(Path('package-lock.json').read_bytes())
    for path, data in [(TEST, original_test), (INPUTS, original_input)]:
        assert not path.exists(), f'Unexpected preexisting fixture {path}'
        path.write_bytes(data)
        mounted.append(path)
    args = ['node', '--experimental-strip-types', '--test', '--test-concurrency=1']
    red = run('baseline', args + [str(TEST)], 125, 1024)
    assert red['exit_code'] == 1, 'Baseline did not produce expected failed assertions'
    output = tap('baseline', 22, 4, 18)
    actual_failures = re.findall(r'^not ok \d+ - TodoRead result selection: (.+)$', output, re.M)
    controls = {'empty-array', 'todowrite-input-wins', 'todowrite-mixed-control', 'todowrite-empty-ignores-result'}
    expected_failures = {e['id'] for e in json.loads(original_input)['cases']} - controls
    assert set(actual_failures) == expected_failures and len(actual_failures) == 18
    assert len(re.findall(r"code: 'ERR_ASSERTION'", output)) == 18, 'Baseline contains non-assertion failures'
    assert set(re.findall(r"error: '([^']+)'", output)) <= {'a returned list must be expandable', 'TodoRead must not use stale input.todos', 'preserve the existing plain todo projection', 'the result-backed todo list has a reachable body'}
    receipt['baseline_qualification'] = {'state': 'EXPECTED_RED', 'intended_assertion_failures': actual_failures, 'passed_controls': sorted(controls), 'tests': 22, 'pass': 4, 'fail': 18}
    assert TEST.read_bytes() == original_test and INPUTS.read_bytes() == original_input
    patch_file = RUN / 'original-body22.patch'
    patch_file.write_bytes(original_patch)
    subprocess.run(['git', 'apply', '--check', str(patch_file)], check=True)
    subprocess.run(['git', 'apply', str(patch_file)], check=True)
    applied = True
    assert PRODUCT.read_bytes() == candidate
    green = run('green', args + [str(TEST)], 125, 1024)
    assert green['exit_code'] == 0
    tap('green', 22, 22, 0)
    assert TEST.read_bytes() == original_test and INPUTS.read_bytes() == original_input
    adjacent = run('adjacent', args + ADJACENT, 125, 1024)
    assert adjacent['exit_code'] == 0, 'Unchanged adjacent tests failed'
    adjacent_output = (RUN / 'adjacent.stdout').read_text()
    total = int(re.findall(r'^# tests (\d+)\s*$', adjacent_output, re.M)[-1])
    tap('adjacent', total, total, 0)
    receipt['adjacent_tests_passed'] = total
    typecheck = run('typecheck', ['npm', 'run', 'typecheck'], 245, 1536)
    assert typecheck['exit_code'] == 0, 'Actual-checkout typecheck failed; no narrowing or fixture removal allowed'
    assert TEST.read_bytes() == original_test and INPUTS.read_bytes() == original_input and PRODUCT.read_bytes() == candidate
    original_binding = json.loads(Path('.ara-state/todoread22-publisher/source-publication-binding.json').read_text())
    for pin in original_binding['protected_COPY26_and_four_label_files'] + original_binding['held_unpublished_not_dependencies']:
        assert sha(Path(pin['path']).read_bytes()) == pin['sha256'], f'Protected original changed: {pin["path"]}'
    assert git('diff', '--name-only', 'HEAD').decode().splitlines() == [str(PRODUCT)]
    receipt['state'] = 'PASS'
except BaseException as error:
    receipt['state'] = 'STOP'
    receipt['error_type'] = type(error).__name__
    receipt['error'] = str(error)
    event('stopped', error_type=type(error).__name__, error=str(error))
finally:
    cleanup_begin = time.monotonic()
    if process is not None:
        stop_group(process)
    if receipt['state'] != 'PASS':
        if applied:
            assert PRODUCT.read_bytes() == candidate, 'Refuse to overwrite an unexpected concurrent product edit'
            subprocess.run(['git', 'apply', '--reverse', str(RUN / 'original-body22.patch')], check=True)
            assert PRODUCT.read_bytes() == baseline_bytes
        for path in mounted:
            expected = original_test if path == TEST else original_input
            assert path.read_bytes() == expected, 'Refuse to remove unexpected fixture changes'
            path.unlink()
    receipt['cleanup_seconds'] = time.monotonic() - cleanup_begin
    receipt['remaining_owned_runtime'] = {str(group): group_members(group) for group in receipt['runtime_groups'] if group_members(group)}
    receipt['finished_at_utc'] = utc()
    receipt['elapsed_seconds'] = time.monotonic() - BEGIN
    receipt['total_cap_seconds'] = 1200
    receipt['cleanup_within_60s'] = receipt['cleanup_seconds'] <= 60
    receipt['total_within_cap'] = receipt['elapsed_seconds'] <= 1200
    receipt['tracked_changes'] = git('diff', '--name-only', 'HEAD').decode().splitlines()
    receipt['fixture_hashes_after'] = {str(path): sha(path.read_bytes()) for path in [TEST, INPUTS] if path.exists()}
    (RUN / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (RUN / 'EXPLICIT_RELEASE').write_text(receipt['finished_at_utc'] + '\n')
    event('released', state=receipt['state'], owned_runtime=receipt['remaining_owned_runtime'])
    print(json.dumps(receipt, indent=2))
    if receipt['state'] != 'PASS':
        raise SystemExit(1)
