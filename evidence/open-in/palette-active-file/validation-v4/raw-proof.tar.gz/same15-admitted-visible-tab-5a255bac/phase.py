import sys, json, subprocess, time, hashlib, datetime
from pathlib import Path
D=Path(__file__).resolve().parent
R=D/'receipt.json'
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(r): R.write_text(json.dumps(r,indent=2)+'\n')
if sys.argv[1]=='init':
    assert not R.exists()
    source=json.loads(Path('.oc-tmp/same15-lifecycle-support-v4/source-only-receipt.json').read_text())
    frozen=dict(source['historical_frozen_hashes'])
    for n,h in source['original_inputs_preserved'].items(): frozen['.oc-tmp/source-followthrough-6ab46a36/'+n]=h
    for n,h in [('support-only.diff',source['combined_support_diff_sha256']),('support-v3-to-v4.diff',source['v3_to_v4_delta_sha256']),('paletteOpenInLifecycle.test.ts.txt',source['corrected_lifecycle_sha256']),('stage-source-support.py',source['stager_sha256'])]: frozen['.oc-tmp/same15-lifecycle-support-v4/'+n]=h
    r={'owner':'Conductor Rebuild SAME15','admission':'ACC_SAME15_VISIBLE_TAB_LABEL_20261113T0038','message_id':'5a255bac-50f1-46f7-a14f-3d72f276a098','started_at':utc(),'start_monotonic':time.monotonic(),'inclusive_ceiling_seconds':934,'prior_consumed_seconds':165.753,'concurrency':1,'phases':[],'candidate_applied':False,'servers_started':[],'status':'RUNNING','frozen_before':frozen}
    save(r)
    assert all(sha(p)==h for p,h in frozen.items()),'frozen input changed'
    def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
    assert git('branch','--show-current')=='reason/openconductor-sol-open-i-15faf4d8'
    assert not git('status','--porcelain','--untracked-files=no')
    r['main']=git('rev-parse','origin/main');r['branch_head']=git('rev-parse','HEAD')
    subprocess.run(['git','diff','--quiet',r['main'],'--'],check=True)
    r['source_pins']=source['source_pins']
    assert all(sha(p)==h for p,h in r['source_pins'].items()),'source pin changed'
    r['package_lock_sha256']=sha('package-lock.json')
    assert r['package_lock_sha256']=='0714cb6ccdd0e8332f4ff08dc6b9ec0eb786e8f7b6b386663d31b9323579796a'
    root=Path.cwd().resolve();mods=Path('node_modules')
    assert mods.is_dir() and not mods.is_symlink() and mods.resolve()==root/'node_modules','own dependencies absent or borrowed'
    lock=json.loads(Path('package-lock.json').read_text())['packages'];installed=json.loads((mods/'.package-lock.json').read_text())['packages']
    pins={}
    for name in ['react','react-test-renderer','typescript','@pierre/diffs','@tauri-apps/api']:
        key='node_modules/'+name; p=mods/name
        assert not p.is_symlink() and p.resolve().is_relative_to(mods.resolve())
        actual=json.loads((p/'package.json').read_text())
        assert actual['version']==lock[key]['version']==installed[key]['version']
        assert installed[key]['integrity']==lock[key]['integrity']
        pins[name]={'version':actual['version'],'integrity_matches':True}
    r['dependency_pins']=pins;r['dependencies']='own-checkout unchanged own-lock; no install or substitution'
    r['guard_passed']=True;save(r);print(json.dumps({k:r[k] for k in ['started_at','main','branch_head','guard_passed','dependency_pins']}))
elif sys.argv[1]=='run':
    r=json.loads(R.read_text());name=sys.argv[2];ceiling=int(sys.argv[3]);argv=sys.argv[4:]
    assert r['status']=='RUNNING'
    elapsed=time.monotonic()-r['start_monotonic']
    assert elapsed+ceiling+60<934,'insufficient remaining budget including cleanup'
    event={'name':name,'argv':argv,'started_at':utc()};r['phases'].append(event);save(r)
    start=time.monotonic()
    with (D/(name+'.log')).open('wb') as log:
        proc=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=ceiling+1)
    event.update(exit_code=proc.returncode,elapsed_seconds=round(time.monotonic()-start,3),ended_at=utc())
    save(r);(D/'events.json').write_text(json.dumps(r['phases'],indent=2)+'\n')
    print(json.dumps(event));print((D/(name+'.log')).read_text()[-23000:])
    sys.exit(proc.returncode)
