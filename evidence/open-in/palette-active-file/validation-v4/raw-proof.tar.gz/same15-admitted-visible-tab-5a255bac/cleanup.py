import json,time,hashlib,subprocess,datetime,re
from pathlib import Path
D=Path(__file__).resolve().parent;R=D/'receipt.json';r=json.loads(R.read_text())
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cleanup={'started_at':utc(),'fixtures':[]}
tap=(D/'adjacent.log').read_text()
assert all(f'# {k} {v}\n' in tap for k,v in [('tests',113),('pass',113),('fail',0),('cancelled',0),('skipped',0),('todo',0)])
assert r['phases'][-1]['name']=='typecheck' and r['phases'][-1]['exit_code']==0
r['adjacent_result']={'collected':113,'pass':113,'fail':0,'cancelled':0,'skipped':0,'todo':0,'files':6}
r['typecheck_result']={'exit_code':0,'passed':True}
assert r['candidate_applied']
assert sha(D/'candidate-executed.diff')==r['executed_product_diff_sha256']
assert subprocess.check_output(['git','diff','--binary'])==(D/'candidate-executed.diff').read_bytes(),'product tree changed after execution'
subprocess.run(['git','apply','--reverse','--check','--','.oc-tmp/source-followthrough-6ab46a36/candidate.NEW-PROPOSED.diff'],check=True)
subprocess.run(['git','apply','--reverse','--','.oc-tmp/source-followthrough-6ab46a36/candidate.NEW-PROPOSED.diff'],check=True)
for p,h in r['executed_fixture_hashes'].items():
    f=Path(p);assert not f.is_symlink() and sha(f)==h
    retained=D/(f.name+'.executed-original.txt');assert not retained.exists();retained.write_bytes(f.read_bytes());f.unlink()
    cleanup['fixtures'].append({'path':p,'sha256':h,'retained':str(retained.relative_to(Path.cwd())),'removed_exact_owned':True})
subprocess.run(['git','diff','--quiet',r['main'],'--'],check=True)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no']).strip()
subprocess.run(['git','diff','--check'],check=True)
r['frozen_after']={p:sha(p) for p in r['frozen_before']};assert r['frozen_after']==r['frozen_before']
assert sha('package-lock.json')==r['package_lock_sha256']
cleanup.update(jobs=[],servers=[],ownruntime=[],tracked_tree_equals_main=True,tracked_clean=True,diff_check_passed=True,all_frozen_hashes_unchanged=True,product_patch_reversed=True,no_background_jobs_started=True,foreground_children_reaped=True,ended_at=utc())
r.update(cleanup=cleanup,status='PASS_RELEASED',released_at=utc(),elapsed_including_cleanup_seconds=round(time.monotonic()-r['start_monotonic'],3),runtime_admission_consumed=True,retry=False)
assert r['elapsed_including_cleanup_seconds']<934
r['coverage_limits']=['Mounted React harness and mocked external-launch adapter only; no actual native/editor launch.','No browser/server/native/provider/build/package run or visual screenshot.','React undefined-component warnings are unsuppressed in raw baseline/candidate TAP; no warning-cause claim.','Historical receipts and all original inputs preserved; v4 baseline independently rerun, no inherited baseline credit.']
R.write_text(json.dumps(r,indent=2)+'\n');(D/'events.json').write_text(json.dumps(r['phases'],indent=2)+'\n')
manifest={str(p.relative_to(D)):sha(p) for p in sorted(D.iterdir()) if p.is_file() and p.name!='MANIFEST.sha256.json'}
(D/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['status','started_at','released_at','elapsed_including_cleanup_seconds','baseline_qualification','candidate_result','adjacent_result','typecheck_result','cleanup']},indent=2))
