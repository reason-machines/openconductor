from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, sys, time

ROOT = Path.cwd()
OUT = ROOT / '.oc-tmp/ci1205-diff-owner-support'
manifest = json.loads((OUT / 'manifest.json').read_text())
source = ROOT / 'src/features/diff/viewed.test.ts'
original = source.read_bytes()
expected_failures = [
    'mounted DiffTab and actual owner wiring auto-close a populated-to-empty raw list without reopen history',
    'mounted DiffTab and actual owner wiring close an initially empty loaded list once',
    'mounted DiffTab never auto-closes loading, failed or filtered-nonempty raw lists',
    'automatic empty Diff close returns to the previously viewed review chat',
    'automatic empty Diff close falls back to the workspace chat if its previous review closed',
    'a stale automatic Diff close cannot steal an inactive tab or another workspace',
    'manual Diff close still records a reopenable Diff tab',
]
start = time.monotonic()
events, groups = [], []
passed = False

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def event(name, **data):
    row = dict(time=stamp(), elapsed_s=round(time.monotonic()-start, 6), name=name, **data)
    events.append(row)
    (OUT / 'events.json').write_text(json.dumps(events, indent=2)+'\n')
    print(json.dumps(row), flush=True)

def run(name, argv, limit):
    if time.monotonic()-start + limit + 60 > 650:
        raise RuntimeError('Insufficient remaining bound with cleanup reserve')
    event(name+'-start', argv=argv)
    with (OUT / (name+'.log')).open('wb') as output:
        proc = subprocess.Popen(argv, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        groups.append(proc.pid)
        try:
            code = proc.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
            event(name+'-timeout')
            raise RuntimeError(name+' exceeded phase ceiling')
    text = (OUT / (name+'.log')).read_text(errors='replace')
    event(name+'-end', code=code, raw_sha256=sha(OUT/(name+'.log')))
    return code, text

def tap(text):
    values = {}
    for key in ('tests','pass','fail','cancelled','skipped','todo'):
        found = re.findall(r'^# '+key+r' (\d+)$', text, re.M)
        if len(found) != 1:
            raise RuntimeError('Missing or ambiguous TAP total: '+key)
        values[key] = int(found[0])
    if any(values[k] != 0 for k in ('cancelled','skipped','todo')):
        raise RuntimeError('Incomplete test collection')
    names = re.findall(r'^(?:not )?ok \d+ - (.*)$', text, re.M)
    if len(names) != values['tests']:
        raise RuntimeError('Test count/name mismatch')
    return values, names

command = ['timeout','-k','5s','120s','nice','-n','19','env','NODE_OPTIONS=--max-old-space-size=1024','node','--experimental-strip-types','--test','--test-concurrency=1']
try:
    event('actual-start', token='ACC-MATCHED-REQUIRED', branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(), head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), main=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip())
    if subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=no'],text=True).strip():
        raise RuntimeError('Tracked tree not clean')
    for name, expected in manifest.items():
        path = OUT/'support.patch' if name == 'support.patch' else OUT/'viewed.test.ts' if name == 'corrected_viewed.test.ts' else ROOT/name
        if sha(path) != expected:
            raise RuntimeError('Source/dependency hash changed: '+name)
    code, text = run('baseline', command+['src/features/diff/viewed.test.ts'],125)
    totals, names = tap(text)
    failures = re.findall(r'^not ok \d+ - (.*)$',text,re.M)
    if code != 1 or failures != expected_failures or totals['fail'] != 7 or text.count("error: 'useEffect is not defined'") != 7:
        raise RuntimeError('Baseline differs from exact hosted failure')
    event('baseline-qualified', totals=totals, failures=failures)
    subprocess.run(['git','apply','--check',str(OUT/'support.patch')],check=True)
    subprocess.run(['git','apply',str(OUT/'support.patch')],check=True)
    if sha(source) != manifest['corrected_viewed.test.ts']:
        raise RuntimeError('Applied support hash mismatch')
    code, text = run('green',command+['src/features/diff/viewed.test.ts'],125)
    green, green_names = tap(text)
    if code != 0 or green['tests'] != totals['tests'] or green['fail'] or green['pass'] != green['tests'] or green_names != names:
        raise RuntimeError('Corrected Diff test failed or test names changed')
    event('diff-green-qualified', totals=green)
    code, text = run('frozen15',command+['src/palette/paletteOpenInTarget.test.ts','src/palette/paletteOpenInLifecycle.test.ts'],125)
    frozen, _ = tap(text)
    if code != 0 or frozen['tests'] != 15 or frozen['pass'] != 15 or frozen['fail']:
        raise RuntimeError('Frozen palette regression failed')
    event('frozen15-qualified', totals=frozen)
    argv = ['timeout','-k','5s','180s','nice','-n','19','env','NODE_OPTIONS=--max-old-space-size=1536','npm','run','typecheck']
    code, _ = run('typecheck',argv,185)
    if code != 0:
        raise RuntimeError('Typecheck failed')
    for name, expected in manifest.items():
        if name in ('src/features/diff/viewed.test.ts','support.patch','corrected_viewed.test.ts'):
            continue
        if sha(ROOT/name) != expected:
            raise RuntimeError('Frozen input changed after runtime: '+name)
    subprocess.run(['git','diff','--check'],check=True)
    passed = True
except Exception as exc:
    event('STOP', reason=str(exc))
finally:
    live = []
    for group in groups:
        try:
            os.killpg(group, 0)
        except ProcessLookupError:
            continue
        live.append(group)
        os.killpg(group, signal.SIGKILL)
    if not passed and sha(source) == manifest['corrected_viewed.test.ts']:
        source.write_bytes(original)
    hashes = {name:sha(ROOT/name) for name in manifest if name not in ('support.patch','corrected_viewed.test.ts')}
    event('actual-release', result='PASS' if passed else 'STOP', jobs=[], servers=[], ownruntime=[], killed_own_groups=live, hashes=hashes)
    receipt = dict(result='PASS' if passed else 'STOP',start=events[0]['time'],release=events[-1]['time'],elapsed_s=time.monotonic()-start,events=events)
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(0 if passed else 1)
