
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001f1af8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}>:
1001f1af8: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1001f1afc: a90167fa    	stp	x26, x25, [sp, #0x10]
1001f1b00: a9025ff8    	stp	x24, x23, [sp, #0x20]
1001f1b04: a90357f6    	stp	x22, x21, [sp, #0x30]
1001f1b08: a9044ff4    	stp	x20, x19, [sp, #0x40]
1001f1b0c: a9057bfd    	stp	x29, x30, [sp, #0x50]
1001f1b10: 910143fd    	add	x29, sp, #0x50
1001f1b14: d10e43ff    	sub	sp, sp, #0x390
1001f1b18: aa0103f6    	mov	x22, x1
1001f1b1c: aa0003f3    	mov	x19, x0
1001f1b20: 5282fe08    	mov	w8, #0x17f0             ; =6128
1001f1b24: 8b080008    	add	x8, x0, x8
1001f1b28: f9001fe8    	str	x8, [sp, #0x38]
1001f1b2c: 3964c108    	ldrb	w8, [x8, #0x930]
1001f1b30: 7100051f    	cmp	w8, #0x1
1001f1b34: 540001cc    	b.gt	0x1001f1b6c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x74>
1001f1b38: 3500afc8    	cbnz	w8, 0x1001f3130 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1638>
1001f1b3c: f9401ff4    	ldr	x20, [sp, #0x38]
1001f1b40: 9124c688    	add	x8, x20, #0x931
1001f1b44: 52802029    	mov	w9, #0x101              ; =257
1001f1b48: 79000109    	strh	w9, [x8]
1001f1b4c: 52800028    	mov	w8, #0x1                ; =1
1001f1b50: 3924ce88    	strb	w8, [x20, #0x933]
1001f1b54: 52822a08    	mov	w8, #0x1150             ; =4432
1001f1b58: 8b080260    	add	x0, x19, x8
1001f1b5c: 91062261    	add	x1, x19, #0x188
1001f1b60: 5281f902    	mov	w2, #0xfc8              ; =4040
1001f1b64: 94463d6b    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f1b68: 14000004    	b	0x1001f1b78 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x80>
1001f1b6c: 71000d1f    	cmp	w8, #0x3
1001f1b70: f9401ff4    	ldr	x20, [sp, #0x38]
1001f1b74: 5400ae41    	b.ne	0x1001f313c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1644>
1001f1b78: 9107a3fa    	add	x26, sp, #0x1e8
1001f1b7c: 52822a08    	mov	w8, #0x1150             ; =4432
1001f1b80: 8b080268    	add	x8, x19, x8
1001f1b84: f9001be8    	str	x8, [sp, #0x30]
1001f1b88: 39648288    	ldrb	w8, [x20, #0x920]
1001f1b8c: 7100051f    	cmp	w8, #0x1
1001f1b90: 54000fec    	b.gt	0x1001f1d8c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x294>
1001f1b94: 3500ada8    	cbnz	w8, 0x1001f3148 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1650>
1001f1b98: 90009894    	adrp	x20, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f1b9c: 9106be94    	add	x20, x20, #0x1af
1001f1ba0: 52826b08    	mov	w8, #0x1358             ; =4952
1001f1ba4: 52800429    	mov	w9, #0x21               ; =33
1001f1ba8: a90727f4    	stp	x20, x9, [sp, #0x70]
1001f1bac: 90009889    	adrp	x9, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f1bb0: 91074129    	add	x9, x9, #0x1d0
1001f1bb4: 8b080277    	add	x23, x19, x8
1001f1bb8: 52800048    	mov	w8, #0x2                ; =2
1001f1bbc: a90823e9    	stp	x9, x8, [sp, #0x80]
1001f1bc0: f9401be8    	ldr	x8, [sp, #0x30]
1001f1bc4: f9004be8    	str	x8, [sp, #0x90]
1001f1bc8: a909fff7    	stp	x23, xzr, [sp, #0x98]
1001f1bcc: 910903e8    	add	x8, sp, #0x240
1001f1bd0: 9101c3e0    	add	x0, sp, #0x70
1001f1bd4: 9415351c    	bl	0x10073f044 <<alloc::string::String as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001f1bd8: 394903fb    	ldrb	w27, [sp, #0x240]
1001f1bdc: 7103ff7f    	cmp	w27, #0xff
1001f1be0: 54002381    	b.ne	0x1001f2050 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x558>
1001f1be4: f94127f8    	ldr	x24, [sp, #0x248]
1001f1be8: f9412bf9    	ldr	x25, [sp, #0x250]
1001f1bec: f9412ff5    	ldr	x21, [sp, #0x258]
1001f1bf0: a909fff7    	stp	x23, xzr, [sp, #0x98]
1001f1bf4: 52800428    	mov	w8, #0x21               ; =33
1001f1bf8: f0009869    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001f1bfc: 911e9d29    	add	x9, x9, #0x7a7
1001f1c00: a90723f4    	stp	x20, x8, [sp, #0x70]
1001f1c04: 528000a8    	mov	w8, #0x5                ; =5
1001f1c08: a90823e9    	stp	x9, x8, [sp, #0x80]
1001f1c0c: f9401be8    	ldr	x8, [sp, #0x30]
1001f1c10: f9004be8    	str	x8, [sp, #0x90]
1001f1c14: 910903e8    	add	x8, sp, #0x240
1001f1c18: 9101c3e0    	add	x0, sp, #0x70
1001f1c1c: 9415350a    	bl	0x10073f044 <<alloc::string::String as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001f1c20: 394903fb    	ldrb	w27, [sp, #0x240]
1001f1c24: 7103ff7f    	cmp	w27, #0xff
1001f1c28: 54003201    	b.ne	0x1001f2268 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x770>
1001f1c2c: f94127fa    	ldr	x26, [sp, #0x248]
1001f1c30: f9412be8    	ldr	x8, [sp, #0x250]
1001f1c34: a90223f9    	stp	x25, x8, [sp, #0x20]
1001f1c38: f9412ffc    	ldr	x28, [sp, #0x258]
1001f1c3c: a909fff7    	stp	x23, xzr, [sp, #0x98]
1001f1c40: 52800428    	mov	w8, #0x21               ; =33
1001f1c44: f0009869    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001f1c48: 913fb529    	add	x9, x9, #0xfed
1001f1c4c: a90723f4    	stp	x20, x8, [sp, #0x70]
1001f1c50: 528000e8    	mov	w8, #0x7                ; =7
1001f1c54: a90823e9    	stp	x9, x8, [sp, #0x80]
1001f1c58: f9401be8    	ldr	x8, [sp, #0x30]
1001f1c5c: f9004be8    	str	x8, [sp, #0x90]
1001f1c60: 910903e8    	add	x8, sp, #0x240
1001f1c64: 9101c3e0    	add	x0, sp, #0x70
1001f1c68: 941534f7    	bl	0x10073f044 <<alloc::string::String as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001f1c6c: 394903fb    	ldrb	w27, [sp, #0x240]
1001f1c70: 7103ff7f    	cmp	w27, #0xff
1001f1c74: 54003f21    	b.ne	0x1001f2458 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x960>
1001f1c78: f94127e9    	ldr	x9, [sp, #0x248]
1001f1c7c: f9412be8    	ldr	x8, [sp, #0x250]
1001f1c80: a90127e8    	stp	x8, x9, [sp, #0x10]
1001f1c84: f9412fe8    	ldr	x8, [sp, #0x258]
1001f1c88: f90007e8    	str	x8, [sp, #0x8]
1001f1c8c: a909fff7    	stp	x23, xzr, [sp, #0x98]
1001f1c90: 52800428    	mov	w8, #0x21               ; =33
1001f1c94: f0009869    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001f1c98: 913fd129    	add	x9, x9, #0xff4
1001f1c9c: a90723f4    	stp	x20, x8, [sp, #0x70]
1001f1ca0: 528000a8    	mov	w8, #0x5                ; =5
1001f1ca4: a90823e9    	stp	x9, x8, [sp, #0x80]
1001f1ca8: f9401be8    	ldr	x8, [sp, #0x30]
1001f1cac: f9004be8    	str	x8, [sp, #0x90]
1001f1cb0: 910903e8    	add	x8, sp, #0x240
1001f1cb4: 9101c3e0    	add	x0, sp, #0x70
1001f1cb8: 941530f4    	bl	0x10073e088 <<core::option::Option<bool> as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001f1cbc: 394903fb    	ldrb	w27, [sp, #0x240]
1001f1cc0: 394907f9    	ldrb	w25, [sp, #0x241]
1001f1cc4: 7103ff7f    	cmp	w27, #0xff
1001f1cc8: 54005901    	b.ne	0x1001f27e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xcf0>
1001f1ccc: a909fff7    	stp	x23, xzr, [sp, #0x98]
1001f1cd0: 52800428    	mov	w8, #0x21               ; =33
1001f1cd4: f0009869    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001f1cd8: 913fe529    	add	x9, x9, #0xff9
1001f1cdc: a90723f4    	stp	x20, x8, [sp, #0x70]
1001f1ce0: 528001e8    	mov	w8, #0xf                ; =15
1001f1ce4: a90823e9    	stp	x9, x8, [sp, #0x80]
1001f1ce8: f9401be8    	ldr	x8, [sp, #0x30]
1001f1cec: f9004be8    	str	x8, [sp, #0x90]
1001f1cf0: 910903e8    	add	x8, sp, #0x240
1001f1cf4: 9101c3e0    	add	x0, sp, #0x70
1001f1cf8: 94152f24    	bl	0x10073d988 <<core::option::Option<alloc::string::String> as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001f1cfc: 394903fb    	ldrb	w27, [sp, #0x240]
1001f1d00: 7103ff7f    	cmp	w27, #0xff
1001f1d04: 54005701    	b.ne	0x1001f27e4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xcec>
1001f1d08: 9107a3e8    	add	x8, sp, #0x1e8
1001f1d0c: 3cc60100    	ldur	q0, [x8, #0x60]
1001f1d10: f9412fe8    	ldr	x8, [sp, #0x258]
1001f1d14: 52826e09    	mov	w9, #0x1370             ; =4976
1001f1d18: f909ba78    	str	x24, [x19, #0x1370]
1001f1d1c: a9422beb    	ldp	x11, x10, [sp, #0x20]
1001f1d20: f909be6b    	str	x11, [x19, #0x1378]
1001f1d24: f909c275    	str	x21, [x19, #0x1380]
1001f1d28: f909c67a    	str	x26, [x19, #0x1388]
1001f1d2c: 9107a3fa    	add	x26, sp, #0x1e8
1001f1d30: f909ca6a    	str	x10, [x19, #0x1390]
1001f1d34: f909ce7c    	str	x28, [x19, #0x1398]
1001f1d38: a9412fea    	ldp	x10, x11, [sp, #0x10]
1001f1d3c: f909d26b    	str	x11, [x19, #0x13a0]
1001f1d40: f909d66a    	str	x10, [x19, #0x13a8]
1001f1d44: f94007ea    	ldr	x10, [sp, #0x8]
1001f1d48: f909da6a    	str	x10, [x19, #0x13b0]
1001f1d4c: f9401ff4    	ldr	x20, [sp, #0x38]
1001f1d50: 39000299    	strb	w25, [x20]
1001f1d54: 5282770a    	mov	w10, #0x13b8            ; =5048
1001f1d58: 3caa6a60    	str	q0, [x19, x10]
1001f1d5c: f909e668    	str	x8, [x19, #0x13c8]
1001f1d60: 5282ff08    	mov	w8, #0x17f8             ; =6136
1001f1d64: 8b080275    	add	x21, x19, x8
1001f1d68: 3900069f    	strb	wzr, [x20, #0x1]
1001f1d6c: 8b090261    	add	x1, x19, x9
1001f1d70: aa1503e0    	mov	x0, x21
1001f1d74: 52809102    	mov	w2, #0x488              ; =1160
1001f1d78: 94463ce6    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f1d7c: 91246288    	add	x8, x20, #0x918
1001f1d80: f90017e8    	str	x8, [sp, #0x28]
1001f1d84: 3924629f    	strb	wzr, [x20, #0x918]
1001f1d88: 1400000c    	b	0x1001f1db8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x2c0>
1001f1d8c: 71000d1f    	cmp	w8, #0x3
1001f1d90: 54009e41    	b.ne	0x1001f3158 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1660>
1001f1d94: f9401fe8    	ldr	x8, [sp, #0x38]
1001f1d98: 91246109    	add	x9, x8, #0x918
1001f1d9c: f90017e9    	str	x9, [sp, #0x28]
1001f1da0: 39646108    	ldrb	w8, [x8, #0x918]
1001f1da4: 5282ff09    	mov	w9, #0x17f8             ; =6136
1001f1da8: 8b090275    	add	x21, x19, x9
1001f1dac: 7100051f    	cmp	w8, #0x1
1001f1db0: 5400010c    	b.gt	0x1001f1dd0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x2d8>
1001f1db4: 35009ea8    	cbnz	w8, 0x1001f3188 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1690>
1001f1db8: 52839008    	mov	w8, #0x1c80             ; =7296
1001f1dbc: 8b080260    	add	x0, x19, x8
1001f1dc0: aa1503e1    	mov	x1, x21
1001f1dc4: 52809102    	mov	w2, #0x488              ; =1160
1001f1dc8: 94463cd2    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f1dcc: 14000003    	b	0x1001f1dd8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x2e0>
1001f1dd0: 71000d1f    	cmp	w8, #0x3
1001f1dd4: 54009e21    	b.ne	0x1001f3198 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16a0>
1001f1dd8: d10363bb    	sub	x27, x29, #0xd8
1001f1ddc: 52839008    	mov	w8, #0x1c80             ; =7296
1001f1de0: 8b080275    	add	x21, x19, x8
1001f1de4: f9401fe8    	ldr	x8, [sp, #0x38]
1001f1de8: 39644508    	ldrb	w8, [x8, #0x911]
1001f1dec: 7100051f    	cmp	w8, #0x1
1001f1df0: 5400112c    	b.gt	0x1001f2014 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x51c>
1001f1df4: 35009ba8    	cbnz	w8, 0x1001f3168 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1670>
1001f1df8: f9401fea    	ldr	x10, [sp, #0x38]
1001f1dfc: 3924555f    	strb	wzr, [x10, #0x915]
1001f1e00: 91244d48    	add	x8, x10, #0x913
1001f1e04: 7900011f    	strh	wzr, [x8]
1001f1e08: 3dc002a0    	ldr	q0, [x21]
1001f1e0c: 3d873a60    	str	q0, [x19, #0x1ce0]
1001f1e10: f9400aa8    	ldr	x8, [x21, #0x10]
1001f1e14: f90e7a68    	str	x8, [x19, #0x1cf0]
1001f1e18: 52839f19    	mov	w25, #0x1cf8            ; =7416
1001f1e1c: f94e5668    	ldr	x8, [x19, #0x1ca8]
1001f1e20: 52839309    	mov	w9, #0x1c98             ; =7320
1001f1e24: 3ce96a60    	ldr	q0, [x19, x9]
1001f1e28: f90e8668    	str	x8, [x19, #0x1d08]
1001f1e2c: 3cb96a60    	str	q0, [x19, x25]
1001f1e30: 3dc72e60    	ldr	q0, [x19, #0x1cb0]
1001f1e34: 3d874660    	str	q0, [x19, #0x1d10]
1001f1e38: f94e6268    	ldr	x8, [x19, #0x1cc0]
1001f1e3c: f90e9268    	str	x8, [x19, #0x1d20]
1001f1e40: 39644154    	ldrb	w20, [x10, #0x910]
1001f1e44: 5283a51a    	mov	w26, #0x1d28            ; =7464
1001f1e48: 52839908    	mov	w8, #0x1cc8             ; =7368
1001f1e4c: 3ce86a60    	ldr	q0, [x19, x8]
1001f1e50: f94e6e68    	ldr	x8, [x19, #0x1cd8]
1001f1e54: f90e9e68    	str	x8, [x19, #0x1d38]
1001f1e58: 3cba6a60    	str	q0, [x19, x26]
1001f1e5c: f94e7660    	ldr	x0, [x19, #0x1ce8]
1001f1e60: f94e7a61    	ldr	x1, [x19, #0x1cf0]
1001f1e64: 9413d1d3    	bl	0x1006e65b0 <conductor_lib::take_canceled_shell_id>
1001f1e68: 52839c1b    	mov	w27, #0x1ce0            ; =7392
1001f1e6c: 36001a40    	tbz	w0, #0x0, 0x1001f21b4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x6bc>
1001f1e70: f90163ff    	str	xzr, [sp, #0x2c0]
1001f1e74: f9016bff    	str	xzr, [sp, #0x2d0]
1001f1e78: 97f83dfa    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f1e7c: 52800080    	mov	w0, #0x4                ; =4
1001f1e80: 52800021    	mov	w1, #0x1                ; =1
1001f1e84: 97f83df3    	bl	0x100001650 <__rustc::__rust_alloc>
1001f1e88: b4009900    	cbz	x0, 0x1001f31a8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16b0>
1001f1e8c: 528dec68    	mov	w8, #0x6f63             ; =28515
1001f1e90: 72acac88    	movk	w8, #0x6564, lsl #16
1001f1e94: b9000008    	str	w8, [x0]
1001f1e98: 52800088    	mov	w8, #0x4                ; =4
1001f1e9c: a93503a8    	stp	x8, x0, [x29, #-0xb0]
1001f1ea0: f81603a8    	stur	x8, [x29, #-0xa0]
1001f1ea4: 52800048    	mov	w8, #0x2                ; =2
1001f1ea8: 3901c3e8    	strb	w8, [sp, #0x70]
1001f1eac: b0009888    	adrp	x8, 0x101502000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x335>
1001f1eb0: 3dc2fd00    	ldr	q0, [x8, #0xbf0]
1001f1eb4: 3c8783e0    	stur	q0, [sp, #0x78]
1001f1eb8: 910903e8    	add	x8, sp, #0x240
1001f1ebc: 910b03e0    	add	x0, sp, #0x2c0
1001f1ec0: d102c3a1    	sub	x1, x29, #0xb0
1001f1ec4: 9101c3e2    	add	x2, sp, #0x70
1001f1ec8: 94143581    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f1ecc: 394903e8    	ldrb	w8, [sp, #0x240]
1001f1ed0: 7103fd1f    	cmp	w8, #0xff
1001f1ed4: 54000060    	b.eq	0x1001f1ee0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x3e8>
1001f1ed8: 910903e0    	add	x0, sp, #0x240
1001f1edc: 97fe07a7    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f1ee0: 97f83de0    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f1ee4: 528000c0    	mov	w0, #0x6                ; =6
1001f1ee8: 52800021    	mov	w1, #0x1                ; =1
1001f1eec: 97f83dd9    	bl	0x100001650 <__rustc::__rust_alloc>
1001f1ef0: b4009640    	cbz	x0, 0x1001f31b8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16c0>
1001f1ef4: 528e8ea8    	mov	w8, #0x7475             ; =29813
1001f1ef8: 79000808    	strh	w8, [x0, #0x4]
1001f1efc: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f1f00: 72adec88    	movk	w8, #0x6f64, lsl #16
1001f1f04: b9000008    	str	w8, [x0]
1001f1f08: 528000c8    	mov	w8, #0x6                ; =6
1001f1f0c: a93503a8    	stp	x8, x0, [x29, #-0xb0]
1001f1f10: f81603a8    	stur	x8, [x29, #-0xa0]
1001f1f14: 52800068    	mov	w8, #0x3                ; =3
1001f1f18: 3901c3e8    	strb	w8, [sp, #0x70]
1001f1f1c: 52800028    	mov	w8, #0x1                ; =1
1001f1f20: a907a3ff    	stp	xzr, x8, [sp, #0x78]
1001f1f24: f90047ff    	str	xzr, [sp, #0x88]
1001f1f28: 910903e8    	add	x8, sp, #0x240
1001f1f2c: 910b03e0    	add	x0, sp, #0x2c0
1001f1f30: d102c3a1    	sub	x1, x29, #0xb0
1001f1f34: 9101c3e2    	add	x2, sp, #0x70
1001f1f38: 94143565    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f1f3c: 394903e8    	ldrb	w8, [sp, #0x240]
1001f1f40: 7103fd1f    	cmp	w8, #0xff
1001f1f44: 54000060    	b.eq	0x1001f1f50 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x458>
1001f1f48: 910903e0    	add	x0, sp, #0x240
1001f1f4c: 97fe078b    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f1f50: 97f83dc4    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f1f54: 528000c0    	mov	w0, #0x6                ; =6
1001f1f58: 52800021    	mov	w1, #0x1                ; =1
1001f1f5c: 97f83dbd    	bl	0x100001650 <__rustc::__rust_alloc>
1001f1f60: b4009340    	cbz	x0, 0x1001f31c8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16d0>
1001f1f64: aa0003f7    	mov	x23, x0
1001f1f68: 528e4e48    	mov	w8, #0x7272             ; =29298
1001f1f6c: 79000808    	strh	w8, [x0, #0x4]
1001f1f70: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f1f74: 72acac88    	movk	w8, #0x6564, lsl #16
1001f1f78: b9000008    	str	w8, [x0]
1001f1f7c: 528000c8    	mov	w8, #0x6                ; =6
1001f1f80: a93503a8    	stp	x8, x0, [x29, #-0xb0]
1001f1f84: f81603a8    	stur	x8, [x29, #-0xa0]
1001f1f88: 97f83db6    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f1f8c: 528002e0    	mov	w0, #0x17               ; =23
1001f1f90: 52800021    	mov	w1, #0x1                ; =1
1001f1f94: 97f83daf    	bl	0x100001650 <__rustc::__rust_alloc>
1001f1f98: b4009200    	cbz	x0, 0x1001f31d8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16e0>
1001f1f9c: 90009888    	adrp	x8, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f1fa0: 91238908    	add	x8, x8, #0x8e2
1001f1fa4: 3dc00100    	ldr	q0, [x8]
1001f1fa8: 3d800000    	str	q0, [x0]
1001f1fac: f840f108    	ldur	x8, [x8, #0xf]
1001f1fb0: f800f008    	stur	x8, [x0, #0xf]
1001f1fb4: 52800068    	mov	w8, #0x3                ; =3
1001f1fb8: 3901c3e8    	strb	w8, [sp, #0x70]
1001f1fbc: 528002e8    	mov	w8, #0x17               ; =23
1001f1fc0: a90783e8    	stp	x8, x0, [sp, #0x78]
1001f1fc4: f90047e8    	str	x8, [sp, #0x88]
1001f1fc8: 910903e8    	add	x8, sp, #0x240
1001f1fcc: 910b03e0    	add	x0, sp, #0x2c0
1001f1fd0: d102c3a1    	sub	x1, x29, #0xb0
1001f1fd4: 9101c3e2    	add	x2, sp, #0x70
1001f1fd8: 9414353d    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f1fdc: 394903e8    	ldrb	w8, [sp, #0x240]
1001f1fe0: 7103fd1f    	cmp	w8, #0xff
1001f1fe4: 54000060    	b.eq	0x1001f1ff0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x4f8>
1001f1fe8: 910903e0    	add	x0, sp, #0x240
1001f1fec: 97fe0763    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f1ff0: f94163f7    	ldr	x23, [sp, #0x2c0]
1001f1ff4: f94167f8    	ldr	x24, [sp, #0x2c8]
1001f1ff8: 528000bc    	mov	w28, #0x5               ; =5
1001f1ffc: f9416bf6    	ldr	x22, [sp, #0x2d0]
1001f2000: 5283a214    	mov	w20, #0x1d10            ; =7440
1001f2004: f87a6a61    	ldr	x1, [x19, x26]
1001f2008: b100043f    	cmn	x1, #0x1
1001f200c: 54003061    	b.ne	0x1001f2618 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb20>
1001f2010: 14000186    	b	0x1001f2628 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb30>
1001f2014: 71000d1f    	cmp	w8, #0x3
1001f2018: 54008b01    	b.ne	0x1001f3178 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1680>
1001f201c: 52841e09    	mov	w9, #0x20f0             ; =8432
1001f2020: 9101c3e8    	add	x8, sp, #0x70
1001f2024: 8b090260    	add	x0, x19, x9
1001f2028: aa1603e1    	mov	x1, x22
1001f202c: 94133616    	bl	0x1006bf884 <<core::future::poll_fn::PollFn<conductor_lib::execute_shell_command_cancellable::{closure#0}::{closure#1}> as core::future::future::Future>::poll>
1001f2030: f9403bf6    	ldr	x22, [sp, #0x70]
1001f2034: b1000adf    	cmn	x22, #0x2
1001f2038: 540001e1    	b.ne	0x1001f2074 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x57c>
1001f203c: 52800068    	mov	w8, #0x3                ; =3
1001f2040: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2044: 39244528    	strb	w8, [x9, #0x911]
1001f2048: 39246128    	strb	w8, [x9, #0x918]
1001f204c: 14000307    	b	0x1001f2c68 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1170>
1001f2050: 394907f9    	ldrb	w25, [sp, #0x241]
1001f2054: b845a348    	ldur	w8, [x26, #0x5a]
1001f2058: b901e3e8    	str	w8, [sp, #0x1e0]
1001f205c: 79448fe8    	ldrh	w8, [sp, #0x246]
1001f2060: 7903cbe8    	strh	w8, [sp, #0x1e4]
1001f2064: f94127fc    	ldr	x28, [sp, #0x248]
1001f2068: f9412bf5    	ldr	x21, [sp, #0x250]
1001f206c: f9412ff6    	ldr	x22, [sp, #0x258]
1001f2070: 1400010d    	b	0x1001f24a4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9ac>
1001f2074: f9403ff7    	ldr	x23, [sp, #0x78]
1001f2078: ad4407e0    	ldp	q0, q1, [sp, #0x80]
1001f207c: ad3807a0    	stp	q0, q1, [x29, #-0x100]
1001f2080: f94053e8    	ldr	x8, [sp, #0xa0]
1001f2084: f81203a8    	stur	x8, [x29, #-0xe0]
1001f2088: 5283d508    	mov	w8, #0x1ea8             ; =7848
1001f208c: 8b080260    	add	x0, x19, x8
1001f2090: 97fe2132    	bl	0x10017a558 <core::ptr::drop_glue::<(tokio::sync::oneshot::Receiver<()>, <tokio::process::Child>::wait_with_output::{closure#0})>>
1001f2094: d24102c8    	eor	x8, x22, #0x8000000000000000
1001f2098: f1000d1f    	cmp	x8, #0x3
1001f209c: 9a9f3508    	csinc	x8, x8, xzr, lo
1001f20a0: b4000fa8    	cbz	x8, 0x1001f2294 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x79c>
1001f20a4: f100051f    	cmp	x8, #0x1
1001f20a8: 54008a81    	b.ne	0x1001f31f8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1700>
1001f20ac: b10006df    	cmn	x22, #0x1
1001f20b0: 54002260    	b.eq	0x1001f24fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xa04>
1001f20b4: a9075ff6    	stp	x22, x23, [sp, #0x70]
1001f20b8: ad7807a0    	ldp	q0, q1, [x29, #-0x100]
1001f20bc: ad0407e0    	stp	q0, q1, [sp, #0x80]
1001f20c0: f85203a8    	ldur	x8, [x29, #-0xe0]
1001f20c4: f90053e8    	str	x8, [sp, #0xa0]
1001f20c8: f81303bf    	stur	xzr, [x29, #-0xd0]
1001f20cc: f81403bf    	stur	xzr, [x29, #-0xc0]
1001f20d0: 97f83d64    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f20d4: 52800098    	mov	w24, #0x4               ; =4
1001f20d8: 52800080    	mov	w0, #0x4                ; =4
1001f20dc: 52800021    	mov	w1, #0x1                ; =1
1001f20e0: 97f83d5c    	bl	0x100001650 <__rustc::__rust_alloc>
1001f20e4: b4008820    	cbz	x0, 0x1001f31e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16f0>
1001f20e8: 528dec68    	mov	w8, #0x6f63             ; =28515
1001f20ec: 72acac88    	movk	w8, #0x6564, lsl #16
1001f20f0: b9000008    	str	w8, [x0]
1001f20f4: 52800088    	mov	w8, #0x4                ; =4
1001f20f8: a93883a8    	stp	x8, x0, [x29, #-0x78]
1001f20fc: f81983a8    	stur	x8, [x29, #-0x68]
1001f2100: b940a3e8    	ldr	w8, [sp, #0xa0]
1001f2104: d348fd09    	lsr	x9, x8, #8
1001f2108: 92401d29    	and	x9, x9, #0xff
1001f210c: 7200191f    	tst	w8, #0x7f
1001f2110: 52800048    	mov	w8, #0x2                ; =2
1001f2114: 1a9f0108    	csel	w8, w8, wzr, eq
1001f2118: 390903e8    	strb	w8, [sp, #0x240]
1001f211c: f90127ff    	str	xzr, [sp, #0x248]
1001f2120: f9012be9    	str	x9, [sp, #0x250]
1001f2124: d102c3a8    	sub	x8, x29, #0xb0
1001f2128: d10343a0    	sub	x0, x29, #0xd0
1001f212c: d101e3a1    	sub	x1, x29, #0x78
1001f2130: 910903e2    	add	x2, sp, #0x240
1001f2134: 941434e6    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f2138: 385503a8    	ldurb	w8, [x29, #-0xb0]
1001f213c: 7103fd1f    	cmp	w8, #0xff
1001f2140: 54000060    	b.eq	0x1001f214c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x654>
1001f2144: d102c3a0    	sub	x0, x29, #0xb0
1001f2148: 97fe070c    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f214c: 97f83d45    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2150: 528000d8    	mov	w24, #0x6               ; =6
1001f2154: 528000c0    	mov	w0, #0x6                ; =6
1001f2158: 52800021    	mov	w1, #0x1                ; =1
1001f215c: 97f83d3d    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2160: b4008440    	cbz	x0, 0x1001f31e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16f0>
1001f2164: aa0003fb    	mov	x27, x0
1001f2168: 528e8ea8    	mov	w8, #0x7475             ; =29813
1001f216c: 79000808    	strh	w8, [x0, #0x4]
1001f2170: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f2174: 72adec88    	movk	w8, #0x6f64, lsl #16
1001f2178: b9000008    	str	w8, [x0]
1001f217c: 528000c8    	mov	w8, #0x6                ; =6
1001f2180: a93703a8    	stp	x8, x0, [x29, #-0x90]
1001f2184: f81803a8    	stur	x8, [x29, #-0x80]
1001f2188: f94043e1    	ldr	x1, [sp, #0x80]
1001f218c: d101e3a8    	sub	x8, x29, #0x78
1001f2190: aa1703e0    	mov	x0, x23
1001f2194: 9444780b    	bl	0x1013101c0 <<alloc::string::String>::from_utf8_lossy>
1001f2198: a97967b8    	ldp	x24, x25, [x29, #-0x70]
1001f219c: b6f826b9    	tbz	x25, #0x3f, 0x1001f2670 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb78>
1001f21a0: d280001c    	mov	x28, #0x0               ; =0
1001f21a4: aa1c03e0    	mov	x0, x28
1001f21a8: aa1903e1    	mov	x1, x25
1001f21ac: 94463741    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f21b0: 14000430    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f21b4: 5283a81c    	mov	w28, #0x1d40            ; =7488
1001f21b8: f94e8260    	ldr	x0, [x19, #0x1d00]
1001f21bc: f94e8661    	ldr	x1, [x19, #0x1d08]
1001f21c0: 8b1c0268    	add	x8, x19, x28
1001f21c4: 9443fa43    	bl	0x1012f0ad0 <<std::sys::process::unix::common::Command>::new>
1001f21c8: f9401fe8    	ldr	x8, [sp, #0x38]
1001f21cc: 3918611f    	strb	wzr, [x8, #0x618]
1001f21d0: 360000d4    	tbz	w20, #0x0, 0x1001f21e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x6f0>
1001f21d4: f0009861    	adrp	x1, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f21d8: 91237821    	add	x1, x1, #0x8de
1001f21dc: 8b1c0260    	add	x0, x19, x28
1001f21e0: 52800042    	mov	w2, #0x2                ; =2
1001f21e4: 9443f9bf    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
1001f21e8: f0009861    	adrp	x1, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f21ec: 91238021    	add	x1, x1, #0x8e0
1001f21f0: 8b1c0260    	add	x0, x19, x28
1001f21f4: 52800042    	mov	w2, #0x2                ; =2
1001f21f8: 9443f9ba    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
1001f21fc: f94e8e61    	ldr	x1, [x19, #0x1d18]
1001f2200: f94e9262    	ldr	x2, [x19, #0x1d20]
1001f2204: 8b1c0260    	add	x0, x19, x28
1001f2208: 9443f9b6    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
1001f220c: 8b1c0260    	add	x0, x19, x28
1001f2210: 52800021    	mov	w1, #0x1                ; =1
1001f2214: 9443facd    	bl	0x1012f0d48 <<std::sys::process::unix::common::Command>::stdin>
1001f2218: 8b1c0260    	add	x0, x19, x28
1001f221c: 52800041    	mov	w1, #0x2                ; =2
1001f2220: 9443faec    	bl	0x1012f0dd0 <<std::sys::process::unix::common::Command>::stdout>
1001f2224: 8b1c0260    	add	x0, x19, x28
1001f2228: 52800041    	mov	w1, #0x2                ; =2
1001f222c: 9443fad8    	bl	0x1012f0d8c <<std::sys::process::unix::common::Command>::stderr>
1001f2230: 52800028    	mov	w8, #0x1                ; =1
1001f2234: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2238: 39186128    	strb	w8, [x9, #0x618]
1001f223c: 90009888    	adrp	x8, 0x101502000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x335>
1001f2240: fd470100    	ldr	d0, [x8, #0xe00]
1001f2244: fd0ec260    	str	d0, [x19, #0x1d80]
1001f2248: d102c3a8    	sub	x8, x29, #0xb0
1001f224c: 8b1c0260    	add	x0, x19, x28
1001f2250: 9444027d    	bl	0x1012f2c44 <<std::process::Command>::spawn>
1001f2254: b85503a8    	ldur	w8, [x29, #-0xb0]
1001f2258: 7100091f    	cmp	w8, #0x2
1001f225c: 54000501    	b.ne	0x1001f22fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x804>
1001f2260: f85583a8    	ldur	x8, [x29, #-0xa8]
1001f2264: 140000ca    	b	0x1001f258c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xa94>
1001f2268: aa1903e0    	mov	x0, x25
1001f226c: 394907f9    	ldrb	w25, [sp, #0x241]
1001f2270: b845a348    	ldur	w8, [x26, #0x5a]
1001f2274: b901e3e8    	str	w8, [sp, #0x1e0]
1001f2278: 79448fe8    	ldrh	w8, [sp, #0x246]
1001f227c: 7903cbe8    	strh	w8, [sp, #0x1e4]
1001f2280: f94127fc    	ldr	x28, [sp, #0x248]
1001f2284: f9412bf5    	ldr	x21, [sp, #0x250]
1001f2288: f9412ff6    	ldr	x22, [sp, #0x258]
1001f228c: b5001078    	cbnz	x24, 0x1001f2498 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9a0>
1001f2290: 14000085    	b	0x1001f24a4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9ac>
1001f2294: b95ea268    	ldr	w8, [x19, #0x1ea0]
1001f2298: 7100051f    	cmp	w8, #0x1
1001f229c: 54002d41    	b.ne	0x1001f2844 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xd4c>
1001f22a0: b95ea668    	ldr	w8, [x19, #0x1ea4]
1001f22a4: b81503a8    	stur	w8, [x29, #-0xb0]
1001f22a8: 37f82be8    	tbnz	w8, #0x1f, 0x1001f2824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xd2c>
1001f22ac: 4b0803e0    	neg	w0, w8
1001f22b0: 52800121    	mov	w1, #0x9                ; =9
1001f22b4: 94463b58    	bl	0x101381014 <dyld_stub_binder+0x101381014>
1001f22b8: 3100041f    	cmn	w0, #0x1
1001f22bc: 54002c41    	b.ne	0x1001f2844 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xd4c>
1001f22c0: 942ae356    	bl	0x100cab018 <<nix::errno::consts::Errno>::last>
1001f22c4: b90243e0    	str	w0, [sp, #0x240]
1001f22c8: d102c3a8    	sub	x8, x29, #0xb0
1001f22cc: f0008969    	adrp	x9, 0x101321000 <<core::net::socket_addr::SocketAddrV6 as core::fmt::Display>::fmt+0xf0>
1001f22d0: 9103b129    	add	x9, x9, #0xec
1001f22d4: a90727e8    	stp	x8, x9, [sp, #0x70]
1001f22d8: 910903e8    	add	x8, sp, #0x240
1001f22dc: b00055c9    	adrp	x9, 0x100cab000 <<nix::errno::consts::Errno>::desc+0x4>
1001f22e0: 91049129    	add	x9, x9, #0x124
1001f22e4: a90827e8    	stp	x8, x9, [sp, #0x80]
1001f22e8: b0015660    	adrp	x0, 0x102cbf000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.108+0x134>
1001f22ec: 910e8000    	add	x0, x0, #0x3a0
1001f22f0: 9101c3e1    	add	x1, sp, #0x70
1001f22f4: 944418c4    	bl	0x1012f8604 <std::io::stdio::_eprint>
1001f22f8: 14000153    	b	0x1001f2844 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xd4c>
1001f22fc: b85543a9    	ldur	w9, [x29, #-0xac]
1001f2300: a975afaa    	ldp	x10, x11, [x29, #-0xa8]
1001f2304: b90243e8    	str	w8, [sp, #0x240]
1001f2308: b90247e9    	str	w9, [sp, #0x244]
1001f230c: f90127ea    	str	x10, [sp, #0x248]
1001f2310: f9012beb    	str	x11, [sp, #0x250]
1001f2314: 9101c3e8    	add	x8, sp, #0x70
1001f2318: 8b1c0260    	add	x0, x19, x28
1001f231c: 910903e1    	add	x1, sp, #0x240
1001f2320: 943e4db0    	bl	0x1011859e0 <<tokio::process::Command>::build_child>
1001f2324: f9403be8    	ldr	x8, [sp, #0x70]
1001f2328: b100051f    	cmn	x8, #0x1
1001f232c: 540012e0    	b.eq	0x1001f2588 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xa90>
1001f2330: 3cc783e0    	ldur	q0, [sp, #0x78]
1001f2334: ad468be1    	ldp	q1, q2, [sp, #0xd0]
1001f2338: ad140be1    	stp	q1, q2, [sp, #0x280]
1001f233c: 3dc03fe1    	ldr	q1, [sp, #0xf0]
1001f2340: 3d80abe1    	str	q1, [sp, #0x2a0]
1001f2344: ad448be1    	ldp	q1, q2, [sp, #0x90]
1001f2348: ad120be1    	stp	q1, q2, [sp, #0x240]
1001f234c: ad4587e2    	ldp	q2, q1, [sp, #0xb0]
1001f2350: ad1307e2    	stp	q2, q1, [sp, #0x260]
1001f2354: 5283c309    	mov	w9, #0x1e18             ; =7704
1001f2358: 3ca96a60    	str	q0, [x19, x9]
1001f235c: ad5303e1    	ldp	q1, q0, [sp, #0x260]
1001f2360: 3d879a60    	str	q0, [x19, #0x1e60]
1001f2364: ad540be0    	ldp	q0, q2, [sp, #0x280]
1001f2368: 3d879e60    	str	q0, [x19, #0x1e70]
1001f236c: 3d87a262    	str	q2, [x19, #0x1e80]
1001f2370: 3dc0abe0    	ldr	q0, [sp, #0x2a0]
1001f2374: 3d87a660    	str	q0, [x19, #0x1e90]
1001f2378: ad520be0    	ldp	q0, q2, [sp, #0x240]
1001f237c: 3d878e60    	str	q0, [x19, #0x1e30]
1001f2380: f94047e9    	ldr	x9, [sp, #0x88]
1001f2384: 5280002a    	mov	w10, #0x1               ; =1
1001f2388: f9401feb    	ldr	x11, [sp, #0x38]
1001f238c: 3924556a    	strb	w10, [x11, #0x915]
1001f2390: 5283c20a    	mov	w10, #0x1e10            ; =7696
1001f2394: 8b0a0277    	add	x23, x19, x10
1001f2398: f90f0a68    	str	x8, [x19, #0x1e10]
1001f239c: f90f1669    	str	x9, [x19, #0x1e28]
1001f23a0: 3d879262    	str	q2, [x19, #0x1e40]
1001f23a4: 3d879661    	str	q1, [x19, #0x1e50]
1001f23a8: aa1703e0    	mov	x0, x23
1001f23ac: 943e5462    	bl	0x101187534 <<tokio::process::Child>::id>
1001f23b0: b91ea260    	str	w0, [x19, #0x1ea0]
1001f23b4: b91ea661    	str	w1, [x19, #0x1ea4]
1001f23b8: f94e9668    	ldr	x8, [x19, #0x1d28]
1001f23bc: f94e9a69    	ldr	x9, [x19, #0x1d30]
1001f23c0: f94e9e63    	ldr	x3, [x19, #0x1d38]
1001f23c4: b100051f    	cmn	x8, #0x1
1001f23c8: 9a8903e2    	csel	x2, xzr, x9, eq
1001f23cc: 9416225c    	bl	0x10077ad3c <conductor_lib::resource_usage::register_resource_usage_command_line>
1001f23d0: 9107a3fa    	add	x26, sp, #0x1e8
1001f23d4: 52800028    	mov	w8, #0x1                ; =1
1001f23d8: 4e080d00    	dup.2d	v0, x8
1001f23dc: 3d801fe0    	str	q0, [sp, #0x70]
1001f23e0: f90053ff    	str	xzr, [sp, #0xa0]
1001f23e4: 3902a3ff    	strb	wzr, [sp, #0xa8]
1001f23e8: 97f83c9e    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f23ec: 52800800    	mov	w0, #0x40               ; =64
1001f23f0: 52800101    	mov	w1, #0x8                ; =8
1001f23f4: 97f83c97    	bl	0x100001650 <__rustc::__rust_alloc>
1001f23f8: b4006660    	cbz	x0, 0x1001f30c4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x15cc>
1001f23fc: aa0003f8    	mov	x24, x0
1001f2400: ad4387e0    	ldp	q0, q1, [sp, #0x70]
1001f2404: ad000400    	stp	q0, q1, [x0]
1001f2408: ad4487e0    	ldp	q0, q1, [sp, #0x90]
1001f240c: ad010400    	stp	q0, q1, [x0, #0x20]
1001f2410: 52800028    	mov	w8, #0x1                ; =1
1001f2414: f8280009    	ldadd	x8, x9, [x0]
1001f2418: b7f872c9    	tbnz	x9, #0x3f, 0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f241c: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2420: 39245128    	strb	w8, [x9, #0x914]
1001f2424: f9015bf8    	str	x24, [sp, #0x2b0]
1001f2428: 39244d28    	strb	w8, [x9, #0x913]
1001f242c: f9015ff8    	str	x24, [sp, #0x2b8]
1001f2430: f94e7660    	ldr	x0, [x19, #0x1ce8]
1001f2434: f94e7a61    	ldr	x1, [x19, #0x1cf0]
1001f2438: 9413d05e    	bl	0x1006e65b0 <conductor_lib::take_canceled_shell_id>
1001f243c: 36001440    	tbz	w0, #0x0, 0x1001f26c4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xbcc>
1001f2440: f9401ff4    	ldr	x20, [sp, #0x38]
1001f2444: 3924529f    	strb	wzr, [x20, #0x914]
1001f2448: aa1803e0    	mov	x0, x24
1001f244c: 941407fd    	bl	0x1006f4440 <<tokio::sync::oneshot::Sender<()>>::send>
1001f2450: d10363bb    	sub	x27, x29, #0xd8
1001f2454: 140000cc    	b	0x1001f2784 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc8c>
1001f2458: 394907f9    	ldrb	w25, [sp, #0x241]
1001f245c: 9107a3e8    	add	x8, sp, #0x1e8
1001f2460: b845a108    	ldur	w8, [x8, #0x5a]
1001f2464: b901e3e8    	str	w8, [sp, #0x1e0]
1001f2468: 79448fe8    	ldrh	w8, [sp, #0x246]
1001f246c: 7903cbe8    	strh	w8, [sp, #0x1e4]
1001f2470: f94127fc    	ldr	x28, [sp, #0x248]
1001f2474: f9412bf5    	ldr	x21, [sp, #0x250]
1001f2478: f9412ff6    	ldr	x22, [sp, #0x258]
1001f247c: b40000ba    	cbz	x26, 0x1001f2490 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x998>
1001f2480: f94017e0    	ldr	x0, [sp, #0x28]
1001f2484: aa1a03e1    	mov	x1, x26
1001f2488: 52800022    	mov	w2, #0x1                ; =1
1001f248c: 97f83c72    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2490: b40000b8    	cbz	x24, 0x1001f24a4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9ac>
1001f2494: f94013e0    	ldr	x0, [sp, #0x20]
1001f2498: aa1803e1    	mov	x1, x24
1001f249c: 52800022    	mov	w2, #0x1                ; =1
1001f24a0: 97f83c6d    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f24a4: f9401be0    	ldr	x0, [sp, #0x30]
1001f24a8: 97fe116b    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001f24ac: f94002e8    	ldr	x8, [x23]
1001f24b0: b100051f    	cmn	x8, #0x1
1001f24b4: 54000200    	b.eq	0x1001f24f4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9fc>
1001f24b8: 52826c08    	mov	w8, #0x1360             ; =4960
1001f24bc: 8b080274    	add	x20, x19, x8
1001f24c0: f949b260    	ldr	x0, [x19, #0x1360]
1001f24c4: f949b668    	ldr	x8, [x19, #0x1368]
1001f24c8: 9100051a    	add	x26, x8, #0x1
1001f24cc: f100075a    	subs	x26, x26, #0x1
1001f24d0: 540000a0    	b.eq	0x1001f24e4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9ec>
1001f24d4: 91018018    	add	x24, x0, #0x60
1001f24d8: 9415b7c0    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001f24dc: aa1803e0    	mov	x0, x24
1001f24e0: 17fffffb    	b	0x1001f24cc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x9d4>
1001f24e4: f94002e8    	ldr	x8, [x23]
1001f24e8: 5280003a    	mov	w26, #0x1               ; =1
1001f24ec: b5004488    	cbnz	x8, 0x1001f2d7c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1284>
1001f24f0: 14000228    	b	0x1001f2d90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1298>
1001f24f4: 5280003a    	mov	w26, #0x1               ; =1
1001f24f8: 14000226    	b	0x1001f2d90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1298>
1001f24fc: f81503b7    	stur	x23, [x29, #-0xb0]
1001f2500: d102c3a8    	sub	x8, x29, #0xb0
1001f2504: d0008969    	adrp	x9, 0x101320000 <<core::num::niche_types::I32NotAllOnes as core::fmt::Debug>::fmt+0x20>
1001f2508: 9116c129    	add	x9, x9, #0x5b0
1001f250c: f90123e8    	str	x8, [sp, #0x240]
1001f2510: f90127e9    	str	x9, [sp, #0x248]
1001f2514: b0015620    	adrp	x0, 0x102cb7000 <_anon.dfaadf50359b6dc611e2f8074053fec3.144+0x643>
1001f2518: 91243800    	add	x0, x0, #0x90e
1001f251c: 9101c3e8    	add	x8, sp, #0x70
1001f2520: 910903e1    	add	x1, sp, #0x240
1001f2524: 94447d54    	bl	0x101311a74 <alloc::fmt::format::format_inner>
1001f2528: f85503a8    	ldur	x8, [x29, #-0xb0]
1001f252c: 92400509    	and	x9, x8, #0x3
1001f2530: d100092a    	sub	x10, x9, #0x2
1001f2534: f100095f    	cmp	x10, #0x2
1001f2538: 54000123    	b.lo	0x1001f255c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xa64>
1001f253c: b4000109    	cbz	x9, 0x1001f255c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xa64>
1001f2540: d1000508    	sub	x8, x8, #0x1
1001f2544: 910903e9    	add	x9, sp, #0x240
1001f2548: f90127e8    	str	x8, [sp, #0x248]
1001f254c: 52800068    	mov	w8, #0x3                ; =3
1001f2550: 390903e8    	strb	w8, [sp, #0x240]
1001f2554: 91002120    	add	x0, x9, #0x8
1001f2558: 9444be5c    	bl	0x101321ec8 <<core::io::error::CustomOwner as core::ops::drop::Drop>::drop>
1001f255c: 3dc01fe0    	ldr	q0, [sp, #0x70]
1001f2560: 3c8e0340    	stur	q0, [x26, #0xe0]
1001f2564: f94043e8    	ldr	x8, [sp, #0x80]
1001f2568: f9016fe8    	str	x8, [sp, #0x2d8]
1001f256c: 52801ffc    	mov	w28, #0xff              ; =255
1001f2570: 390b03fc    	strb	w28, [sp, #0x2c0]
1001f2574: f0017ba8    	adrp	x8, 0x103169000 <dyld_stub_binder+0x103169000>
1001f2578: 9111c108    	add	x8, x8, #0x470
1001f257c: f8bfc108    	ldapr	x8, [x8]
1001f2580: b40023e8    	cbz	x8, 0x1001f29fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf04>
1001f2584: 140002b2    	b	0x1001f304c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1554>
1001f2588: f9403fe8    	ldr	x8, [sp, #0x78]
1001f258c: f90163e8    	str	x8, [sp, #0x2c0]
1001f2590: 910b03e8    	add	x8, sp, #0x2c0
1001f2594: d0008969    	adrp	x9, 0x101320000 <<core::num::niche_types::I32NotAllOnes as core::fmt::Debug>::fmt+0x20>
1001f2598: 9116c129    	add	x9, x9, #0x5b0
1001f259c: a93527a8    	stp	x8, x9, [x29, #-0xb0]
1001f25a0: b0015620    	adrp	x0, 0x102cb7000 <_anon.dfaadf50359b6dc611e2f8074053fec3.144+0x643>
1001f25a4: 9123c000    	add	x0, x0, #0x8f0
1001f25a8: 910903e8    	add	x8, sp, #0x240
1001f25ac: d102c3a1    	sub	x1, x29, #0xb0
1001f25b0: 94447d31    	bl	0x101311a74 <alloc::fmt::format::format_inner>
1001f25b4: f94163e8    	ldr	x8, [sp, #0x2c0]
1001f25b8: 92400509    	and	x9, x8, #0x3
1001f25bc: d100092a    	sub	x10, x9, #0x2
1001f25c0: f100095f    	cmp	x10, #0x2
1001f25c4: 54000123    	b.lo	0x1001f25e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xaf0>
1001f25c8: b4000109    	cbz	x9, 0x1001f25e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xaf0>
1001f25cc: d1000508    	sub	x8, x8, #0x1
1001f25d0: d102c3a9    	sub	x9, x29, #0xb0
1001f25d4: f81583a8    	stur	x8, [x29, #-0xa8]
1001f25d8: 52800068    	mov	w8, #0x3                ; =3
1001f25dc: 381503a8    	sturb	w8, [x29, #-0xb0]
1001f25e0: 91002120    	add	x0, x9, #0x8
1001f25e4: 9444be39    	bl	0x101321ec8 <<core::io::error::CustomOwner as core::ops::drop::Drop>::drop>
1001f25e8: f94123f7    	ldr	x23, [sp, #0x240]
1001f25ec: f94127f8    	ldr	x24, [sp, #0x248]
1001f25f0: f9412bf6    	ldr	x22, [sp, #0x250]
1001f25f4: f9401fe8    	ldr	x8, [sp, #0x38]
1001f25f8: 3924551f    	strb	wzr, [x8, #0x915]
1001f25fc: 8b1c0260    	add	x0, x19, x28
1001f2600: 97fe07be    	bl	0x1001744f8 <core::ptr::drop_glue::<std::process::Command>>
1001f2604: 52801ffc    	mov	w28, #0xff              ; =255
1001f2608: 5283a214    	mov	w20, #0x1d10            ; =7440
1001f260c: f87a6a61    	ldr	x1, [x19, x26]
1001f2610: b100043f    	cmn	x1, #0x1
1001f2614: 540000a0    	b.eq	0x1001f2628 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb30>
1001f2618: b4000081    	cbz	x1, 0x1001f2628 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb30>
1001f261c: f94e9a60    	ldr	x0, [x19, #0x1d30]
1001f2620: 52800022    	mov	w2, #0x1                ; =1
1001f2624: 97f83c0c    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2628: f8746a61    	ldr	x1, [x19, x20]
1001f262c: 9107a3f4    	add	x20, sp, #0x1e8
1001f2630: b4000081    	cbz	x1, 0x1001f2640 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb48>
1001f2634: f94e8e60    	ldr	x0, [x19, #0x1d18]
1001f2638: 52800022    	mov	w2, #0x1                ; =1
1001f263c: 97f83c06    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2640: f8796a61    	ldr	x1, [x19, x25]
1001f2644: b4000081    	cbz	x1, 0x1001f2654 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb5c>
1001f2648: f94e8260    	ldr	x0, [x19, #0x1d00]
1001f264c: 52800022    	mov	w2, #0x1                ; =1
1001f2650: 97f83c01    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2654: f87b6a61    	ldr	x1, [x19, x27]
1001f2658: b4000081    	cbz	x1, 0x1001f2668 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xb70>
1001f265c: f94e7660    	ldr	x0, [x19, #0x1ce8]
1001f2660: 52800022    	mov	w2, #0x1                ; =1
1001f2664: 97f83bfc    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2668: d10363b9    	sub	x25, x29, #0xd8
1001f266c: 1400013f    	b	0x1001f2b68 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1070>
1001f2670: b4003f19    	cbz	x25, 0x1001f2e50 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1358>
1001f2674: 97f83bfb    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2678: 5280003c    	mov	w28, #0x1               ; =1
1001f267c: aa1903e0    	mov	x0, x25
1001f2680: 52800021    	mov	w1, #0x1                ; =1
1001f2684: 97f83bf3    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2688: b4ffd8e0    	cbz	x0, 0x1001f21a4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x6ac>
1001f268c: aa0003fa    	mov	x26, x0
1001f2690: aa1803e1    	mov	x1, x24
1001f2694: aa1903e2    	mov	x2, x25
1001f2698: 94463a9e    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f269c: 97f83bf1    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f26a0: aa1903e0    	mov	x0, x25
1001f26a4: 52800021    	mov	w1, #0x1                ; =1
1001f26a8: 97f83bea    	bl	0x100001650 <__rustc::__rust_alloc>
1001f26ac: b4005d40    	cbz	x0, 0x1001f3254 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x175c>
1001f26b0: aa0003fc    	mov	x28, x0
1001f26b4: aa1a03e1    	mov	x1, x26
1001f26b8: aa1903e2    	mov	x2, x25
1001f26bc: 94463a95    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f26c0: 140001e6    	b	0x1001f2e58 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1360>
1001f26c4: f0017ba8    	adrp	x8, 0x103169000 <dyld_stub_binder+0x103169000>
1001f26c8: 9111c108    	add	x8, x8, #0x470
1001f26cc: f8bfc108    	ldapr	x8, [x8]
1001f26d0: b5005028    	cbnz	x8, 0x1001f30d4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x15dc>
1001f26d4: f0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f26d8: 9110c000    	add	x0, x0, #0x430
1001f26dc: 9101c3e8    	add	x8, sp, #0x70
1001f26e0: 94120b0d    	bl	0x100675314 <<std::sync::poison::mutex::Mutex<()>>::lock>
1001f26e4: f9403be8    	ldr	x8, [sp, #0x70]
1001f26e8: f100051f    	cmp	x8, #0x1
1001f26ec: 54004fc0    	b.eq	0x1001f30e4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x15ec>
1001f26f0: f9403ff9    	ldr	x25, [sp, #0x78]
1001f26f4: 394203fa    	ldrb	w26, [sp, #0x80]
1001f26f8: 9101c3e8    	add	x8, sp, #0x70
1001f26fc: 8b1b0260    	add	x0, x19, x27
1001f2700: 94447de2    	bl	0x101311e88 <<alloc::string::String as core::clone::Clone>::clone>
1001f2704: f9401fe8    	ldr	x8, [sp, #0x38]
1001f2708: 3924511f    	strb	wzr, [x8, #0x914]
1001f270c: 91004320    	add	x0, x25, #0x10
1001f2710: 9101c3e1    	add	x1, sp, #0x70
1001f2714: aa1803e2    	mov	x2, x24
1001f2718: 941507af    	bl	0x1007345d4 <<hashbrown::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>, std::hash::random::RandomState>>::insert>
1001f271c: d10363bb    	sub	x27, x29, #0xd8
1001f2720: a93507a0    	stp	x0, x1, [x29, #-0xb0]
1001f2724: b40001a0    	cbz	x0, 0x1001f2758 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc60>
1001f2728: d102c3b4    	sub	x20, x29, #0xb0
1001f272c: 91002280    	add	x0, x20, #0x8
1001f2730: 94147485    	bl	0x10070f944 <<tokio::sync::oneshot::Sender<()> as core::ops::drop::Drop>::drop>
1001f2734: f85583a8    	ldur	x8, [x29, #-0xa8]
1001f2738: b4000108    	cbz	x8, 0x1001f2758 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc60>
1001f273c: 92800009    	mov	x9, #-0x1               ; =-1
1001f2740: f8690108    	ldaddl	x9, x8, [x8]
1001f2744: f100051f    	cmp	x8, #0x1
1001f2748: 54000081    	b.ne	0x1001f2758 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc60>
1001f274c: d50339bf    	dmb	ishld
1001f2750: 91002280    	add	x0, x20, #0x8
1001f2754: 943dc4fa    	bl	0x101163b3c <<alloc::sync::Arc<tokio::sync::oneshot::Inner<()>>>::drop_slow>
1001f2758: 370000da    	tbnz	w26, #0x0, 0x1001f2770 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc78>
1001f275c: 90017c28    	adrp	x8, 0x103176000 <crossbeam_utils::atomic::atomic_cell::lock::LOCKS+0x1b00>
1001f2760: 9125e108    	add	x8, x8, #0x978
1001f2764: f9400108    	ldr	x8, [x8]
1001f2768: f240f91f    	tst	x8, #0x7fffffffffffffff
1001f276c: 54004d81    	b.ne	0x1001f311c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1624>
1001f2770: f9400320    	ldr	x0, [x25]
1001f2774: 9443c5a6    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1001f2778: f9415ff8    	ldr	x24, [sp, #0x2b8]
1001f277c: f9401ff4    	ldr	x20, [sp, #0x38]
1001f2780: 9107a3fa    	add	x26, sp, #0x1e8
1001f2784: ad4202e1    	ldp	q1, q0, [x23, #0x40]
1001f2788: 3d87c260    	str	q0, [x19, #0x1f00]
1001f278c: ad430ae0    	ldp	q0, q2, [x23, #0x60]
1001f2790: 3d87c660    	str	q0, [x19, #0x1f10]
1001f2794: 3d87ca62    	str	q2, [x19, #0x1f20]
1001f2798: 3dc022e0    	ldr	q0, [x23, #0x80]
1001f279c: 3d87ce60    	str	q0, [x19, #0x1f30]
1001f27a0: ad4002e2    	ldp	q2, q0, [x23]
1001f27a4: 3d87b260    	str	q0, [x19, #0x1ec0]
1001f27a8: ad410ee0    	ldp	q0, q3, [x23, #0x20]
1001f27ac: 3d87b660    	str	q0, [x19, #0x1ed0]
1001f27b0: 3d87ba63    	str	q3, [x19, #0x1ee0]
1001f27b4: 3d87be61    	str	q1, [x19, #0x1ef0]
1001f27b8: 91244a88    	add	x8, x20, #0x912
1001f27bc: 7912269f    	strh	wzr, [x20, #0x912]
1001f27c0: 3924569f    	strb	wzr, [x20, #0x915]
1001f27c4: 5283d509    	mov	w9, #0x1ea8             ; =7848
1001f27c8: 8b090269    	add	x9, x19, x9
1001f27cc: f90f5678    	str	x24, [x19, #0x1ea8]
1001f27d0: 3d87ae62    	str	q2, [x19, #0x1eb0]
1001f27d4: 3923e29f    	strb	wzr, [x20, #0x8f8]
1001f27d8: f9107a68    	str	x8, [x19, #0x20f0]
1001f27dc: f9107e69    	str	x9, [x19, #0x20f8]
1001f27e0: 17fffe0f    	b	0x1001f201c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x524>
1001f27e4: 394907f9    	ldrb	w25, [sp, #0x241]
1001f27e8: 9107a3e8    	add	x8, sp, #0x1e8
1001f27ec: b845a108    	ldur	w8, [x8, #0x5a]
1001f27f0: b901e3e8    	str	w8, [sp, #0x1e0]
1001f27f4: 79448fe8    	ldrh	w8, [sp, #0x246]
1001f27f8: 7903cbe8    	strh	w8, [sp, #0x1e4]
1001f27fc: f94127fc    	ldr	x28, [sp, #0x248]
1001f2800: f9412bf5    	ldr	x21, [sp, #0x250]
1001f2804: f9412ff6    	ldr	x22, [sp, #0x258]
1001f2808: f9400fe1    	ldr	x1, [sp, #0x18]
1001f280c: b4000081    	cbz	x1, 0x1001f281c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xd24>
1001f2810: f9400be0    	ldr	x0, [sp, #0x10]
1001f2814: 52800022    	mov	w2, #0x1                ; =1
1001f2818: 97f83b8f    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f281c: b5ffe33a    	cbnz	x26, 0x1001f2480 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x988>
1001f2820: 17ffff1c    	b	0x1001f2490 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x998>
1001f2824: f0008968    	adrp	x8, 0x101321000 <<core::net::socket_addr::SocketAddrV6 as core::fmt::Display>::fmt+0xf0>
1001f2828: 9103b108    	add	x8, x8, #0xec
1001f282c: d102c3a9    	sub	x9, x29, #0xb0
1001f2830: a90723e9    	stp	x9, x8, [sp, #0x70]
1001f2834: b0015660    	adrp	x0, 0x102cbf000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.108+0x134>
1001f2838: 910f6000    	add	x0, x0, #0x3d8
1001f283c: 9101c3e1    	add	x1, sp, #0x70
1001f2840: 94441771    	bl	0x1012f8604 <std::io::stdio::_eprint>
1001f2844: f81703bf    	stur	xzr, [x29, #-0x90]
1001f2848: f81803bf    	stur	xzr, [x29, #-0x80]
1001f284c: 97f83b85    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2850: 52800080    	mov	w0, #0x4                ; =4
1001f2854: 52800021    	mov	w1, #0x1                ; =1
1001f2858: 97f83b7e    	bl	0x100001650 <__rustc::__rust_alloc>
1001f285c: b4004dc0    	cbz	x0, 0x1001f3214 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x171c>
1001f2860: 528dec68    	mov	w8, #0x6f63             ; =28515
1001f2864: 72acac88    	movk	w8, #0x6564, lsl #16
1001f2868: b9000008    	str	w8, [x0]
1001f286c: 52800088    	mov	w8, #0x4                ; =4
1001f2870: a93883a8    	stp	x8, x0, [x29, #-0x78]
1001f2874: f81983a8    	stur	x8, [x29, #-0x68]
1001f2878: 52800048    	mov	w8, #0x2                ; =2
1001f287c: 3901c3e8    	strb	w8, [sp, #0x70]
1001f2880: 90009888    	adrp	x8, 0x101502000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x335>
1001f2884: 3dc2fd00    	ldr	q0, [x8, #0xbf0]
1001f2888: 3c8783e0    	stur	q0, [sp, #0x78]
1001f288c: 910903e8    	add	x8, sp, #0x240
1001f2890: d10243a0    	sub	x0, x29, #0x90
1001f2894: d101e3a1    	sub	x1, x29, #0x78
1001f2898: 9101c3e2    	add	x2, sp, #0x70
1001f289c: 9414330c    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f28a0: 394903e8    	ldrb	w8, [sp, #0x240]
1001f28a4: 7103fd1f    	cmp	w8, #0xff
1001f28a8: 54000060    	b.eq	0x1001f28b4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xdbc>
1001f28ac: 910903e0    	add	x0, sp, #0x240
1001f28b0: 97fe0532    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f28b4: 97f83b6b    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f28b8: 528000c0    	mov	w0, #0x6                ; =6
1001f28bc: 52800021    	mov	w1, #0x1                ; =1
1001f28c0: 97f83b64    	bl	0x100001650 <__rustc::__rust_alloc>
1001f28c4: b4004b00    	cbz	x0, 0x1001f3224 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x172c>
1001f28c8: 528e8ea8    	mov	w8, #0x7475             ; =29813
1001f28cc: 79000808    	strh	w8, [x0, #0x4]
1001f28d0: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f28d4: 72adec88    	movk	w8, #0x6f64, lsl #16
1001f28d8: b9000008    	str	w8, [x0]
1001f28dc: 528000c8    	mov	w8, #0x6                ; =6
1001f28e0: a93883a8    	stp	x8, x0, [x29, #-0x78]
1001f28e4: f81983a8    	stur	x8, [x29, #-0x68]
1001f28e8: 52800068    	mov	w8, #0x3                ; =3
1001f28ec: 3901c3e8    	strb	w8, [sp, #0x70]
1001f28f0: 52800028    	mov	w8, #0x1                ; =1
1001f28f4: a907a3ff    	stp	xzr, x8, [sp, #0x78]
1001f28f8: f90047ff    	str	xzr, [sp, #0x88]
1001f28fc: 910903e8    	add	x8, sp, #0x240
1001f2900: d10243a0    	sub	x0, x29, #0x90
1001f2904: d101e3a1    	sub	x1, x29, #0x78
1001f2908: 9101c3e2    	add	x2, sp, #0x70
1001f290c: 941432f0    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f2910: 394903e8    	ldrb	w8, [sp, #0x240]
1001f2914: 7103fd1f    	cmp	w8, #0xff
1001f2918: 54000060    	b.eq	0x1001f2924 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xe2c>
1001f291c: 910903e0    	add	x0, sp, #0x240
1001f2920: 97fe0516    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f2924: 97f83b4f    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2928: 528000c0    	mov	w0, #0x6                ; =6
1001f292c: 52800021    	mov	w1, #0x1                ; =1
1001f2930: 97f83b48    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2934: b4004800    	cbz	x0, 0x1001f3234 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x173c>
1001f2938: aa0003f7    	mov	x23, x0
1001f293c: 528e4e48    	mov	w8, #0x7272             ; =29298
1001f2940: 79000808    	strh	w8, [x0, #0x4]
1001f2944: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f2948: 72acac88    	movk	w8, #0x6564, lsl #16
1001f294c: b9000008    	str	w8, [x0]
1001f2950: 528000c8    	mov	w8, #0x6                ; =6
1001f2954: a93883a8    	stp	x8, x0, [x29, #-0x78]
1001f2958: f81983a8    	stur	x8, [x29, #-0x68]
1001f295c: 97f83b41    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2960: 528002e0    	mov	w0, #0x17               ; =23
1001f2964: 52800021    	mov	w1, #0x1                ; =1
1001f2968: 97f83b3a    	bl	0x100001650 <__rustc::__rust_alloc>
1001f296c: b40046c0    	cbz	x0, 0x1001f3244 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x174c>
1001f2970: f0009868    	adrp	x8, 0x101501000 <_anon.a1fe893330618e2aa7f7ddee619ac267.0+0xe76>
1001f2974: 91238908    	add	x8, x8, #0x8e2
1001f2978: 3dc00100    	ldr	q0, [x8]
1001f297c: 3d800000    	str	q0, [x0]
1001f2980: f840f108    	ldur	x8, [x8, #0xf]
1001f2984: f800f008    	stur	x8, [x0, #0xf]
1001f2988: 52800068    	mov	w8, #0x3                ; =3
1001f298c: 3901c3e8    	strb	w8, [sp, #0x70]
1001f2990: 528002e8    	mov	w8, #0x17               ; =23
1001f2994: a90783e8    	stp	x8, x0, [sp, #0x78]
1001f2998: f90047e8    	str	x8, [sp, #0x88]
1001f299c: 910903e8    	add	x8, sp, #0x240
1001f29a0: d10243a0    	sub	x0, x29, #0x90
1001f29a4: d101e3a1    	sub	x1, x29, #0x78
1001f29a8: 9101c3e2    	add	x2, sp, #0x70
1001f29ac: 941432c8    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f29b0: 394903e8    	ldrb	w8, [sp, #0x240]
1001f29b4: 7103fd1f    	cmp	w8, #0xff
1001f29b8: 54000060    	b.eq	0x1001f29c4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xecc>
1001f29bc: 910903e0    	add	x0, sp, #0x240
1001f29c0: 97fe04ee    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f29c4: f85803a8    	ldur	x8, [x29, #-0x80]
1001f29c8: 3cd703a0    	ldur	q0, [x29, #-0x90]
1001f29cc: 3c82f360    	stur	q0, [x27, #0x2f]
1001f29d0: f803f368    	stur	x8, [x27, #0x3f]
1001f29d4: 528000bc    	mov	w28, #0x5               ; =5
1001f29d8: 390b03fc    	strb	w28, [sp, #0x2c0]
1001f29dc: 3cd503a0    	ldur	q0, [x29, #-0xb0]
1001f29e0: 3c8d9340    	stur	q0, [x26, #0xd9]
1001f29e4: 3cc37360    	ldur	q0, [x27, #0x37]
1001f29e8: 3d80b7e0    	str	q0, [sp, #0x2d0]
1001f29ec: f0017ba8    	adrp	x8, 0x103169000 <dyld_stub_binder+0x103169000>
1001f29f0: 9111c108    	add	x8, x8, #0x470
1001f29f4: f8bfc108    	ldapr	x8, [x8]
1001f29f8: b50032a8    	cbnz	x8, 0x1001f304c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1554>
1001f29fc: f0017bb8    	adrp	x24, 0x103169000 <dyld_stub_binder+0x103169000>
1001f2a00: 9110c318    	add	x24, x24, #0x430
1001f2a04: f8bfc300    	ldapr	x0, [x24]
1001f2a08: b40032a0    	cbz	x0, 0x1001f305c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1564>
1001f2a0c: 9443c4f9    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
1001f2a10: 90017c34    	adrp	x20, 0x103176000 <crossbeam_utils::atomic::atomic_cell::lock::LOCKS+0x1b00>
1001f2a14: 9125e294    	add	x20, x20, #0x978
1001f2a18: f9400288    	ldr	x8, [x20]
1001f2a1c: f240f91f    	tst	x8, #0x7fffffffffffffff
1001f2a20: 54003261    	b.ne	0x1001f306c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1574>
1001f2a24: 52800017    	mov	w23, #0x0               ; =0
1001f2a28: f0017bb6    	adrp	x22, 0x103169000 <dyld_stub_binder+0x103169000>
1001f2a2c: 3950e2c8    	ldrb	w8, [x22, #0x438]
1001f2a30: 35003288    	cbnz	w8, 0x1001f3080 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1588>
1001f2a34: 52839c19    	mov	w25, #0x1ce0            ; =7392
1001f2a38: f0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f2a3c: 91110000    	add	x0, x0, #0x440
1001f2a40: 8b190261    	add	x1, x19, x25
1001f2a44: 94149d6d    	bl	0x100719ff8 <<hashbrown::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>, std::hash::random::RandomState>>::remove::<alloc::string::String>>
1001f2a48: f90123e0    	str	x0, [sp, #0x240]
1001f2a4c: f90127e1    	str	x1, [sp, #0x248]
1001f2a50: b40002e0    	cbz	x0, 0x1001f2aac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfb4>
1001f2a54: b40002c1    	cbz	x1, 0x1001f2aac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfb4>
1001f2a58: 910903f8    	add	x24, sp, #0x240
1001f2a5c: aa0103fa    	mov	x26, x1
1001f2a60: 9100c020    	add	x0, x1, #0x30
1001f2a64: 943e18bd    	bl	0x101178d58 <<tokio::sync::oneshot::State>::set_complete>
1001f2a68: 528000a8    	mov	w8, #0x5                ; =5
1001f2a6c: 8a080008    	and	x8, x0, x8
1001f2a70: f100051f    	cmp	x8, #0x1
1001f2a74: 54000081    	b.ne	0x1001f2a84 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf8c>
1001f2a78: a9420348    	ldp	x8, x0, [x26, #0x20]
1001f2a7c: f9400908    	ldr	x8, [x8, #0x10]
1001f2a80: d63f0100    	blr	x8
1001f2a84: f94127e8    	ldr	x8, [sp, #0x248]
1001f2a88: 9107a3fa    	add	x26, sp, #0x1e8
1001f2a8c: b4000108    	cbz	x8, 0x1001f2aac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfb4>
1001f2a90: 92800009    	mov	x9, #-0x1               ; =-1
1001f2a94: f8690108    	ldaddl	x9, x8, [x8]
1001f2a98: f100051f    	cmp	x8, #0x1
1001f2a9c: 54000081    	b.ne	0x1001f2aac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfb4>
1001f2aa0: d50339bf    	dmb	ishld
1001f2aa4: 91002300    	add	x0, x24, #0x8
1001f2aa8: 943dc425    	bl	0x101163b3c <<alloc::sync::Arc<tokio::sync::oneshot::Inner<()>>>::drop_slow>
1001f2aac: 37000097    	tbnz	w23, #0x0, 0x1001f2abc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfc4>
1001f2ab0: f9400288    	ldr	x8, [x20]
1001f2ab4: f240f91f    	tst	x8, #0x7fffffffffffffff
1001f2ab8: 54002fc1    	b.ne	0x1001f30b0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x15b8>
1001f2abc: f0017ba8    	adrp	x8, 0x103169000 <dyld_stub_binder+0x103169000>
1001f2ac0: f9421900    	ldr	x0, [x8, #0x430]
1001f2ac4: 9443c4d2    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1001f2ac8: b95ea260    	ldr	w0, [x19, #0x1ea0]
1001f2acc: b95ea661    	ldr	w1, [x19, #0x1ea4]
1001f2ad0: 941622c1    	bl	0x10077b5d4 <conductor_lib::resource_usage::unregister_resource_usage_command_line>
1001f2ad4: b84d9348    	ldur	w8, [x26, #0xd9]
1001f2ad8: b81283a8    	stur	w8, [x29, #-0xd8]
1001f2adc: b942c7e8    	ldr	w8, [sp, #0x2c4]
1001f2ae0: b8003368    	stur	w8, [x27, #0x3]
1001f2ae4: f94167f7    	ldr	x23, [sp, #0x2c8]
1001f2ae8: f9416bf8    	ldr	x24, [sp, #0x2d0]
1001f2aec: f9416ff6    	ldr	x22, [sp, #0x2d8]
1001f2af0: f9401fe8    	ldr	x8, [sp, #0x38]
1001f2af4: 39244d1f    	strb	wzr, [x8, #0x913]
1001f2af8: 7912291f    	strh	wzr, [x8, #0x914]
1001f2afc: 5283a808    	mov	w8, #0x1d40             ; =7488
1001f2b00: 8b080260    	add	x0, x19, x8
1001f2b04: 97fe067d    	bl	0x1001744f8 <core::ptr::drop_glue::<std::process::Command>>
1001f2b08: f94e9661    	ldr	x1, [x19, #0x1d28]
1001f2b0c: b100043f    	cmn	x1, #0x1
1001f2b10: 540000a0    	b.eq	0x1001f2b24 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x102c>
1001f2b14: b4000081    	cbz	x1, 0x1001f2b24 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x102c>
1001f2b18: f94e9a60    	ldr	x0, [x19, #0x1d30]
1001f2b1c: 52800022    	mov	w2, #0x1                ; =1
1001f2b20: 97f83acd    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2b24: f94e8a61    	ldr	x1, [x19, #0x1d10]
1001f2b28: b4000081    	cbz	x1, 0x1001f2b38 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1040>
1001f2b2c: f94e8e60    	ldr	x0, [x19, #0x1d18]
1001f2b30: 52800022    	mov	w2, #0x1                ; =1
1001f2b34: 97f83ac8    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2b38: f94e7e61    	ldr	x1, [x19, #0x1cf8]
1001f2b3c: b4000081    	cbz	x1, 0x1001f2b4c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1054>
1001f2b40: f94e8260    	ldr	x0, [x19, #0x1d00]
1001f2b44: 52800022    	mov	w2, #0x1                ; =1
1001f2b48: 97f83ac3    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2b4c: f8796a61    	ldr	x1, [x19, x25]
1001f2b50: 9107a3f4    	add	x20, sp, #0x1e8
1001f2b54: d10363b9    	sub	x25, x29, #0xd8
1001f2b58: b4000081    	cbz	x1, 0x1001f2b68 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1070>
1001f2b5c: f94e7660    	ldr	x0, [x19, #0x1ce8]
1001f2b60: 52800022    	mov	w2, #0x1                ; =1
1001f2b64: 97f83abc    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2b68: b8403328    	ldur	w8, [x25, #0x3]
1001f2b6c: b8003288    	stur	w8, [x20, #0x3]
1001f2b70: b85283a8    	ldur	w8, [x29, #-0xd8]
1001f2b74: b901ebe8    	str	w8, [sp, #0x1e8]
1001f2b78: 52800028    	mov	w8, #0x1                ; =1
1001f2b7c: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2b80: 39244528    	strb	w8, [x9, #0x911]
1001f2b84: b941ebe8    	ldr	w8, [sp, #0x1e8]
1001f2b88: b901f3e8    	str	w8, [sp, #0x1f0]
1001f2b8c: b8403288    	ldur	w8, [x20, #0x3]
1001f2b90: b800b288    	stur	w8, [x20, #0xb]
1001f2b94: aa1503e0    	mov	x0, x21
1001f2b98: 97fdb53e    	bl	0x100160090 <core::ptr::drop_glue::<conductor_lib::execute_shell_command_cancellable::{closure#0}>>
1001f2b9c: 7103ff9f    	cmp	w28, #0xff
1001f2ba0: 540000e1    	b.ne	0x1001f2bbc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x10c4>
1001f2ba4: b6f806b6    	tbz	x22, #0x3f, 0x1001f2c78 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1180>
1001f2ba8: d2800019    	mov	x25, #0x0               ; =0
1001f2bac: aa1903e0    	mov	x0, x25
1001f2bb0: aa1603e1    	mov	x1, x22
1001f2bb4: 944634bf    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f2bb8: 140001ae    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f2bbc: 3907e3fc    	strb	w28, [sp, #0x1f8]
1001f2bc0: b941f3e8    	ldr	w8, [sp, #0x1f0]
1001f2bc4: b8011288    	stur	w8, [x20, #0x11]
1001f2bc8: b840b288    	ldur	w8, [x20, #0xb]
1001f2bcc: b901ffe8    	str	w8, [sp, #0x1fc]
1001f2bd0: f90103f7    	str	x23, [sp, #0x200]
1001f2bd4: f90107f8    	str	x24, [sp, #0x208]
1001f2bd8: f9010bf6    	str	x22, [sp, #0x210]
1001f2bdc: 9101c3e8    	add	x8, sp, #0x70
1001f2be0: 9107e3e0    	add	x0, sp, #0x1f8
1001f2be4: 94135446    	bl	0x1006c7cfc <<serde_json::value::Value as tauri::ipc::IpcResponse>::body>
1001f2be8: f9403be8    	ldr	x8, [sp, #0x70]
1001f2bec: 3cc783e0    	ldur	q0, [sp, #0x78]
1001f2bf0: 3cc883e1    	ldur	q1, [sp, #0x88]
1001f2bf4: ad1207e0    	stp	q0, q1, [sp, #0x240]
1001f2bf8: b100051f    	cmn	x8, #0x1
1001f2bfc: 54000640    	b.eq	0x1001f2cc4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x11cc>
1001f2c00: 9107a3f4    	add	x20, sp, #0x1e8
1001f2c04: f9404fe9    	ldr	x9, [sp, #0x98]
1001f2c08: f9003be8    	str	x8, [sp, #0x70]
1001f2c0c: ad5207e0    	ldp	q0, q1, [sp, #0x240]
1001f2c10: 3c8783e0    	stur	q0, [sp, #0x78]
1001f2c14: 3c8883e1    	stur	q1, [sp, #0x88]
1001f2c18: f9004fe9    	str	x9, [sp, #0x98]
1001f2c1c: 910863e0    	add	x0, sp, #0x218
1001f2c20: 9101c3e1    	add	x1, sp, #0x70
1001f2c24: 94027e89    	bl	0x100292648 <<core::result::Result<tauri::ipc::InvokeResponseBody, tauri::ipc::InvokeError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, tauri::error::Error>>>::from_residual>
1001f2c28: f9410ffa    	ldr	x26, [sp, #0x218]
1001f2c2c: 394883fb    	ldrb	w27, [sp, #0x220]
1001f2c30: 394887f9    	ldrb	w25, [sp, #0x221]
1001f2c34: b843a288    	ldur	w8, [x20, #0x3a]
1001f2c38: b901dbe8    	str	w8, [sp, #0x1d8]
1001f2c3c: 79444fe8    	ldrh	w8, [sp, #0x226]
1001f2c40: 7903bbe8    	strh	w8, [sp, #0x1dc]
1001f2c44: f94117fc    	ldr	x28, [sp, #0x228]
1001f2c48: f9411bf5    	ldr	x21, [sp, #0x230]
1001f2c4c: f9411ff6    	ldr	x22, [sp, #0x238]
1001f2c50: 52800028    	mov	w8, #0x1                ; =1
1001f2c54: f94017e9    	ldr	x9, [sp, #0x28]
1001f2c58: 39000128    	strb	w8, [x9]
1001f2c5c: f1000b5f    	cmp	x26, #0x2
1001f2c60: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2c64: 54000601    	b.ne	0x1001f2d24 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x122c>
1001f2c68: 52800068    	mov	w8, #0x3                ; =3
1001f2c6c: 39248128    	strb	w8, [x9, #0x920]
1001f2c70: 52800020    	mov	w0, #0x1                ; =1
1001f2c74: 1400006e    	b	0x1001f2e2c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1334>
1001f2c78: b40003b6    	cbz	x22, 0x1001f2cec <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x11f4>
1001f2c7c: 97f83a79    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2c80: 52800039    	mov	w25, #0x1               ; =1
1001f2c84: aa1603e0    	mov	x0, x22
1001f2c88: 52800021    	mov	w1, #0x1                ; =1
1001f2c8c: 97f83a71    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2c90: b4fff8e0    	cbz	x0, 0x1001f2bac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x10b4>
1001f2c94: aa0003f5    	mov	x21, x0
1001f2c98: aa1803e1    	mov	x1, x24
1001f2c9c: aa1603e2    	mov	x2, x22
1001f2ca0: 9446391c    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f2ca4: b4000297    	cbz	x23, 0x1001f2cf4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x11fc>
1001f2ca8: 5280003a    	mov	w26, #0x1               ; =1
1001f2cac: aa1803e0    	mov	x0, x24
1001f2cb0: aa1703e1    	mov	x1, x23
1001f2cb4: 52800022    	mov	w2, #0x1                ; =1
1001f2cb8: 97f83a67    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2cbc: 5280007b    	mov	w27, #0x3               ; =3
1001f2cc0: 1400000f    	b	0x1001f2cfc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1204>
1001f2cc4: 9107a3e8    	add	x8, sp, #0x1e8
1001f2cc8: d280001a    	mov	x26, #0x0               ; =0
1001f2ccc: ad5203e1    	ldp	q1, q0, [sp, #0x240]
1001f2cd0: 3c848100    	stur	q0, [x8, #0x48]
1001f2cd4: 3c838101    	stur	q1, [x8, #0x38]
1001f2cd8: 394883fb    	ldrb	w27, [sp, #0x220]
1001f2cdc: f94117fc    	ldr	x28, [sp, #0x228]
1001f2ce0: f9411bf5    	ldr	x21, [sp, #0x230]
1001f2ce4: f9411ff6    	ldr	x22, [sp, #0x238]
1001f2ce8: 14000007    	b	0x1001f2d04 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x120c>
1001f2cec: 52800035    	mov	w21, #0x1               ; =1
1001f2cf0: b5fffdd7    	cbnz	x23, 0x1001f2ca8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x11b0>
1001f2cf4: 5280007b    	mov	w27, #0x3               ; =3
1001f2cf8: 5280003a    	mov	w26, #0x1               ; =1
1001f2cfc: aa1603fc    	mov	x28, x22
1001f2d00: 9107a3e8    	add	x8, sp, #0x1e8
1001f2d04: 394887f9    	ldrb	w25, [sp, #0x221]
1001f2d08: b843a108    	ldur	w8, [x8, #0x3a]
1001f2d0c: b901dbe8    	str	w8, [sp, #0x1d8]
1001f2d10: 79444fe8    	ldrh	w8, [sp, #0x226]
1001f2d14: 7903bbe8    	strh	w8, [sp, #0x1dc]
1001f2d18: 52800028    	mov	w8, #0x1                ; =1
1001f2d1c: f94017e9    	ldr	x9, [sp, #0x28]
1001f2d20: 39000128    	strb	w8, [x9]
1001f2d24: b941dbe8    	ldr	w8, [sp, #0x1d8]
1001f2d28: b901e3e8    	str	w8, [sp, #0x1e0]
1001f2d2c: 7943bbe8    	ldrh	w8, [sp, #0x1dc]
1001f2d30: 7903cbe8    	strh	w8, [sp, #0x1e4]
1001f2d34: f9401be0    	ldr	x0, [sp, #0x30]
1001f2d38: 97fe0f47    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001f2d3c: f949ae68    	ldr	x8, [x19, #0x1358]
1001f2d40: b100051f    	cmn	x8, #0x1
1001f2d44: 54000260    	b.eq	0x1001f2d90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1298>
1001f2d48: 52826c08    	mov	w8, #0x1360             ; =4960
1001f2d4c: 8b080274    	add	x20, x19, x8
1001f2d50: f949b260    	ldr	x0, [x19, #0x1360]
1001f2d54: f949b668    	ldr	x8, [x19, #0x1368]
1001f2d58: 91000518    	add	x24, x8, #0x1
1001f2d5c: f1000718    	subs	x24, x24, #0x1
1001f2d60: 540000a0    	b.eq	0x1001f2d74 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x127c>
1001f2d64: 91018017    	add	x23, x0, #0x60
1001f2d68: 9415b59c    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001f2d6c: aa1703e0    	mov	x0, x23
1001f2d70: 17fffffb    	b	0x1001f2d5c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1264>
1001f2d74: f949ae68    	ldr	x8, [x19, #0x1358]
1001f2d78: b40000c8    	cbz	x8, 0x1001f2d90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1298>
1001f2d7c: f9400280    	ldr	x0, [x20]
1001f2d80: 8b080508    	add	x8, x8, x8, lsl #1
1001f2d84: d37be901    	lsl	x1, x8, #5
1001f2d88: 52800102    	mov	w2, #0x8                ; =8
1001f2d8c: 97f83a32    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2d90: b941e3e8    	ldr	w8, [sp, #0x1e0]
1001f2d94: b9006be8    	str	w8, [sp, #0x68]
1001f2d98: 7943cbe8    	ldrh	w8, [sp, #0x1e4]
1001f2d9c: 7900dbe8    	strh	w8, [sp, #0x6c]
1001f2da0: 52800028    	mov	w8, #0x1                ; =1
1001f2da4: a94353e0    	ldp	x0, x20, [sp, #0x30]
1001f2da8: 39248288    	strb	w8, [x20, #0x920]
1001f2dac: 97fd9794    	bl	0x100158bfc <core::ptr::drop_glue::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>>
1001f2db0: b9406be8    	ldr	w8, [sp, #0x68]
1001f2db4: b804a3e8    	stur	w8, [sp, #0x4a]
1001f2db8: 7940dbe8    	ldrh	w8, [sp, #0x6c]
1001f2dbc: 79009fe8    	strh	w8, [sp, #0x4e]
1001f2dc0: a90557fc    	stp	x28, x21, [sp, #0x50]
1001f2dc4: f90033f6    	str	x22, [sp, #0x60]
1001f2dc8: 92400348    	and	x8, x26, #0x1
1001f2dcc: 390123fb    	strb	w27, [sp, #0x48]
1001f2dd0: 390127f9    	strb	w25, [sp, #0x49]
1001f2dd4: f90023e8    	str	x8, [sp, #0x40]
1001f2dd8: 3924ce9f    	strb	wzr, [x20, #0x933]
1001f2ddc: 9101c3e0    	add	x0, sp, #0x70
1001f2de0: aa1303e1    	mov	x1, x19
1001f2de4: 52802d02    	mov	w2, #0x168              ; =360
1001f2de8: 944638ca    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f2dec: 3924ca9f    	strb	wzr, [x20, #0x932]
1001f2df0: 3924c69f    	strb	wzr, [x20, #0x931]
1001f2df4: 9105a268    	add	x8, x19, #0x168
1001f2df8: 3dc00100    	ldr	q0, [x8]
1001f2dfc: 3d8093e0    	str	q0, [sp, #0x240]
1001f2e00: a9578668    	ldp	x8, x1, [x19, #0x178]
1001f2e04: f9012be8    	str	x8, [sp, #0x250]
1001f2e08: b9611a64    	ldr	w4, [x19, #0x2118]
1001f2e0c: b9611e65    	ldr	w5, [x19, #0x211c]
1001f2e10: 9101c3e0    	add	x0, sp, #0x70
1001f2e14: 910103e2    	add	x2, sp, #0x40
1001f2e18: 910903e3    	add	x3, sp, #0x240
1001f2e1c: 9410602b    	bl	0x10060aec8 <<tauri::ipc::InvokeResolver>::return_result>
1001f2e20: 52800000    	mov	w0, #0x0                ; =0
1001f2e24: 52800028    	mov	w8, #0x1                ; =1
1001f2e28: f9401fe9    	ldr	x9, [sp, #0x38]
1001f2e2c: 3924c128    	strb	w8, [x9, #0x930]
1001f2e30: 910e43ff    	add	sp, sp, #0x390
1001f2e34: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1001f2e38: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1001f2e3c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1001f2e40: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1001f2e44: a94167fa    	ldp	x26, x25, [sp, #0x10]
1001f2e48: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1001f2e4c: d65f03c0    	ret
1001f2e50: 5280003a    	mov	w26, #0x1               ; =1
1001f2e54: 5280003c    	mov	w28, #0x1               ; =1
1001f2e58: 52800068    	mov	w8, #0x3                ; =3
1001f2e5c: 390903e8    	strb	w8, [sp, #0x240]
1001f2e60: f90127f9    	str	x25, [sp, #0x248]
1001f2e64: f9012bfc    	str	x28, [sp, #0x250]
1001f2e68: f9012ff9    	str	x25, [sp, #0x258]
1001f2e6c: d102c3a8    	sub	x8, x29, #0xb0
1001f2e70: d10343a0    	sub	x0, x29, #0xd0
1001f2e74: d10243a1    	sub	x1, x29, #0x90
1001f2e78: 910903e2    	add	x2, sp, #0x240
1001f2e7c: 94143194    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f2e80: 385503a8    	ldurb	w8, [x29, #-0xb0]
1001f2e84: 7103fd1f    	cmp	w8, #0xff
1001f2e88: 54000060    	b.eq	0x1001f2e94 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x139c>
1001f2e8c: d102c3a0    	sub	x0, x29, #0xb0
1001f2e90: 97fe03ba    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f2e94: b40000b9    	cbz	x25, 0x1001f2ea8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x13b0>
1001f2e98: aa1a03e0    	mov	x0, x26
1001f2e9c: aa1903e1    	mov	x1, x25
1001f2ea0: 52800022    	mov	w2, #0x1                ; =1
1001f2ea4: 97f839ec    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2ea8: f85883a1    	ldur	x1, [x29, #-0x78]
1001f2eac: f100003f    	cmp	x1, #0x0
1001f2eb0: 5400008d    	b.le	0x1001f2ec0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x13c8>
1001f2eb4: aa1803e0    	mov	x0, x24
1001f2eb8: 52800022    	mov	w2, #0x1                ; =1
1001f2ebc: 97f839e6    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2ec0: 97f839e8    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2ec4: 528000d8    	mov	w24, #0x6               ; =6
1001f2ec8: 528000c0    	mov	w0, #0x6                ; =6
1001f2ecc: 52800021    	mov	w1, #0x1                ; =1
1001f2ed0: 97f839e0    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2ed4: b40018a0    	cbz	x0, 0x1001f31e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x16f0>
1001f2ed8: aa0003fc    	mov	x28, x0
1001f2edc: 528e4e48    	mov	w8, #0x7272             ; =29298
1001f2ee0: 79000808    	strh	w8, [x0, #0x4]
1001f2ee4: 528e8e68    	mov	w8, #0x7473             ; =29811
1001f2ee8: 72acac88    	movk	w8, #0x6564, lsl #16
1001f2eec: b9000008    	str	w8, [x0]
1001f2ef0: 528000c8    	mov	w8, #0x6                ; =6
1001f2ef4: a93703a8    	stp	x8, x0, [x29, #-0x90]
1001f2ef8: f81803a8    	stur	x8, [x29, #-0x80]
1001f2efc: a94907fa    	ldp	x26, x1, [sp, #0x90]
1001f2f00: d101e3a8    	sub	x8, x29, #0x78
1001f2f04: aa1a03e0    	mov	x0, x26
1001f2f08: 944474ae    	bl	0x1013101c0 <<alloc::string::String>::from_utf8_lossy>
1001f2f0c: a97967b4    	ldp	x20, x25, [x29, #-0x70]
1001f2f10: b6f800d9    	tbz	x25, #0x3f, 0x1001f2f28 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1430>
1001f2f14: d2800018    	mov	x24, #0x0               ; =0
1001f2f18: aa1803e0    	mov	x0, x24
1001f2f1c: aa1903e1    	mov	x1, x25
1001f2f20: 944633e4    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f2f24: 140000d3    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f2f28: b40002b9    	cbz	x25, 0x1001f2f7c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1484>
1001f2f2c: 97f839cd    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2f30: 52800038    	mov	w24, #0x1               ; =1
1001f2f34: aa1903e0    	mov	x0, x25
1001f2f38: 52800021    	mov	w1, #0x1                ; =1
1001f2f3c: 97f839c5    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2f40: b4fffec0    	cbz	x0, 0x1001f2f18 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1420>
1001f2f44: aa0003fb    	mov	x27, x0
1001f2f48: aa1403e1    	mov	x1, x20
1001f2f4c: aa1903e2    	mov	x2, x25
1001f2f50: 94463870    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f2f54: 97f839c3    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001f2f58: aa1903e0    	mov	x0, x25
1001f2f5c: 52800021    	mov	w1, #0x1                ; =1
1001f2f60: 97f839bc    	bl	0x100001650 <__rustc::__rust_alloc>
1001f2f64: b4001800    	cbz	x0, 0x1001f3264 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x176c>
1001f2f68: aa0003f8    	mov	x24, x0
1001f2f6c: aa1b03e1    	mov	x1, x27
1001f2f70: aa1903e2    	mov	x2, x25
1001f2f74: 94463867    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001f2f78: 14000003    	b	0x1001f2f84 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x148c>
1001f2f7c: 5280003b    	mov	w27, #0x1               ; =1
1001f2f80: 52800038    	mov	w24, #0x1               ; =1
1001f2f84: 52800068    	mov	w8, #0x3                ; =3
1001f2f88: 390903e8    	strb	w8, [sp, #0x240]
1001f2f8c: f90127f9    	str	x25, [sp, #0x248]
1001f2f90: f9012bf8    	str	x24, [sp, #0x250]
1001f2f94: f9012ff9    	str	x25, [sp, #0x258]
1001f2f98: d102c3a8    	sub	x8, x29, #0xb0
1001f2f9c: d10343a0    	sub	x0, x29, #0xd0
1001f2fa0: d10243a1    	sub	x1, x29, #0x90
1001f2fa4: 910903e2    	add	x2, sp, #0x240
1001f2fa8: 94143149    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
1001f2fac: 385503a8    	ldurb	w8, [x29, #-0xb0]
1001f2fb0: 7103fd1f    	cmp	w8, #0xff
1001f2fb4: 54000060    	b.eq	0x1001f2fc0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x14c8>
1001f2fb8: d102c3a0    	sub	x0, x29, #0xb0
1001f2fbc: 97fe036f    	bl	0x100173d78 <core::ptr::drop_glue::<serde_json::value::Value>>
1001f2fc0: b40000b9    	cbz	x25, 0x1001f2fd4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x14dc>
1001f2fc4: aa1b03e0    	mov	x0, x27
1001f2fc8: aa1903e1    	mov	x1, x25
1001f2fcc: 52800022    	mov	w2, #0x1                ; =1
1001f2fd0: 97f839a1    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2fd4: f85883a1    	ldur	x1, [x29, #-0x78]
1001f2fd8: f100003f    	cmp	x1, #0x0
1001f2fdc: 5400008d    	b.le	0x1001f2fec <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x14f4>
1001f2fe0: aa1403e0    	mov	x0, x20
1001f2fe4: 52800022    	mov	w2, #0x1                ; =1
1001f2fe8: 97f8399b    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f2fec: f85303b4    	ldur	x20, [x29, #-0xd0]
1001f2ff0: d10363bb    	sub	x27, x29, #0xd8
1001f2ff4: 3cc10360    	ldur	q0, [x27, #0x10]
1001f2ff8: 3d8093e0    	str	q0, [sp, #0x240]
1001f2ffc: b40000b6    	cbz	x22, 0x1001f3010 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1518>
1001f3000: aa1703e0    	mov	x0, x23
1001f3004: aa1603e1    	mov	x1, x22
1001f3008: 52800022    	mov	w2, #0x1                ; =1
1001f300c: 97f83992    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3010: f94047e1    	ldr	x1, [sp, #0x88]
1001f3014: b4000081    	cbz	x1, 0x1001f3024 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x152c>
1001f3018: aa1a03e0    	mov	x0, x26
1001f301c: 52800022    	mov	w2, #0x1                ; =1
1001f3020: 97f8398d    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3024: 3dc093e0    	ldr	q0, [sp, #0x240]
1001f3028: 3d80b7e0    	str	q0, [sp, #0x2d0]
1001f302c: 528000bc    	mov	w28, #0x5               ; =5
1001f3030: 390b03fc    	strb	w28, [sp, #0x2c0]
1001f3034: f90167f4    	str	x20, [sp, #0x2c8]
1001f3038: 9107a3fa    	add	x26, sp, #0x1e8
1001f303c: d0017ba8    	adrp	x8, 0x103169000 <dyld_stub_binder+0x103169000>
1001f3040: 9111c108    	add	x8, x8, #0x470
1001f3044: f8bfc108    	ldapr	x8, [x8]
1001f3048: b4ffcda8    	cbz	x8, 0x1001f29fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf04>
1001f304c: d0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f3050: 9110c000    	add	x0, x0, #0x430
1001f3054: 9444dd73    	bl	0x10132a620 <<std::sync::once_lock::OnceLock<std::sync::poison::mutex::Mutex<std::collections::hash::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::poison::mutex::Mutex<std::collections::hash::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>>>>>::get_or_init<conductor_lib::cancellable_shell_registry::{closure#0}>::{closure#0}, !>>
1001f3058: 17fffe69    	b	0x1001f29fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf04>
1001f305c: d0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f3060: 9110c000    	add	x0, x0, #0x430
1001f3064: 9444db21    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
1001f3068: 17fffe69    	b	0x1001f2a0c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf14>
1001f306c: 94463275    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1001f3070: 52000017    	eor	w23, w0, #0x1
1001f3074: d0017bb6    	adrp	x22, 0x103169000 <dyld_stub_binder+0x103169000>
1001f3078: 3950e2c8    	ldrb	w8, [x22, #0x438]
1001f307c: 34ffcdc8    	cbz	w8, 0x1001f2a34 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xf3c>
1001f3080: f9003bf8    	str	x24, [sp, #0x70]
1001f3084: 3901e3f7    	strb	w23, [sp, #0x78]
1001f3088: f0009860    	adrp	x0, 0x101502000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x335>
1001f308c: 910e6400    	add	x0, x0, #0x399
1001f3090: 900173c3    	adrp	x3, 0x10306b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.1000+0xde0>
1001f3094: 9111c063    	add	x3, x3, #0x470
1001f3098: d00173a4    	adrp	x4, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f309c: 9128e084    	add	x4, x4, #0xa38
1001f30a0: 9101c3e2    	add	x2, sp, #0x70
1001f30a4: 52800561    	mov	w1, #0x2b               ; =43
1001f30a8: 94463401    	bl	0x1013800ac <core::result::unwrap_failed>
1001f30ac: 14000071    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f30b0: 94463264    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1001f30b4: 3707d040    	tbnz	w0, #0x0, 0x1001f2abc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfc4>
1001f30b8: 52800028    	mov	w8, #0x1                ; =1
1001f30bc: 3910e2c8    	strb	w8, [x22, #0x438]
1001f30c0: 17fffe7f    	b	0x1001f2abc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xfc4>
1001f30c4: 52800100    	mov	w0, #0x8                ; =8
1001f30c8: 52800801    	mov	w1, #0x40               ; =64
1001f30cc: 94463373    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
1001f30d0: 14000068    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f30d4: d0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f30d8: 9110c000    	add	x0, x0, #0x430
1001f30dc: 9444dd51    	bl	0x10132a620 <<std::sync::once_lock::OnceLock<std::sync::poison::mutex::Mutex<std::collections::hash::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::poison::mutex::Mutex<std::collections::hash::map::HashMap<alloc::string::String, tokio::sync::oneshot::Sender<()>>>>>::get_or_init<conductor_lib::cancellable_shell_registry::{closure#0}>::{closure#0}, !>>
1001f30e0: 17fffd7d    	b	0x1001f26d4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xbdc>
1001f30e4: f9403fe8    	ldr	x8, [sp, #0x78]
1001f30e8: 394203e9    	ldrb	w9, [sp, #0x80]
1001f30ec: f90123e8    	str	x8, [sp, #0x240]
1001f30f0: 390923e9    	strb	w9, [sp, #0x248]
1001f30f4: f0009860    	adrp	x0, 0x101502000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x335>
1001f30f8: 910e6400    	add	x0, x0, #0x399
1001f30fc: 900173c3    	adrp	x3, 0x10306b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.1000+0xde0>
1001f3100: 9111c063    	add	x3, x3, #0x470
1001f3104: d00173a4    	adrp	x4, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f3108: 91282084    	add	x4, x4, #0xa08
1001f310c: 910903e2    	add	x2, sp, #0x240
1001f3110: 52800561    	mov	w1, #0x2b               ; =43
1001f3114: 944633e6    	bl	0x1013800ac <core::result::unwrap_failed>
1001f3118: 14000056    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f311c: 94463249    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1001f3120: 3707b280    	tbnz	w0, #0x0, 0x1001f2770 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc78>
1001f3124: 52800028    	mov	w8, #0x1                ; =1
1001f3128: 39002328    	strb	w8, [x25, #0x8]
1001f312c: 17fffd91    	b	0x1001f2770 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0xc78>
1001f3130: b00173a0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001f3134: 9114a000    	add	x0, x0, #0x528
1001f3138: 9446349e    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001f313c: b00173a0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001f3140: 9114a000    	add	x0, x0, #0x528
1001f3144: 944634a2    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001f3148: d00173a0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f314c: 911d4000    	add	x0, x0, #0x750
1001f3150: 94463498    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001f3154: 14000047    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3158: d00173a0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f315c: 911d4000    	add	x0, x0, #0x750
1001f3160: 9446349b    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001f3164: 14000043    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3168: d00173a0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f316c: 91288000    	add	x0, x0, #0xa20
1001f3170: 94463490    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001f3174: 1400003f    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3178: d00173a0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f317c: 91288000    	add	x0, x0, #0xa20
1001f3180: 94463493    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001f3184: 1400003b    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3188: b00173a0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001f318c: 91144000    	add	x0, x0, #0x510
1001f3190: 94463488    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001f3194: 14000037    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3198: b00173a0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001f319c: 91144000    	add	x0, x0, #0x510
1001f31a0: 9446348b    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001f31a4: 14000033    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31a8: 52800020    	mov	w0, #0x1                ; =1
1001f31ac: 52800081    	mov	w1, #0x4                ; =4
1001f31b0: 94463340    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f31b4: 1400002f    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31b8: 52800020    	mov	w0, #0x1                ; =1
1001f31bc: 528000c1    	mov	w1, #0x6                ; =6
1001f31c0: 9446333c    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f31c4: 1400002b    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31c8: 52800020    	mov	w0, #0x1                ; =1
1001f31cc: 528000c1    	mov	w1, #0x6                ; =6
1001f31d0: 94463338    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f31d4: 14000027    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31d8: 52800020    	mov	w0, #0x1                ; =1
1001f31dc: 528002e1    	mov	w1, #0x17               ; =23
1001f31e0: 94463334    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f31e4: 14000023    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31e8: 52800020    	mov	w0, #0x1                ; =1
1001f31ec: aa1803e1    	mov	x1, x24
1001f31f0: 94463330    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f31f4: 1400001f    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f31f8: b0009860    	adrp	x0, 0x101500000 <dyld_stub_binder+0x101500000>
1001f31fc: 9117cc00    	add	x0, x0, #0x5f3
1001f3200: d00173a2    	adrp	x2, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001f3204: 91294042    	add	x2, x2, #0xa50
1001f3208: 52800d61    	mov	w1, #0x6b               ; =107
1001f320c: 94463424    	bl	0x10138029c <core::panicking::panic_fmt>
1001f3210: 14000018    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3214: 52800020    	mov	w0, #0x1                ; =1
1001f3218: 52800081    	mov	w1, #0x4                ; =4
1001f321c: 94463325    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3220: 14000014    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3224: 52800020    	mov	w0, #0x1                ; =1
1001f3228: 528000c1    	mov	w1, #0x6                ; =6
1001f322c: 94463321    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3230: 14000010    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3234: 52800020    	mov	w0, #0x1                ; =1
1001f3238: 528000c1    	mov	w1, #0x6                ; =6
1001f323c: 9446331d    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3240: 1400000c    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3244: 52800020    	mov	w0, #0x1                ; =1
1001f3248: 528002e1    	mov	w1, #0x17               ; =23
1001f324c: 94463319    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3250: 14000008    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3254: 52800020    	mov	w0, #0x1                ; =1
1001f3258: aa1903e1    	mov	x1, x25
1001f325c: 94463315    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3260: 14000004    	b	0x1001f3270 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1778>
1001f3264: 52800020    	mov	w0, #0x1                ; =1
1001f3268: aa1903e1    	mov	x1, x25
1001f326c: 94463311    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001f3270: d4200020    	brk	#0x1
1001f3274: 14000022    	b	0x1001f32fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1804>
1001f3278: 140000a7    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f327c: 14000007    	b	0x1001f3298 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x17a0>
1001f3280: aa0003f6    	mov	x22, x0
1001f3284: aa1c03e0    	mov	x0, x28
1001f3288: 528000c1    	mov	w1, #0x6                ; =6
1001f328c: 52800022    	mov	w2, #0x1                ; =1
1001f3290: 97f838f1    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3294: 14000003    	b	0x1001f32a0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x17a8>
1001f3298: aa0003f6    	mov	x22, x0
1001f329c: b40020b9    	cbz	x25, 0x1001f36b0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bb8>
1001f32a0: aa1b03e0    	mov	x0, x27
1001f32a4: aa1903e1    	mov	x1, x25
1001f32a8: 14000100    	b	0x1001f36a8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bb0>
1001f32ac: aa0003f6    	mov	x22, x0
1001f32b0: f85583a8    	ldur	x8, [x29, #-0xa8]
1001f32b4: b4000268    	cbz	x8, 0x1001f3300 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1808>
1001f32b8: 92800009    	mov	x9, #-0x1               ; =-1
1001f32bc: f8690108    	ldaddl	x9, x8, [x8]
1001f32c0: f100051f    	cmp	x8, #0x1
1001f32c4: 540001e1    	b.ne	0x1001f3300 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1808>
1001f32c8: d50339bf    	dmb	ishld
1001f32cc: 91002280    	add	x0, x20, #0x8
1001f32d0: 943dc21b    	bl	0x101163b3c <<alloc::sync::Arc<tokio::sync::oneshot::Inner<()>>>::drop_slow>
1001f32d4: 1400000b    	b	0x1001f3300 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1808>
1001f32d8: 9446338f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f32dc: 14000013    	b	0x1001f3328 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1830>
1001f32e0: aa0003f6    	mov	x22, x0
1001f32e4: aa1b03e0    	mov	x0, x27
1001f32e8: 528000c1    	mov	w1, #0x6                ; =6
1001f32ec: 52800022    	mov	w2, #0x1                ; =1
1001f32f0: 97f838d9    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f32f4: 1400000f    	b	0x1001f3330 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1838>
1001f32f8: 14000001    	b	0x1001f32fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1804>
1001f32fc: aa0003f6    	mov	x22, x0
1001f3300: aa1903e0    	mov	x0, x25
1001f3304: aa1a03e1    	mov	x1, x26
1001f3308: 97fc9fe9    	bl	0x10011b2ac <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<core::option::Option<tokio::sync::mpsc::unbounded::UnboundedSender<tauri_plugin_store::store::AutoSaveMessage>>>>>
1001f330c: 140000fd    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f3310: 14000081    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f3314: 14000080    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f3318: 1400007f    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f331c: aa0003f6    	mov	x22, x0
1001f3320: aa1c03e0    	mov	x0, x28
1001f3324: 1400001d    	b	0x1001f3398 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x18a0>
1001f3328: aa0003f6    	mov	x22, x0
1001f332c: b4001d79    	cbz	x25, 0x1001f36d8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1be0>
1001f3330: aa1a03e0    	mov	x0, x26
1001f3334: aa1903e1    	mov	x1, x25
1001f3338: 140000e6    	b	0x1001f36d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bd8>
1001f333c: aa0003f6    	mov	x22, x0
1001f3340: f85503a0    	ldur	x0, [x29, #-0xb0]
1001f3344: 97fe1045    	bl	0x100177458 <core::ptr::drop_glue::<core::io::error::Error>>
1001f3348: 140000ee    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f334c: 94463372    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3350: aa0003f6    	mov	x22, x0
1001f3354: f9400fe8    	ldr	x8, [sp, #0x18]
1001f3358: b40002e8    	cbz	x8, 0x1001f33b4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x18bc>
1001f335c: a94107e0    	ldp	x0, x1, [sp, #0x10]
1001f3360: 52800022    	mov	w2, #0x1                ; =1
1001f3364: 97f838bc    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3368: b400097a    	cbz	x26, 0x1001f3494 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x199c>
1001f336c: 14000013    	b	0x1001f33b8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x18c0>
1001f3370: 14000069    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f3374: 14000068    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f3378: aa0003f6    	mov	x22, x0
1001f337c: 140000be    	b	0x1001f3674 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b7c>
1001f3380: aa0003f6    	mov	x22, x0
1001f3384: 140000bc    	b	0x1001f3674 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b7c>
1001f3388: 1400001f    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f338c: 1400001e    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f3390: aa0003f6    	mov	x22, x0
1001f3394: aa1b03e0    	mov	x0, x27
1001f3398: 528000c1    	mov	w1, #0x6                ; =6
1001f339c: 140000d3    	b	0x1001f36e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bf0>
1001f33a0: 14000019    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f33a4: 1400005a    	b	0x1001f350c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a14>
1001f33a8: aa0003f6    	mov	x22, x0
1001f33ac: f9400fe8    	ldr	x8, [sp, #0x18]
1001f33b0: b5fffd68    	cbnz	x8, 0x1001f335c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1864>
1001f33b4: b400071a    	cbz	x26, 0x1001f3494 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x199c>
1001f33b8: f94017e0    	ldr	x0, [sp, #0x28]
1001f33bc: aa1a03e1    	mov	x1, x26
1001f33c0: 52800022    	mov	w2, #0x1                ; =1
1001f33c4: 97f838a4    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f33c8: b5000698    	cbnz	x24, 0x1001f3498 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19a0>
1001f33cc: 14000111    	b	0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f33d0: aa0003f6    	mov	x22, x0
1001f33d4: 140000df    	b	0x1001f3750 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c58>
1001f33d8: 1400000b    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f33dc: aa0003f6    	mov	x22, x0
1001f33e0: aa1703e0    	mov	x0, x23
1001f33e4: 528000c1    	mov	w1, #0x6                ; =6
1001f33e8: 52800022    	mov	w2, #0x1                ; =1
1001f33ec: 97f8389a    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f33f0: 14000006    	b	0x1001f3408 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1910>
1001f33f4: 14000004    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f33f8: 14000003    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f33fc: 14000002    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f3400: 14000001    	b	0x1001f3404 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x190c>
1001f3404: aa0003f6    	mov	x22, x0
1001f3408: d10243a0    	sub	x0, x29, #0x90
1001f340c: 94146ed5    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1001f3410: 140000bc    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f3414: 14000040    	b	0x1001f3514 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a1c>
1001f3418: 14000032    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f341c: 14000031    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f3420: 14000030    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f3424: aa0003f6    	mov	x22, x0
1001f3428: f94127e8    	ldr	x8, [sp, #0x248]
1001f342c: b4000668    	cbz	x8, 0x1001f34f8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a00>
1001f3430: 92800009    	mov	x9, #-0x1               ; =-1
1001f3434: f8690108    	ldaddl	x9, x8, [x8]
1001f3438: f100051f    	cmp	x8, #0x1
1001f343c: 540005e1    	b.ne	0x1001f34f8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a00>
1001f3440: d50339bf    	dmb	ishld
1001f3444: 91002300    	add	x0, x24, #0x8
1001f3448: 943dc1bd    	bl	0x101163b3c <<alloc::sync::Arc<tokio::sync::oneshot::Inner<()>>>::drop_slow>
1001f344c: 1400002b    	b	0x1001f34f8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a00>
1001f3450: 94463331    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3454: aa0003f6    	mov	x22, x0
1001f3458: f94163e0    	ldr	x0, [sp, #0x2c0]
1001f345c: 97fe0fff    	bl	0x100177458 <core::ptr::drop_glue::<core::io::error::Error>>
1001f3460: 140000ba    	b	0x1001f3748 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c50>
1001f3464: 9446332c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3468: 14000044    	b	0x1001f3578 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a80>
1001f346c: 14000002    	b	0x1001f3474 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x197c>
1001f3470: 14000001    	b	0x1001f3474 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x197c>
1001f3474: aa0003f6    	mov	x22, x0
1001f3478: 14000085    	b	0x1001f368c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b94>
1001f347c: aa0003f6    	mov	x22, x0
1001f3480: b40000ba    	cbz	x26, 0x1001f3494 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x199c>
1001f3484: f94017e0    	ldr	x0, [sp, #0x28]
1001f3488: aa1a03e1    	mov	x1, x26
1001f348c: 52800022    	mov	w2, #0x1                ; =1
1001f3490: 97f83871    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3494: b4001bf8    	cbz	x24, 0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f3498: f94013e0    	ldr	x0, [sp, #0x20]
1001f349c: 1400002c    	b	0x1001f354c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a54>
1001f34a0: 14000010    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f34a4: aa0003f6    	mov	x22, x0
1001f34a8: aa1703e0    	mov	x0, x23
1001f34ac: 528000c1    	mov	w1, #0x6                ; =6
1001f34b0: 52800022    	mov	w2, #0x1                ; =1
1001f34b4: 97f83868    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f34b8: 1400000b    	b	0x1001f34e4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19ec>
1001f34bc: 1400001f    	b	0x1001f3538 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a40>
1001f34c0: 14000008    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f34c4: 1400001d    	b	0x1001f3538 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a40>
1001f34c8: 14000006    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f34cc: 1400001b    	b	0x1001f3538 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a40>
1001f34d0: 14000004    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f34d4: 14000019    	b	0x1001f3538 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a40>
1001f34d8: 14000018    	b	0x1001f3538 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a40>
1001f34dc: 14000001    	b	0x1001f34e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x19e8>
1001f34e0: aa0003f6    	mov	x22, x0
1001f34e4: 910b03e0    	add	x0, sp, #0x2c0
1001f34e8: 94146e9e    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1001f34ec: 1400009c    	b	0x1001f375c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c64>
1001f34f0: 1400001b    	b	0x1001f355c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a64>
1001f34f4: aa0003f6    	mov	x22, x0
1001f34f8: d0017ba0    	adrp	x0, 0x103169000 <dyld_stub_binder+0x103169000>
1001f34fc: 9110c000    	add	x0, x0, #0x430
1001f3500: aa1703e1    	mov	x1, x23
1001f3504: 97fc9f6a    	bl	0x10011b2ac <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<core::option::Option<tokio::sync::mpsc::unbounded::UnboundedSender<tauri_plugin_store::store::AutoSaveMessage>>>>>
1001f3508: 14000061    	b	0x1001f368c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b94>
1001f350c: aa0003f6    	mov	x22, x0
1001f3510: 14000078    	b	0x1001f36f0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bf8>
1001f3514: aa0003f6    	mov	x22, x0
1001f3518: 1400007a    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f351c: 14000017    	b	0x1001f3578 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a80>
1001f3520: aa0003f6    	mov	x22, x0
1001f3524: 52826b08    	mov	w8, #0x1358             ; =4952
1001f3528: 8b080260    	add	x0, x19, x8
1001f352c: 97fc80c1    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001f3530: 140000bd    	b	0x1001f3824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d2c>
1001f3534: 1400000a    	b	0x1001f355c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1a64>
1001f3538: aa0003f6    	mov	x22, x0
1001f353c: 14000083    	b	0x1001f3748 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c50>
1001f3540: aa0003f6    	mov	x22, x0
1001f3544: b4001678    	cbz	x24, 0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f3548: aa1903e0    	mov	x0, x25
1001f354c: aa1803e1    	mov	x1, x24
1001f3550: 52800022    	mov	w2, #0x1                ; =1
1001f3554: 97f83840    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3558: 140000ae    	b	0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f355c: aa0003f6    	mov	x22, x0
1001f3560: 1400007f    	b	0x1001f375c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c64>
1001f3564: aa0003f6    	mov	x22, x0
1001f3568: 5283d508    	mov	w8, #0x1ea8             ; =7848
1001f356c: 8b080260    	add	x0, x19, x8
1001f3570: 97fe1bfa    	bl	0x10017a558 <core::ptr::drop_glue::<(tokio::sync::oneshot::Receiver<()>, <tokio::process::Child>::wait_with_output::{closure#0})>>
1001f3574: 14000063    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f3578: aa0003f6    	mov	x22, x0
1001f357c: 140000a2    	b	0x1001f3804 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d0c>
1001f3580: aa0003f6    	mov	x22, x0
1001f3584: aa1703e0    	mov	x0, x23
1001f3588: 97fc80aa    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001f358c: 140000a6    	b	0x1001f3824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d2c>
1001f3590: aa0003f6    	mov	x22, x0
1001f3594: f94017e8    	ldr	x8, [sp, #0x28]
1001f3598: 39400108    	ldrb	w8, [x8]
1001f359c: 340000a8    	cbz	w8, 0x1001f35b0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1ab8>
1001f35a0: 71000d1f    	cmp	w8, #0x3
1001f35a4: 54001361    	b.ne	0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f35a8: 52839008    	mov	w8, #0x1c80             ; =7296
1001f35ac: 8b080275    	add	x21, x19, x8
1001f35b0: aa1503e0    	mov	x0, x21
1001f35b4: 97fdb2b7    	bl	0x100160090 <core::ptr::drop_glue::<conductor_lib::execute_shell_command_cancellable::{closure#0}>>
1001f35b8: 14000096    	b	0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f35bc: aa0003f6    	mov	x22, x0
1001f35c0: 14000094    	b	0x1001f3810 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d18>
1001f35c4: aa0003f6    	mov	x22, x0
1001f35c8: 14000078    	b	0x1001f37a8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1cb0>
1001f35cc: 14000001    	b	0x1001f35d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1ad8>
1001f35d0: aa0003f6    	mov	x22, x0
1001f35d4: 14000099    	b	0x1001f3838 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d40>
1001f35d8: aa0003f6    	mov	x22, x0
1001f35dc: 14000095    	b	0x1001f3830 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d38>
1001f35e0: aa0003f6    	mov	x22, x0
1001f35e4: f1000718    	subs	x24, x24, #0x1
1001f35e8: 540000c0    	b.eq	0x1001f3600 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b08>
1001f35ec: 910182f5    	add	x21, x23, #0x60
1001f35f0: aa1703e0    	mov	x0, x23
1001f35f4: 9415b379    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001f35f8: aa1503f7    	mov	x23, x21
1001f35fc: 17fffffa    	b	0x1001f35e4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1aec>
1001f3600: f949ae68    	ldr	x8, [x19, #0x1358]
1001f3604: b50001a8    	cbnz	x8, 0x1001f3638 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b40>
1001f3608: 14000087    	b	0x1001f3824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d2c>
1001f360c: 944632c2    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3610: aa0003f6    	mov	x22, x0
1001f3614: f100075a    	subs	x26, x26, #0x1
1001f3618: 540000c0    	b.eq	0x1001f3630 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b38>
1001f361c: 91018315    	add	x21, x24, #0x60
1001f3620: aa1803e0    	mov	x0, x24
1001f3624: 9415b36d    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001f3628: aa1503f8    	mov	x24, x21
1001f362c: 17fffffa    	b	0x1001f3614 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1b1c>
1001f3630: f94002e8    	ldr	x8, [x23]
1001f3634: b4000f88    	cbz	x8, 0x1001f3824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d2c>
1001f3638: f9400280    	ldr	x0, [x20]
1001f363c: 8b080508    	add	x8, x8, x8, lsl #1
1001f3640: d37be901    	lsl	x1, x8, #5
1001f3644: 52800102    	mov	w2, #0x8                ; =8
1001f3648: 97f83803    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f364c: 14000076    	b	0x1001f3824 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d2c>
1001f3650: 944632b1    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3654: aa0003f6    	mov	x22, x0
1001f3658: 910903e0    	add	x0, sp, #0x240
1001f365c: 97fc96e9    	bl	0x100119200 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<core::option::Option<tokio::sync::mpsc::unbounded::UnboundedSender<tauri_plugin_store::store::AutoSaveMessage>>>>>>
1001f3660: 14000028    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f3664: 944632ac    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3668: aa0003f6    	mov	x22, x0
1001f366c: 9101c3e0    	add	x0, sp, #0x70
1001f3670: 94138cde    	bl	0x1006d69e8 <core::ptr::drop_glue::<alloc::sync::ArcInner<tokio::sync::oneshot::Inner<()>>>>
1001f3674: f9401fe8    	ldr	x8, [sp, #0x38]
1001f3678: 1400002f    	b	0x1001f3734 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c3c>
1001f367c: 944632a6    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f3680: aa0003f6    	mov	x22, x0
1001f3684: 9101c3e0    	add	x0, sp, #0x70
1001f3688: 97fc96de    	bl	0x100119200 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<core::option::Option<tokio::sync::mpsc::unbounded::UnboundedSender<tauri_plugin_store::store::AutoSaveMessage>>>>>>
1001f368c: 910b03e0    	add	x0, sp, #0x2c0
1001f3690: 97fc8669    	bl	0x100115034 <core::ptr::drop_glue::<core::result::Result<serde_json::value::Value, alloc::string::String>>>
1001f3694: 1400001b    	b	0x1001f3700 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c08>
1001f3698: 9446329f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f369c: aa0003f6    	mov	x22, x0
1001f36a0: aa1c03e0    	mov	x0, x28
1001f36a4: 528000c1    	mov	w1, #0x6                ; =6
1001f36a8: 52800022    	mov	w2, #0x1                ; =1
1001f36ac: 97f837ea    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f36b0: f85883a1    	ldur	x1, [x29, #-0x78]
1001f36b4: f100043f    	cmp	x1, #0x1
1001f36b8: 540001cb    	b.lt	0x1001f36f0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bf8>
1001f36bc: aa1403e0    	mov	x0, x20
1001f36c0: 1400000a    	b	0x1001f36e8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bf0>
1001f36c4: aa0003f6    	mov	x22, x0
1001f36c8: aa1b03e0    	mov	x0, x27
1001f36cc: 528000c1    	mov	w1, #0x6                ; =6
1001f36d0: 52800022    	mov	w2, #0x1                ; =1
1001f36d4: 97f837e0    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f36d8: f85883a1    	ldur	x1, [x29, #-0x78]
1001f36dc: f100043f    	cmp	x1, #0x1
1001f36e0: 5400008b    	b.lt	0x1001f36f0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1bf8>
1001f36e4: aa1803e0    	mov	x0, x24
1001f36e8: 52800022    	mov	w2, #0x1                ; =1
1001f36ec: 97f837da    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f36f0: d10343a0    	sub	x0, x29, #0xd0
1001f36f4: 94146e1b    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1001f36f8: 9101c3e0    	add	x0, sp, #0x70
1001f36fc: 97fe036c    	bl	0x1001744ac <core::ptr::drop_glue::<std::process::Output>>
1001f3700: f9401fe8    	ldr	x8, [sp, #0x38]
1001f3704: 39644d08    	ldrb	w8, [x8, #0x913]
1001f3708: 36000068    	tbz	w8, #0x0, 0x1001f3714 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c1c>
1001f370c: 910ae3e0    	add	x0, sp, #0x2b8
1001f3710: 97fc9cb6    	bl	0x10011a9e8 <core::ptr::drop_glue::<tokio::sync::oneshot::Receiver<()>>>
1001f3714: f9401fe8    	ldr	x8, [sp, #0x38]
1001f3718: 39244d1f    	strb	wzr, [x8, #0x913]
1001f371c: 39645108    	ldrb	w8, [x8, #0x914]
1001f3720: 36000068    	tbz	w8, #0x0, 0x1001f372c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c34>
1001f3724: 910ac3e0    	add	x0, sp, #0x2b0
1001f3728: 97fc9b7a    	bl	0x10011a510 <core::ptr::drop_glue::<tokio::sync::oneshot::Sender<()>>>
1001f372c: f9401fe8    	ldr	x8, [sp, #0x38]
1001f3730: 3924511f    	strb	wzr, [x8, #0x914]
1001f3734: 39645508    	ldrb	w8, [x8, #0x915]
1001f3738: 36000088    	tbz	w8, #0x0, 0x1001f3748 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c50>
1001f373c: 5283c208    	mov	w8, #0x1e10             ; =7696
1001f3740: 8b080260    	add	x0, x19, x8
1001f3744: 97fe0eca    	bl	0x10017726c <core::ptr::drop_glue::<tokio::process::Child>>
1001f3748: f9401fe8    	ldr	x8, [sp, #0x38]
1001f374c: 3924551f    	strb	wzr, [x8, #0x915]
1001f3750: 5283a808    	mov	w8, #0x1d40             ; =7488
1001f3754: 8b080260    	add	x0, x19, x8
1001f3758: 97fe0368    	bl	0x1001744f8 <core::ptr::drop_glue::<std::process::Command>>
1001f375c: f94e9661    	ldr	x1, [x19, #0x1d28]
1001f3760: b100043f    	cmn	x1, #0x1
1001f3764: 540000a0    	b.eq	0x1001f3778 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c80>
1001f3768: b4000081    	cbz	x1, 0x1001f3778 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c80>
1001f376c: f94e9a60    	ldr	x0, [x19, #0x1d30]
1001f3770: 52800022    	mov	w2, #0x1                ; =1
1001f3774: 97f837b8    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3778: f94e8a61    	ldr	x1, [x19, #0x1d10]
1001f377c: b50001c1    	cbnz	x1, 0x1001f37b4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1cbc>
1001f3780: f94e7e61    	ldr	x1, [x19, #0x1cf8]
1001f3784: b5000221    	cbnz	x1, 0x1001f37c8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1cd0>
1001f3788: f94e7261    	ldr	x1, [x19, #0x1ce0]
1001f378c: b4000081    	cbz	x1, 0x1001f379c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1ca4>
1001f3790: f94e7660    	ldr	x0, [x19, #0x1ce8]
1001f3794: 52800022    	mov	w2, #0x1                ; =1
1001f3798: 97f837af    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f379c: 52800048    	mov	w8, #0x2                ; =2
1001f37a0: f9401fe9    	ldr	x9, [sp, #0x38]
1001f37a4: 39244528    	strb	w8, [x9, #0x911]
1001f37a8: aa1503e0    	mov	x0, x21
1001f37ac: 97fdb239    	bl	0x100160090 <core::ptr::drop_glue::<conductor_lib::execute_shell_command_cancellable::{closure#0}>>
1001f37b0: 14000015    	b	0x1001f3804 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d0c>
1001f37b4: f94e8e60    	ldr	x0, [x19, #0x1d18]
1001f37b8: 52800022    	mov	w2, #0x1                ; =1
1001f37bc: 97f837a6    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f37c0: f94e7e61    	ldr	x1, [x19, #0x1cf8]
1001f37c4: b4fffe21    	cbz	x1, 0x1001f3788 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c90>
1001f37c8: f94e8260    	ldr	x0, [x19, #0x1d00]
1001f37cc: 52800022    	mov	w2, #0x1                ; =1
1001f37d0: 97f837a1    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f37d4: f94e7261    	ldr	x1, [x19, #0x1ce0]
1001f37d8: b5fffdc1    	cbnz	x1, 0x1001f3790 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1c98>
1001f37dc: 17fffff0    	b	0x1001f379c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1ca4>
1001f37e0: 9446324d    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f37e4: 9446324c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f37e8: 9446324b    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f37ec: aa0003f6    	mov	x22, x0
1001f37f0: b40000b7    	cbz	x23, 0x1001f3804 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d0c>
1001f37f4: aa1803e0    	mov	x0, x24
1001f37f8: aa1703e1    	mov	x1, x23
1001f37fc: 52800022    	mov	w2, #0x1                ; =1
1001f3800: 97f83795    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3804: 52800048    	mov	w8, #0x2                ; =2
1001f3808: f94017e9    	ldr	x9, [sp, #0x28]
1001f380c: 39000128    	strb	w8, [x9]
1001f3810: f9401be0    	ldr	x0, [sp, #0x30]
1001f3814: 97fe0c90    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001f3818: 52826b08    	mov	w8, #0x1358             ; =4952
1001f381c: 8b080260    	add	x0, x19, x8
1001f3820: 97fc8004    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001f3824: 52800048    	mov	w8, #0x2                ; =2
1001f3828: f9401fe9    	ldr	x9, [sp, #0x38]
1001f382c: 39248128    	strb	w8, [x9, #0x920]
1001f3830: f9401be0    	ldr	x0, [sp, #0x30]
1001f3834: 97fd94f2    	bl	0x100158bfc <core::ptr::drop_glue::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>>
1001f3838: f9401fe8    	ldr	x8, [sp, #0x38]
1001f383c: 3964cd08    	ldrb	w8, [x8, #0x933]
1001f3840: 36000068    	tbz	w8, #0x0, 0x1001f384c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d54>
1001f3844: aa1303e0    	mov	x0, x19
1001f3848: 97fe0dd0    	bl	0x100176f88 <core::ptr::drop_glue::<tauri::webview::Webview>>
1001f384c: f9401fe8    	ldr	x8, [sp, #0x38]
1001f3850: 3964c908    	ldrb	w8, [x8, #0x932]
1001f3854: 36000128    	tbz	w8, #0x0, 0x1001f3878 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d80>
1001f3858: f940c268    	ldr	x8, [x19, #0x180]
1001f385c: 92800009    	mov	x9, #-0x1               ; =-1
1001f3860: f8690108    	ldaddl	x9, x8, [x8]
1001f3864: f100051f    	cmp	x8, #0x1
1001f3868: 54000081    	b.ne	0x1001f3878 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1d80>
1001f386c: d50339bf    	dmb	ishld
1001f3870: 91060260    	add	x0, x19, #0x180
1001f3874: 943afaf3    	bl	0x1010b2440 <<alloc::sync::Arc<std::sync::poison::mutex::Mutex<core::option::Option<alloc::boxed::Box<dyn core::ops::function::FnOnce<(tauri::webview::Webview, alloc::string::String, tauri::ipc::InvokeResponse, tauri::ipc::CallbackFn, tauri::ipc::CallbackFn), Output = ()> + core::marker::Send>>>>>::drop_slow>
1001f3878: f9401fe8    	ldr	x8, [sp, #0x38]
1001f387c: 3964c508    	ldrb	w8, [x8, #0x931]
1001f3880: 360000c8    	tbz	w8, #0x0, 0x1001f3898 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1da0>
1001f3884: f940b661    	ldr	x1, [x19, #0x168]
1001f3888: b4000081    	cbz	x1, 0x1001f3898 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#3}::{closure#0}>::{closure#0}+0x1da0>
1001f388c: f940ba60    	ldr	x0, [x19, #0x170]
1001f3890: 52800022    	mov	w2, #0x1                ; =1
1001f3894: 97f83770    	bl	0x100001654 <__rustc::__rust_dealloc>
1001f3898: 52800048    	mov	w8, #0x2                ; =2
1001f389c: f9401fe9    	ldr	x9, [sp, #0x38]
1001f38a0: 3924c128    	strb	w8, [x9, #0x930]
1001f38a4: aa1603e0    	mov	x0, x22
1001f38a8: 944634b8    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
1001f38ac: 9446321a    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001f38b0: 94463219    	bl	0x101380114 <core::panicking::panic_in_cleanup>
