
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001ea8c4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}>:
1001ea8c4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1001ea8c8: a90167fa    	stp	x26, x25, [sp, #0x10]
1001ea8cc: a9025ff8    	stp	x24, x23, [sp, #0x20]
1001ea8d0: a90357f6    	stp	x22, x21, [sp, #0x30]
1001ea8d4: a9044ff4    	stp	x20, x19, [sp, #0x40]
1001ea8d8: a9057bfd    	stp	x29, x30, [sp, #0x50]
1001ea8dc: 910143fd    	add	x29, sp, #0x50
1001ea8e0: d10a43ff    	sub	sp, sp, #0x290
1001ea8e4: aa0103f4    	mov	x20, x1
1001ea8e8: aa0003f3    	mov	x19, x0
1001ea8ec: 39600008    	ldrb	w8, [x0, #0x800]
1001ea8f0: 7100051f    	cmp	w8, #0x1
1001ea8f4: 5400018c    	b.gt	0x1001ea924 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x60>
1001ea8f8: 35003ce8    	cbnz	w8, 0x1001eb094 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7d0>
1001ea8fc: 91200668    	add	x8, x19, #0x801
1001ea900: 52802029    	mov	w9, #0x101              ; =257
1001ea904: 79000109    	strh	w9, [x8]
1001ea908: 52800028    	mov	w8, #0x1                ; =1
1001ea90c: 39200e68    	strb	w8, [x19, #0x803]
1001ea910: 91130260    	add	x0, x19, #0x4c0
1001ea914: 91062261    	add	x1, x19, #0x188
1001ea918: 52806702    	mov	w2, #0x338              ; =824
1001ea91c: 944659fd    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001ea920: 14000003    	b	0x1001ea92c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x68>
1001ea924: 71000d1f    	cmp	w8, #0x3
1001ea928: 54003bc1    	b.ne	0x1001eb0a0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7dc>
1001ea92c: 910723fa    	add	x26, sp, #0x1c8
1001ea930: 91130275    	add	x21, x19, #0x4c0
1001ea934: 395fc268    	ldrb	w8, [x19, #0x7f0]
1001ea938: 7100051f    	cmp	w8, #0x1
1001ea93c: 54000c2c    	b.gt	0x1001eaac0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x1fc>
1001ea940: 35003b68    	cbnz	w8, 0x1001eb0ac <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7e8>
1001ea944: d00098b7    	adrp	x23, 0x101500000 <dyld_stub_binder+0x101500000>
1001ea948: 913f62f7    	add	x23, x23, #0xfd8
1001ea94c: 528002a8    	mov	w8, #0x15               ; =21
1001ea950: a90523f7    	stp	x23, x8, [sp, #0x50]
1001ea954: d00098a8    	adrp	x8, 0x101500000 <dyld_stub_binder+0x101500000>
1001ea958: 911e9d08    	add	x8, x8, #0x7a7
1001ea95c: 911b2279    	add	x25, x19, #0x6c8
1001ea960: 528000a9    	mov	w9, #0x5                ; =5
1001ea964: a90627e8    	stp	x8, x9, [sp, #0x60]
1001ea968: f9003bf5    	str	x21, [sp, #0x70]
1001ea96c: a907fff9    	stp	x25, xzr, [sp, #0x78]
1001ea970: d10343a8    	sub	x8, x29, #0xd0
1001ea974: 910143e0    	add	x0, sp, #0x50
1001ea978: 941551b3    	bl	0x10073f044 <<alloc::string::String as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001ea97c: 385303bb    	ldurb	w27, [x29, #-0xd0]
1001ea980: 7103ff7f    	cmp	w27, #0xff
1001ea984: 540015a1    	b.ne	0x1001eac38 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x374>
1001ea988: a973f3b6    	ldp	x22, x28, [x29, #-0xc8]
1001ea98c: f85483b8    	ldur	x24, [x29, #-0xb8]
1001ea990: a907fff9    	stp	x25, xzr, [sp, #0x78]
1001ea994: 528002a8    	mov	w8, #0x15               ; =21
1001ea998: d00098a9    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001ea99c: 913fb529    	add	x9, x9, #0xfed
1001ea9a0: a90523f7    	stp	x23, x8, [sp, #0x50]
1001ea9a4: 528000e8    	mov	w8, #0x7                ; =7
1001ea9a8: a90623e9    	stp	x9, x8, [sp, #0x60]
1001ea9ac: f9003bf5    	str	x21, [sp, #0x70]
1001ea9b0: d10343a8    	sub	x8, x29, #0xd0
1001ea9b4: 910143e0    	add	x0, sp, #0x50
1001ea9b8: f9000ffc    	str	x28, [sp, #0x18]
1001ea9bc: 941551a2    	bl	0x10073f044 <<alloc::string::String as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001ea9c0: 385303bb    	ldurb	w27, [x29, #-0xd0]
1001ea9c4: 7103ff7f    	cmp	w27, #0xff
1001ea9c8: 54001ac1    	b.ne	0x1001ead20 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x45c>
1001ea9cc: a973a3a9    	ldp	x9, x8, [x29, #-0xc8]
1001ea9d0: a900a7e8    	stp	x8, x9, [sp, #0x8]
1001ea9d4: f85483a8    	ldur	x8, [x29, #-0xb8]
1001ea9d8: f90003e8    	str	x8, [sp]
1001ea9dc: a907fff9    	stp	x25, xzr, [sp, #0x78]
1001ea9e0: 528002a8    	mov	w8, #0x15               ; =21
1001ea9e4: d00098a9    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001ea9e8: 913fd129    	add	x9, x9, #0xff4
1001ea9ec: a90523f7    	stp	x23, x8, [sp, #0x50]
1001ea9f0: 528000a8    	mov	w8, #0x5                ; =5
1001ea9f4: a90623e9    	stp	x9, x8, [sp, #0x60]
1001ea9f8: f9003bf5    	str	x21, [sp, #0x70]
1001ea9fc: d10343a8    	sub	x8, x29, #0xd0
1001eaa00: 910143e0    	add	x0, sp, #0x50
1001eaa04: 94154da1    	bl	0x10073e088 <<core::option::Option<bool> as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001eaa08: 385303bb    	ldurb	w27, [x29, #-0xd0]
1001eaa0c: 385313bc    	ldurb	w28, [x29, #-0xcf]
1001eaa10: 7103ff7f    	cmp	w27, #0xff
1001eaa14: 540031e1    	b.ne	0x1001eb050 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x78c>
1001eaa18: a907fff9    	stp	x25, xzr, [sp, #0x78]
1001eaa1c: 528002a8    	mov	w8, #0x15               ; =21
1001eaa20: d00098a9    	adrp	x9, 0x101500000 <dyld_stub_binder+0x101500000>
1001eaa24: 913fe529    	add	x9, x9, #0xff9
1001eaa28: a90523f7    	stp	x23, x8, [sp, #0x50]
1001eaa2c: 528001e8    	mov	w8, #0xf                ; =15
1001eaa30: a90623e9    	stp	x9, x8, [sp, #0x60]
1001eaa34: f9003bf5    	str	x21, [sp, #0x70]
1001eaa38: d10343a8    	sub	x8, x29, #0xd0
1001eaa3c: 910143e0    	add	x0, sp, #0x50
1001eaa40: 94154bd2    	bl	0x10073d988 <<core::option::Option<alloc::string::String> as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
1001eaa44: 385303bb    	ldurb	w27, [x29, #-0xd0]
1001eaa48: 7103ff7f    	cmp	w27, #0xff
1001eaa4c: 54003001    	b.ne	0x1001eb04c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x788>
1001eaa50: 3cc50340    	ldur	q0, [x26, #0x50]
1001eaa54: f85483a8    	ldur	x8, [x29, #-0xb8]
1001eaa58: f9037276    	str	x22, [x19, #0x6e0]
1001eaa5c: a9412be9    	ldp	x9, x10, [sp, #0x10]
1001eaa60: f903766a    	str	x10, [x19, #0x6e8]
1001eaa64: f9037a78    	str	x24, [x19, #0x6f0]
1001eaa68: f9037e69    	str	x9, [x19, #0x6f8]
1001eaa6c: a9402be9    	ldp	x9, x10, [sp]
1001eaa70: f903826a    	str	x10, [x19, #0x700]
1001eaa74: f9038669    	str	x9, [x19, #0x708]
1001eaa78: 391cc27c    	strb	w28, [x19, #0x730]
1001eaa7c: 3d81c660    	str	q0, [x19, #0x710]
1001eaa80: f9039268    	str	x8, [x19, #0x720]
1001eaa84: 391cc67f    	strb	wzr, [x19, #0x731]
1001eaa88: 911ce275    	add	x21, x19, #0x738
1001eaa8c: 3dc1c260    	ldr	q0, [x19, #0x700]
1001eaa90: 3dc1c661    	ldr	q1, [x19, #0x710]
1001eaa94: ad0106a0    	stp	q0, q1, [x21, #0x20]
1001eaa98: 3dc1ca60    	ldr	q0, [x19, #0x720]
1001eaa9c: 3d8012a0    	str	q0, [x21, #0x40]
1001eaaa0: f9439a68    	ldr	x8, [x19, #0x730]
1001eaaa4: f903c668    	str	x8, [x19, #0x788]
1001eaaa8: 3dc1ba60    	ldr	q0, [x19, #0x6e0]
1001eaaac: 3dc1be61    	ldr	q1, [x19, #0x6f0]
1001eaab0: ad0006a0    	stp	q0, q1, [x21]
1001eaab4: 911fa279    	add	x25, x19, #0x7e8
1001eaab8: 391fa27f    	strb	wzr, [x19, #0x7e8]
1001eaabc: 14000009    	b	0x1001eaae0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x21c>
1001eaac0: 71000d1f    	cmp	w8, #0x3
1001eaac4: 54002fc1    	b.ne	0x1001eb0bc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7f8>
1001eaac8: 911fa279    	add	x25, x19, #0x7e8
1001eaacc: 395fa268    	ldrb	w8, [x19, #0x7e8]
1001eaad0: 911ce275    	add	x21, x19, #0x738
1001eaad4: 7100051f    	cmp	w8, #0x1
1001eaad8: 540001ac    	b.gt	0x1001eab0c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x248>
1001eaadc: 35003088    	cbnz	w8, 0x1001eb0ec <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x828>
1001eaae0: ad4106a0    	ldp	q0, q1, [x21, #0x20]
1001eaae4: 3d81ee60    	str	q0, [x19, #0x7b0]
1001eaae8: 3d81f261    	str	q1, [x19, #0x7c0]
1001eaaec: 3dc012a0    	ldr	q0, [x21, #0x40]
1001eaaf0: 3d81f660    	str	q0, [x19, #0x7d0]
1001eaaf4: f9402aa8    	ldr	x8, [x21, #0x50]
1001eaaf8: f903f268    	str	x8, [x19, #0x7e0]
1001eaafc: ad4006a0    	ldp	q0, q1, [x21]
1001eab00: 3d81e660    	str	q0, [x19, #0x790]
1001eab04: 3d81ea61    	str	q1, [x19, #0x7a0]
1001eab08: 14000003    	b	0x1001eab14 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x250>
1001eab0c: 71000d1f    	cmp	w8, #0x3
1001eab10: 54002f61    	b.ne	0x1001eb0fc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x838>
1001eab14: 911e4268    	add	x8, x19, #0x790
1001eab18: 395f8669    	ldrb	w9, [x19, #0x7e1]
1001eab1c: 7100053f    	cmp	w9, #0x1
1001eab20: 5400060c    	b.gt	0x1001eabe0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x31c>
1001eab24: 35002d49    	cbnz	w9, 0x1001eb0cc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x808>
1001eab28: 3dc00100    	ldr	q0, [x8]
1001eab2c: 3c9303a0    	stur	q0, [x29, #-0xd0]
1001eab30: f9400908    	ldr	x8, [x8, #0x10]
1001eab34: 911ea269    	add	x9, x19, #0x7a8
1001eab38: f943de6a    	ldr	x10, [x19, #0x7b8]
1001eab3c: f81403a8    	stur	x8, [x29, #-0xc0]
1001eab40: f81583aa    	stur	x10, [x29, #-0xa8]
1001eab44: 3dc00120    	ldr	q0, [x9]
1001eab48: 3c860340    	stur	q0, [x26, #0x60]
1001eab4c: 395f8268    	ldrb	w8, [x19, #0x7e0]
1001eab50: 3dc1f260    	ldr	q0, [x19, #0x7c0]
1001eab54: 3c9603a0    	stur	q0, [x29, #-0xa0]
1001eab58: f943ea69    	ldr	x9, [x19, #0x7d0]
1001eab5c: f81703a9    	stur	x9, [x29, #-0x90]
1001eab60: 381783a8    	sturb	w8, [x29, #-0x88]
1001eab64: 90017c55    	adrp	x21, 0x103172000 <<h2::proto::streams::state::State>::reserve_remote::__CALLSITE+0x10>
1001eab68: 911d22b5    	add	x21, x21, #0x748
1001eab6c: f8bfc2a8    	ldapr	x8, [x21]
1001eab70: b50028a8    	cbnz	x8, 0x1001eb084 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7c0>
1001eab74: ad7a87a0    	ldp	q0, q1, [x29, #-0xb0]
1001eab78: ad0387e0    	stp	q0, q1, [sp, #0x70]
1001eab7c: 3cd703a0    	ldur	q0, [x29, #-0x90]
1001eab80: 3d8027e0    	str	q0, [sp, #0x90]
1001eab84: ad7983a1    	ldp	q1, q0, [x29, #-0xd0]
1001eab88: ad0283e1    	stp	q1, q0, [sp, #0x50]
1001eab8c: f9400ea8    	ldr	x8, [x21, #0x18]
1001eab90: 910022a9    	add	x9, x21, #0x8
1001eab94: 910142aa    	add	x10, x21, #0x50
1001eab98: f100091f    	cmp	x8, #0x2
1001eab9c: 9a8a0121    	csel	x1, x9, x10, eq
1001eaba0: b9400028    	ldr	w8, [x1]
1001eaba4: 52800b09    	mov	w9, #0x58               ; =88
1001eaba8: 5280020a    	mov	w10, #0x10              ; =16
1001eabac: 9a890149    	csel	x9, x10, x9, eq
1001eabb0: f8696aa9    	ldr	x9, [x21, x9]
1001eabb4: 7100011f    	cmp	w8, #0x0
1001eabb8: 52804808    	mov	w8, #0x240              ; =576
1001eabbc: 5280440a    	mov	w10, #0x220             ; =544
1001eabc0: 9a881148    	csel	x8, x10, x8, ne
1001eabc4: f00173e3    	adrp	x3, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001eabc8: 91270063    	add	x3, x3, #0x9c0
1001eabcc: 8b080120    	add	x0, x9, x8
1001eabd0: 910143e2    	add	x2, sp, #0x50
1001eabd4: 9414c40b    	bl	0x10071bc00 <<tokio::runtime::blocking::pool::Spawner>::spawn_blocking::<conductor_lib::execute_shell_command::{closure#0}::{closure#0}, core::result::Result<serde_json::value::Value, alloc::string::String>>>
1001eabd8: f903ee60    	str	x0, [x19, #0x7d8]
1001eabdc: 14000003    	b	0x1001eabe8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x324>
1001eabe0: 71000d3f    	cmp	w9, #0x3
1001eabe4: 540027c1    	b.ne	0x1001eb0dc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x818>
1001eabe8: 911f6275    	add	x21, x19, #0x7d8
1001eabec: 910143e8    	add	x8, sp, #0x50
1001eabf0: 911f6260    	add	x0, x19, #0x7d8
1001eabf4: aa1403e1    	mov	x1, x20
1001eabf8: 94155d91    	bl	0x10074223c <<tokio::runtime::task::join::JoinHandle<core::result::Result<serde_json::value::Value, alloc::string::String>> as core::future::future::Future>::poll>
1001eabfc: 394143f8    	ldrb	w24, [sp, #0x50]
1001eac00: 7103f71f    	cmp	w24, #0xfd
1001eac04: 540002a0    	b.eq	0x1001eac58 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x394>
1001eac08: 7103fb1f    	cmp	w24, #0xfe
1001eac0c: 540002e1    	b.ne	0x1001eac68 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x3a4>
1001eac10: 5280001b    	mov	w27, #0x0               ; =0
1001eac14: 394163f8    	ldrb	w24, [sp, #0x58]
1001eac18: b84593e8    	ldur	w8, [sp, #0x59]
1001eac1c: b81303a8    	stur	w8, [x29, #-0xd0]
1001eac20: b9405fe8    	ldr	w8, [sp, #0x5c]
1001eac24: b804b348    	stur	w8, [x26, #0x4b]
1001eac28: d280019c    	mov	x28, #0xc               ; =12
1001eac2c: f2f0001c    	movk	x28, #0x8000, lsl #48
1001eac30: a9465ff6    	ldp	x22, x23, [sp, #0x60]
1001eac34: 14000015    	b	0x1001eac88 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x3c4>
1001eac38: 385313bc    	ldurb	w28, [x29, #-0xcf]
1001eac3c: b844a348    	ldur	w8, [x26, #0x4a]
1001eac40: b901c3e8    	str	w8, [sp, #0x1c0]
1001eac44: 785363a8    	ldurh	w8, [x29, #-0xca]
1001eac48: 79038be8    	strh	w8, [sp, #0x1c4]
1001eac4c: a973d7b7    	ldp	x23, x21, [x29, #-0xc8]
1001eac50: f85483b4    	ldur	x20, [x29, #-0xb8]
1001eac54: 1400003f    	b	0x1001ead50 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x48c>
1001eac58: 52800068    	mov	w8, #0x3                ; =3
1001eac5c: 391f8668    	strb	w8, [x19, #0x7e1]
1001eac60: 391fa268    	strb	w8, [x19, #0x7e8]
1001eac64: 14000086    	b	0x1001eae7c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x5b8>
1001eac68: b84513e8    	ldur	w8, [sp, #0x51]
1001eac6c: b81303a8    	stur	w8, [x29, #-0xd0]
1001eac70: b94057e8    	ldr	w8, [sp, #0x54]
1001eac74: b804b348    	stur	w8, [x26, #0x4b]
1001eac78: a945dff6    	ldp	x22, x23, [sp, #0x58]
1001eac7c: 9280001c    	mov	x28, #-0x1              ; =-1
1001eac80: 5280003b    	mov	w27, #0x1               ; =1
1001eac84: f94037f4    	ldr	x20, [sp, #0x68]
1001eac88: b85303a8    	ldur	w8, [x29, #-0xd0]
1001eac8c: b81803a8    	stur	w8, [x29, #-0x80]
1001eac90: b844b348    	ldur	w8, [x26, #0x4b]
1001eac94: b809b348    	stur	w8, [x26, #0x9b]
1001eac98: f94002b5    	ldr	x21, [x21]
1001eac9c: aa1503e0    	mov	x0, x21
1001eaca0: 943e36b1    	bl	0x101178764 <<tokio::runtime::task::state::State>::drop_join_handle_fast>
1001eaca4: 34000060    	cbz	w0, 0x1001eacb0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x3ec>
1001eaca8: aa1503e0    	mov	x0, x21
1001eacac: 943e7f31    	bl	0x10118a970 <<tokio::runtime::task::raw::RawTask>::drop_join_handle_slow>
1001eacb0: 360000bb    	tbz	w27, #0x0, 0x1001eacc4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x400>
1001eacb4: 7103fb1f    	cmp	w24, #0xfe
1001eacb8: 54000761    	b.ne	0x1001eada4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4e0>
1001eacbc: 52801ff8    	mov	w24, #0xff              ; =255
1001eacc0: 1400003d    	b	0x1001eadb4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4f0>
1001eacc4: f9002bfc    	str	x28, [sp, #0x50]
1001eacc8: 390163f8    	strb	w24, [sp, #0x58]
1001eaccc: b85803a8    	ldur	w8, [x29, #-0x80]
1001eacd0: b80593e8    	stur	w8, [sp, #0x59]
1001eacd4: b849b348    	ldur	w8, [x26, #0x9b]
1001eacd8: b9005fe8    	str	w8, [sp, #0x5c]
1001eacdc: a9065ff6    	stp	x22, x23, [sp, #0x60]
1001eace0: f9003bf4    	str	x20, [sp, #0x70]
1001eace4: 910143e8    	add	x8, sp, #0x50
1001eace8: b00076e9    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
1001eacec: 913e2129    	add	x9, x9, #0xf88
1001eacf0: a93927a8    	stp	x8, x9, [x29, #-0x70]
1001eacf4: b0015660    	adrp	x0, 0x102cb7000 <_anon.dfaadf50359b6dc611e2f8074053fec3.144+0x643>
1001eacf8: 91221400    	add	x0, x0, #0x885
1001eacfc: d10343a8    	sub	x8, x29, #0xd0
1001ead00: d101c3a1    	sub	x1, x29, #0x70
1001ead04: 94449b5c    	bl	0x101311a74 <alloc::fmt::format::format_inner>
1001ead08: 910143e0    	add	x0, sp, #0x50
1001ead0c: 97fe2f8c    	bl	0x100176b3c <core::ptr::drop_glue::<tauri::error::Error>>
1001ead10: a9735fb6    	ldp	x22, x23, [x29, #-0xd0]
1001ead14: 52801ff8    	mov	w24, #0xff              ; =255
1001ead18: f85403b4    	ldur	x20, [x29, #-0xc0]
1001ead1c: 14000026    	b	0x1001eadb4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4f0>
1001ead20: 385313bc    	ldurb	w28, [x29, #-0xcf]
1001ead24: b844a348    	ldur	w8, [x26, #0x4a]
1001ead28: b901c3e8    	str	w8, [sp, #0x1c0]
1001ead2c: 785363a8    	ldurh	w8, [x29, #-0xca]
1001ead30: 79038be8    	strh	w8, [sp, #0x1c4]
1001ead34: a973d7b7    	ldp	x23, x21, [x29, #-0xc8]
1001ead38: f85483b4    	ldur	x20, [x29, #-0xb8]
1001ead3c: b40000b6    	cbz	x22, 0x1001ead50 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x48c>
1001ead40: f9400fe0    	ldr	x0, [sp, #0x18]
1001ead44: aa1603e1    	mov	x1, x22
1001ead48: 52800022    	mov	w2, #0x1                ; =1
1001ead4c: 97f85a42    	bl	0x100001654 <__rustc::__rust_dealloc>
1001ead50: 91130260    	add	x0, x19, #0x4c0
1001ead54: 97fe2f40    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001ead58: f9400328    	ldr	x8, [x25]
1001ead5c: b100051f    	cmn	x8, #0x1
1001ead60: 540001e0    	b.eq	0x1001ead9c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4d8>
1001ead64: 911b427a    	add	x26, x19, #0x6d0
1001ead68: f9436a60    	ldr	x0, [x19, #0x6d0]
1001ead6c: f9436e68    	ldr	x8, [x19, #0x6d8]
1001ead70: 91000518    	add	x24, x8, #0x1
1001ead74: f1000718    	subs	x24, x24, #0x1
1001ead78: 540000a0    	b.eq	0x1001ead8c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4c8>
1001ead7c: 91018016    	add	x22, x0, #0x60
1001ead80: 9415d596    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001ead84: aa1603e0    	mov	x0, x22
1001ead88: 17fffffb    	b	0x1001ead74 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x4b0>
1001ead8c: f9400328    	ldr	x8, [x25]
1001ead90: 52800038    	mov	w24, #0x1               ; =1
1001ead94: b5000f48    	cbnz	x8, 0x1001eaf7c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6b8>
1001ead98: 1400007e    	b	0x1001eaf90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6cc>
1001ead9c: 52800038    	mov	w24, #0x1               ; =1
1001eada0: 1400007c    	b	0x1001eaf90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6cc>
1001eada4: b85803a8    	ldur	w8, [x29, #-0x80]
1001eada8: b81883a8    	stur	w8, [x29, #-0x78]
1001eadac: b849b348    	ldur	w8, [x26, #0x9b]
1001eadb0: b80a3348    	stur	w8, [x26, #0xa3]
1001eadb4: 52800028    	mov	w8, #0x1                ; =1
1001eadb8: 391f8668    	strb	w8, [x19, #0x7e1]
1001eadbc: 911e4260    	add	x0, x19, #0x790
1001eadc0: 97fdd43e    	bl	0x10015feb8 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}>>
1001eadc4: 7103ff1f    	cmp	w24, #0xff
1001eadc8: 540000e1    	b.ne	0x1001eade4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x520>
1001eadcc: b6f80614    	tbz	x20, #0x3f, 0x1001eae8c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x5c8>
1001eadd0: d2800018    	mov	x24, #0x0               ; =0
1001eadd4: aa1803e0    	mov	x0, x24
1001eadd8: aa1403e1    	mov	x1, x20
1001eaddc: 94465435    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1001eade0: 140000ca    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eade4: 390723f8    	strb	w24, [sp, #0x1c8]
1001eade8: b85883a8    	ldur	w8, [x29, #-0x78]
1001eadec: b8001348    	stur	w8, [x26, #0x1]
1001eadf0: b84a3348    	ldur	w8, [x26, #0xa3]
1001eadf4: b901cfe8    	str	w8, [sp, #0x1cc]
1001eadf8: a91d5ff6    	stp	x22, x23, [sp, #0x1d0]
1001eadfc: f900f3f4    	str	x20, [sp, #0x1e0]
1001eae00: 910143e8    	add	x8, sp, #0x50
1001eae04: 910723e0    	add	x0, sp, #0x1c8
1001eae08: 941373bd    	bl	0x1006c7cfc <<serde_json::value::Value as tauri::ipc::IpcResponse>::body>
1001eae0c: f9402be8    	ldr	x8, [sp, #0x50]
1001eae10: 3cc583e0    	ldur	q0, [sp, #0x58]
1001eae14: 3cc683e1    	ldur	q1, [sp, #0x68]
1001eae18: ad3987a0    	stp	q0, q1, [x29, #-0xd0]
1001eae1c: b100051f    	cmn	x8, #0x1
1001eae20: 540005c0    	b.eq	0x1001eaed8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x614>
1001eae24: f9403fe9    	ldr	x9, [sp, #0x78]
1001eae28: f9002be8    	str	x8, [sp, #0x50]
1001eae2c: ad7987a0    	ldp	q0, q1, [x29, #-0xd0]
1001eae30: 3c8583e0    	stur	q0, [sp, #0x58]
1001eae34: 3c8683e1    	stur	q1, [sp, #0x68]
1001eae38: f9003fe9    	str	x9, [sp, #0x78]
1001eae3c: d103e3a0    	sub	x0, x29, #0xf8
1001eae40: 910143e1    	add	x1, sp, #0x50
1001eae44: 94029e01    	bl	0x100292648 <<core::result::Result<tauri::ipc::InvokeResponseBody, tauri::ipc::InvokeError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, tauri::error::Error>>>::from_residual>
1001eae48: f85083b8    	ldur	x24, [x29, #-0xf8]
1001eae4c: 385103bb    	ldurb	w27, [x29, #-0xf0]
1001eae50: 385113bc    	ldurb	w28, [x29, #-0xef]
1001eae54: b842a348    	ldur	w8, [x26, #0x2a]
1001eae58: b901bbe8    	str	w8, [sp, #0x1b8]
1001eae5c: 785163a8    	ldurh	w8, [x29, #-0xea]
1001eae60: 79037be8    	strh	w8, [sp, #0x1bc]
1001eae64: a971d7b7    	ldp	x23, x21, [x29, #-0xe8]
1001eae68: f85283b4    	ldur	x20, [x29, #-0xd8]
1001eae6c: 52800028    	mov	w8, #0x1                ; =1
1001eae70: 39000328    	strb	w8, [x25]
1001eae74: f1000b1f    	cmp	x24, #0x2
1001eae78: 54000581    	b.ne	0x1001eaf28 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x664>
1001eae7c: 52800068    	mov	w8, #0x3                ; =3
1001eae80: 391fc268    	strb	w8, [x19, #0x7f0]
1001eae84: 52800020    	mov	w0, #0x1                ; =1
1001eae88: 14000068    	b	0x1001eb028 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x764>
1001eae8c: b4000374    	cbz	x20, 0x1001eaef8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x634>
1001eae90: 97f859f4    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1001eae94: 52800038    	mov	w24, #0x1               ; =1
1001eae98: aa1403e0    	mov	x0, x20
1001eae9c: 52800021    	mov	w1, #0x1                ; =1
1001eaea0: 97f859ec    	bl	0x100001650 <__rustc::__rust_alloc>
1001eaea4: b4fff980    	cbz	x0, 0x1001eadd4 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x510>
1001eaea8: aa0003f5    	mov	x21, x0
1001eaeac: aa1703e1    	mov	x1, x23
1001eaeb0: aa1403e2    	mov	x2, x20
1001eaeb4: 94465897    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001eaeb8: b4000256    	cbz	x22, 0x1001eaf00 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x63c>
1001eaebc: 52800038    	mov	w24, #0x1               ; =1
1001eaec0: aa1703e0    	mov	x0, x23
1001eaec4: aa1603e1    	mov	x1, x22
1001eaec8: 52800022    	mov	w2, #0x1                ; =1
1001eaecc: 97f859e2    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eaed0: 5280007b    	mov	w27, #0x3               ; =3
1001eaed4: 1400000d    	b	0x1001eaf08 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x644>
1001eaed8: d2800018    	mov	x24, #0x0               ; =0
1001eaedc: ad7983a1    	ldp	q1, q0, [x29, #-0xd0]
1001eaee0: 3c838340    	stur	q0, [x26, #0x38]
1001eaee4: 3c828341    	stur	q1, [x26, #0x28]
1001eaee8: 385103bb    	ldurb	w27, [x29, #-0xf0]
1001eaeec: a971d7b7    	ldp	x23, x21, [x29, #-0xe8]
1001eaef0: f85283b4    	ldur	x20, [x29, #-0xd8]
1001eaef4: 14000006    	b	0x1001eaf0c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x648>
1001eaef8: 52800035    	mov	w21, #0x1               ; =1
1001eaefc: b5fffe16    	cbnz	x22, 0x1001eaebc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x5f8>
1001eaf00: 5280007b    	mov	w27, #0x3               ; =3
1001eaf04: 52800038    	mov	w24, #0x1               ; =1
1001eaf08: aa1403f7    	mov	x23, x20
1001eaf0c: 385113bc    	ldurb	w28, [x29, #-0xef]
1001eaf10: b842a348    	ldur	w8, [x26, #0x2a]
1001eaf14: b901bbe8    	str	w8, [sp, #0x1b8]
1001eaf18: 785163a8    	ldurh	w8, [x29, #-0xea]
1001eaf1c: 79037be8    	strh	w8, [sp, #0x1bc]
1001eaf20: 52800028    	mov	w8, #0x1                ; =1
1001eaf24: 39000328    	strb	w8, [x25]
1001eaf28: b941bbe8    	ldr	w8, [sp, #0x1b8]
1001eaf2c: b901c3e8    	str	w8, [sp, #0x1c0]
1001eaf30: 79437be8    	ldrh	w8, [sp, #0x1bc]
1001eaf34: 79038be8    	strh	w8, [sp, #0x1c4]
1001eaf38: 91130260    	add	x0, x19, #0x4c0
1001eaf3c: 97fe2ec6    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001eaf40: f9436668    	ldr	x8, [x19, #0x6c8]
1001eaf44: b100051f    	cmn	x8, #0x1
1001eaf48: 54000240    	b.eq	0x1001eaf90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6cc>
1001eaf4c: 911b427a    	add	x26, x19, #0x6d0
1001eaf50: f9436a60    	ldr	x0, [x19, #0x6d0]
1001eaf54: f9436e68    	ldr	x8, [x19, #0x6d8]
1001eaf58: 91000519    	add	x25, x8, #0x1
1001eaf5c: f1000739    	subs	x25, x25, #0x1
1001eaf60: 540000a0    	b.eq	0x1001eaf74 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6b0>
1001eaf64: 91018016    	add	x22, x0, #0x60
1001eaf68: 9415d51c    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001eaf6c: aa1603e0    	mov	x0, x22
1001eaf70: 17fffffb    	b	0x1001eaf5c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x698>
1001eaf74: f9436668    	ldr	x8, [x19, #0x6c8]
1001eaf78: b40000c8    	cbz	x8, 0x1001eaf90 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x6cc>
1001eaf7c: f9400340    	ldr	x0, [x26]
1001eaf80: 8b080508    	add	x8, x8, x8, lsl #1
1001eaf84: d37be901    	lsl	x1, x8, #5
1001eaf88: 52800102    	mov	w2, #0x8                ; =8
1001eaf8c: 97f859b2    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eaf90: b941c3e8    	ldr	w8, [sp, #0x1c0]
1001eaf94: b9004be8    	str	w8, [sp, #0x48]
1001eaf98: 79438be8    	ldrh	w8, [sp, #0x1c4]
1001eaf9c: 79009be8    	strh	w8, [sp, #0x4c]
1001eafa0: 52800028    	mov	w8, #0x1                ; =1
1001eafa4: 391fc268    	strb	w8, [x19, #0x7f0]
1001eafa8: 91130260    	add	x0, x19, #0x4c0
1001eafac: 97fdb1ec    	bl	0x10015775c <core::ptr::drop_glue::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>>
1001eafb0: b9404be8    	ldr	w8, [sp, #0x48]
1001eafb4: b802a3e8    	stur	w8, [sp, #0x2a]
1001eafb8: 79409be8    	ldrh	w8, [sp, #0x4c]
1001eafbc: 79005fe8    	strh	w8, [sp, #0x2e]
1001eafc0: a90357f7    	stp	x23, x21, [sp, #0x30]
1001eafc4: f90023f4    	str	x20, [sp, #0x40]
1001eafc8: 92400308    	and	x8, x24, #0x1
1001eafcc: 3900a3fb    	strb	w27, [sp, #0x28]
1001eafd0: 3900a7fc    	strb	w28, [sp, #0x29]
1001eafd4: f90013e8    	str	x8, [sp, #0x20]
1001eafd8: 39200e7f    	strb	wzr, [x19, #0x803]
1001eafdc: 910143e0    	add	x0, sp, #0x50
1001eafe0: aa1303e1    	mov	x1, x19
1001eafe4: 52802d02    	mov	w2, #0x168              ; =360
1001eafe8: 9446584a    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1001eafec: 39200a7f    	strb	wzr, [x19, #0x802]
1001eaff0: 3920067f    	strb	wzr, [x19, #0x801]
1001eaff4: 9105a268    	add	x8, x19, #0x168
1001eaff8: 3dc00100    	ldr	q0, [x8]
1001eaffc: 3c9303a0    	stur	q0, [x29, #-0xd0]
1001eb000: a9578668    	ldp	x8, x1, [x19, #0x178]
1001eb004: f81403a8    	stur	x8, [x29, #-0xc0]
1001eb008: b947fa64    	ldr	w4, [x19, #0x7f8]
1001eb00c: b947fe65    	ldr	w5, [x19, #0x7fc]
1001eb010: 910143e0    	add	x0, sp, #0x50
1001eb014: 910083e2    	add	x2, sp, #0x20
1001eb018: d10343a3    	sub	x3, x29, #0xd0
1001eb01c: 94107fab    	bl	0x10060aec8 <<tauri::ipc::InvokeResolver>::return_result>
1001eb020: 52800000    	mov	w0, #0x0                ; =0
1001eb024: 52800028    	mov	w8, #0x1                ; =1
1001eb028: 39200268    	strb	w8, [x19, #0x800]
1001eb02c: 910a43ff    	add	sp, sp, #0x290
1001eb030: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1001eb034: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1001eb038: a94357f6    	ldp	x22, x21, [sp, #0x30]
1001eb03c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1001eb040: a94167fa    	ldp	x26, x25, [sp, #0x10]
1001eb044: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1001eb048: d65f03c0    	ret
1001eb04c: 385313bc    	ldurb	w28, [x29, #-0xcf]
1001eb050: b844a348    	ldur	w8, [x26, #0x4a]
1001eb054: b901c3e8    	str	w8, [sp, #0x1c0]
1001eb058: 785363a8    	ldurh	w8, [x29, #-0xca]
1001eb05c: 79038be8    	strh	w8, [sp, #0x1c4]
1001eb060: a973d7b7    	ldp	x23, x21, [x29, #-0xc8]
1001eb064: f85483b4    	ldur	x20, [x29, #-0xb8]
1001eb068: f9400be1    	ldr	x1, [sp, #0x10]
1001eb06c: b4000081    	cbz	x1, 0x1001eb07c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x7b8>
1001eb070: f94007e0    	ldr	x0, [sp, #0x8]
1001eb074: 52800022    	mov	w2, #0x1                ; =1
1001eb078: 97f85977    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb07c: b5ffe636    	cbnz	x22, 0x1001ead40 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x47c>
1001eb080: 17ffff34    	b	0x1001ead50 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x48c>
1001eb084: f0017c20    	adrp	x0, 0x103172000 <<h2::proto::streams::state::State>::reserve_remote::__CALLSITE+0x10>
1001eb088: 911d2000    	add	x0, x0, #0x748
1001eb08c: 9444fdb9    	bl	0x10132a770 <<std::sync::once_lock::OnceLock<tauri::async_runtime::GlobalRuntime>>::initialize::<<std::sync::once_lock::OnceLock<tauri::async_runtime::GlobalRuntime>>::get_or_init<tauri::async_runtime::default_runtime>::{closure#0}, !>>
1001eb090: 17fffeb9    	b	0x1001eab74 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x2b0>
1001eb094: b00173e0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001eb098: 9114a000    	add	x0, x0, #0x528
1001eb09c: 944654c5    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001eb0a0: b00173e0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001eb0a4: 9114a000    	add	x0, x0, #0x528
1001eb0a8: 944654c9    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001eb0ac: d00173e0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001eb0b0: 911d4000    	add	x0, x0, #0x750
1001eb0b4: 944654bf    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001eb0b8: 14000014    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eb0bc: d00173e0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001eb0c0: 911d4000    	add	x0, x0, #0x750
1001eb0c4: 944654c2    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001eb0c8: 14000010    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eb0cc: d00173e0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001eb0d0: 91276000    	add	x0, x0, #0x9d8
1001eb0d4: 944654b7    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001eb0d8: 1400000c    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eb0dc: d00173e0    	adrp	x0, 0x103069000 <_anon.a1fe893330618e2aa7f7ddee619ac267.2+0xe20>
1001eb0e0: 91276000    	add	x0, x0, #0x9d8
1001eb0e4: 944654ba    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001eb0e8: 14000008    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eb0ec: b00173e0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001eb0f0: 91144000    	add	x0, x0, #0x510
1001eb0f4: 944654af    	bl	0x1013803b0 <core::panicking::panic_const::panic_const_async_fn_resumed>
1001eb0f8: 14000004    	b	0x1001eb108 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x844>
1001eb0fc: b00173e0    	adrp	x0, 0x103068000 <dyld_stub_binder+0x103068000>
1001eb100: 91144000    	add	x0, x0, #0x510
1001eb104: 944654b2    	bl	0x1013803cc <core::panicking::panic_const::panic_const_async_fn_resumed_panic>
1001eb108: d4200020    	brk	#0x1
1001eb10c: aa0003f4    	mov	x20, x0
1001eb110: d10343a0    	sub	x0, x29, #0xd0
1001eb114: 94114aa4    	bl	0x10063dba4 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}::{closure#0}>>
1001eb118: 1400003d    	b	0x1001eb20c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x948>
1001eb11c: 944653fe    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb120: aa0003f4    	mov	x20, x0
1001eb124: f9400be8    	ldr	x8, [sp, #0x10]
1001eb128: b50000c8    	cbnz	x8, 0x1001eb140 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x87c>
1001eb12c: 14000008    	b	0x1001eb14c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x888>
1001eb130: 1400001b    	b	0x1001eb19c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x8d8>
1001eb134: aa0003f4    	mov	x20, x0
1001eb138: f9400be8    	ldr	x8, [sp, #0x10]
1001eb13c: b4000088    	cbz	x8, 0x1001eb14c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x888>
1001eb140: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001eb144: 52800022    	mov	w2, #0x1                ; =1
1001eb148: 97f85943    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb14c: b50001d6    	cbnz	x22, 0x1001eb184 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x8c0>
1001eb150: 1400005c    	b	0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb154: 14000012    	b	0x1001eb19c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x8d8>
1001eb158: aa0003f4    	mov	x20, x0
1001eb15c: 910143e0    	add	x0, sp, #0x50
1001eb160: 97fe2e77    	bl	0x100176b3c <core::ptr::drop_glue::<tauri::error::Error>>
1001eb164: 1400002a    	b	0x1001eb20c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x948>
1001eb168: 944653eb    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb16c: aa0003f4    	mov	x20, x0
1001eb170: 911b2260    	add	x0, x19, #0x6c8
1001eb174: 97fca1af    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001eb178: 14000056    	b	0x1001eb2d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa0c>
1001eb17c: aa0003f4    	mov	x20, x0
1001eb180: b4000a16    	cbz	x22, 0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb184: f9400fe0    	ldr	x0, [sp, #0x18]
1001eb188: aa1603e1    	mov	x1, x22
1001eb18c: 52800022    	mov	w2, #0x1                ; =1
1001eb190: 97f85931    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb194: 1400004b    	b	0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb198: 1400001c    	b	0x1001eb208 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x944>
1001eb19c: aa0003f4    	mov	x20, x0
1001eb1a0: 14000046    	b	0x1001eb2b8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9f4>
1001eb1a4: aa0003f4    	mov	x20, x0
1001eb1a8: 911b2260    	add	x0, x19, #0x6c8
1001eb1ac: 97fca1a1    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001eb1b0: 14000048    	b	0x1001eb2d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa0c>
1001eb1b4: aa0003f4    	mov	x20, x0
1001eb1b8: 39400328    	ldrb	w8, [x25]
1001eb1bc: 34000088    	cbz	w8, 0x1001eb1cc <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x908>
1001eb1c0: 71000d1f    	cmp	w8, #0x3
1001eb1c4: 540007e1    	b.ne	0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb1c8: 911e4275    	add	x21, x19, #0x790
1001eb1cc: aa1503e0    	mov	x0, x21
1001eb1d0: 97fdd33a    	bl	0x10015feb8 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}>>
1001eb1d4: 1400003b    	b	0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb1d8: aa0003f4    	mov	x20, x0
1001eb1dc: 14000039    	b	0x1001eb2c0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9fc>
1001eb1e0: aa0003f4    	mov	x20, x0
1001eb1e4: 911f6260    	add	x0, x19, #0x7d8
1001eb1e8: 941562aa    	bl	0x100743c90 <<tokio::runtime::task::join::JoinHandle<()> as core::ops::drop::Drop>::drop>
1001eb1ec: 14000008    	b	0x1001eb20c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x948>
1001eb1f0: 944653c9    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb1f4: aa0003f4    	mov	x20, x0
1001eb1f8: 14000007    	b	0x1001eb214 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x950>
1001eb1fc: 14000001    	b	0x1001eb200 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x93c>
1001eb200: aa0003f4    	mov	x20, x0
1001eb204: 14000037    	b	0x1001eb2e0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa1c>
1001eb208: aa0003f4    	mov	x20, x0
1001eb20c: 52800048    	mov	w8, #0x2                ; =2
1001eb210: 391f8668    	strb	w8, [x19, #0x7e1]
1001eb214: 911e4260    	add	x0, x19, #0x790
1001eb218: 97fdd328    	bl	0x10015feb8 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}>>
1001eb21c: 14000027    	b	0x1001eb2b8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9f4>
1001eb220: 944653bd    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb224: aa0003f4    	mov	x20, x0
1001eb228: 1400002c    	b	0x1001eb2d8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa14>
1001eb22c: aa0003f4    	mov	x20, x0
1001eb230: f1000739    	subs	x25, x25, #0x1
1001eb234: 540000c0    	b.eq	0x1001eb24c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x988>
1001eb238: 910182d5    	add	x21, x22, #0x60
1001eb23c: aa1603e0    	mov	x0, x22
1001eb240: 9415d466    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001eb244: aa1503f6    	mov	x22, x21
1001eb248: 17fffffa    	b	0x1001eb230 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x96c>
1001eb24c: f9436668    	ldr	x8, [x19, #0x6c8]
1001eb250: b50001a8    	cbnz	x8, 0x1001eb284 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9c0>
1001eb254: 1400001f    	b	0x1001eb2d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa0c>
1001eb258: 944653af    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb25c: aa0003f4    	mov	x20, x0
1001eb260: f1000718    	subs	x24, x24, #0x1
1001eb264: 540000c0    	b.eq	0x1001eb27c <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9b8>
1001eb268: 910182d5    	add	x21, x22, #0x60
1001eb26c: aa1603e0    	mov	x0, x22
1001eb270: 9415d45a    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
1001eb274: aa1503f6    	mov	x22, x21
1001eb278: 17fffffa    	b	0x1001eb260 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x99c>
1001eb27c: f9400328    	ldr	x8, [x25]
1001eb280: b4000288    	cbz	x8, 0x1001eb2d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa0c>
1001eb284: f9400340    	ldr	x0, [x26]
1001eb288: 8b080508    	add	x8, x8, x8, lsl #1
1001eb28c: d37be901    	lsl	x1, x8, #5
1001eb290: 52800102    	mov	w2, #0x8                ; =8
1001eb294: 97f858f0    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb298: 1400000e    	b	0x1001eb2d0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa0c>
1001eb29c: 9446539e    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb2a0: aa0003f4    	mov	x20, x0
1001eb2a4: b40000b6    	cbz	x22, 0x1001eb2b8 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0x9f4>
1001eb2a8: aa1703e0    	mov	x0, x23
1001eb2ac: aa1603e1    	mov	x1, x22
1001eb2b0: 52800022    	mov	w2, #0x1                ; =1
1001eb2b4: 97f858e8    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb2b8: 52800048    	mov	w8, #0x2                ; =2
1001eb2bc: 39000328    	strb	w8, [x25]
1001eb2c0: 91130260    	add	x0, x19, #0x4c0
1001eb2c4: 97fe2de4    	bl	0x100176a54 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
1001eb2c8: 911b2260    	add	x0, x19, #0x6c8
1001eb2cc: 97fca159    	bl	0x100113830 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
1001eb2d0: 52800048    	mov	w8, #0x2                ; =2
1001eb2d4: 391fc268    	strb	w8, [x19, #0x7f0]
1001eb2d8: 91130260    	add	x0, x19, #0x4c0
1001eb2dc: 97fdb120    	bl	0x10015775c <core::ptr::drop_glue::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>>
1001eb2e0: 39600e68    	ldrb	w8, [x19, #0x803]
1001eb2e4: 36000068    	tbz	w8, #0x0, 0x1001eb2f0 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa2c>
1001eb2e8: aa1303e0    	mov	x0, x19
1001eb2ec: 97fe2f27    	bl	0x100176f88 <core::ptr::drop_glue::<tauri::webview::Webview>>
1001eb2f0: 39600a68    	ldrb	w8, [x19, #0x802]
1001eb2f4: 36000128    	tbz	w8, #0x0, 0x1001eb318 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa54>
1001eb2f8: f940c268    	ldr	x8, [x19, #0x180]
1001eb2fc: 92800009    	mov	x9, #-0x1               ; =-1
1001eb300: f8690108    	ldaddl	x9, x8, [x8]
1001eb304: f100051f    	cmp	x8, #0x1
1001eb308: 54000081    	b.ne	0x1001eb318 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa54>
1001eb30c: d50339bf    	dmb	ishld
1001eb310: 91060260    	add	x0, x19, #0x180
1001eb314: 943b1c4b    	bl	0x1010b2440 <<alloc::sync::Arc<std::sync::poison::mutex::Mutex<core::option::Option<alloc::boxed::Box<dyn core::ops::function::FnOnce<(tauri::webview::Webview, alloc::string::String, tauri::ipc::InvokeResponse, tauri::ipc::CallbackFn, tauri::ipc::CallbackFn), Output = ()> + core::marker::Send>>>>>::drop_slow>
1001eb318: 39600668    	ldrb	w8, [x19, #0x801]
1001eb31c: 360000c8    	tbz	w8, #0x0, 0x1001eb334 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa70>
1001eb320: f940b661    	ldr	x1, [x19, #0x168]
1001eb324: b4000081    	cbz	x1, 0x1001eb334 <<tauri::ipc::InvokeResolver>::respond_async_serialized_inner::<conductor_lib::run::{closure#5}::{closure#2}::{closure#0}>::{closure#0}+0xa70>
1001eb328: f940ba60    	ldr	x0, [x19, #0x170]
1001eb32c: 52800022    	mov	w2, #0x1                ; =1
1001eb330: 97f858c9    	bl	0x100001654 <__rustc::__rust_dealloc>
1001eb334: 52800048    	mov	w8, #0x2                ; =2
1001eb338: 39200268    	strb	w8, [x19, #0x800]
1001eb33c: aa1403e0    	mov	x0, x20
1001eb340: 94465612    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
1001eb344: 94465374    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1001eb348: 94465373    	bl	0x101380114 <core::panicking::panic_in_cleanup>
