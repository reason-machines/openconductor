#!/usr/bin/env python3
import hashlib,json,pathlib,re
root=pathlib.Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
manifest=json.loads((root/'manifest.json').read_text())
for row in manifest['files']:
    data=(root/row['path']).read_bytes()
    assert len(data)==row['size'] and sha(data)==row['sha256'],row['path']
report=json.loads((root/'static-recovery.json').read_text())
count=0
for row in report['functions']:
    start=int(row['address'],16);end=int(row['end_exclusive'],16)
    data=(root/(row['address']+'.bin')).read_bytes()
    text=(root/(row['address']+'.s')).read_text()
    assert len(data)==end-start and sha(data)==row['raw_sha256']
    words=[]
    for line in text.splitlines():
        match=re.match(r'^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(.+)$',line)
        if match:words.append((int(match[1],16),bytes.fromhex(match[2])[::-1]))
    assert [a for a,b in words]==list(range(start,end,4))
    assert b''.join(b for a,b in words)==data
    count+=len(words)
assert count==8874
assert report['rea_macho']['subject']['digest']['sha256']==manifest['binary_sha256']
print(json.dumps({'archive_payload_hashes':'PASS','payloads':len(manifest['files']),'contiguous_function_intervals':'PASS','ranges':len(report['functions']),'instruction_word_to_raw_bytes':'PASS','instruction_words':count,'rea_subject_binding':'PASS','target_runtime':'NOT RUN'}))
