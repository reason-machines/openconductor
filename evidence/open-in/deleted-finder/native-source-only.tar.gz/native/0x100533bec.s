
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100533bec <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll>:
100533bec: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100533bf0: a90167fa    	stp	x26, x25, [sp, #0x10]
100533bf4: a9025ff8    	stp	x24, x23, [sp, #0x20]
100533bf8: a90357f6    	stp	x22, x21, [sp, #0x30]
100533bfc: a9044ff4    	stp	x20, x19, [sp, #0x40]
100533c00: a9057bfd    	stp	x29, x30, [sp, #0x50]
100533c04: 910143fd    	add	x29, sp, #0x50
100533c08: d10ac3ff    	sub	sp, sp, #0x2b0
100533c0c: aa0803f3    	mov	x19, x8
100533c10: f9400008    	ldr	x8, [x0]
100533c14: 92800009    	mov	x9, #-0x1               ; =-1
100533c18: f9000009    	str	x9, [x0]
100533c1c: b100051f    	cmn	x8, #0x1
100533c20: 54002e60    	b.eq	0x1005341ec <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x600>
100533c24: f9000be8    	str	x8, [sp, #0x10]
100533c28: 3cc18000    	ldur	q0, [x0, #0x18]
100533c2c: 3c8283e0    	stur	q0, [sp, #0x28]
100533c30: 3cc28000    	ldur	q0, [x0, #0x28]
100533c34: 3c8383e0    	stur	q0, [sp, #0x38]
100533c38: 3cc38000    	ldur	q0, [x0, #0x38]
100533c3c: 3c8483e0    	stur	q0, [sp, #0x48]
100533c40: f9402408    	ldr	x8, [x0, #0x48]
100533c44: f9002fe8    	str	x8, [sp, #0x58]
100533c48: 3cc08000    	ldur	q0, [x0, #0x8]
100533c4c: 3c8183e0    	stur	q0, [sp, #0x18]
100533c50: 94315b90    	bl	0x10118aa90 <tokio::task::coop::stop>
100533c54: ad4087e0    	ldp	q0, q1, [sp, #0x10]
100533c58: ad0307e0    	stp	q0, q1, [sp, #0x60]
100533c5c: ad4187e0    	ldp	q0, q1, [sp, #0x30]
100533c60: ad0407e0    	stp	q0, q1, [sp, #0x80]
100533c64: 3dc017e0    	ldr	q0, [sp, #0x50]
100533c68: 3d802be0    	str	q0, [sp, #0xa0]
100533c6c: a94687f4    	ldp	x20, x1, [sp, #0x68]
100533c70: 9102e3e8    	add	x8, sp, #0xb8
100533c74: aa1403e0    	mov	x0, x20
100533c78: 9436f396    	bl	0x1012f0ad0 <<std::sys::process::unix::common::Command>::new>
100533c7c: 3942a3e8    	ldrb	w8, [sp, #0xa8]
100533c80: 360000c8    	tbz	w8, #0x0, 0x100533c98 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0xac>
100533c84: 90007f01    	adrp	x1, 0x101513000 <_anon.def0b1131f0f986ffe3c7338b3d94cc4.425+0x1>
100533c88: 9109f821    	add	x1, x1, #0x27e
100533c8c: 9102e3e0    	add	x0, sp, #0xb8
100533c90: 52800042    	mov	w2, #0x2                ; =2
100533c94: 9436f313    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
100533c98: 90007f01    	adrp	x1, 0x101513000 <_anon.def0b1131f0f986ffe3c7338b3d94cc4.425+0x1>
100533c9c: 910a0021    	add	x1, x1, #0x280
100533ca0: 9102e3e0    	add	x0, sp, #0xb8
100533ca4: 52800042    	mov	w2, #0x2                ; =2
100533ca8: 9436f30e    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
100533cac: a9480bf5    	ldp	x21, x2, [sp, #0x80]
100533cb0: 9102e3e0    	add	x0, sp, #0xb8
100533cb4: aa1503e1    	mov	x1, x21
100533cb8: 9436f30a    	bl	0x1012f08e0 <<std::sys::process::unix::common::Command>::arg>
100533cbc: 9102e3e0    	add	x0, sp, #0xb8
100533cc0: 52800021    	mov	w1, #0x1                ; =1
100533cc4: 9436f421    	bl	0x1012f0d48 <<std::sys::process::unix::common::Command>::stdin>
100533cc8: 9102e3e0    	add	x0, sp, #0xb8
100533ccc: 52800041    	mov	w1, #0x2                ; =2
100533cd0: 9436f440    	bl	0x1012f0dd0 <<std::sys::process::unix::common::Command>::stdout>
100533cd4: 9102e3e0    	add	x0, sp, #0xb8
100533cd8: 52800041    	mov	w1, #0x2                ; =2
100533cdc: 9436f42c    	bl	0x1012f0d8c <<std::sys::process::unix::common::Command>::stderr>
100533ce0: 910663e8    	add	x8, sp, #0x198
100533ce4: 9102e3e0    	add	x0, sp, #0xb8
100533ce8: 9436fbd7    	bl	0x1012f2c44 <<std::process::Command>::spawn>
100533cec: 910603f7    	add	x23, sp, #0x180
100533cf0: b9419be8    	ldr	w8, [sp, #0x198]
100533cf4: 7100091f    	cmp	w8, #0x2
100533cf8: 54000381    	b.ne	0x100533d68 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x17c>
100533cfc: f940d3e8    	ldr	x8, [sp, #0x1a0]
100533d00: f81483a8    	stur	x8, [x29, #-0xb8]
100533d04: d102e3a8    	sub	x8, x29, #0xb8
100533d08: b0006f69    	adrp	x9, 0x101320000 <<core::num::niche_types::I32NotAllOnes as core::fmt::Debug>::fmt+0x20>
100533d0c: 9116c129    	add	x9, x9, #0x5b0
100533d10: a93627a8    	stp	x8, x9, [x29, #-0xa0]
100533d14: 90013c20    	adrp	x0, 0x102cb7000 <_anon.dfaadf50359b6dc611e2f8074053fec3.144+0x643>
100533d18: 9123c000    	add	x0, x0, #0x8f0
100533d1c: 910743e8    	add	x8, sp, #0x1d0
100533d20: d10283a1    	sub	x1, x29, #0xa0
100533d24: 94377754    	bl	0x101311a74 <alloc::fmt::format::format_inner>
100533d28: f85483a8    	ldur	x8, [x29, #-0xb8]
100533d2c: 92400509    	and	x9, x8, #0x3
100533d30: d100092a    	sub	x10, x9, #0x2
100533d34: f100095f    	cmp	x10, #0x2
100533d38: 54000123    	b.lo	0x100533d5c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x170>
100533d3c: b4000109    	cbz	x9, 0x100533d5c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x170>
100533d40: d1000508    	sub	x8, x8, #0x1
100533d44: d10283a9    	sub	x9, x29, #0xa0
100533d48: f81683a8    	stur	x8, [x29, #-0x98]
100533d4c: 52800068    	mov	w8, #0x3                ; =3
100533d50: 381603a8    	sturb	w8, [x29, #-0xa0]
100533d54: 91002120    	add	x0, x9, #0x8
100533d58: 9437b85c    	bl	0x101321ec8 <<core::io::error::CustomOwner as core::ops::drop::Drop>::drop>
100533d5c: f940ebf8    	ldr	x24, [sp, #0x1d0]
100533d60: 3cc582e0    	ldur	q0, [x23, #0x58]
100533d64: 14000076    	b	0x100533f3c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x350>
100533d68: f841c2e9    	ldur	x9, [x23, #0x1c]
100533d6c: f84242ea    	ldur	x10, [x23, #0x24]
100533d70: b941afeb    	ldr	w11, [sp, #0x1ac]
100533d74: f80042e9    	stur	x9, [x23, #0x4]
100533d78: b90183e8    	str	w8, [sp, #0x180]
100533d7c: b90197eb    	str	w11, [sp, #0x194]
100533d80: f800c2ea    	stur	x10, [x23, #0xc]
100533d84: d360fd36    	lsr	x22, x9, #32
100533d88: a94927e8    	ldp	x8, x9, [sp, #0x90]
100533d8c: f94053e3    	ldr	x3, [sp, #0xa0]
100533d90: b100051f    	cmn	x8, #0x1
100533d94: 9a8903e2    	csel	x2, xzr, x9, eq
100533d98: 52800020    	mov	w0, #0x1                ; =1
100533d9c: aa1603e1    	mov	x1, x22
100533da0: 94091be7    	bl	0x10077ad3c <conductor_lib::resource_usage::register_resource_usage_command_line>
100533da4: 3dc063e0    	ldr	q0, [sp, #0x180]
100533da8: 3d8077e0    	str	q0, [sp, #0x1d0]
100533dac: f940cbe8    	ldr	x8, [sp, #0x190]
100533db0: f900f3e8    	str	x8, [sp, #0x1e0]
100533db4: 910663e8    	add	x8, sp, #0x198
100533db8: 910743e0    	add	x0, sp, #0x1d0
100533dbc: 9436df5a    	bl	0x1012ebb24 <<std::process::Child>::wait_with_output>
100533dc0: 52800020    	mov	w0, #0x1                ; =1
100533dc4: aa1603e1    	mov	x1, x22
100533dc8: 94091e03    	bl	0x10077b5d4 <conductor_lib::resource_usage::unregister_resource_usage_command_line>
100533dcc: a959ebf6    	ldp	x22, x26, [sp, #0x198]
100533dd0: b10006df    	cmn	x22, #0x1
100533dd4: 54000820    	b.eq	0x100533ed8 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x2ec>
100533dd8: 3cc382e0    	ldur	q0, [x23, #0x38]
100533ddc: f940e7e8    	ldr	x8, [sp, #0x1c8]
100533de0: f90103e8    	str	x8, [sp, #0x200]
100533de4: 3cc282e1    	ldur	q1, [x23, #0x28]
100533de8: ad0f03e1    	stp	q1, q0, [sp, #0x1e0]
100533dec: a91d6bf6    	stp	x22, x26, [sp, #0x1d0]
100533df0: f81083bf    	stur	xzr, [x29, #-0xf8]
100533df4: f81183bf    	stur	xzr, [x29, #-0xe8]
100533df8: 97eb361a    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100533dfc: 52800098    	mov	w24, #0x4               ; =4
100533e00: 52800080    	mov	w0, #0x4                ; =4
100533e04: 52800021    	mov	w1, #0x1                ; =1
100533e08: 97eb3612    	bl	0x100001650 <__rustc::__rust_alloc>
100533e0c: b4001fc0    	cbz	x0, 0x100534204 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x618>
100533e10: 528dec68    	mov	w8, #0x6f63             ; =28515
100533e14: 72acac88    	movk	w8, #0x6564, lsl #16
100533e18: b9000008    	str	w8, [x0]
100533e1c: 52800088    	mov	w8, #0x4                ; =4
100533e20: a93803a8    	stp	x8, x0, [x29, #-0x80]
100533e24: f81903a8    	stur	x8, [x29, #-0x70]
100533e28: b94203e8    	ldr	w8, [sp, #0x200]
100533e2c: d348fd09    	lsr	x9, x8, #8
100533e30: 92401d29    	and	x9, x9, #0xff
100533e34: 7200191f    	tst	w8, #0x7f
100533e38: 52800048    	mov	w8, #0x2                ; =2
100533e3c: 1a9f0108    	csel	w8, w8, wzr, eq
100533e40: 381603a8    	sturb	w8, [x29, #-0xa0]
100533e44: a936a7bf    	stp	xzr, x9, [x29, #-0x98]
100533e48: d10383a8    	sub	x8, x29, #0xe0
100533e4c: d103e3a0    	sub	x0, x29, #0xf8
100533e50: d10203a1    	sub	x1, x29, #0x80
100533e54: d10283a2    	sub	x2, x29, #0xa0
100533e58: 94072d9d    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
100533e5c: 385203a8    	ldurb	w8, [x29, #-0xe0]
100533e60: 7103fd1f    	cmp	w8, #0xff
100533e64: 54000060    	b.eq	0x100533e70 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x284>
100533e68: d10383a0    	sub	x0, x29, #0xe0
100533e6c: 97fed063    	bl	0x1004e7ff8 <core::ptr::drop_glue::<serde_json::value::Value>>
100533e70: 97eb35fc    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100533e74: 528000d8    	mov	w24, #0x6               ; =6
100533e78: 528000c0    	mov	w0, #0x6                ; =6
100533e7c: 52800021    	mov	w1, #0x1                ; =1
100533e80: 97eb35f4    	bl	0x100001650 <__rustc::__rust_alloc>
100533e84: b4001c00    	cbz	x0, 0x100534204 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x618>
100533e88: aa0003fb    	mov	x27, x0
100533e8c: 528e8ea8    	mov	w8, #0x7475             ; =29813
100533e90: 79000808    	strh	w8, [x0, #0x4]
100533e94: 528e8e68    	mov	w8, #0x7473             ; =29811
100533e98: 72adec88    	movk	w8, #0x6f64, lsl #16
100533e9c: b9000008    	str	w8, [x0]
100533ea0: 528000c8    	mov	w8, #0x6                ; =6
100533ea4: a93483a8    	stp	x8, x0, [x29, #-0xb8]
100533ea8: f81583a8    	stur	x8, [x29, #-0xa8]
100533eac: f940f3e1    	ldr	x1, [sp, #0x1e0]
100533eb0: d10203a8    	sub	x8, x29, #0x80
100533eb4: aa1a03e0    	mov	x0, x26
100533eb8: 943770c2    	bl	0x1013101c0 <<alloc::string::String>::from_utf8_lossy>
100533ebc: a978e7b8    	ldp	x24, x25, [x29, #-0x78]
100533ec0: b6f80819    	tbz	x25, #0x3f, 0x100533fc0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x3d4>
100533ec4: d280001c    	mov	x28, #0x0               ; =0
100533ec8: aa1c03e0    	mov	x0, x28
100533ecc: aa1903e1    	mov	x1, x25
100533ed0: 94392ff8    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100533ed4: 140000d7    	b	0x100534230 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x644>
100533ed8: f81803ba    	stur	x26, [x29, #-0x80]
100533edc: d10203a8    	sub	x8, x29, #0x80
100533ee0: b0006f69    	adrp	x9, 0x101320000 <<core::num::niche_types::I32NotAllOnes as core::fmt::Debug>::fmt+0x20>
100533ee4: 9116c129    	add	x9, x9, #0x5b0
100533ee8: a93227a8    	stp	x8, x9, [x29, #-0xe0]
100533eec: 90013c20    	adrp	x0, 0x102cb7000 <_anon.dfaadf50359b6dc611e2f8074053fec3.144+0x643>
100533ef0: 91243800    	add	x0, x0, #0x90e
100533ef4: d10283a8    	sub	x8, x29, #0xa0
100533ef8: d10383a1    	sub	x1, x29, #0xe0
100533efc: 943776de    	bl	0x101311a74 <alloc::fmt::format::format_inner>
100533f00: f85803a8    	ldur	x8, [x29, #-0x80]
100533f04: 92400509    	and	x9, x8, #0x3
100533f08: d100092a    	sub	x10, x9, #0x2
100533f0c: f100095f    	cmp	x10, #0x2
100533f10: 54000123    	b.lo	0x100533f34 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x348>
100533f14: b4000109    	cbz	x9, 0x100533f34 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x348>
100533f18: d1000508    	sub	x8, x8, #0x1
100533f1c: d10383a9    	sub	x9, x29, #0xe0
100533f20: f81283a8    	stur	x8, [x29, #-0xd8]
100533f24: 52800068    	mov	w8, #0x3                ; =3
100533f28: 381203a8    	sturb	w8, [x29, #-0xe0]
100533f2c: 91002120    	add	x0, x9, #0x8
100533f30: 9437b7e6    	bl	0x101321ec8 <<core::io::error::CustomOwner as core::ops::drop::Drop>::drop>
100533f34: f85603b8    	ldur	x24, [x29, #-0xa0]
100533f38: 3cce82e0    	ldur	q0, [x23, #0xe8]
100533f3c: 3c9203a0    	stur	q0, [x29, #-0xe0]
100533f40: 52801ff6    	mov	w22, #0xff              ; =255
100533f44: 9102e3e0    	add	x0, sp, #0xb8
100533f48: 97fed13d    	bl	0x1004e843c <core::ptr::drop_glue::<std::process::Command>>
100533f4c: f94033e1    	ldr	x1, [sp, #0x60]
100533f50: b4000081    	cbz	x1, 0x100533f60 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x374>
100533f54: aa1403e0    	mov	x0, x20
100533f58: 52800022    	mov	w2, #0x1                ; =1
100533f5c: 97eb35be    	bl	0x100001654 <__rustc::__rust_dealloc>
100533f60: f9403fe1    	ldr	x1, [sp, #0x78]
100533f64: b4000081    	cbz	x1, 0x100533f74 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x388>
100533f68: aa1503e0    	mov	x0, x21
100533f6c: 52800022    	mov	w2, #0x1                ; =1
100533f70: 97eb35b9    	bl	0x100001654 <__rustc::__rust_dealloc>
100533f74: f9404be1    	ldr	x1, [sp, #0x90]
100533f78: b100043f    	cmn	x1, #0x1
100533f7c: 540000a0    	b.eq	0x100533f90 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x3a4>
100533f80: b4000081    	cbz	x1, 0x100533f90 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x3a4>
100533f84: f9404fe0    	ldr	x0, [sp, #0x98]
100533f88: 52800022    	mov	w2, #0x1                ; =1
100533f8c: 97eb35b2    	bl	0x100001654 <__rustc::__rust_dealloc>
100533f90: 39000276    	strb	w22, [x19]
100533f94: f9000678    	str	x24, [x19, #0x8]
100533f98: 3cd203a0    	ldur	q0, [x29, #-0xe0]
100533f9c: 3d800660    	str	q0, [x19, #0x10]
100533fa0: 910ac3ff    	add	sp, sp, #0x2b0
100533fa4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100533fa8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100533fac: a94357f6    	ldp	x22, x21, [sp, #0x30]
100533fb0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100533fb4: a94167fa    	ldp	x26, x25, [sp, #0x10]
100533fb8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100533fbc: d65f03c0    	ret
100533fc0: f90003fa    	str	x26, [sp]
100533fc4: b40002b9    	cbz	x25, 0x100534018 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x42c>
100533fc8: 97eb35a6    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100533fcc: 5280003c    	mov	w28, #0x1               ; =1
100533fd0: aa1903e0    	mov	x0, x25
100533fd4: 52800021    	mov	w1, #0x1                ; =1
100533fd8: 97eb359e    	bl	0x100001650 <__rustc::__rust_alloc>
100533fdc: b4fff760    	cbz	x0, 0x100533ec8 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x2dc>
100533fe0: aa0003fa    	mov	x26, x0
100533fe4: aa1803e1    	mov	x1, x24
100533fe8: aa1903e2    	mov	x2, x25
100533fec: 94393449    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100533ff0: 97eb359c    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100533ff4: aa1903e0    	mov	x0, x25
100533ff8: 52800021    	mov	w1, #0x1                ; =1
100533ffc: 97eb3595    	bl	0x100001650 <__rustc::__rust_alloc>
100534000: b40010a0    	cbz	x0, 0x100534214 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x628>
100534004: aa0003fc    	mov	x28, x0
100534008: aa1a03e1    	mov	x1, x26
10053400c: aa1903e2    	mov	x2, x25
100534010: 94393440    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100534014: 14000003    	b	0x100534020 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x434>
100534018: 5280003a    	mov	w26, #0x1               ; =1
10053401c: 5280003c    	mov	w28, #0x1               ; =1
100534020: 52800068    	mov	w8, #0x3                ; =3
100534024: 381603a8    	sturb	w8, [x29, #-0xa0]
100534028: a936f3b9    	stp	x25, x28, [x29, #-0x98]
10053402c: f81783b9    	stur	x25, [x29, #-0x88]
100534030: d10383a8    	sub	x8, x29, #0xe0
100534034: d103e3a0    	sub	x0, x29, #0xf8
100534038: d102e3a1    	sub	x1, x29, #0xb8
10053403c: d10283a2    	sub	x2, x29, #0xa0
100534040: 94072d23    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
100534044: 385203a8    	ldurb	w8, [x29, #-0xe0]
100534048: 7103fd1f    	cmp	w8, #0xff
10053404c: 54000060    	b.eq	0x100534058 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x46c>
100534050: d10383a0    	sub	x0, x29, #0xe0
100534054: 97fecfe9    	bl	0x1004e7ff8 <core::ptr::drop_glue::<serde_json::value::Value>>
100534058: b40000b9    	cbz	x25, 0x10053406c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x480>
10053405c: aa1a03e0    	mov	x0, x26
100534060: aa1903e1    	mov	x1, x25
100534064: 52800022    	mov	w2, #0x1                ; =1
100534068: 97eb357b    	bl	0x100001654 <__rustc::__rust_dealloc>
10053406c: f85803a1    	ldur	x1, [x29, #-0x80]
100534070: f100003f    	cmp	x1, #0x0
100534074: 5400008d    	b.le	0x100534084 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x498>
100534078: aa1803e0    	mov	x0, x24
10053407c: 52800022    	mov	w2, #0x1                ; =1
100534080: 97eb3575    	bl	0x100001654 <__rustc::__rust_dealloc>
100534084: 97eb3577    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100534088: 528000d8    	mov	w24, #0x6               ; =6
10053408c: 528000c0    	mov	w0, #0x6                ; =6
100534090: 52800021    	mov	w1, #0x1                ; =1
100534094: 97eb356f    	bl	0x100001650 <__rustc::__rust_alloc>
100534098: b4000b60    	cbz	x0, 0x100534204 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x618>
10053409c: aa0003fc    	mov	x28, x0
1005340a0: 528e4e48    	mov	w8, #0x7272             ; =29298
1005340a4: 79000808    	strh	w8, [x0, #0x4]
1005340a8: 528e8e68    	mov	w8, #0x7473             ; =29811
1005340ac: 72acac88    	movk	w8, #0x6564, lsl #16
1005340b0: b9000008    	str	w8, [x0]
1005340b4: 528000c8    	mov	w8, #0x6                ; =6
1005340b8: a93483a8    	stp	x8, x0, [x29, #-0xb8]
1005340bc: f81583a8    	stur	x8, [x29, #-0xa8]
1005340c0: a95f07fa    	ldp	x26, x1, [sp, #0x1f0]
1005340c4: d10203a8    	sub	x8, x29, #0x80
1005340c8: aa1a03e0    	mov	x0, x26
1005340cc: 9437703d    	bl	0x1013101c0 <<alloc::string::String>::from_utf8_lossy>
1005340d0: a978e7a8    	ldp	x8, x25, [x29, #-0x78]
1005340d4: f90007e8    	str	x8, [sp, #0x8]
1005340d8: b6f800d9    	tbz	x25, #0x3f, 0x1005340f0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x504>
1005340dc: d2800018    	mov	x24, #0x0               ; =0
1005340e0: aa1803e0    	mov	x0, x24
1005340e4: aa1903e1    	mov	x1, x25
1005340e8: 94392f72    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1005340ec: 14000051    	b	0x100534230 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x644>
1005340f0: b40002b9    	cbz	x25, 0x100534144 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x558>
1005340f4: 97eb355b    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1005340f8: 52800038    	mov	w24, #0x1               ; =1
1005340fc: aa1903e0    	mov	x0, x25
100534100: 52800021    	mov	w1, #0x1                ; =1
100534104: 97eb3553    	bl	0x100001650 <__rustc::__rust_alloc>
100534108: b4fffec0    	cbz	x0, 0x1005340e0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x4f4>
10053410c: aa0003fb    	mov	x27, x0
100534110: f94007e1    	ldr	x1, [sp, #0x8]
100534114: aa1903e2    	mov	x2, x25
100534118: 943933fe    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10053411c: 97eb3551    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100534120: aa1903e0    	mov	x0, x25
100534124: 52800021    	mov	w1, #0x1                ; =1
100534128: 97eb354a    	bl	0x100001650 <__rustc::__rust_alloc>
10053412c: b40007c0    	cbz	x0, 0x100534224 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x638>
100534130: aa0003f8    	mov	x24, x0
100534134: aa1b03e1    	mov	x1, x27
100534138: aa1903e2    	mov	x2, x25
10053413c: 943933f5    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100534140: 14000003    	b	0x10053414c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x560>
100534144: 5280003b    	mov	w27, #0x1               ; =1
100534148: 52800038    	mov	w24, #0x1               ; =1
10053414c: 52800068    	mov	w8, #0x3                ; =3
100534150: 381603a8    	sturb	w8, [x29, #-0xa0]
100534154: a936e3b9    	stp	x25, x24, [x29, #-0x98]
100534158: f81783b9    	stur	x25, [x29, #-0x88]
10053415c: d10383a8    	sub	x8, x29, #0xe0
100534160: d103e3a0    	sub	x0, x29, #0xf8
100534164: d102e3a1    	sub	x1, x29, #0xb8
100534168: d10283a2    	sub	x2, x29, #0xa0
10053416c: 94072cd8    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
100534170: 385203a8    	ldurb	w8, [x29, #-0xe0]
100534174: 7103fd1f    	cmp	w8, #0xff
100534178: 54000060    	b.eq	0x100534184 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x598>
10053417c: d10383a0    	sub	x0, x29, #0xe0
100534180: 97fecf9e    	bl	0x1004e7ff8 <core::ptr::drop_glue::<serde_json::value::Value>>
100534184: b40000b9    	cbz	x25, 0x100534198 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x5ac>
100534188: aa1b03e0    	mov	x0, x27
10053418c: aa1903e1    	mov	x1, x25
100534190: 52800022    	mov	w2, #0x1                ; =1
100534194: 97eb3530    	bl	0x100001654 <__rustc::__rust_dealloc>
100534198: f85803a1    	ldur	x1, [x29, #-0x80]
10053419c: f100003f    	cmp	x1, #0x0
1005341a0: 5400008d    	b.le	0x1005341b0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x5c4>
1005341a4: f94007e0    	ldr	x0, [sp, #0x8]
1005341a8: 52800022    	mov	w2, #0x1                ; =1
1005341ac: 97eb352a    	bl	0x100001654 <__rustc::__rust_dealloc>
1005341b0: f85083b8    	ldur	x24, [x29, #-0xf8]
1005341b4: 3cc902e0    	ldur	q0, [x23, #0x90]
1005341b8: 3c9203a0    	stur	q0, [x29, #-0xe0]
1005341bc: b40000b6    	cbz	x22, 0x1005341d0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x5e4>
1005341c0: f94003e0    	ldr	x0, [sp]
1005341c4: aa1603e1    	mov	x1, x22
1005341c8: 52800022    	mov	w2, #0x1                ; =1
1005341cc: 97eb3522    	bl	0x100001654 <__rustc::__rust_dealloc>
1005341d0: f940f7e1    	ldr	x1, [sp, #0x1e8]
1005341d4: b4000081    	cbz	x1, 0x1005341e4 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x5f8>
1005341d8: aa1a03e0    	mov	x0, x26
1005341dc: 52800022    	mov	w2, #0x1                ; =1
1005341e0: 97eb351d    	bl	0x100001654 <__rustc::__rust_dealloc>
1005341e4: 528000b6    	mov	w22, #0x5               ; =5
1005341e8: 17ffff57    	b	0x100533f44 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x358>
1005341ec: f0007ee0    	adrp	x0, 0x101513000 <_anon.def0b1131f0f986ffe3c7338b3d94cc4.425+0x1>
1005341f0: 9110ec00    	add	x0, x0, #0x43b
1005341f4: d0015a42    	adrp	x2, 0x10307e000 <_anon.def0b1131f0f986ffe3c7338b3d94cc4.521+0x40>
1005341f8: 91178042    	add	x2, x2, #0x5e0
1005341fc: 528005a1    	mov	w1, #0x2d               ; =45
100534200: 94392f98    	bl	0x101380060 <core::option::expect_failed>
100534204: 52800020    	mov	w0, #0x1                ; =1
100534208: aa1803e1    	mov	x1, x24
10053420c: 94392f29    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100534210: 14000008    	b	0x100534230 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x644>
100534214: 52800020    	mov	w0, #0x1                ; =1
100534218: aa1903e1    	mov	x1, x25
10053421c: 94392f25    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100534220: 14000004    	b	0x100534230 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x644>
100534224: 52800020    	mov	w0, #0x1                ; =1
100534228: aa1903e1    	mov	x1, x25
10053422c: 94392f21    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100534230: d4200020    	brk	#0x1
100534234: 14000040    	b	0x100534334 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x748>
100534238: 14000007    	b	0x100534254 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x668>
10053423c: aa0003f3    	mov	x19, x0
100534240: aa1c03e0    	mov	x0, x28
100534244: 528000c1    	mov	w1, #0x6                ; =6
100534248: 52800022    	mov	w2, #0x1                ; =1
10053424c: 97eb3502    	bl	0x100001654 <__rustc::__rust_dealloc>
100534250: 14000003    	b	0x10053425c <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x670>
100534254: aa0003f3    	mov	x19, x0
100534258: b40007d9    	cbz	x25, 0x100534350 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x764>
10053425c: aa1b03e0    	mov	x0, x27
100534260: aa1903e1    	mov	x1, x25
100534264: 14000039    	b	0x100534348 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x75c>
100534268: 1400000a    	b	0x100534290 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x6a4>
10053426c: aa0003f3    	mov	x19, x0
100534270: aa1b03e0    	mov	x0, x27
100534274: 528000c1    	mov	w1, #0x6                ; =6
100534278: 52800022    	mov	w2, #0x1                ; =1
10053427c: 97eb34f6    	bl	0x100001654 <__rustc::__rust_dealloc>
100534280: 14000006    	b	0x100534298 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x6ac>
100534284: aa0003f3    	mov	x19, x0
100534288: aa1c03e0    	mov	x0, x28
10053428c: 1400000d    	b	0x1005342c0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x6d4>
100534290: aa0003f3    	mov	x19, x0
100534294: b4000739    	cbz	x25, 0x100534378 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x78c>
100534298: aa1a03e0    	mov	x0, x26
10053429c: aa1903e1    	mov	x1, x25
1005342a0: 14000034    	b	0x100534370 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x784>
1005342a4: aa0003f3    	mov	x19, x0
1005342a8: d10203a0    	sub	x0, x29, #0x80
1005342ac: 97fed8fd    	bl	0x1004ea6a0 <core::ptr::drop_glue::<core::io::error::Error>>
1005342b0: 1400003c    	b	0x1005343a0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7b4>
1005342b4: 94392f98    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1005342b8: aa0003f3    	mov	x19, x0
1005342bc: aa1b03e0    	mov	x0, x27
1005342c0: 528000c1    	mov	w1, #0x6                ; =6
1005342c4: 14000031    	b	0x100534388 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x79c>
1005342c8: 1400000f    	b	0x100534304 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x718>
1005342cc: aa0003f3    	mov	x19, x0
1005342d0: 910663e0    	add	x0, sp, #0x198
1005342d4: 97feb594    	bl	0x1004e1924 <core::ptr::drop_glue::<core::result::Result<std::process::Output, core::io::error::Error>>>
1005342d8: 14000032    	b	0x1005343a0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7b4>
1005342dc: 14000016    	b	0x100534334 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x748>
1005342e0: aa0003f3    	mov	x19, x0
1005342e4: 910603e0    	add	x0, sp, #0x180
1005342e8: 97fed02d    	bl	0x1004e839c <core::ptr::drop_glue::<std::process::Child>>
1005342ec: 1400002d    	b	0x1005343a0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7b4>
1005342f0: aa0003f3    	mov	x19, x0
1005342f4: d102e3a0    	sub	x0, x29, #0xb8
1005342f8: 97fed8ea    	bl	0x1004ea6a0 <core::ptr::drop_glue::<core::io::error::Error>>
1005342fc: 14000029    	b	0x1005343a0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7b4>
100534300: 94392f85    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100534304: aa0003f3    	mov	x19, x0
100534308: 14000022    	b	0x100534390 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7a4>
10053430c: aa0003f3    	mov	x19, x0
100534310: 910043e0    	add	x0, sp, #0x10
100534314: 97fecc33    	bl	0x1004e73e0 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}::{closure#0}>>
100534318: aa1303e0    	mov	x0, x19
10053431c: 9439321b    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
100534320: aa0003f3    	mov	x19, x0
100534324: 910183e0    	add	x0, sp, #0x60
100534328: 97fecc2e    	bl	0x1004e73e0 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}::{closure#0}>>
10053432c: aa1303e0    	mov	x0, x19
100534330: 94393216    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
100534334: aa0003f3    	mov	x19, x0
100534338: 1400001a    	b	0x1005343a0 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7b4>
10053433c: aa0003f3    	mov	x19, x0
100534340: aa1c03e0    	mov	x0, x28
100534344: 528000c1    	mov	w1, #0x6                ; =6
100534348: 52800022    	mov	w2, #0x1                ; =1
10053434c: 97eb34c2    	bl	0x100001654 <__rustc::__rust_dealloc>
100534350: f85803a1    	ldur	x1, [x29, #-0x80]
100534354: f100043f    	cmp	x1, #0x1
100534358: 540001cb    	b.lt	0x100534390 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7a4>
10053435c: f94007e0    	ldr	x0, [sp, #0x8]
100534360: 1400000a    	b	0x100534388 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x79c>
100534364: aa0003f3    	mov	x19, x0
100534368: aa1b03e0    	mov	x0, x27
10053436c: 528000c1    	mov	w1, #0x6                ; =6
100534370: 52800022    	mov	w2, #0x1                ; =1
100534374: 97eb34b8    	bl	0x100001654 <__rustc::__rust_dealloc>
100534378: f85803a1    	ldur	x1, [x29, #-0x80]
10053437c: f100043f    	cmp	x1, #0x1
100534380: 5400008b    	b.lt	0x100534390 <<tokio::runtime::blocking::task::BlockingTask<conductor_lib::execute_shell_command::{closure#0}::{closure#0}> as core::future::future::Future>::poll+0x7a4>
100534384: aa1803e0    	mov	x0, x24
100534388: 52800022    	mov	w2, #0x1                ; =1
10053438c: 97eb34b2    	bl	0x100001654 <__rustc::__rust_dealloc>
100534390: d103e3a0    	sub	x0, x29, #0xf8
100534394: 94076af3    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
100534398: 910743e0    	add	x0, sp, #0x1d0
10053439c: 97fed015    	bl	0x1004e83f0 <core::ptr::drop_glue::<std::process::Output>>
1005343a0: 9102e3e0    	add	x0, sp, #0xb8
1005343a4: 97fed026    	bl	0x1004e843c <core::ptr::drop_glue::<std::process::Command>>
1005343a8: 910183e0    	add	x0, sp, #0x60
1005343ac: 97fecc0d    	bl	0x1004e73e0 <core::ptr::drop_glue::<conductor_lib::execute_shell_command::{closure#0}::{closure#0}>>
1005343b0: aa1303e0    	mov	x0, x19
1005343b4: 943931f5    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
1005343b8: 94392f57    	bl	0x101380114 <core::panicking::panic_in_cleanup>
