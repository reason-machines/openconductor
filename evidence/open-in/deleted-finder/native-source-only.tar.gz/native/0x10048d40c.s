
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010048d40c <conductor_lib::run::{closure#5}::{closure#14}>:
10048d40c: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
10048d410: a90157f6    	stp	x22, x21, [sp, #0x10]
10048d414: a9024ff4    	stp	x20, x19, [sp, #0x20]
10048d418: a9037bfd    	stp	x29, x30, [sp, #0x30]
10048d41c: 9100c3fd    	add	x29, sp, #0x30
10048d420: d11b03ff    	sub	sp, sp, #0x6c0
10048d424: f90003ff    	str	xzr, [sp]
10048d428: aa0003f3    	mov	x19, x0
10048d42c: 910e83f4    	add	x20, sp, #0x3a0
10048d430: 910023f5    	add	x21, sp, #0x8
10048d434: 910023e0    	add	x0, sp, #0x8
10048d438: aa1303e1    	mov	x1, x19
10048d43c: 52804102    	mov	w2, #0x208              ; =520
10048d440: 943bcf34    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048d444: 910843e0    	add	x0, sp, #0x210
10048d448: 91082261    	add	x1, x19, #0x208
10048d44c: 52803202    	mov	w2, #0x190              ; =400
10048d450: 943bcf30    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048d454: 910e6268    	add	x8, x19, #0x398
10048d458: 3dc00100    	ldr	q0, [x8]
10048d45c: 3d800280    	str	q0, [x20]
10048d460: f941d668    	ldr	x8, [x19, #0x3a8]
10048d464: f901dbe8    	str	x8, [sp, #0x3b0]
10048d468: d0008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048d46c: 91218508    	add	x8, x8, #0x861
10048d470: f902b3ff    	str	xzr, [sp, #0x560]
10048d474: 52800249    	mov	w9, #0x12               ; =18
10048d478: f9029be8    	str	x8, [sp, #0x530]
10048d47c: f9029fe9    	str	x9, [sp, #0x538]
10048d480: d0008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048d484: 91209d08    	add	x8, x8, #0x827
10048d488: 52800129    	mov	w9, #0x9                ; =9
10048d48c: f902a3e8    	str	x8, [sp, #0x540]
10048d490: f902a7e9    	str	x9, [sp, #0x548]
10048d494: f902abf5    	str	x21, [sp, #0x550]
10048d498: f902aff4    	str	x20, [sp, #0x558]
10048d49c: 52800035    	mov	w21, #0x1               ; =1
10048d4a0: 910ee3e8    	add	x8, sp, #0x3b8
10048d4a4: 9114c3e0    	add	x0, sp, #0x530
10048d4a8: 9400cf44    	bl	0x1004c11b8 <<tauri::app::AppHandle as tauri::ipc::command::CommandArg<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_command>
10048d4ac: f941dfe8    	ldr	x8, [sp, #0x3b8]
10048d4b0: b100051f    	cmn	x8, #0x1
10048d4b4: 54000580    	b.eq	0x10048d564 <conductor_lib::run::{closure#5}::{closure#14}+0x158>
10048d4b8: 910c67e8    	add	x8, sp, #0x319
10048d4bc: 3ccff100    	ldur	q0, [x8, #0xff]
10048d4c0: 910ca7e8    	add	x8, sp, #0x329
10048d4c4: 3ccff101    	ldur	q1, [x8, #0xff]
10048d4c8: ad088680    	stp	q0, q1, [x20, #0x110]
10048d4cc: 910ce7e8    	add	x8, sp, #0x339
10048d4d0: 3ccff100    	ldur	q0, [x8, #0xff]
10048d4d4: 3d804e80    	str	q0, [x20, #0x130]
10048d4d8: f94227e8    	ldr	x8, [sp, #0x448]
10048d4dc: f90273e8    	str	x8, [sp, #0x4e0]
10048d4e0: 910b67e8    	add	x8, sp, #0x2d9
10048d4e4: 3ccff100    	ldur	q0, [x8, #0xff]
10048d4e8: 910ba7e8    	add	x8, sp, #0x2e9
10048d4ec: 3ccff101    	ldur	q1, [x8, #0xff]
10048d4f0: ad068680    	stp	q0, q1, [x20, #0xd0]
10048d4f4: 910be7e8    	add	x8, sp, #0x2f9
10048d4f8: 3ccff100    	ldur	q0, [x8, #0xff]
10048d4fc: 910c27e8    	add	x8, sp, #0x309
10048d500: 3ccff101    	ldur	q1, [x8, #0xff]
10048d504: ad078680    	stp	q0, q1, [x20, #0xf0]
10048d508: 910ae7e8    	add	x8, sp, #0x2b9
10048d50c: 3ccff100    	ldur	q0, [x8, #0xff]
10048d510: 910b27e8    	add	x8, sp, #0x2c9
10048d514: 3ccff101    	ldur	q1, [x8, #0xff]
10048d518: ad058680    	stp	q0, q1, [x20, #0xb0]
10048d51c: 9113a3e8    	add	x8, sp, #0x4e8
10048d520: 911143e0    	add	x0, sp, #0x450
10048d524: 94096026    	bl	0x1006e55bc <conductor_lib::open_settings_page>
10048d528: 9114c3e0    	add	x0, sp, #0x530
10048d52c: 91082261    	add	x1, x19, #0x208
10048d530: 52803202    	mov	w2, #0x190              ; =400
10048d534: 943bcef7    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048d538: f94277f4    	ldr	x20, [sp, #0x4e8]
10048d53c: b100069f    	cmn	x20, #0x1
10048d540: 54000400    	b.eq	0x10048d5c0 <conductor_lib::run::{closure#5}::{closure#14}+0x1b4>
10048d544: f9427bf5    	ldr	x21, [sp, #0x4f0]
10048d548: f9427ff3    	ldr	x19, [sp, #0x4f8]
10048d54c: b6f80413    	tbz	x19, #0x3f, 0x10048d5cc <conductor_lib::run::{closure#5}::{closure#14}+0x1c0>
10048d550: d2800017    	mov	x23, #0x0               ; =0
10048d554: aa1703e0    	mov	x0, x23
10048d558: aa1303e1    	mov	x1, x19
10048d55c: 943bca55    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
10048d560: d4200020    	brk	#0x1
10048d564: 9113a3f5    	add	x21, sp, #0x4e8
10048d568: ad410680    	ldp	q0, q1, [x20, #0x20]
10048d56c: 3c8082a0    	stur	q0, [x21, #0x8]
10048d570: 3c8182a1    	stur	q1, [x21, #0x18]
10048d574: 9114c3e0    	add	x0, sp, #0x530
10048d578: 91082261    	add	x1, x19, #0x208
10048d57c: 52802d02    	mov	w2, #0x168              ; =360
10048d580: 943bcee4    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048d584: f941cbe1    	ldr	x1, [sp, #0x390]
10048d588: 3dc0de60    	ldr	q0, [x19, #0x370]
10048d58c: 3c8282a0    	stur	q0, [x21, #0x28]
10048d590: f941c268    	ldr	x8, [x19, #0x380]
10048d594: f90293e8    	str	x8, [sp, #0x520]
10048d598: b9439be4    	ldr	w4, [sp, #0x398]
10048d59c: b9439fe5    	ldr	w5, [sp, #0x39c]
10048d5a0: 52800028    	mov	w8, #0x1                ; =1
10048d5a4: f90277e8    	str	x8, [sp, #0x4e8]
10048d5a8: 52800015    	mov	w21, #0x0               ; =0
10048d5ac: 9114c3e0    	add	x0, sp, #0x530
10048d5b0: 9113a3e2    	add	x2, sp, #0x4e8
10048d5b4: 911443e3    	add	x3, sp, #0x510
10048d5b8: 9405f644    	bl	0x10060aec8 <<tauri::ipc::InvokeResolver>::return_result>
10048d5bc: 1400001c    	b	0x10048d62c <conductor_lib::run::{closure#5}::{closure#14}+0x220>
10048d5c0: 52801fe8    	mov	w8, #0xff               ; =255
10048d5c4: 390ee3e8    	strb	w8, [sp, #0x3b8]
10048d5c8: 14000016    	b	0x10048d620 <conductor_lib::run::{closure#5}::{closure#14}+0x214>
10048d5cc: b4000673    	cbz	x19, 0x10048d698 <conductor_lib::run::{closure#5}::{closure#14}+0x28c>
10048d5d0: 97edd024    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048d5d4: 52800037    	mov	w23, #0x1               ; =1
10048d5d8: aa1303e0    	mov	x0, x19
10048d5dc: 52800021    	mov	w1, #0x1                ; =1
10048d5e0: 97edd01c    	bl	0x100001650 <__rustc::__rust_alloc>
10048d5e4: b4fffb80    	cbz	x0, 0x10048d554 <conductor_lib::run::{closure#5}::{closure#14}+0x148>
10048d5e8: aa0003f6    	mov	x22, x0
10048d5ec: aa1503e1    	mov	x1, x21
10048d5f0: aa1303e2    	mov	x2, x19
10048d5f4: 943bcec7    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048d5f8: b40000b4    	cbz	x20, 0x10048d60c <conductor_lib::run::{closure#5}::{closure#14}+0x200>
10048d5fc: aa1503e0    	mov	x0, x21
10048d600: aa1403e1    	mov	x1, x20
10048d604: 52800022    	mov	w2, #0x1                ; =1
10048d608: 97edd013    	bl	0x100001654 <__rustc::__rust_dealloc>
10048d60c: 52800068    	mov	w8, #0x3                ; =3
10048d610: 390ee3e8    	strb	w8, [sp, #0x3b8]
10048d614: f901e3f3    	str	x19, [sp, #0x3c0]
10048d618: f901e7f6    	str	x22, [sp, #0x3c8]
10048d61c: f901ebf3    	str	x19, [sp, #0x3d0]
10048d620: 9114c3e0    	add	x0, sp, #0x530
10048d624: 910ee3e1    	add	x1, sp, #0x3b8
10048d628: 9404adef    	bl	0x1005b8de4 <<tauri::ipc::InvokeResolver>::respond::<()>>
10048d62c: f941d3e8    	ldr	x8, [sp, #0x3a0]
10048d630: b100051f    	cmn	x8, #0x1
10048d634: 54000220    	b.eq	0x10048d678 <conductor_lib::run::{closure#5}::{closure#14}+0x26c>
10048d638: f941d7e0    	ldr	x0, [sp, #0x3a8]
10048d63c: f941dbe8    	ldr	x8, [sp, #0x3b0]
10048d640: 91000515    	add	x21, x8, #0x1
10048d644: f10006b5    	subs	x21, x21, #0x1
10048d648: 540000a0    	b.eq	0x10048d65c <conductor_lib::run::{closure#5}::{closure#14}+0x250>
10048d64c: 91018014    	add	x20, x0, #0x60
10048d650: 940b4b62    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
10048d654: aa1403e0    	mov	x0, x20
10048d658: 17fffffb    	b	0x10048d644 <conductor_lib::run::{closure#5}::{closure#14}+0x238>
10048d65c: f941d3e8    	ldr	x8, [sp, #0x3a0]
10048d660: b40000c8    	cbz	x8, 0x10048d678 <conductor_lib::run::{closure#5}::{closure#14}+0x26c>
10048d664: f941d7e0    	ldr	x0, [sp, #0x3a8]
10048d668: 8b080508    	add	x8, x8, x8, lsl #1
10048d66c: d37be901    	lsl	x1, x8, #5
10048d670: 52800102    	mov	w2, #0x8                ; =8
10048d674: 97edcff8    	bl	0x100001654 <__rustc::__rust_dealloc>
10048d678: 910023e0    	add	x0, sp, #0x8
10048d67c: 97ff78a7    	bl	0x10046b918 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
10048d680: 911b03ff    	add	sp, sp, #0x6c0
10048d684: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10048d688: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10048d68c: a94157f6    	ldp	x22, x21, [sp, #0x10]
10048d690: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10048d694: d65f03c0    	ret
10048d698: 52800036    	mov	w22, #0x1               ; =1
10048d69c: b5fffb14    	cbnz	x20, 0x10048d5fc <conductor_lib::run::{closure#5}::{closure#14}+0x1f0>
10048d6a0: 17ffffdb    	b	0x10048d60c <conductor_lib::run::{closure#5}::{closure#14}+0x200>
10048d6a4: aa0003f3    	mov	x19, x0
10048d6a8: 1400001c    	b	0x10048d718 <conductor_lib::run::{closure#5}::{closure#14}+0x30c>
10048d6ac: aa0003f3    	mov	x19, x0
10048d6b0: 1400001b    	b	0x10048d71c <conductor_lib::run::{closure#5}::{closure#14}+0x310>
10048d6b4: aa0003f3    	mov	x19, x0
10048d6b8: f10006b5    	subs	x21, x21, #0x1
10048d6bc: 540000c0    	b.eq	0x10048d6d4 <conductor_lib::run::{closure#5}::{closure#14}+0x2c8>
10048d6c0: 91018296    	add	x22, x20, #0x60
10048d6c4: aa1403e0    	mov	x0, x20
10048d6c8: 940b4b44    	bl	0x1007603d8 <core::ptr::drop_glue::<tauri_utils::acl::resolved::ResolvedCommand>>
10048d6cc: aa1603f4    	mov	x20, x22
10048d6d0: 17fffffa    	b	0x10048d6b8 <conductor_lib::run::{closure#5}::{closure#14}+0x2ac>
10048d6d4: f941d3e8    	ldr	x8, [sp, #0x3a0]
10048d6d8: b40002c8    	cbz	x8, 0x10048d730 <conductor_lib::run::{closure#5}::{closure#14}+0x324>
10048d6dc: f941d7e0    	ldr	x0, [sp, #0x3a8]
10048d6e0: 8b080508    	add	x8, x8, x8, lsl #1
10048d6e4: d37be901    	lsl	x1, x8, #5
10048d6e8: 52800102    	mov	w2, #0x8                ; =8
10048d6ec: 97edcfda    	bl	0x100001654 <__rustc::__rust_dealloc>
10048d6f0: 14000010    	b	0x10048d730 <conductor_lib::run::{closure#5}::{closure#14}+0x324>
10048d6f4: 943bca88    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10048d6f8: aa0003f3    	mov	x19, x0
10048d6fc: b40000b4    	cbz	x20, 0x10048d710 <conductor_lib::run::{closure#5}::{closure#14}+0x304>
10048d700: aa1503e0    	mov	x0, x21
10048d704: aa1403e1    	mov	x1, x20
10048d708: 52800022    	mov	w2, #0x1                ; =1
10048d70c: 97edcfd2    	bl	0x100001654 <__rustc::__rust_dealloc>
10048d710: 9114c3e0    	add	x0, sp, #0x530
10048d714: 97ff78bb    	bl	0x10046ba00 <core::ptr::drop_glue::<tauri::ipc::InvokeResolver>>
10048d718: 52800015    	mov	w21, #0x0               ; =0
10048d71c: 910e83e0    	add	x0, sp, #0x3a0
10048d720: 97ff3012    	bl	0x100459768 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<tauri_utils::acl::resolved::ResolvedCommand>>>>
10048d724: 36000075    	tbz	w21, #0x0, 0x10048d730 <conductor_lib::run::{closure#5}::{closure#14}+0x324>
10048d728: 910843e0    	add	x0, sp, #0x210
10048d72c: 97ff78b5    	bl	0x10046ba00 <core::ptr::drop_glue::<tauri::ipc::InvokeResolver>>
10048d730: 910023e0    	add	x0, sp, #0x8
10048d734: 97ff7879    	bl	0x10046b918 <core::ptr::drop_glue::<tauri::ipc::InvokeMessage>>
10048d738: aa1303e0    	mov	x0, x19
10048d73c: 943bcd13    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
10048d740: 943bca75    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10048d744: 943bca74    	bl	0x101380114 <core::panicking::panic_in_cleanup>
