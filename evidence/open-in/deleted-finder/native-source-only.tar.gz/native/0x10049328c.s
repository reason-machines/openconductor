
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010049328c <conductor_lib::run::{closure#2}>:
10049328c: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
100493290: a9014ff4    	stp	x20, x19, [sp, #0x10]
100493294: a9027bfd    	stp	x29, x30, [sp, #0x20]
100493298: 910083fd    	add	x29, sp, #0x20
10049329c: d11ec3ff    	sub	sp, sp, #0x7b0
1004932a0: f90003ff    	str	xzr, [sp]
1004932a4: aa0103f3    	mov	x19, x1
1004932a8: aa0003f4    	mov	x20, x0
1004932ac: 39400028    	ldrb	w8, [x1]
1004932b0: 7100051f    	cmp	w8, #0x1
1004932b4: 54000420    	b.eq	0x100493338 <conductor_lib::run::{closure#2}+0xac>
1004932b8: 35000348    	cbnz	w8, 0x100493320 <conductor_lib::run::{closure#2}+0x94>
1004932bc: b00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004932c0: 910a7000    	add	x0, x0, #0x29c
1004932c4: 52800521    	mov	w1, #0x29               ; =41
1004932c8: 9439948b    	bl	0x1012f84f4 <std::io::stdio::_print>
1004932cc: f9404694    	ldr	x20, [x20, #0x88]
1004932d0: f9496688    	ldr	x8, [x20, #0x12c8]
1004932d4: 91004100    	add	x0, x8, #0x10
1004932d8: 97fef2c6    	bl	0x10044fdf0 <<tauri::state::StateManager>::try_get::<conductor_lib::sidecar::SidecarProcessState>>
1004932dc: b4001200    	cbz	x0, 0x10049351c <conductor_lib::run::{closure#2}+0x290>
1004932e0: 940b8764    	bl	0x100775070 <<conductor_lib::sidecar::SidecarProcessState>::stop_sidecar>
1004932e4: f9496688    	ldr	x8, [x20, #0x12c8]
1004932e8: 91004100    	add	x0, x8, #0x10
1004932ec: 97fef13b    	bl	0x10044f7d8 <<tauri::state::StateManager>::try_get::<conductor_lib::app_logger::AppLoggerState>>
1004932f0: b40011c0    	cbz	x0, 0x100493528 <conductor_lib::run::{closure#2}+0x29c>
1004932f4: 940b73d0    	bl	0x100770234 <<conductor_lib::app_logger::AppLoggerState>::stop>
1004932f8: f9496688    	ldr	x8, [x20, #0x12c8]
1004932fc: 91004100    	add	x0, x8, #0x10
100493300: 97fef1b8    	bl	0x10044f9e0 <<tauri::state::StateManager>::try_get::<conductor_lib::app_actions::AppActionsState>>
100493304: b40011a0    	cbz	x0, 0x100493538 <conductor_lib::run::{closure#2}+0x2ac>
100493308: 940b7911    	bl	0x10077174c <<conductor_lib::app_actions::AppActionsState>::stop>
10049330c: f9496688    	ldr	x8, [x20, #0x12c8]
100493310: 91004100    	add	x0, x8, #0x10
100493314: 97fef339    	bl	0x10044fff8 <<tauri::state::StateManager>::try_get::<workspace_runtime_core::pty::PtyManager>>
100493318: b4001180    	cbz	x0, 0x100493548 <conductor_lib::run::{closure#2}+0x2bc>
10049331c: 941feeaf    	bl	0x100c8edd8 <<workspace_runtime_core::pty::PtyManager>::kill_all>
100493320: aa1303e0    	mov	x0, x19
100493324: 911ec3ff    	add	sp, sp, #0x7b0
100493328: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10049332c: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100493330: a8c357f6    	ldp	x22, x21, [sp], #0x30
100493334: 17ff60ea    	b	0x10046b6dc <core::ptr::drop_glue::<tauri::app::RunEvent>>
100493338: b9400668    	ldr	w8, [x19, #0x4]
10049333c: 340000e8    	cbz	w8, 0x100493358 <conductor_lib::run::{closure#2}+0xcc>
100493340: 91004260    	add	x0, x19, #0x10
100493344: 911ec3ff    	add	sp, sp, #0x7b0
100493348: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10049334c: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100493350: a8c357f6    	ldp	x22, x21, [sp], #0x30
100493354: 14029c3b    	b	0x10053a440 <<std::sync::mpmc::Sender<()> as core::ops::drop::Drop>::drop>
100493358: aa1403e0    	mov	x0, x20
10049335c: 97ff99ac    	bl	0x100479a0c <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::state::<conductor_lib::QuitHandlerReady>>
100493360: 08dffc08    	ldarb	w8, [x0]
100493364: 34fffee8    	cbz	w8, 0x100493340 <conductor_lib::run::{closure#2}+0xb4>
100493368: 3dc00660    	ldr	q0, [x19, #0x10]
10049336c: 3d8003e0    	str	q0, [sp]
100493370: f9401268    	ldr	x8, [x19, #0x20]
100493374: f9000be8    	str	x8, [sp, #0x10]
100493378: 910003e0    	mov	x0, sp
10049337c: 9430face    	bl	0x1010d1eb4 <<tauri::app::ExitRequestApi>::prevent_exit>
100493380: 900083c1    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100493384: 9122e021    	add	x1, x1, #0x8b8
100493388: 910083e8    	add	x8, sp, #0x20
10049338c: aa1403e0    	mov	x0, x20
100493390: 52800082    	mov	w2, #0x4                ; =4
100493394: 9400ce3b    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100493398: f94013e8    	ldr	x8, [sp, #0x20]
10049339c: b100051f    	cmn	x8, #0x1
1004933a0: 54000aa0    	b.eq	0x1004934f4 <conductor_lib::run::{closure#2}+0x268>
1004933a4: 910e83e0    	add	x0, sp, #0x3a0
1004933a8: 910083e1    	add	x1, sp, #0x20
1004933ac: 52807002    	mov	w2, #0x380              ; =896
1004933b0: 943bb758    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1004933b4: f81803bf    	stur	xzr, [x29, #-0x80]
1004933b8: f81903bf    	stur	xzr, [x29, #-0x70]
1004933bc: 97edb8a9    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1004933c0: 528000c0    	mov	w0, #0x6                ; =6
1004933c4: 52800021    	mov	w1, #0x1                ; =1
1004933c8: 97edb8a2    	bl	0x100001650 <__rustc::__rust_alloc>
1004933cc: b4000de0    	cbz	x0, 0x100493588 <conductor_lib::run::{closure#2}+0x2fc>
1004933d0: aa0003f5    	mov	x21, x0
1004933d4: 528cac68    	mov	w8, #0x6563             ; =25955
1004933d8: 79000808    	strh	w8, [x0, #0x4]
1004933dc: 528dee68    	mov	w8, #0x6f73             ; =28531
1004933e0: 72ae4ea8    	movk	w8, #0x7275, lsl #16
1004933e4: b9000008    	str	w8, [x0]
1004933e8: 528000c8    	mov	w8, #0x6                ; =6
1004933ec: a93983a8    	stp	x8, x0, [x29, #-0x68]
1004933f0: f81a83a8    	stur	x8, [x29, #-0x58]
1004933f4: 97edb89b    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1004933f8: 528000c0    	mov	w0, #0x6                ; =6
1004933fc: 52800021    	mov	w1, #0x1                ; =1
100493400: 97edb894    	bl	0x100001650 <__rustc::__rust_alloc>
100493404: b4000ca0    	cbz	x0, 0x100493598 <conductor_lib::run::{closure#2}+0x30c>
100493408: 528daca8    	mov	w8, #0x6d65             ; =28005
10049340c: 79000808    	strh	w8, [x0, #0x4]
100493410: 528f2e68    	mov	w8, #0x7973             ; =31091
100493414: 72ae8e68    	movk	w8, #0x7473, lsl #16
100493418: b9000008    	str	w8, [x0]
10049341c: 52800068    	mov	w8, #0x3                ; =3
100493420: 381b03a8    	sturb	w8, [x29, #-0x50]
100493424: 528000c8    	mov	w8, #0x6                ; =6
100493428: a93b83a8    	stp	x8, x0, [x29, #-0x48]
10049342c: f81c83a8    	stur	x8, [x29, #-0x38]
100493430: d102c3a8    	sub	x8, x29, #0xb0
100493434: d10203a0    	sub	x0, x29, #0x80
100493438: d101a3a1    	sub	x1, x29, #0x68
10049343c: d10143a2    	sub	x2, x29, #0x50
100493440: 9409b023    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
100493444: 385503a8    	ldurb	w8, [x29, #-0xb0]
100493448: 7103fd1f    	cmp	w8, #0xff
10049344c: 54000060    	b.eq	0x100493458 <conductor_lib::run::{closure#2}+0x1cc>
100493450: d102c3a0    	sub	x0, x29, #0xb0
100493454: 97ff539f    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
100493458: 3cd803a0    	ldur	q0, [x29, #-0x80]
10049345c: 3c9b83a0    	stur	q0, [x29, #-0x48]
100493460: f85903a8    	ldur	x8, [x29, #-0x70]
100493464: f81c83a8    	stur	x8, [x29, #-0x38]
100493468: 528000a8    	mov	w8, #0x5                ; =5
10049346c: 381b03a8    	sturb	w8, [x29, #-0x50]
100493470: b00083e1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100493474: 910ad021    	add	x1, x1, #0x2b4
100493478: d102c3a8    	sub	x8, x29, #0xb0
10049347c: 910e83e0    	add	x0, sp, #0x3a0
100493480: d10143a3    	sub	x3, x29, #0x50
100493484: 528001c2    	mov	w2, #0xe                ; =14
100493488: 940a7576    	bl	0x100730a60 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<serde_json::value::Value>>
10049348c: f85503a8    	ldur	x8, [x29, #-0xb0]
100493490: b100051f    	cmn	x8, #0x1
100493494: 54000240    	b.eq	0x1004934dc <conductor_lib::run::{closure#2}+0x250>
100493498: ad7a87a0    	ldp	q0, q1, [x29, #-0xb0]
10049349c: ad3d87a0    	stp	q0, q1, [x29, #-0x50]
1004934a0: 3cd703a0    	ldur	q0, [x29, #-0x90]
1004934a4: 3c9d03a0    	stur	q0, [x29, #-0x30]
1004934a8: d10143a8    	sub	x8, x29, #0x50
1004934ac: 900061a9    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
1004934b0: 913e2129    	add	x9, x9, #0xf88
1004934b4: a939a7a8    	stp	x8, x9, [x29, #-0x68]
1004934b8: f0014120    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
1004934bc: 91259000    	add	x0, x0, #0x964
1004934c0: d101a3a1    	sub	x1, x29, #0x68
1004934c4: 94399450    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004934c8: aa1403e0    	mov	x0, x20
1004934cc: 52800001    	mov	w1, #0x0                ; =0
1004934d0: 9400758a    	bl	0x1004b0af8 <<tauri::app::AppHandle>::exit>
1004934d4: d10143a0    	sub	x0, x29, #0x50
1004934d8: 97ff622b    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004934dc: 910e83f5    	add	x21, sp, #0x3a0
1004934e0: 910e83e0    	add	x0, sp, #0x3a0
1004934e4: 97ff62d0    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
1004934e8: 910862a0    	add	x0, x21, #0x218
1004934ec: 97ff63a2    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004934f0: 14000004    	b	0x100493500 <conductor_lib::run::{closure#2}+0x274>
1004934f4: aa1403e0    	mov	x0, x20
1004934f8: 52800001    	mov	w1, #0x0                ; =0
1004934fc: 9400757f    	bl	0x1004b0af8 <<tauri::app::AppHandle>::exit>
100493500: 91004260    	add	x0, x19, #0x10
100493504: 94029bcf    	bl	0x10053a440 <<std::sync::mpmc::Sender<()> as core::ops::drop::Drop>::drop>
100493508: 911ec3ff    	add	sp, sp, #0x7b0
10049350c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
100493510: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100493514: a8c357f6    	ldp	x22, x21, [sp], #0x30
100493518: d65f03c0    	ret
10049351c: f00083c8    	adrp	x8, 0x10150e000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.321+0x12d8>
100493520: 912aad08    	add	x8, x8, #0xaab
100493524: 14000007    	b	0x100493540 <conductor_lib::run::{closure#2}+0x2b4>
100493528: f00083c8    	adrp	x8, 0x10150e000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.321+0x12d8>
10049352c: 9125f908    	add	x8, x8, #0x97e
100493530: 52800529    	mov	w9, #0x29               ; =41
100493534: 14000008    	b	0x100493554 <conductor_lib::run::{closure#2}+0x2c8>
100493538: f00083c8    	adrp	x8, 0x10150e000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.321+0x12d8>
10049353c: 91269d08    	add	x8, x8, #0x9a7
100493540: 52800569    	mov	w9, #0x2b               ; =43
100493544: 14000004    	b	0x100493554 <conductor_lib::run::{closure#2}+0x2c8>
100493548: f00083c8    	adrp	x8, 0x10150e000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.321+0x12d8>
10049354c: 912bfd08    	add	x8, x8, #0xaff
100493550: 528004e9    	mov	w9, #0x27               ; =39
100493554: a90227e8    	stp	x8, x9, [sp, #0x20]
100493558: 910083e8    	add	x8, sp, #0x20
10049355c: f901d3e8    	str	x8, [sp, #0x3a0]
100493560: 910e83e1    	add	x1, sp, #0x3a0
100493564: d0001568    	adrp	x8, 0x100741000 <<&tungstenite::protocol::message::Message as core::fmt::Debug>::fmt+0xb8>
100493568: 9107b108    	add	x8, x8, #0x1ec
10049356c: f9000428    	str	x8, [x1, #0x8]
100493570: f0014120    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100493574: 91136000    	add	x0, x0, #0x4d8
100493578: f0015f22    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
10049357c: 91194042    	add	x2, x2, #0x650
100493580: 943bb347    	bl	0x10138029c <core::panicking::panic_fmt>
100493584: 14000008    	b	0x1004935a4 <conductor_lib::run::{closure#2}+0x318>
100493588: 52800020    	mov	w0, #0x1                ; =1
10049358c: 528000c1    	mov	w1, #0x6                ; =6
100493590: 943bb248    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100493594: 14000004    	b	0x1004935a4 <conductor_lib::run::{closure#2}+0x318>
100493598: 52800020    	mov	w0, #0x1                ; =1
10049359c: 528000c1    	mov	w1, #0x6                ; =6
1004935a0: 943bb244    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1004935a4: d4200020    	brk	#0x1
1004935a8: aa0003f4    	mov	x20, x0
1004935ac: 910862a0    	add	x0, x21, #0x218
1004935b0: 97ff6371    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004935b4: 1400001a    	b	0x10049361c <conductor_lib::run::{closure#2}+0x390>
1004935b8: 943bb2d7    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004935bc: 1400000d    	b	0x1004935f0 <conductor_lib::run::{closure#2}+0x364>
1004935c0: aa0003f4    	mov	x20, x0
1004935c4: aa1503e0    	mov	x0, x21
1004935c8: 528000c1    	mov	w1, #0x6                ; =6
1004935cc: 52800022    	mov	w2, #0x1                ; =1
1004935d0: 97edb821    	bl	0x100001654 <__rustc::__rust_dealloc>
1004935d4: 14000008    	b	0x1004935f4 <conductor_lib::run::{closure#2}+0x368>
1004935d8: aa0003f4    	mov	x20, x0
1004935dc: d10143a0    	sub	x0, x29, #0x50
1004935e0: 97ff61e9    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004935e4: 14000006    	b	0x1004935fc <conductor_lib::run::{closure#2}+0x370>
1004935e8: aa0003f4    	mov	x20, x0
1004935ec: 14000004    	b	0x1004935fc <conductor_lib::run::{closure#2}+0x370>
1004935f0: aa0003f4    	mov	x20, x0
1004935f4: d10203a0    	sub	x0, x29, #0x80
1004935f8: 9409ee5a    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1004935fc: 910e83e0    	add	x0, sp, #0x3a0
100493600: 97ff6b68    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
100493604: 14000006    	b	0x10049361c <conductor_lib::run::{closure#2}+0x390>
100493608: aa0003f4    	mov	x20, x0
10049360c: 91004260    	add	x0, x19, #0x10
100493610: 94029b8c    	bl	0x10053a440 <<std::sync::mpmc::Sender<()> as core::ops::drop::Drop>::drop>
100493614: 14000008    	b	0x100493634 <conductor_lib::run::{closure#2}+0x3a8>
100493618: aa0003f4    	mov	x20, x0
10049361c: 910003e0    	mov	x0, sp
100493620: 94029b88    	bl	0x10053a440 <<std::sync::mpmc::Sender<()> as core::ops::drop::Drop>::drop>
100493624: 14000004    	b	0x100493634 <conductor_lib::run::{closure#2}+0x3a8>
100493628: aa0003f4    	mov	x20, x0
10049362c: aa1303e0    	mov	x0, x19
100493630: 97ff602b    	bl	0x10046b6dc <core::ptr::drop_glue::<tauri::app::RunEvent>>
100493634: aa1403e0    	mov	x0, x20
100493638: 943bb554    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
10049363c: 943bb2b6    	bl	0x101380114 <core::panicking::panic_in_cleanup>
