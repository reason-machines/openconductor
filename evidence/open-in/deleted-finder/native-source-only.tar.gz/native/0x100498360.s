
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100498360 <conductor_lib::run::{closure#1}>:
100498360: a9bc6ffc    	stp	x28, x27, [sp, #-0x40]!
100498364: a90157f6    	stp	x22, x21, [sp, #0x10]
100498368: a9024ff4    	stp	x20, x19, [sp, #0x20]
10049836c: a9037bfd    	stp	x29, x30, [sp, #0x30]
100498370: 9100c3fd    	add	x29, sp, #0x30
100498374: d11e43ff    	sub	sp, sp, #0x790
100498378: f90003ff    	str	xzr, [sp]
10049837c: aa0203f4    	mov	x20, x2
100498380: a940a053    	ldp	x19, x8, [x2, #0x8]
100498384: d1001508    	sub	x8, x8, #0x5
100498388: f1003d1f    	cmp	x8, #0xf
10049838c: 54005be8    	b.hi	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498390: aa0103f5    	mov	x21, x1
100498394: 900083a9    	adrp	x9, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
100498398: 910f0129    	add	x9, x9, #0x3c0
10049839c: 1000008a    	adr	x10, 0x1004983ac <conductor_lib::run::{closure#1}+0x4c>
1004983a0: 7868792b    	ldrh	w11, [x9, x8, lsl #1]
1004983a4: 8b0b094a    	add	x10, x10, x11, lsl #2
1004983a8: d61f0140    	br	x10
1004983ac: b9400268    	ldr	w8, [x19]
1004983b0: 39401269    	ldrb	w9, [x19, #0x4]
1004983b4: 528cac8a    	mov	w10, #0x6564            ; =25956
1004983b8: 72aeac4a    	movk	w10, #0x7562, lsl #16
1004983bc: 6b0a011f    	cmp	w8, w10
1004983c0: 52800ce8    	mov	w8, #0x67               ; =103
1004983c4: 7a480120    	ccmp	w9, w8, #0x0, eq
1004983c8: 54005a01    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004983cc: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
1004983d0: 9122e021    	add	x1, x1, #0x8b8
1004983d4: 910003e8    	mov	x8, sp
1004983d8: aa1503e0    	mov	x0, x21
1004983dc: 52800082    	mov	w2, #0x4                ; =4
1004983e0: 9400ba28    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
1004983e4: f94003e8    	ldr	x8, [sp]
1004983e8: b100051f    	cmn	x8, #0x1
1004983ec: 540058e0    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004983f0: 910e03f6    	add	x22, sp, #0x380
1004983f4: 910e03e0    	add	x0, sp, #0x380
1004983f8: 910003e1    	mov	x1, sp
1004983fc: 52807002    	mov	w2, #0x380              ; =896
100498400: 943ba344    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498404: 910862c0    	add	x0, x22, #0x218
100498408: 9400a9ce    	bl	0x1004c2b40 <<tauri_runtime_wry::WryWebviewDispatcher<tauri::EventLoopMessage> as tauri_runtime::WebviewDispatch<tauri::EventLoopMessage>>::open_devtools>
10049840c: 910e03e0    	add	x0, sp, #0x380
100498410: 97ff4f05    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498414: 910862c0    	add	x0, x22, #0x218
100498418: 97ff4fd7    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
10049841c: 140002bb    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498420: a9402668    	ldp	x8, x9, [x19]
100498424: b940126a    	ldr	w10, [x19, #0x10]
100498428: d28dee8b    	mov	x11, #0x6f74            ; =28532
10049842c: f2aceceb    	movk	x11, #0x6767, lsl #16
100498430: f2ccad8b    	movk	x11, #0x656c, lsl #32
100498434: f2ee4beb    	movk	x11, #0x725f, lsl #48
100498438: eb0b011f    	cmp	x8, x11
10049843c: d28ced28    	mov	x8, #0x6769             ; =26473
100498440: f2ae8d08    	movk	x8, #0x7468, lsl #16
100498444: f2ce6be8    	movk	x8, #0x735f, lsl #32
100498448: f2ec8d28    	movk	x8, #0x6469, lsl #48
10049844c: fa480120    	ccmp	x9, x8, #0x0, eq
100498450: 528c4ca8    	mov	w8, #0x6265             ; =25189
100498454: 72ae4c28    	movk	w8, #0x7261, lsl #16
100498458: 7a480140    	ccmp	w10, w8, #0x0, eq
10049845c: 54005561    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498460: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498464: 9122e021    	add	x1, x1, #0x8b8
100498468: 910003e8    	mov	x8, sp
10049846c: aa1503e0    	mov	x0, x21
100498470: 52800082    	mov	w2, #0x4                ; =4
100498474: 9400ba03    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498478: f94003e8    	ldr	x8, [sp]
10049847c: b100051f    	cmn	x8, #0x1
100498480: 54005440    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498484: 910e03e0    	add	x0, sp, #0x380
100498488: 910003e1    	mov	x1, sp
10049848c: 52807002    	mov	w2, #0x380              ; =896
100498490: 943ba320    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498494: f00083a1    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100498498: 913c9021    	add	x1, x1, #0xf24
10049849c: d10303a8    	sub	x8, x29, #0xc0
1004984a0: 910003e0    	mov	x0, sp
1004984a4: 52800282    	mov	w2, #0x14               ; =20
1004984a8: 940a61ac    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
1004984ac: f85403a8    	ldur	x8, [x29, #-0xc0]
1004984b0: b100051f    	cmn	x8, #0x1
1004984b4: 540001e0    	b.eq	0x1004984f0 <conductor_lib::run::{closure#1}+0x190>
1004984b8: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
1004984bc: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
1004984c0: 3cd603a0    	ldur	q0, [x29, #-0xa0]
1004984c4: 3c9c03a0    	stur	q0, [x29, #-0x40]
1004984c8: d10183a8    	sub	x8, x29, #0x60
1004984cc: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
1004984d0: 913e2129    	add	x9, x9, #0xf88
1004984d4: a938a7a8    	stp	x8, x9, [x29, #-0x78]
1004984d8: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
1004984dc: 9126e800    	add	x0, x0, #0x9ba
1004984e0: d101e3a1    	sub	x1, x29, #0x78
1004984e4: 94398048    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004984e8: d10183a0    	sub	x0, x29, #0x60
1004984ec: 97ff4e26    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004984f0: 910e03f6    	add	x22, sp, #0x380
1004984f4: 910e03e0    	add	x0, sp, #0x380
1004984f8: 97ff4ecb    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
1004984fc: 910862c0    	add	x0, x22, #0x218
100498500: 97ff4f9d    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498504: 14000281    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498508: f9400268    	ldr	x8, [x19]
10049850c: f8405269    	ldur	x9, [x19, #0x5]
100498510: d28dec8a    	mov	x10, #0x6f64            ; =28516
100498514: f2aeac6a    	movk	x10, #0x7563, lsl #16
100498518: f2ccadaa    	movk	x10, #0x656d, lsl #32
10049851c: f2ee8dca    	movk	x10, #0x746e, lsl #48
100498520: eb0a011f    	cmp	x8, x10
100498524: d28dcca8    	mov	x8, #0x6e65             ; =28261
100498528: f2ac2e88    	movk	x8, #0x6174, lsl #16
10049852c: f2cd2e88    	movk	x8, #0x6974, lsl #32
100498530: f2edcde8    	movk	x8, #0x6e6f, lsl #48
100498534: fa480120    	ccmp	x9, x8, #0x0, eq
100498538: 54004400    	b.eq	0x100498db8 <conductor_lib::run::{closure#1}+0xa58>
10049853c: f9400268    	ldr	x8, [x19]
100498540: f8405269    	ldur	x9, [x19, #0x5]
100498544: d28cae6a    	mov	x10, #0x6573            ; =25971
100498548: f2ac8dca    	movk	x10, #0x646e, lsl #16
10049854c: f2cccbea    	movk	x10, #0x665f, lsl #32
100498550: f2ecacaa    	movk	x10, #0x6565, lsl #48
100498554: eb0a011f    	cmp	x8, x10
100498558: d28cacc8    	mov	x8, #0x6566             ; =25958
10049855c: f2ac8ca8    	movk	x8, #0x6465, lsl #16
100498560: f2cc2c48    	movk	x8, #0x6162, lsl #32
100498564: f2ed6c68    	movk	x8, #0x6b63, lsl #48
100498568: fa480120    	ccmp	x9, x8, #0x0, eq
10049856c: 54004ce1    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498570: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498574: 9122e021    	add	x1, x1, #0x8b8
100498578: 910003e8    	mov	x8, sp
10049857c: aa1503e0    	mov	x0, x21
100498580: 52800082    	mov	w2, #0x4                ; =4
100498584: 9400b9bf    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498588: f94003e8    	ldr	x8, [sp]
10049858c: b100051f    	cmn	x8, #0x1
100498590: 54004bc0    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498594: 910e03e0    	add	x0, sp, #0x380
100498598: 910003e1    	mov	x1, sp
10049859c: 52807002    	mov	w2, #0x380              ; =896
1004985a0: 943ba2dc    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1004985a4: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004985a8: 910cf821    	add	x1, x1, #0x33e
1004985ac: d10303a8    	sub	x8, x29, #0xc0
1004985b0: 910003e0    	mov	x0, sp
1004985b4: 52800282    	mov	w2, #0x14               ; =20
1004985b8: 940a6168    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
1004985bc: f85403a8    	ldur	x8, [x29, #-0xc0]
1004985c0: b100051f    	cmn	x8, #0x1
1004985c4: 540001e0    	b.eq	0x100498600 <conductor_lib::run::{closure#1}+0x2a0>
1004985c8: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
1004985cc: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
1004985d0: 3cd603a0    	ldur	q0, [x29, #-0xa0]
1004985d4: 3c9c03a0    	stur	q0, [x29, #-0x40]
1004985d8: d10183a8    	sub	x8, x29, #0x60
1004985dc: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
1004985e0: 913e2129    	add	x9, x9, #0xf88
1004985e4: a938a7a8    	stp	x8, x9, [x29, #-0x78]
1004985e8: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
1004985ec: 912a8000    	add	x0, x0, #0xaa0
1004985f0: d101e3a1    	sub	x1, x29, #0x78
1004985f4: 94398004    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004985f8: d10183a0    	sub	x0, x29, #0x60
1004985fc: 97ff4de2    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498600: 910e03e0    	add	x0, sp, #0x380
100498604: 97ff5767    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
100498608: 14000240    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
10049860c: f9400268    	ldr	x8, [x19]
100498610: f8406269    	ldur	x9, [x19, #0x6]
100498614: d28cac4a    	mov	x10, #0x6562            ; =25954
100498618: f2ae8e6a    	movk	x10, #0x7473, lsl #16
10049861c: f2ce0bea    	movk	x10, #0x705f, lsl #32
100498620: f2ec2e4a    	movk	x10, #0x6172, lsl #48
100498624: eb0a011f    	cmp	x8, x10
100498628: d28c2e48    	mov	x8, #0x6172             ; =24946
10049862c: f2ae8c68    	movk	x8, #0x7463, lsl #16
100498630: f2cc6d28    	movk	x8, #0x6369, lsl #32
100498634: f2ee6ca8    	movk	x8, #0x7365, lsl #48
100498638: fa480120    	ccmp	x9, x8, #0x0, eq
10049863c: 54004661    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498640: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498644: 9122e021    	add	x1, x1, #0x8b8
100498648: 910003e8    	mov	x8, sp
10049864c: aa1503e0    	mov	x0, x21
100498650: 52800082    	mov	w2, #0x4                ; =4
100498654: 9400b98b    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498658: f94003e8    	ldr	x8, [sp]
10049865c: b100051f    	cmn	x8, #0x1
100498660: 54004540    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498664: 910e03e0    	add	x0, sp, #0x380
100498668: 910003e1    	mov	x1, sp
10049866c: 52807002    	mov	w2, #0x380              ; =896
100498670: 943ba2a8    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498674: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498678: 910c9c21    	add	x1, x1, #0x327
10049867c: d10303a8    	sub	x8, x29, #0xc0
100498680: 910003e0    	mov	x0, sp
100498684: 528002e2    	mov	w2, #0x17               ; =23
100498688: 940a6134    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
10049868c: f85403a8    	ldur	x8, [x29, #-0xc0]
100498690: b100051f    	cmn	x8, #0x1
100498694: 540001e0    	b.eq	0x1004986d0 <conductor_lib::run::{closure#1}+0x370>
100498698: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
10049869c: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
1004986a0: 3cd603a0    	ldur	q0, [x29, #-0xa0]
1004986a4: 3c9c03a0    	stur	q0, [x29, #-0x40]
1004986a8: d10183a8    	sub	x8, x29, #0x60
1004986ac: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
1004986b0: 913e2129    	add	x9, x9, #0xf88
1004986b4: a938a7a8    	stp	x8, x9, [x29, #-0x78]
1004986b8: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
1004986bc: 9129c800    	add	x0, x0, #0xa72
1004986c0: d101e3a1    	sub	x1, x29, #0x78
1004986c4: 94397fd0    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004986c8: d10183a0    	sub	x0, x29, #0x60
1004986cc: 97ff4dae    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004986d0: 910e03f6    	add	x22, sp, #0x380
1004986d4: 910e03e0    	add	x0, sp, #0x380
1004986d8: 97ff4e53    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
1004986dc: 910862c0    	add	x0, x22, #0x218
1004986e0: 97ff4f25    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004986e4: 14000209    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004986e8: f9400268    	ldr	x8, [x19]
1004986ec: f8403269    	ldur	x9, [x19, #0x3]
1004986f0: d28d2c8a    	mov	x10, #0x6964            ; =26980
1004986f4: f2acec2a    	movk	x10, #0x6761, lsl #16
1004986f8: f2cdedca    	movk	x10, #0x6f6e, lsl #32
1004986fc: f2ee8e6a    	movk	x10, #0x7473, lsl #48
100498700: eb0a011f    	cmp	x8, x10
100498704: d28dcce8    	mov	x8, #0x6e67             ; =28263
100498708: f2ae6de8    	movk	x8, #0x736f, lsl #16
10049870c: f2cd2e88    	movk	x8, #0x6974, lsl #32
100498710: f2ee6c68    	movk	x8, #0x7363, lsl #48
100498714: fa480120    	ccmp	x9, x8, #0x0, eq
100498718: 540039e0    	b.eq	0x100498e54 <conductor_lib::run::{closure#1}+0xaf4>
10049871c: f9400268    	ldr	x8, [x19]
100498720: f8403269    	ldur	x9, [x19, #0x3]
100498724: d28eac6a    	mov	x10, #0x7563            ; =30051
100498728: f2ae8e6a    	movk	x10, #0x7473, lsl #16
10049872c: f2cdadea    	movk	x10, #0x6d6f, lsl #32
100498730: f2ee2bea    	movk	x10, #0x715f, lsl #48
100498734: eb0a011f    	cmp	x8, x10
100498738: d28dee88    	mov	x8, #0x6f74             ; =28532
10049873c: f2abeda8    	movk	x8, #0x5f6d, lsl #16
100498740: f2ceae28    	movk	x8, #0x7571, lsl #32
100498744: f2ee8d28    	movk	x8, #0x7469, lsl #48
100498748: fa480120    	ccmp	x9, x8, #0x0, eq
10049874c: 54003de1    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498750: 900083c0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498754: 910b2400    	add	x0, x0, #0x2c9
100498758: 528007a1    	mov	w1, #0x3d               ; =61
10049875c: 94397f66    	bl	0x1012f84f4 <std::io::stdio::_print>
100498760: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498764: 9122e021    	add	x1, x1, #0x8b8
100498768: 910003e8    	mov	x8, sp
10049876c: aa1503e0    	mov	x0, x21
100498770: 52800082    	mov	w2, #0x4                ; =4
100498774: 9400b943    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498778: f94003e8    	ldr	x8, [sp]
10049877c: b100051f    	cmn	x8, #0x1
100498780: 54003be0    	b.eq	0x100498efc <conductor_lib::run::{closure#1}+0xb9c>
100498784: 910e03e0    	add	x0, sp, #0x380
100498788: 910003e1    	mov	x1, sp
10049878c: 52807002    	mov	w2, #0x380              ; =896
100498790: 943ba260    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498794: f81703bf    	stur	xzr, [x29, #-0x90]
100498798: f81803bf    	stur	xzr, [x29, #-0x80]
10049879c: 97eda3b1    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1004987a0: 528000c0    	mov	w0, #0x6                ; =6
1004987a4: 52800021    	mov	w1, #0x1                ; =1
1004987a8: 97eda3aa    	bl	0x100001650 <__rustc::__rust_alloc>
1004987ac: b4003dc0    	cbz	x0, 0x100498f64 <conductor_lib::run::{closure#1}+0xc04>
1004987b0: aa0003f6    	mov	x22, x0
1004987b4: 528cac68    	mov	w8, #0x6563             ; =25955
1004987b8: 79000808    	strh	w8, [x0, #0x4]
1004987bc: 528dee68    	mov	w8, #0x6f73             ; =28531
1004987c0: 72ae4ea8    	movk	w8, #0x7275, lsl #16
1004987c4: b9000008    	str	w8, [x0]
1004987c8: 528000c8    	mov	w8, #0x6                ; =6
1004987cc: a93883a8    	stp	x8, x0, [x29, #-0x78]
1004987d0: f81983a8    	stur	x8, [x29, #-0x68]
1004987d4: f0015f00    	adrp	x0, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
1004987d8: 91086000    	add	x0, x0, #0x218
1004987dc: d10183a8    	sub	x8, x29, #0x60
1004987e0: 9407f2a0    	bl	0x100695260 <serde_json::value::to_value::<&&str>>
1004987e4: 385a03a8    	ldurb	w8, [x29, #-0x60]
1004987e8: 7103fd1f    	cmp	w8, #0xff
1004987ec: 54003a40    	b.eq	0x100498f34 <conductor_lib::run::{closure#1}+0xbd4>
1004987f0: ad7d07a0    	ldp	q0, q1, [x29, #-0x60]
1004987f4: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
1004987f8: d10183a8    	sub	x8, x29, #0x60
1004987fc: d10243a0    	sub	x0, x29, #0x90
100498800: d101e3a1    	sub	x1, x29, #0x78
100498804: d10303a2    	sub	x2, x29, #0xc0
100498808: 94099b31    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10049880c: 385a03a8    	ldurb	w8, [x29, #-0x60]
100498810: 7103fd1f    	cmp	w8, #0xff
100498814: 54000060    	b.eq	0x100498820 <conductor_lib::run::{closure#1}+0x4c0>
100498818: d10183a0    	sub	x0, x29, #0x60
10049881c: 97ff3ead    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
100498820: 3cd703a0    	ldur	q0, [x29, #-0x90]
100498824: 3c9a83a0    	stur	q0, [x29, #-0x58]
100498828: f85803a8    	ldur	x8, [x29, #-0x80]
10049882c: f81b83a8    	stur	x8, [x29, #-0x48]
100498830: 528000a8    	mov	w8, #0x5                ; =5
100498834: 381a03a8    	sturb	w8, [x29, #-0x60]
100498838: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
10049883c: 910ad021    	add	x1, x1, #0x2b4
100498840: d10303a8    	sub	x8, x29, #0xc0
100498844: 910e03e0    	add	x0, sp, #0x380
100498848: d10183a3    	sub	x3, x29, #0x60
10049884c: 528001c2    	mov	w2, #0xe                ; =14
100498850: 940a6084    	bl	0x100730a60 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<serde_json::value::Value>>
100498854: f85403a8    	ldur	x8, [x29, #-0xc0]
100498858: b100051f    	cmn	x8, #0x1
10049885c: 54000240    	b.eq	0x1004988a4 <conductor_lib::run::{closure#1}+0x544>
100498860: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498864: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498868: 3cd603a0    	ldur	q0, [x29, #-0xa0]
10049886c: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498870: d10183a8    	sub	x8, x29, #0x60
100498874: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498878: 913e2129    	add	x9, x9, #0xf88
10049887c: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498880: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498884: 91259000    	add	x0, x0, #0x964
100498888: d101e3a1    	sub	x1, x29, #0x78
10049888c: 94397f5e    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498890: aa1503e0    	mov	x0, x21
100498894: 52800001    	mov	w1, #0x0                ; =0
100498898: 94006098    	bl	0x1004b0af8 <<tauri::app::AppHandle>::exit>
10049889c: d10183a0    	sub	x0, x29, #0x60
1004988a0: 97ff4d39    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004988a4: 910e03f6    	add	x22, sp, #0x380
1004988a8: 910e03e0    	add	x0, sp, #0x380
1004988ac: 97ff4dde    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
1004988b0: 910862c0    	add	x0, x22, #0x218
1004988b4: 97ff4eb0    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004988b8: 14000194    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004988bc: f9400268    	ldr	x8, [x19]
1004988c0: 39402269    	ldrb	w9, [x19, #0x8]
1004988c4: d28d0c6a    	mov	x10, #0x6863            ; =26723
1004988c8: f2adcc2a    	movk	x10, #0x6e61, lsl #16
1004988cc: f2ccacea    	movk	x10, #0x6567, lsl #32
1004988d0: f2eded8a    	movk	x10, #0x6f6c, lsl #48
1004988d4: eb0a011f    	cmp	x8, x10
1004988d8: 52800ce8    	mov	w8, #0x67               ; =103
1004988dc: 7a480120    	ccmp	w9, w8, #0x0, eq
1004988e0: 54003141    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004988e4: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
1004988e8: 9122e021    	add	x1, x1, #0x8b8
1004988ec: 910003e8    	mov	x8, sp
1004988f0: aa1503e0    	mov	x0, x21
1004988f4: 52800082    	mov	w2, #0x4                ; =4
1004988f8: 9400b8e2    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
1004988fc: f94003e8    	ldr	x8, [sp]
100498900: b100051f    	cmn	x8, #0x1
100498904: 54003020    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498908: 910e03e0    	add	x0, sp, #0x380
10049890c: 910003e1    	mov	x1, sp
100498910: 52807002    	mov	w2, #0x380              ; =896
100498914: 943ba1ff    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498918: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
10049891c: 910c5421    	add	x1, x1, #0x315
100498920: d10303a8    	sub	x8, x29, #0xc0
100498924: 910003e0    	mov	x0, sp
100498928: 52800242    	mov	w2, #0x12               ; =18
10049892c: 940a608b    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498930: f85403a8    	ldur	x8, [x29, #-0xc0]
100498934: b100051f    	cmn	x8, #0x1
100498938: 540001e0    	b.eq	0x100498974 <conductor_lib::run::{closure#1}+0x614>
10049893c: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498940: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498944: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498948: 3c9c03a0    	stur	q0, [x29, #-0x40]
10049894c: d10183a8    	sub	x8, x29, #0x60
100498950: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498954: 913e2129    	add	x9, x9, #0xf88
100498958: a938a7a8    	stp	x8, x9, [x29, #-0x78]
10049895c: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498960: 91292400    	add	x0, x0, #0xa49
100498964: d101e3a1    	sub	x1, x29, #0x78
100498968: 94397f27    	bl	0x1012f8604 <std::io::stdio::_eprint>
10049896c: d10183a0    	sub	x0, x29, #0x60
100498970: 97ff4d05    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498974: 910e03f6    	add	x22, sp, #0x380
100498978: 910e03e0    	add	x0, sp, #0x380
10049897c: 97ff4daa    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498980: 910862c0    	add	x0, x22, #0x218
100498984: 97ff4e7c    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498988: 14000160    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
10049898c: f9400268    	ldr	x8, [x19]
100498990: d28cae69    	mov	x9, #0x6573             ; =25971
100498994: f2ae8e89    	movk	x9, #0x7474, lsl #16
100498998: f2cdcd29    	movk	x9, #0x6e69, lsl #32
10049899c: f2ee6ce9    	movk	x9, #0x7367, lsl #48
1004989a0: eb09011f    	cmp	x8, x9
1004989a4: 54002b21    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
1004989a8: 910003e0    	mov	x0, sp
1004989ac: aa1503e1    	mov	x1, x21
1004989b0: 9400a578    	bl	0x1004c1f90 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone>
1004989b4: f94046a8    	ldr	x8, [x21, #0x88]
1004989b8: 52800029    	mov	w9, #0x1                ; =1
1004989bc: f8290109    	ldadd	x9, x9, [x8]
1004989c0: b7f82d89    	tbnz	x9, #0x3f, 0x100498f70 <conductor_lib::run::{closure#1}+0xc10>
1004989c4: f9404aa9    	ldr	x9, [x21, #0x90]
1004989c8: 5280002a    	mov	w10, #0x1               ; =1
1004989cc: f82a012a    	ldadd	x10, x10, [x9]
1004989d0: b7f82d0a    	tbnz	x10, #0x3f, 0x100498f70 <conductor_lib::run::{closure#1}+0xc10>
1004989d4: ad4307e0    	ldp	q0, q1, [sp, #0x60]
1004989d8: ad1f07e0    	stp	q0, q1, [sp, #0x3e0]
1004989dc: f94043ea    	ldr	x10, [sp, #0x80]
1004989e0: ad4107e0    	ldp	q0, q1, [sp, #0x20]
1004989e4: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
1004989e8: ad4203e1    	ldp	q1, q0, [sp, #0x40]
1004989ec: ad1e03e1    	stp	q1, q0, [sp, #0x3c0]
1004989f0: ad4003e1    	ldp	q1, q0, [sp]
1004989f4: ad1c03e1    	stp	q1, q0, [sp, #0x380]
1004989f8: f90203ea    	str	x10, [sp, #0x400]
1004989fc: f90207e8    	str	x8, [sp, #0x408]
100498a00: f9020be9    	str	x9, [sp, #0x410]
100498a04: 910003e8    	mov	x8, sp
100498a08: 910e03e0    	add	x0, sp, #0x380
100498a0c: 940932ec    	bl	0x1006e55bc <conductor_lib::open_settings_page>
100498a10: f94003e8    	ldr	x8, [sp]
100498a14: b100051f    	cmn	x8, #0x1
100498a18: 54002780    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498a1c: 3dc003e0    	ldr	q0, [sp]
100498a20: 3d80e3e0    	str	q0, [sp, #0x380]
100498a24: f9400be8    	ldr	x8, [sp, #0x10]
100498a28: f901cbe8    	str	x8, [sp, #0x390]
100498a2c: 910e03e8    	add	x8, sp, #0x380
100498a30: d0000149    	adrp	x9, 0x1004c2000 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone+0x70>
100498a34: 91269129    	add	x9, x9, #0x9a4
100498a38: a93a27a8    	stp	x8, x9, [x29, #-0x60]
100498a3c: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498a40: 912cb400    	add	x0, x0, #0xb2d
100498a44: d10183a1    	sub	x1, x29, #0x60
100498a48: 94397eef    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498a4c: f941c3e1    	ldr	x1, [sp, #0x380]
100498a50: b40025c1    	cbz	x1, 0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498a54: f941c7e0    	ldr	x0, [sp, #0x388]
100498a58: 52800022    	mov	w2, #0x1                ; =1
100498a5c: 97eda2fe    	bl	0x100001654 <__rustc::__rust_dealloc>
100498a60: 1400012a    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498a64: f9400268    	ldr	x8, [x19]
100498a68: f8407269    	ldur	x9, [x19, #0x7]
100498a6c: d28eae6a    	mov	x10, #0x7573            ; =30067
100498a70: f2adac4a    	movk	x10, #0x6d62, lsl #16
100498a74: f2ce8d2a    	movk	x10, #0x7469, lsl #32
100498a78: f2ec2bea    	movk	x10, #0x615f, lsl #48
100498a7c: eb0a011f    	cmp	x8, x10
100498a80: d28bec28    	mov	x8, #0x5f61             ; =24417
100498a84: f2ae4e08    	movk	x8, #0x7270, lsl #16
100498a88: f2cdade8    	movk	x8, #0x6d6f, lsl #32
100498a8c: f2ee8e08    	movk	x8, #0x7470, lsl #48
100498a90: fa480120    	ccmp	x9, x8, #0x0, eq
100498a94: 540023a1    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498a98: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498a9c: 9122e021    	add	x1, x1, #0x8b8
100498aa0: 910003e8    	mov	x8, sp
100498aa4: aa1503e0    	mov	x0, x21
100498aa8: 52800082    	mov	w2, #0x4                ; =4
100498aac: 9400b875    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498ab0: f94003e8    	ldr	x8, [sp]
100498ab4: b100051f    	cmn	x8, #0x1
100498ab8: 54002280    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498abc: 910e03e0    	add	x0, sp, #0x380
100498ac0: 910003e1    	mov	x1, sp
100498ac4: 52807002    	mov	w2, #0x380              ; =896
100498ac8: 943ba192    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498acc: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498ad0: 910bf021    	add	x1, x1, #0x2fc
100498ad4: d10303a8    	sub	x8, x29, #0xc0
100498ad8: 910003e0    	mov	x0, sp
100498adc: 52800322    	mov	w2, #0x19               ; =25
100498ae0: 940a601e    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498ae4: f85403a8    	ldur	x8, [x29, #-0xc0]
100498ae8: b100051f    	cmn	x8, #0x1
100498aec: 540001e0    	b.eq	0x100498b28 <conductor_lib::run::{closure#1}+0x7c8>
100498af0: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498af4: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498af8: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498afc: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498b00: d10183a8    	sub	x8, x29, #0x60
100498b04: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498b08: 913e2129    	add	x9, x9, #0xf88
100498b0c: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498b10: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498b14: 91286400    	add	x0, x0, #0xa19
100498b18: d101e3a1    	sub	x1, x29, #0x78
100498b1c: 94397eba    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498b20: d10183a0    	sub	x0, x29, #0x60
100498b24: 97ff4c98    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498b28: 910e03f6    	add	x22, sp, #0x380
100498b2c: 910e03e0    	add	x0, sp, #0x380
100498b30: 97ff4d3d    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498b34: 910862c0    	add	x0, x22, #0x218
100498b38: 97ff4e0f    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498b3c: 140000f3    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498b40: a9402668    	ldp	x8, x9, [x19]
100498b44: 3940426a    	ldrb	w10, [x19, #0x10]
100498b48: d28d0c6b    	mov	x11, #0x6863            ; =26723
100498b4c: f2ac6cab    	movk	x11, #0x6365, lsl #16
100498b50: f2cbed6b    	movk	x11, #0x5f6b, lsl #32
100498b54: f2edeccb    	movk	x11, #0x6f66, lsl #48
100498b58: eb0b011f    	cmp	x8, x11
100498b5c: d28bee48    	mov	x8, #0x5f72             ; =24434
100498b60: f2ae0ea8    	movk	x8, #0x7075, lsl #16
100498b64: f2cc2c88    	movk	x8, #0x6164, lsl #32
100498b68: f2ecae88    	movk	x8, #0x6574, lsl #48
100498b6c: fa480120    	ccmp	x9, x8, #0x0, eq
100498b70: 52800e68    	mov	w8, #0x73               ; =115
100498b74: 7a480140    	ccmp	w10, w8, #0x0, eq
100498b78: 54001c81    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498b7c: 910003e0    	mov	x0, sp
100498b80: aa1503e1    	mov	x1, x21
100498b84: 9400a503    	bl	0x1004c1f90 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone>
100498b88: f94046a8    	ldr	x8, [x21, #0x88]
100498b8c: 52800029    	mov	w9, #0x1                ; =1
100498b90: f8290109    	ldadd	x9, x9, [x8]
100498b94: b7f81ee9    	tbnz	x9, #0x3f, 0x100498f70 <conductor_lib::run::{closure#1}+0xc10>
100498b98: f9404aa9    	ldr	x9, [x21, #0x90]
100498b9c: 5280002a    	mov	w10, #0x1               ; =1
100498ba0: f82a012a    	ldadd	x10, x10, [x9]
100498ba4: b7f81e6a    	tbnz	x10, #0x3f, 0x100498f70 <conductor_lib::run::{closure#1}+0xc10>
100498ba8: ad4307e0    	ldp	q0, q1, [sp, #0x60]
100498bac: ad1f07e0    	stp	q0, q1, [sp, #0x3e0]
100498bb0: f94043ea    	ldr	x10, [sp, #0x80]
100498bb4: ad4107e0    	ldp	q0, q1, [sp, #0x20]
100498bb8: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
100498bbc: ad4203e1    	ldp	q1, q0, [sp, #0x40]
100498bc0: ad1e03e1    	stp	q1, q0, [sp, #0x3c0]
100498bc4: ad4003e1    	ldp	q1, q0, [sp]
100498bc8: ad1c03e1    	stp	q1, q0, [sp, #0x380]
100498bcc: f90203ea    	str	x10, [sp, #0x400]
100498bd0: f90207e8    	str	x8, [sp, #0x408]
100498bd4: f9020be9    	str	x9, [sp, #0x410]
100498bd8: 910e03e0    	add	x0, sp, #0x380
100498bdc: 94025e88    	bl	0x1005305fc <conductor_lib::updater::start_manual_update>
100498be0: 140000ca    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498be4: a9402668    	ldp	x8, x9, [x19]
100498be8: f840b26a    	ldur	x10, [x19, #0xb]
100498bec: d28dee8b    	mov	x11, #0x6f74            ; =28532
100498bf0: f2aceceb    	movk	x11, #0x6767, lsl #16
100498bf4: f2ccad8b    	movk	x11, #0x656c, lsl #32
100498bf8: f2ed8beb    	movk	x11, #0x6c5f, lsl #48
100498bfc: eb0b011f    	cmp	x8, x11
100498c00: d28ccca8    	mov	x8, #0x6665             ; =26213
100498c04: f2abee88    	movk	x8, #0x5f74, lsl #16
100498c08: f2cd2e68    	movk	x8, #0x6973, lsl #32
100498c0c: f2ecac88    	movk	x8, #0x6564, lsl #48
100498c10: fa480120    	ccmp	x9, x8, #0x0, eq
100498c14: d28e6be8    	mov	x8, #0x735f             ; =29535
100498c18: f2ac8d28    	movk	x8, #0x6469, lsl #16
100498c1c: f2cc4ca8    	movk	x8, #0x6265, lsl #32
100498c20: f2ee4c28    	movk	x8, #0x7261, lsl #48
100498c24: fa480140    	ccmp	x10, x8, #0x0, eq
100498c28: 54001701    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498c2c: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498c30: 9122e021    	add	x1, x1, #0x8b8
100498c34: 910003e8    	mov	x8, sp
100498c38: aa1503e0    	mov	x0, x21
100498c3c: 52800082    	mov	w2, #0x4                ; =4
100498c40: 9400b810    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498c44: f94003e8    	ldr	x8, [sp]
100498c48: b100051f    	cmn	x8, #0x1
100498c4c: 540015e0    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498c50: 910e03e0    	add	x0, sp, #0x380
100498c54: 910003e1    	mov	x1, sp
100498c58: 52807002    	mov	w2, #0x380              ; =896
100498c5c: 943ba12d    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498c60: f00083a1    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100498c64: 913bf821    	add	x1, x1, #0xefe
100498c68: d10303a8    	sub	x8, x29, #0xc0
100498c6c: 910003e0    	mov	x0, sp
100498c70: 52800262    	mov	w2, #0x13               ; =19
100498c74: 940a5fb9    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498c78: f85403a8    	ldur	x8, [x29, #-0xc0]
100498c7c: b100051f    	cmn	x8, #0x1
100498c80: 540001e0    	b.eq	0x100498cbc <conductor_lib::run::{closure#1}+0x95c>
100498c84: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498c88: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498c8c: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498c90: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498c94: d10183a8    	sub	x8, x29, #0x60
100498c98: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498c9c: 913e2129    	add	x9, x9, #0xf88
100498ca0: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498ca4: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498ca8: 9127a800    	add	x0, x0, #0x9ea
100498cac: d101e3a1    	sub	x1, x29, #0x78
100498cb0: 94397e55    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498cb4: d10183a0    	sub	x0, x29, #0x60
100498cb8: 97ff4c33    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498cbc: 910e03f6    	add	x22, sp, #0x380
100498cc0: 910e03e0    	add	x0, sp, #0x380
100498cc4: 97ff4cd8    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498cc8: 910862c0    	add	x0, x22, #0x218
100498ccc: 97ff4daa    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498cd0: 1400008e    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498cd4: a9402668    	ldp	x8, x9, [x19]
100498cd8: 7940226a    	ldrh	w10, [x19, #0x10]
100498cdc: d28cad6b    	mov	x11, #0x656b            ; =25963
100498ce0: f2ac4f2b    	movk	x11, #0x6279, lsl #16
100498ce4: f2cc2deb    	movk	x11, #0x616f, lsl #32
100498ce8: f2ec8e4b    	movk	x11, #0x6472, lsl #48
100498cec: eb0b011f    	cmp	x8, x11
100498cf0: d28e6be8    	mov	x8, #0x735f             ; =29535
100498cf4: f2aded08    	movk	x8, #0x6f68, lsl #16
100498cf8: f2ce8e48    	movk	x8, #0x7472, lsl #32
100498cfc: f2eeac68    	movk	x8, #0x7563, lsl #48
100498d00: fa480120    	ccmp	x9, x8, #0x0, eq
100498d04: 528e6e88    	mov	w8, #0x7374             ; =29556
100498d08: 7a480140    	ccmp	w10, w8, #0x0, eq
100498d0c: 54000fe1    	b.ne	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498d10: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498d14: 9122e021    	add	x1, x1, #0x8b8
100498d18: 910003e8    	mov	x8, sp
100498d1c: aa1503e0    	mov	x0, x21
100498d20: 52800082    	mov	w2, #0x4                ; =4
100498d24: 9400b7d7    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498d28: f94003e8    	ldr	x8, [sp]
100498d2c: b100051f    	cmn	x8, #0x1
100498d30: 54000ec0    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498d34: 910e03e0    	add	x0, sp, #0x380
100498d38: 910003e1    	mov	x1, sp
100498d3c: 52807002    	mov	w2, #0x380              ; =896
100498d40: 943ba0f4    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498d44: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498d48: 910d4821    	add	x1, x1, #0x352
100498d4c: d10303a8    	sub	x8, x29, #0xc0
100498d50: 910003e0    	mov	x0, sp
100498d54: 528003c2    	mov	w2, #0x1e               ; =30
100498d58: 940a5f80    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498d5c: f85403a8    	ldur	x8, [x29, #-0xc0]
100498d60: b100051f    	cmn	x8, #0x1
100498d64: 540001e0    	b.eq	0x100498da0 <conductor_lib::run::{closure#1}+0xa40>
100498d68: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498d6c: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498d70: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498d74: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498d78: d10183a8    	sub	x8, x29, #0x60
100498d7c: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498d80: 913e2129    	add	x9, x9, #0xf88
100498d84: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498d88: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498d8c: 912b2c00    	add	x0, x0, #0xacb
100498d90: d101e3a1    	sub	x1, x29, #0x78
100498d94: 94397e1c    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498d98: d10183a0    	sub	x0, x29, #0x60
100498d9c: 97ff4bfa    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498da0: 910e03f6    	add	x22, sp, #0x380
100498da4: 910e03e0    	add	x0, sp, #0x380
100498da8: 97ff4c9f    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498dac: 910862c0    	add	x0, x22, #0x218
100498db0: 97ff4d71    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498db4: 14000055    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498db8: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498dbc: 9122e021    	add	x1, x1, #0x8b8
100498dc0: 910003e8    	mov	x8, sp
100498dc4: aa1503e0    	mov	x0, x21
100498dc8: 52800082    	mov	w2, #0x4                ; =4
100498dcc: 9400b7ad    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498dd0: f94003e8    	ldr	x8, [sp]
100498dd4: b100051f    	cmn	x8, #0x1
100498dd8: 54000980    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498ddc: 910e03e0    	add	x0, sp, #0x380
100498de0: 910003e1    	mov	x1, sp
100498de4: 52807002    	mov	w2, #0x380              ; =896
100498de8: 943ba0ca    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498dec: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498df0: 910dc021    	add	x1, x1, #0x370
100498df4: d10303a8    	sub	x8, x29, #0xc0
100498df8: 910003e0    	mov	x0, sp
100498dfc: 528002c2    	mov	w2, #0x16               ; =22
100498e00: 940a5f56    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498e04: f85403a8    	ldur	x8, [x29, #-0xc0]
100498e08: b100051f    	cmn	x8, #0x1
100498e0c: 540001e0    	b.eq	0x100498e48 <conductor_lib::run::{closure#1}+0xae8>
100498e10: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498e14: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498e18: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498e1c: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498e20: d10183a8    	sub	x8, x29, #0x60
100498e24: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498e28: 913e2129    	add	x9, x9, #0xf88
100498e2c: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498e30: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498e34: 912c0000    	add	x0, x0, #0xb00
100498e38: d101e3a1    	sub	x1, x29, #0x78
100498e3c: 94397df2    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498e40: d10183a0    	sub	x0, x29, #0x60
100498e44: 97ff4bd0    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498e48: 910e03e0    	add	x0, sp, #0x380
100498e4c: 97ff5555    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
100498e50: 1400002e    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498e54: f0008381    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100498e58: 9122e021    	add	x1, x1, #0x8b8
100498e5c: 910003e8    	mov	x8, sp
100498e60: aa1503e0    	mov	x0, x21
100498e64: 52800082    	mov	w2, #0x4                ; =4
100498e68: 9400b786    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
100498e6c: f94003e8    	ldr	x8, [sp]
100498e70: b100051f    	cmn	x8, #0x1
100498e74: 540004a0    	b.eq	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498e78: 910e03e0    	add	x0, sp, #0x380
100498e7c: 910003e1    	mov	x1, sp
100498e80: 52807002    	mov	w2, #0x380              ; =896
100498e84: 943ba0a3    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100498e88: 900083c1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498e8c: 910b9c21    	add	x1, x1, #0x2e7
100498e90: d10303a8    	sub	x8, x29, #0xc0
100498e94: 910003e0    	mov	x0, sp
100498e98: 528002a2    	mov	w2, #0x15               ; =21
100498e9c: 940a5f2f    	bl	0x100730b58 <<tauri::webview::webview_window::WebviewWindow as tauri::Emitter<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::emit::<()>>
100498ea0: f85403a8    	ldur	x8, [x29, #-0xc0]
100498ea4: b100051f    	cmn	x8, #0x1
100498ea8: 540001e0    	b.eq	0x100498ee4 <conductor_lib::run::{closure#1}+0xb84>
100498eac: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
100498eb0: ad3d07a0    	stp	q0, q1, [x29, #-0x60]
100498eb4: 3cd603a0    	ldur	q0, [x29, #-0xa0]
100498eb8: 3c9c03a0    	stur	q0, [x29, #-0x40]
100498ebc: d10183a8    	sub	x8, x29, #0x60
100498ec0: f0006169    	adrp	x9, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
100498ec4: 913e2129    	add	x9, x9, #0xf88
100498ec8: a938a7a8    	stp	x8, x9, [x29, #-0x78]
100498ecc: d0014100    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100498ed0: 91263800    	add	x0, x0, #0x98e
100498ed4: d101e3a1    	sub	x1, x29, #0x78
100498ed8: 94397dcb    	bl	0x1012f8604 <std::io::stdio::_eprint>
100498edc: d10183a0    	sub	x0, x29, #0x60
100498ee0: 97ff4ba9    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498ee4: 910e03f6    	add	x22, sp, #0x380
100498ee8: 910e03e0    	add	x0, sp, #0x380
100498eec: 97ff4c4e    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100498ef0: 910862c0    	add	x0, x22, #0x218
100498ef4: 97ff4d20    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498ef8: 14000004    	b	0x100498f08 <conductor_lib::run::{closure#1}+0xba8>
100498efc: aa1503e0    	mov	x0, x21
100498f00: 52800001    	mov	w1, #0x0                ; =0
100498f04: 94005efd    	bl	0x1004b0af8 <<tauri::app::AppHandle>::exit>
100498f08: f9400281    	ldr	x1, [x20]
100498f0c: b4000081    	cbz	x1, 0x100498f1c <conductor_lib::run::{closure#1}+0xbbc>
100498f10: aa1303e0    	mov	x0, x19
100498f14: 52800022    	mov	w2, #0x1                ; =1
100498f18: 97eda1cf    	bl	0x100001654 <__rustc::__rust_dealloc>
100498f1c: 911e43ff    	add	sp, sp, #0x790
100498f20: a9437bfd    	ldp	x29, x30, [sp, #0x30]
100498f24: a9424ff4    	ldp	x20, x19, [sp, #0x20]
100498f28: a94157f6    	ldp	x22, x21, [sp, #0x10]
100498f2c: a8c46ffc    	ldp	x28, x27, [sp], #0x40
100498f30: d65f03c0    	ret
100498f34: f85a83a8    	ldur	x8, [x29, #-0x58]
100498f38: f81403a8    	stur	x8, [x29, #-0xc0]
100498f3c: 900083c0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100498f40: 91137400    	add	x0, x0, #0x4dd
100498f44: f0015f03    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100498f48: 91134063    	add	x3, x3, #0x4d0
100498f4c: f0015f04    	adrp	x4, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100498f50: 9108a084    	add	x4, x4, #0x228
100498f54: d10303a2    	sub	x2, x29, #0xc0
100498f58: 52800561    	mov	w1, #0x2b               ; =43
100498f5c: 943b9c54    	bl	0x1013800ac <core::result::unwrap_failed>
100498f60: 14000004    	b	0x100498f70 <conductor_lib::run::{closure#1}+0xc10>
100498f64: 52800020    	mov	w0, #0x1                ; =1
100498f68: 528000c1    	mov	w1, #0x6                ; =6
100498f6c: 943b9bd1    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100498f70: d4200020    	brk	#0x1
100498f74: aa0003f5    	mov	x21, x0
100498f78: d10183a0    	sub	x0, x29, #0x60
100498f7c: 97ff4b82    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498f80: 14000065    	b	0x100499114 <conductor_lib::run::{closure#1}+0xdb4>
100498f84: aa0003f5    	mov	x21, x0
100498f88: 910862c0    	add	x0, x22, #0x218
100498f8c: 97ff4cfa    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100498f90: 14000091    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100498f94: 943b9c60    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100498f98: 1400005c    	b	0x100499108 <conductor_lib::run::{closure#1}+0xda8>
100498f9c: aa0003f5    	mov	x21, x0
100498fa0: 14000085    	b	0x1004991b4 <conductor_lib::run::{closure#1}+0xe54>
100498fa4: aa0003f5    	mov	x21, x0
100498fa8: d10183a0    	sub	x0, x29, #0x60
100498fac: 97ff4b76    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498fb0: 1400006d    	b	0x100499164 <conductor_lib::run::{closure#1}+0xe04>
100498fb4: aa0003f5    	mov	x21, x0
100498fb8: d10183a0    	sub	x0, x29, #0x60
100498fbc: 97ff4b72    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498fc0: 1400006d    	b	0x100499174 <conductor_lib::run::{closure#1}+0xe14>
100498fc4: aa0003f5    	mov	x21, x0
100498fc8: d10183a0    	sub	x0, x29, #0x60
100498fcc: 97ff4b6e    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498fd0: 14000055    	b	0x100499124 <conductor_lib::run::{closure#1}+0xdc4>
100498fd4: aa0003f5    	mov	x21, x0
100498fd8: d10183a0    	sub	x0, x29, #0x60
100498fdc: 97ff4b6a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498fe0: 14000055    	b	0x100499134 <conductor_lib::run::{closure#1}+0xdd4>
100498fe4: aa0003f5    	mov	x21, x0
100498fe8: d10183a0    	sub	x0, x29, #0x60
100498fec: 97ff4b66    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100498ff0: 14000055    	b	0x100499144 <conductor_lib::run::{closure#1}+0xde4>
100498ff4: aa0003f5    	mov	x21, x0
100498ff8: d10183a0    	sub	x0, x29, #0x60
100498ffc: 97ff4b62    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100499000: 14000055    	b	0x100499154 <conductor_lib::run::{closure#1}+0xdf4>
100499004: aa0003f5    	mov	x21, x0
100499008: d10183a0    	sub	x0, x29, #0x60
10049900c: 97ff4b5e    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100499010: 1400005d    	b	0x100499184 <conductor_lib::run::{closure#1}+0xe24>
100499014: aa0003f5    	mov	x21, x0
100499018: d10183a0    	sub	x0, x29, #0x60
10049901c: 97ff4b5a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100499020: 1400005d    	b	0x100499194 <conductor_lib::run::{closure#1}+0xe34>
100499024: aa0003f5    	mov	x21, x0
100499028: d10183a0    	sub	x0, x29, #0x60
10049902c: 97ff4b56    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100499030: 14000067    	b	0x1004991cc <conductor_lib::run::{closure#1}+0xe6c>
100499034: aa0003f5    	mov	x21, x0
100499038: f941c3e1    	ldr	x1, [sp, #0x380]
10049903c: b4000cc1    	cbz	x1, 0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499040: f941c7e0    	ldr	x0, [sp, #0x388]
100499044: 52800022    	mov	w2, #0x1                ; =1
100499048: 97eda183    	bl	0x100001654 <__rustc::__rust_dealloc>
10049904c: 14000062    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499050: aa0003f5    	mov	x21, x0
100499054: 910862c0    	add	x0, x22, #0x218
100499058: 97ff4cc7    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
10049905c: 1400005e    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499060: 943b9c2d    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100499064: aa0003f5    	mov	x21, x0
100499068: 910862c0    	add	x0, x22, #0x218
10049906c: 97ff4cc2    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100499070: 14000059    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499074: 943b9c28    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100499078: aa0003f5    	mov	x21, x0
10049907c: 910862c0    	add	x0, x22, #0x218
100499080: 97ff4cbd    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100499084: 14000054    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499088: 943b9c23    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049908c: aa0003f5    	mov	x21, x0
100499090: 910862c0    	add	x0, x22, #0x218
100499094: 97ff4cb8    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100499098: 1400004f    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
10049909c: 943b9c1e    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004990a0: aa0003f5    	mov	x21, x0
1004990a4: 910862c0    	add	x0, x22, #0x218
1004990a8: 97ff4cb3    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004990ac: 1400004a    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004990b0: 943b9c19    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004990b4: aa0003f5    	mov	x21, x0
1004990b8: 910862c0    	add	x0, x22, #0x218
1004990bc: 97ff4cae    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004990c0: 14000045    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004990c4: 943b9c14    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004990c8: aa0003f5    	mov	x21, x0
1004990cc: 910862c0    	add	x0, x22, #0x218
1004990d0: 97ff4ca9    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004990d4: 14000040    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004990d8: 943b9c0f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004990dc: aa0003f5    	mov	x21, x0
1004990e0: 910862c0    	add	x0, x22, #0x218
1004990e4: 97ff4ca4    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
1004990e8: 1400003b    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004990ec: 943b9c0a    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004990f0: aa0003f5    	mov	x21, x0
1004990f4: 910e03e0    	add	x0, sp, #0x380
1004990f8: 97ff54aa    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
1004990fc: 14000036    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499100: aa0003f5    	mov	x21, x0
100499104: 14000032    	b	0x1004991cc <conductor_lib::run::{closure#1}+0xe6c>
100499108: aa0003f5    	mov	x21, x0
10049910c: 1400002e    	b	0x1004991c4 <conductor_lib::run::{closure#1}+0xe64>
100499110: aa0003f5    	mov	x21, x0
100499114: 910e03e0    	add	x0, sp, #0x380
100499118: 97ff54a2    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049911c: 1400002e    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499120: aa0003f5    	mov	x21, x0
100499124: 910e03e0    	add	x0, sp, #0x380
100499128: 97ff549e    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049912c: 1400002a    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499130: aa0003f5    	mov	x21, x0
100499134: 910e03e0    	add	x0, sp, #0x380
100499138: 97ff549a    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049913c: 14000026    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499140: aa0003f5    	mov	x21, x0
100499144: 910e03e0    	add	x0, sp, #0x380
100499148: 97ff5496    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049914c: 14000022    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499150: aa0003f5    	mov	x21, x0
100499154: 910e03e0    	add	x0, sp, #0x380
100499158: 97ff5492    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049915c: 1400001e    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499160: aa0003f5    	mov	x21, x0
100499164: 910e03e0    	add	x0, sp, #0x380
100499168: 97ff548e    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049916c: 1400001a    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499170: aa0003f5    	mov	x21, x0
100499174: 910e03e0    	add	x0, sp, #0x380
100499178: 97ff548a    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049917c: 14000016    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499180: aa0003f5    	mov	x21, x0
100499184: 910e03e0    	add	x0, sp, #0x380
100499188: 97ff5486    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049918c: 14000012    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
100499190: aa0003f5    	mov	x21, x0
100499194: 910e03e0    	add	x0, sp, #0x380
100499198: 97ff5482    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
10049919c: 1400000e    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004991a0: aa0003f5    	mov	x21, x0
1004991a4: 1400000c    	b	0x1004991d4 <conductor_lib::run::{closure#1}+0xe74>
1004991a8: aa0003f5    	mov	x21, x0
1004991ac: d10303a0    	sub	x0, x29, #0xc0
1004991b0: 97ff3c1d    	bl	0x100468224 <core::ptr::drop_glue::<serde_json::error::Error>>
1004991b4: aa1603e0    	mov	x0, x22
1004991b8: 528000c1    	mov	w1, #0x6                ; =6
1004991bc: 52800022    	mov	w2, #0x1                ; =1
1004991c0: 97eda125    	bl	0x100001654 <__rustc::__rust_dealloc>
1004991c4: d10243a0    	sub	x0, x29, #0x90
1004991c8: 9409d766    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1004991cc: 910e03e0    	add	x0, sp, #0x380
1004991d0: 97ff5474    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
1004991d4: f9400281    	ldr	x1, [x20]
1004991d8: b4000081    	cbz	x1, 0x1004991e8 <conductor_lib::run::{closure#1}+0xe88>
1004991dc: aa1303e0    	mov	x0, x19
1004991e0: 52800022    	mov	w2, #0x1                ; =1
1004991e4: 97eda11c    	bl	0x100001654 <__rustc::__rust_dealloc>
1004991e8: aa1503e0    	mov	x0, x21
1004991ec: 943b9e67    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
1004991f0: 943b9bc9    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004991f4: 943b9bc8    	bl	0x101380114 <core::panicking::panic_in_cleanup>
