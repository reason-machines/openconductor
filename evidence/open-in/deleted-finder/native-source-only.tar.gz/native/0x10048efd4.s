
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010048efd4 <conductor_lib::run::{closure#0}>:
10048efd4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10048efd8: a90167fa    	stp	x26, x25, [sp, #0x10]
10048efdc: a9025ff8    	stp	x24, x23, [sp, #0x20]
10048efe0: a90357f6    	stp	x22, x21, [sp, #0x30]
10048efe4: a9044ff4    	stp	x20, x19, [sp, #0x40]
10048efe8: a9057bfd    	stp	x29, x30, [sp, #0x50]
10048efec: 910143fd    	add	x29, sp, #0x50
10048eff0: d14007ff    	sub	sp, sp, #0x1, lsl #12   ; =0x1000
10048eff4: f90003ff    	str	xzr, [sp]
10048eff8: d10e43ff    	sub	sp, sp, #0x390
10048effc: aa0003f3    	mov	x19, x0
10048f000: 9409602d    	bl	0x1006e70b4 <conductor_lib::startup_sidebar_transparency_enabled>
10048f004: aa0003f6    	mov	x22, x0
10048f008: f940a669    	ldr	x9, [x19, #0x148]
10048f00c: f947e928    	ldr	x8, [x9, #0xfd0]
10048f010: b100051f    	cmn	x8, #0x1
10048f014: 54000100    	b.eq	0x10048f034 <conductor_lib::run::{closure#0}+0x60>
10048f018: 912c43e8    	add	x8, sp, #0xb10
10048f01c: 913f4120    	add	x0, x9, #0xfd0
10048f020: 943a0b9a    	bl	0x101311e88 <<alloc::string::String as core::clone::Clone>::clone>
10048f024: f9458bf5    	ldr	x21, [sp, #0xb10]
10048f028: f9458ff4    	ldr	x20, [sp, #0xb18]
10048f02c: f94593f7    	ldr	x23, [sp, #0xb20]
10048f030: 1400000f    	b	0x10048f06c <conductor_lib::run::{closure#0}+0x98>
10048f034: 97edc98b    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f038: 52800120    	mov	w0, #0x9                ; =9
10048f03c: 52800021    	mov	w1, #0x1                ; =1
10048f040: 97edc984    	bl	0x100001650 <__rustc::__rust_alloc>
10048f044: b4017020    	cbz	x0, 0x100491e48 <conductor_lib::run::{closure#0}+0x2e74>
10048f048: aa0003f4    	mov	x20, x0
10048f04c: 52800e48    	mov	w8, #0x72               ; =114
10048f050: 39002008    	strb	w8, [x0, #0x8]
10048f054: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f058: 91150108    	add	x8, x8, #0x540
10048f05c: f9400108    	ldr	x8, [x8]
10048f060: f9000008    	str	x8, [x0]
10048f064: 52800137    	mov	w23, #0x9               ; =9
10048f068: 52800135    	mov	w21, #0x9               ; =9
10048f06c: f9078bff    	str	xzr, [sp, #0xf10]
10048f070: f90793ff    	str	xzr, [sp, #0xf20]
10048f074: 97edc97b    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f078: 528000b8    	mov	w24, #0x5               ; =5
10048f07c: 528000a0    	mov	w0, #0x5                ; =5
10048f080: 52800021    	mov	w1, #0x1                ; =1
10048f084: 97edc973    	bl	0x100001650 <__rustc::__rust_alloc>
10048f088: b4014000    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f08c: aa0003f9    	mov	x25, x0
10048f090: 52800d88    	mov	w8, #0x6c               ; =108
10048f094: 39001008    	strb	w8, [x0, #0x4]
10048f098: 528c2d88    	mov	w8, #0x616c             ; =24940
10048f09c: 72acac48    	movk	w8, #0x6562, lsl #16
10048f0a0: b9000008    	str	w8, [x0]
10048f0a4: 528000a8    	mov	w8, #0x5                ; =5
10048f0a8: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f0ac: f90013e8    	str	x8, [sp, #0x20]
10048f0b0: 97edc96c    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f0b4: 52800080    	mov	w0, #0x4                ; =4
10048f0b8: 52800021    	mov	w1, #0x1                ; =1
10048f0bc: 97edc965    	bl	0x100001650 <__rustc::__rust_alloc>
10048f0c0: b40155c0    	cbz	x0, 0x100491b78 <conductor_lib::run::{closure#0}+0x2ba4>
10048f0c4: 528c2da8    	mov	w8, #0x616d             ; =24941
10048f0c8: 72adcd28    	movk	w8, #0x6e69, lsl #16
10048f0cc: b9000008    	str	w8, [x0]
10048f0d0: 52800068    	mov	w8, #0x3                ; =3
10048f0d4: 392c43e8    	strb	w8, [sp, #0xb10]
10048f0d8: 52800088    	mov	w8, #0x4                ; =4
10048f0dc: f9058fe8    	str	x8, [sp, #0xb18]
10048f0e0: f90593e0    	str	x0, [sp, #0xb20]
10048f0e4: f90597e8    	str	x8, [sp, #0xb28]
10048f0e8: 911e43e8    	add	x8, sp, #0x790
10048f0ec: 913c43e0    	add	x0, sp, #0xf10
10048f0f0: 910043e1    	add	x1, sp, #0x10
10048f0f4: 912c43e2    	add	x2, sp, #0xb10
10048f0f8: 9409c0f5    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f0fc: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f100: 7103fd1f    	cmp	w8, #0xff
10048f104: 54000060    	b.eq	0x10048f110 <conductor_lib::run::{closure#0}+0x13c>
10048f108: 911e43e0    	add	x0, sp, #0x790
10048f10c: 97ff6471    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f110: 97edc954    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f114: 528000b8    	mov	w24, #0x5               ; =5
10048f118: 528000a0    	mov	w0, #0x5                ; =5
10048f11c: 52800021    	mov	w1, #0x1                ; =1
10048f120: 97edc94c    	bl	0x100001650 <__rustc::__rust_alloc>
10048f124: b4013b20    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f128: aa0003f9    	mov	x25, x0
10048f12c: 52800ca8    	mov	w8, #0x65               ; =101
10048f130: 39001008    	strb	w8, [x0, #0x4]
10048f134: 528d2e88    	mov	w8, #0x6974             ; =26996
10048f138: 72ad8e88    	movk	w8, #0x6c74, lsl #16
10048f13c: b9000008    	str	w8, [x0]
10048f140: 528000a8    	mov	w8, #0x5                ; =5
10048f144: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f148: f90013e8    	str	x8, [sp, #0x20]
10048f14c: b6f800d7    	tbz	x23, #0x3f, 0x10048f164 <conductor_lib::run::{closure#0}+0x190>
10048f150: d280001a    	mov	x26, #0x0               ; =0
10048f154: aa1a03e0    	mov	x0, x26
10048f158: aa1703e1    	mov	x1, x23
10048f15c: 943bc355    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
10048f160: 14000baa    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048f164: b4000197    	cbz	x23, 0x10048f194 <conductor_lib::run::{closure#0}+0x1c0>
10048f168: 97edc93e    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f16c: 5280003a    	mov	w26, #0x1               ; =1
10048f170: aa1703e0    	mov	x0, x23
10048f174: 52800021    	mov	w1, #0x1                ; =1
10048f178: 97edc936    	bl	0x100001650 <__rustc::__rust_alloc>
10048f17c: b4fffec0    	cbz	x0, 0x10048f154 <conductor_lib::run::{closure#0}+0x180>
10048f180: aa0003f8    	mov	x24, x0
10048f184: aa1403e1    	mov	x1, x20
10048f188: aa1703e2    	mov	x2, x23
10048f18c: 943bc7e1    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f190: 14000002    	b	0x10048f198 <conductor_lib::run::{closure#0}+0x1c4>
10048f194: 52800038    	mov	w24, #0x1               ; =1
10048f198: 52800068    	mov	w8, #0x3                ; =3
10048f19c: 392c43e8    	strb	w8, [sp, #0xb10]
10048f1a0: f9058ff7    	str	x23, [sp, #0xb18]
10048f1a4: f90593f8    	str	x24, [sp, #0xb20]
10048f1a8: f90597f7    	str	x23, [sp, #0xb28]
10048f1ac: 911e43e8    	add	x8, sp, #0x790
10048f1b0: 913c43e0    	add	x0, sp, #0xf10
10048f1b4: 910043e1    	add	x1, sp, #0x10
10048f1b8: 912c43e2    	add	x2, sp, #0xb10
10048f1bc: 9409c0c4    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f1c0: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f1c4: 7103fd1f    	cmp	w8, #0xff
10048f1c8: 54000060    	b.eq	0x10048f1d4 <conductor_lib::run::{closure#0}+0x200>
10048f1cc: 911e43e0    	add	x0, sp, #0x790
10048f1d0: 97ff6440    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f1d4: 97edc923    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f1d8: 528000b8    	mov	w24, #0x5               ; =5
10048f1dc: 528000a0    	mov	w0, #0x5                ; =5
10048f1e0: 52800021    	mov	w1, #0x1                ; =1
10048f1e4: 97edc91b    	bl	0x100001650 <__rustc::__rust_alloc>
10048f1e8: b4013500    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f1ec: 912c43fa    	add	x26, sp, #0xb10
10048f1f0: 52800d08    	mov	w8, #0x68               ; =104
10048f1f4: 39001008    	strb	w8, [x0, #0x4]
10048f1f8: 528d2ee8    	mov	w8, #0x6977             ; =26999
10048f1fc: 72ae8c88    	movk	w8, #0x7464, lsl #16
10048f200: b9000008    	str	w8, [x0]
10048f204: 528000a8    	mov	w8, #0x5                ; =5
10048f208: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f20c: f90013e8    	str	x8, [sp, #0x20]
10048f210: 52800048    	mov	w8, #0x2                ; =2
10048f214: 392c43e8    	strb	w8, [sp, #0xb10]
10048f218: 900083e8    	adrp	x8, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
10048f21c: 3dc31100    	ldr	q0, [x8, #0xc40]
10048f220: 3c808340    	stur	q0, [x26, #0x8]
10048f224: 911e43e8    	add	x8, sp, #0x790
10048f228: 913c43e0    	add	x0, sp, #0xf10
10048f22c: 910043e1    	add	x1, sp, #0x10
10048f230: 912c43e2    	add	x2, sp, #0xb10
10048f234: 9409c0a6    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f238: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f23c: 7103fd1f    	cmp	w8, #0xff
10048f240: 54000060    	b.eq	0x10048f24c <conductor_lib::run::{closure#0}+0x278>
10048f244: 911e43e0    	add	x0, sp, #0x790
10048f248: 97ff6422    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f24c: 97edc905    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f250: 528000d8    	mov	w24, #0x6               ; =6
10048f254: 528000c0    	mov	w0, #0x6                ; =6
10048f258: 52800021    	mov	w1, #0x1                ; =1
10048f25c: 97edc8fd    	bl	0x100001650 <__rustc::__rust_alloc>
10048f260: b4013140    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f264: 528e8d08    	mov	w8, #0x7468             ; =29800
10048f268: 79000808    	strh	w8, [x0, #0x4]
10048f26c: 528cad08    	mov	w8, #0x6568             ; =25960
10048f270: 72aced28    	movk	w8, #0x6769, lsl #16
10048f274: b9000008    	str	w8, [x0]
10048f278: 528000c8    	mov	w8, #0x6                ; =6
10048f27c: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f280: f90013e8    	str	x8, [sp, #0x20]
10048f284: 52800048    	mov	w8, #0x2                ; =2
10048f288: 392c43e8    	strb	w8, [sp, #0xb10]
10048f28c: 900083e8    	adrp	x8, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
10048f290: 3dc31500    	ldr	q0, [x8, #0xc50]
10048f294: 3c808340    	stur	q0, [x26, #0x8]
10048f298: 911e43e8    	add	x8, sp, #0x790
10048f29c: 913c43e0    	add	x0, sp, #0xf10
10048f2a0: 910043e1    	add	x1, sp, #0x10
10048f2a4: 912c43e2    	add	x2, sp, #0xb10
10048f2a8: 9409c089    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f2ac: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f2b0: 7103fd1f    	cmp	w8, #0xff
10048f2b4: 54000060    	b.eq	0x10048f2c0 <conductor_lib::run::{closure#0}+0x2ec>
10048f2b8: 911e43e0    	add	x0, sp, #0x790
10048f2bc: 97ff6405    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f2c0: 97edc8e8    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f2c4: 52800118    	mov	w24, #0x8               ; =8
10048f2c8: 52800100    	mov	w0, #0x8                ; =8
10048f2cc: 52800021    	mov	w1, #0x1                ; =1
10048f2d0: 97edc8e0    	bl	0x100001650 <__rustc::__rust_alloc>
10048f2d4: b4012da0    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f2d8: d28d2da8    	mov	x8, #0x696d             ; =26989
10048f2dc: f2aaedc8    	movk	x8, #0x576e, lsl #16
10048f2e0: f2cc8d28    	movk	x8, #0x6469, lsl #32
10048f2e4: f2ed0e88    	movk	x8, #0x6874, lsl #48
10048f2e8: f9000008    	str	x8, [x0]
10048f2ec: 52800108    	mov	w8, #0x8                ; =8
10048f2f0: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f2f4: f90013e8    	str	x8, [sp, #0x20]
10048f2f8: 52800048    	mov	w8, #0x2                ; =2
10048f2fc: 392c43e8    	strb	w8, [sp, #0xb10]
10048f300: 900083e8    	adrp	x8, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
10048f304: 3dc31900    	ldr	q0, [x8, #0xc60]
10048f308: 3c808340    	stur	q0, [x26, #0x8]
10048f30c: 911e43e8    	add	x8, sp, #0x790
10048f310: 913c43e0    	add	x0, sp, #0xf10
10048f314: 910043e1    	add	x1, sp, #0x10
10048f318: 912c43e2    	add	x2, sp, #0xb10
10048f31c: 9409c06c    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f320: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f324: 7103fd1f    	cmp	w8, #0xff
10048f328: 54000060    	b.eq	0x10048f334 <conductor_lib::run::{closure#0}+0x360>
10048f32c: 911e43e0    	add	x0, sp, #0x790
10048f330: 97ff63e8    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f334: 97edc8cb    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f338: 52800138    	mov	w24, #0x9               ; =9
10048f33c: 52800120    	mov	w0, #0x9                ; =9
10048f340: 52800021    	mov	w1, #0x1                ; =1
10048f344: 97edc8c3    	bl	0x100001650 <__rustc::__rust_alloc>
10048f348: b4012a00    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f34c: 52800e88    	mov	w8, #0x74               ; =116
10048f350: 90008409    	adrp	x9, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f354: 9123c929    	add	x9, x9, #0x8f2
10048f358: 39002008    	strb	w8, [x0, #0x8]
10048f35c: f9400128    	ldr	x8, [x9]
10048f360: f9000008    	str	x8, [x0]
10048f364: 52800128    	mov	w8, #0x9                ; =9
10048f368: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f36c: f90013e8    	str	x8, [sp, #0x20]
10048f370: 52800048    	mov	w8, #0x2                ; =2
10048f374: 392c43e8    	strb	w8, [sp, #0xb10]
10048f378: 900083e8    	adrp	x8, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
10048f37c: 3dc31d00    	ldr	q0, [x8, #0xc70]
10048f380: 3c808340    	stur	q0, [x26, #0x8]
10048f384: 911e43e8    	add	x8, sp, #0x790
10048f388: 913c43e0    	add	x0, sp, #0xf10
10048f38c: 910043e1    	add	x1, sp, #0x10
10048f390: 912c43e2    	add	x2, sp, #0xb10
10048f394: 9409c04e    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f398: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f39c: 7103fd1f    	cmp	w8, #0xff
10048f3a0: 54000060    	b.eq	0x10048f3ac <conductor_lib::run::{closure#0}+0x3d8>
10048f3a4: 911e43e0    	add	x0, sp, #0x790
10048f3a8: 97ff63ca    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f3ac: 97edc8ad    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f3b0: 52800178    	mov	w24, #0xb               ; =11
10048f3b4: 52800160    	mov	w0, #0xb                ; =11
10048f3b8: 52800021    	mov	w1, #0x1                ; =1
10048f3bc: 97edc8a5    	bl	0x100001650 <__rustc::__rust_alloc>
10048f3c0: b4012640    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f3c4: 528ded28    	mov	w8, #0x6f69             ; =28521
10048f3c8: 72ae6dc8    	movk	w8, #0x736e, lsl #16
10048f3cc: b8007008    	stur	w8, [x0, #0x7]
10048f3d0: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f3d4: 9123ed08    	add	x8, x8, #0x8fb
10048f3d8: f9400108    	ldr	x8, [x8]
10048f3dc: f9000008    	str	x8, [x0]
10048f3e0: 52800168    	mov	w8, #0xb                ; =11
10048f3e4: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f3e8: f90013e8    	str	x8, [sp, #0x20]
10048f3ec: 52802028    	mov	w8, #0x101              ; =257
10048f3f0: 7905a3e8    	strh	w8, [sp, #0x2d0]
10048f3f4: ad5687e0    	ldp	q0, q1, [sp, #0x2d0]
10048f3f8: 3d82c7e0    	str	q0, [sp, #0xb10]
10048f3fc: 3d82cbe1    	str	q1, [sp, #0xb20]
10048f400: 911e43e8    	add	x8, sp, #0x790
10048f404: 913c43e0    	add	x0, sp, #0xf10
10048f408: 910043e1    	add	x1, sp, #0x10
10048f40c: 912c43e2    	add	x2, sp, #0xb10
10048f410: 9409c02f    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f414: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f418: 7103fd1f    	cmp	w8, #0xff
10048f41c: 54000060    	b.eq	0x10048f428 <conductor_lib::run::{closure#0}+0x454>
10048f420: 911e43e0    	add	x0, sp, #0x790
10048f424: 97ff63ab    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f428: 97edc88e    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f42c: 52800178    	mov	w24, #0xb               ; =11
10048f430: 52800037    	mov	w23, #0x1               ; =1
10048f434: 52800160    	mov	w0, #0xb                ; =11
10048f438: 52800021    	mov	w1, #0x1                ; =1
10048f43c: 97edc885    	bl	0x100001650 <__rustc::__rust_alloc>
10048f440: b4012240    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f444: 528cae48    	mov	w8, #0x6572             ; =25970
10048f448: 72ae8dc8    	movk	w8, #0x746e, lsl #16
10048f44c: b8007008    	stur	w8, [x0, #0x7]
10048f450: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f454: 91241908    	add	x8, x8, #0x906
10048f458: f9400108    	ldr	x8, [x8]
10048f45c: f9000008    	str	x8, [x0]
10048f460: 52800168    	mov	w8, #0xb                ; =11
10048f464: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f468: f90013e8    	str	x8, [sp, #0x20]
10048f46c: 392c43f7    	strb	w23, [sp, #0xb10]
10048f470: 392c47f6    	strb	w22, [sp, #0xb11]
10048f474: 911e43e8    	add	x8, sp, #0x790
10048f478: 913c43e0    	add	x0, sp, #0xf10
10048f47c: 910043e1    	add	x1, sp, #0x10
10048f480: 912c43e2    	add	x2, sp, #0xb10
10048f484: 9409c012    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f488: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f48c: 7103fd1f    	cmp	w8, #0xff
10048f490: 54000060    	b.eq	0x10048f49c <conductor_lib::run::{closure#0}+0x4c8>
10048f494: 911e43e0    	add	x0, sp, #0x790
10048f498: 97ff638e    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f49c: 97edc871    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f4a0: 528001f8    	mov	w24, #0xf               ; =15
10048f4a4: 528001e0    	mov	w0, #0xf                ; =15
10048f4a8: 52800021    	mov	w1, #0x1                ; =1
10048f4ac: 97edc869    	bl	0x100001650 <__rustc::__rust_alloc>
10048f4b0: b4011ec0    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f4b4: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f4b8: 91244508    	add	x8, x8, #0x911
10048f4bc: f9400109    	ldr	x9, [x8]
10048f4c0: f9000009    	str	x9, [x0]
10048f4c4: f8407108    	ldur	x8, [x8, #0x7]
10048f4c8: f8007008    	stur	x8, [x0, #0x7]
10048f4cc: 528001e8    	mov	w8, #0xf                ; =15
10048f4d0: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f4d4: f90013e8    	str	x8, [sp, #0x20]
10048f4d8: 36000076    	tbz	w22, #0x0, 0x10048f4e4 <conductor_lib::run::{closure#0}+0x510>
10048f4dc: 52800008    	mov	w8, #0x0                ; =0
10048f4e0: 1400000e    	b	0x10048f518 <conductor_lib::run::{closure#0}+0x544>
10048f4e4: aa0003f6    	mov	x22, x0
10048f4e8: 97edc85e    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f4ec: 528000e0    	mov	w0, #0x7                ; =7
10048f4f0: 52800021    	mov	w1, #0x1                ; =1
10048f4f4: 97edc857    	bl	0x100001650 <__rustc::__rust_alloc>
10048f4f8: b4014ae0    	cbz	x0, 0x100491e54 <conductor_lib::run::{closure#0}+0x2e80>
10048f4fc: 52862628    	mov	w8, #0x3131             ; =12593
10048f500: 72a60628    	movk	w8, #0x3031, lsl #16
10048f504: b8003008    	stur	w8, [x0, #0x3]
10048f508: 52862468    	mov	w8, #0x3123             ; =12579
10048f50c: 72a62688    	movk	w8, #0x3134, lsl #16
10048f510: b9000008    	str	w8, [x0]
10048f514: 52800068    	mov	w8, #0x3                ; =3
10048f518: 392c43e8    	strb	w8, [sp, #0xb10]
10048f51c: 528000e8    	mov	w8, #0x7                ; =7
10048f520: f9058fe8    	str	x8, [sp, #0xb18]
10048f524: f90593e0    	str	x0, [sp, #0xb20]
10048f528: f90597e8    	str	x8, [sp, #0xb28]
10048f52c: 911e43e8    	add	x8, sp, #0x790
10048f530: 913c43e0    	add	x0, sp, #0xf10
10048f534: 910043e1    	add	x1, sp, #0x10
10048f538: 912c43e2    	add	x2, sp, #0xb10
10048f53c: 9409bfe4    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f540: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f544: 7103fd1f    	cmp	w8, #0xff
10048f548: 54000060    	b.eq	0x10048f554 <conductor_lib::run::{closure#0}+0x580>
10048f54c: 911e43e0    	add	x0, sp, #0x790
10048f550: 97ff6360    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f554: 97edc843    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f558: 52800178    	mov	w24, #0xb               ; =11
10048f55c: 52800160    	mov	w0, #0xb                ; =11
10048f560: 52800021    	mov	w1, #0x1                ; =1
10048f564: 97edc83b    	bl	0x100001650 <__rustc::__rust_alloc>
10048f568: b4011900    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f56c: 528e8d28    	mov	w8, #0x7469             ; =29801
10048f570: 72acad88    	movk	w8, #0x656c, lsl #16
10048f574: b8007008    	stur	w8, [x0, #0x7]
10048f578: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f57c: 91248108    	add	x8, x8, #0x920
10048f580: f9400108    	ldr	x8, [x8]
10048f584: f9000008    	str	x8, [x0]
10048f588: 52800168    	mov	w8, #0xb                ; =11
10048f58c: f903cbe8    	str	x8, [sp, #0x790]
10048f590: f903cfe0    	str	x0, [sp, #0x798]
10048f594: f903d3e8    	str	x8, [sp, #0x7a0]
10048f598: 912c43e8    	add	x8, sp, #0xb10
10048f59c: 913c43e0    	add	x0, sp, #0xf10
10048f5a0: 911e43e1    	add	x1, sp, #0x790
10048f5a4: 910b43e2    	add	x2, sp, #0x2d0
10048f5a8: 9409bfc9    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f5ac: 396c43e8    	ldrb	w8, [sp, #0xb10]
10048f5b0: 7103fd1f    	cmp	w8, #0xff
10048f5b4: 54000060    	b.eq	0x10048f5c0 <conductor_lib::run::{closure#0}+0x5ec>
10048f5b8: 912c43e0    	add	x0, sp, #0xb10
10048f5bc: 97ff6345    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f5c0: 97edc828    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f5c4: 528001b8    	mov	w24, #0xd               ; =13
10048f5c8: 528001a0    	mov	w0, #0xd                ; =13
10048f5cc: 52800021    	mov	w1, #0x1                ; =1
10048f5d0: 97edc820    	bl	0x100001650 <__rustc::__rust_alloc>
10048f5d4: b40115a0    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f5d8: aa0003f6    	mov	x22, x0
10048f5dc: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f5e0: 9124ad08    	add	x8, x8, #0x92b
10048f5e4: f9400109    	ldr	x9, [x8]
10048f5e8: f9000009    	str	x9, [x0]
10048f5ec: f8405108    	ldur	x8, [x8, #0x5]
10048f5f0: f8005008    	stur	x8, [x0, #0x5]
10048f5f4: 528001a8    	mov	w8, #0xd                ; =13
10048f5f8: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f5fc: f90013e8    	str	x8, [sp, #0x20]
10048f600: 97edc818    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f604: 528000e0    	mov	w0, #0x7                ; =7
10048f608: 52800021    	mov	w1, #0x1                ; =1
10048f60c: 97edc811    	bl	0x100001650 <__rustc::__rust_alloc>
10048f610: b4013340    	cbz	x0, 0x100491c78 <conductor_lib::run::{closure#0}+0x2ca4>
10048f614: 528d8e48    	mov	w8, #0x6c72             ; =27762
10048f618: 72af2c28    	movk	w8, #0x7961, lsl #16
10048f61c: b8003008    	stur	w8, [x0, #0x3]
10048f620: 528ec9e8    	mov	w8, #0x764f             ; =30287
10048f624: 72ae4ca8    	movk	w8, #0x7265, lsl #16
10048f628: b9000008    	str	w8, [x0]
10048f62c: 52800068    	mov	w8, #0x3                ; =3
10048f630: 392c43e8    	strb	w8, [sp, #0xb10]
10048f634: 528000e8    	mov	w8, #0x7                ; =7
10048f638: f9058fe8    	str	x8, [sp, #0xb18]
10048f63c: f90593e0    	str	x0, [sp, #0xb20]
10048f640: f90597e8    	str	x8, [sp, #0xb28]
10048f644: 911e43e8    	add	x8, sp, #0x790
10048f648: 913c43e0    	add	x0, sp, #0xf10
10048f64c: 910043e1    	add	x1, sp, #0x10
10048f650: 912c43e2    	add	x2, sp, #0xb10
10048f654: 9409bf9e    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f658: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f65c: 7103fd1f    	cmp	w8, #0xff
10048f660: 54000060    	b.eq	0x10048f66c <conductor_lib::run::{closure#0}+0x698>
10048f664: 911e43e0    	add	x0, sp, #0x790
10048f668: 97ff631a    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f66c: 97edc7fd    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f670: 52800258    	mov	w24, #0x12              ; =18
10048f674: 52800036    	mov	w22, #0x1               ; =1
10048f678: 52800240    	mov	w0, #0x12               ; =18
10048f67c: 52800021    	mov	w1, #0x1                ; =1
10048f680: 97edc7f4    	bl	0x100001650 <__rustc::__rust_alloc>
10048f684: b4011020    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f688: 528c8ca8    	mov	w8, #0x6465             ; =25701
10048f68c: 79002008    	strh	w8, [x0, #0x10]
10048f690: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f694: 9124fd08    	add	x8, x8, #0x93f
10048f698: 3dc00100    	ldr	q0, [x8]
10048f69c: 3d800000    	str	q0, [x0]
10048f6a0: 52800248    	mov	w8, #0x12               ; =18
10048f6a4: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f6a8: f90013e8    	str	x8, [sp, #0x20]
10048f6ac: 791623f6    	strh	w22, [sp, #0xb10]
10048f6b0: 911e43e8    	add	x8, sp, #0x790
10048f6b4: 913c43e0    	add	x0, sp, #0xf10
10048f6b8: 910043e1    	add	x1, sp, #0x10
10048f6bc: 912c43e2    	add	x2, sp, #0xb10
10048f6c0: 9409bf83    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f6c4: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f6c8: 7103fd1f    	cmp	w8, #0xff
10048f6cc: 54000060    	b.eq	0x10048f6d8 <conductor_lib::run::{closure#0}+0x704>
10048f6d0: 911e43e0    	add	x0, sp, #0x790
10048f6d4: 97ff62ff    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f6d8: 97edc7e2    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f6dc: 52800298    	mov	w24, #0x14              ; =20
10048f6e0: 52800280    	mov	w0, #0x14               ; =20
10048f6e4: 52800021    	mov	w1, #0x1                ; =1
10048f6e8: 97edc7da    	bl	0x100001650 <__rustc::__rust_alloc>
10048f6ec: b4010ce0    	cbz	x0, 0x100491888 <conductor_lib::run::{closure#0}+0x28b4>
10048f6f0: aa0003f6    	mov	x22, x0
10048f6f4: 528d2e88    	mov	w8, #0x6974             ; =26996
10048f6f8: 72adcde8    	movk	w8, #0x6e6f, lsl #16
10048f6fc: b9001008    	str	w8, [x0, #0x10]
10048f700: 90008408    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f704: 91254508    	add	x8, x8, #0x951
10048f708: 3dc00100    	ldr	q0, [x8]
10048f70c: 3d800000    	str	q0, [x0]
10048f710: 52800288    	mov	w8, #0x14               ; =20
10048f714: f907a3e8    	str	x8, [sp, #0xf40]
10048f718: f907a7e0    	str	x0, [sp, #0xf48]
10048f71c: f907abe8    	str	x8, [sp, #0xf50]
10048f720: f9089bff    	str	xzr, [sp, #0x1130]
10048f724: f908a3ff    	str	xzr, [sp, #0x1140]
10048f728: 97edc7ce    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f72c: 52800020    	mov	w0, #0x1                ; =1
10048f730: 52800021    	mov	w1, #0x1                ; =1
10048f734: 97edc7c7    	bl	0x100001650 <__rustc::__rust_alloc>
10048f738: b4012280    	cbz	x0, 0x100491b88 <conductor_lib::run::{closure#0}+0x2bb4>
10048f73c: aa0003f7    	mov	x23, x0
10048f740: 52800f08    	mov	w8, #0x78               ; =120
10048f744: 39000008    	strb	w8, [x0]
10048f748: 52800028    	mov	w8, #0x1                ; =1
10048f74c: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f750: f90013e8    	str	x8, [sp, #0x20]
10048f754: 912c43e8    	add	x8, sp, #0xb10
10048f758: 1e655000    	fmov	d0, #13.00000000
10048f75c: 94383393    	bl	0x10129c5a8 <<serde_json::value::Value as core::convert::From<f64>>::from>
10048f760: 396c43e8    	ldrb	w8, [sp, #0xb10]
10048f764: 7103fd1f    	cmp	w8, #0xff
10048f768: 5400a3a0    	b.eq	0x100490bdc <conductor_lib::run::{closure#0}+0x1c08>
10048f76c: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10048f770: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
10048f774: 3d81e7e0    	str	q0, [sp, #0x790]
10048f778: 3d81ebe1    	str	q1, [sp, #0x7a0]
10048f77c: 912c43e8    	add	x8, sp, #0xb10
10048f780: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10048f784: 9104c000    	add	x0, x0, #0x130
10048f788: 910043e1    	add	x1, sp, #0x10
10048f78c: 911e43e2    	add	x2, sp, #0x790
10048f790: 9409bf4f    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f794: 396c43e8    	ldrb	w8, [sp, #0xb10]
10048f798: 7103fd1f    	cmp	w8, #0xff
10048f79c: 54000060    	b.eq	0x10048f7a8 <conductor_lib::run::{closure#0}+0x7d4>
10048f7a0: 912c43e0    	add	x0, sp, #0xb10
10048f7a4: 97ff62cb    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f7a8: 97edc7ae    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048f7ac: 52800020    	mov	w0, #0x1                ; =1
10048f7b0: 52800021    	mov	w1, #0x1                ; =1
10048f7b4: 97edc7a7    	bl	0x100001650 <__rustc::__rust_alloc>
10048f7b8: b4011e80    	cbz	x0, 0x100491b88 <conductor_lib::run::{closure#0}+0x2bb4>
10048f7bc: aa0003f7    	mov	x23, x0
10048f7c0: 52800f28    	mov	w8, #0x79               ; =121
10048f7c4: 39000008    	strb	w8, [x0]
10048f7c8: 52800028    	mov	w8, #0x1                ; =1
10048f7cc: a90103e8    	stp	x8, x0, [sp, #0x10]
10048f7d0: f90013e8    	str	x8, [sp, #0x20]
10048f7d4: 943426a2    	bl	0x10119925c <<objc2_foundation::generated::__NSProcessInfo::NSProcessInfo>::processInfo>
10048f7d8: aa0003f8    	mov	x24, x0
10048f7dc: 912c43e8    	add	x8, sp, #0xb10
10048f7e0: 943426e2    	bl	0x101199368 <<objc2_foundation::generated::__NSProcessInfo::NSProcessInfo>::operatingSystemVersion>
10048f7e4: f9458bf9    	ldr	x25, [sp, #0xb10]
10048f7e8: aa1803e0    	mov	x0, x24
10048f7ec: 943bc69a    	bl	0x101381254 <dyld_stub_binder+0x101381254>
10048f7f0: f100673f    	cmp	x25, #0x19
10048f7f4: 1e665000    	fmov	d0, #18.00000000
10048f7f8: 1e66d001    	fmov	d1, #22.00000000
10048f7fc: 1e60cc20    	fcsel	d0, d1, d0, gt
10048f800: 912c43e8    	add	x8, sp, #0xb10
10048f804: 94383369    	bl	0x10129c5a8 <<serde_json::value::Value as core::convert::From<f64>>::from>
10048f808: 396c43e8    	ldrb	w8, [sp, #0xb10]
10048f80c: 7103fd1f    	cmp	w8, #0xff
10048f810: 54009fe0    	b.eq	0x100490c0c <conductor_lib::run::{closure#0}+0x1c38>
10048f814: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10048f818: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
10048f81c: 3d81e7e0    	str	q0, [sp, #0x790]
10048f820: 3d81ebe1    	str	q1, [sp, #0x7a0]
10048f824: 912c43e8    	add	x8, sp, #0xb10
10048f828: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10048f82c: 9104c000    	add	x0, x0, #0x130
10048f830: 910043e1    	add	x1, sp, #0x10
10048f834: 911e43e2    	add	x2, sp, #0x790
10048f838: 9409bf25    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f83c: 396c43e8    	ldrb	w8, [sp, #0xb10]
10048f840: 7103fd1f    	cmp	w8, #0xff
10048f844: 54000060    	b.eq	0x10048f850 <conductor_lib::run::{closure#0}+0x87c>
10048f848: 912c43e0    	add	x0, sp, #0xb10
10048f84c: 97ff62a1    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f850: 3dc44fe0    	ldr	q0, [sp, #0x1130]
10048f854: 3c808340    	stur	q0, [x26, #0x8]
10048f858: f948a3e8    	ldr	x8, [sp, #0x1140]
10048f85c: f90597e8    	str	x8, [sp, #0xb28]
10048f860: 528000a8    	mov	w8, #0x5                ; =5
10048f864: 392c43e8    	strb	w8, [sp, #0xb10]
10048f868: 911e43e8    	add	x8, sp, #0x790
10048f86c: 913c43e0    	add	x0, sp, #0xf10
10048f870: 913d03e1    	add	x1, sp, #0xf40
10048f874: 912c43e2    	add	x2, sp, #0xb10
10048f878: 9409bf15    	bl	0x1006ff4cc <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value>>::insert>
10048f87c: 395e43e8    	ldrb	w8, [sp, #0x790]
10048f880: 7103fd1f    	cmp	w8, #0xff
10048f884: 54000060    	b.eq	0x10048f890 <conductor_lib::run::{closure#0}+0x8bc>
10048f888: 911e43e0    	add	x0, sp, #0x790
10048f88c: 97ff6291    	bl	0x1004682d0 <core::ptr::drop_glue::<serde_json::value::Value>>
10048f890: 911e43fb    	add	x27, sp, #0x790
10048f894: 3dc3c7e0    	ldr	q0, [sp, #0xf10]
10048f898: 3c808360    	stur	q0, [x27, #0x8]
10048f89c: f94793e8    	ldr	x8, [sp, #0xf20]
10048f8a0: f903d7e8    	str	x8, [sp, #0x7a8]
10048f8a4: 528000a8    	mov	w8, #0x5                ; =5
10048f8a8: 391e43e8    	strb	w8, [sp, #0x790]
10048f8ac: 90008401    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048f8b0: 91259c21    	add	x1, x1, #0x967
10048f8b4: f0015f43    	adrp	x3, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
10048f8b8: 912cc063    	add	x3, x3, #0xb30
10048f8bc: 912c43e8    	add	x8, sp, #0xb10
10048f8c0: 911e43e0    	add	x0, sp, #0x790
10048f8c4: 52800182    	mov	w2, #0xc                ; =12
10048f8c8: 52800c24    	mov	w4, #0x61               ; =97
10048f8cc: 940854ef    	bl	0x1006a4c88 <<serde_json::value::Value as serde_core::de::Deserializer>::deserialize_struct::<<tauri_utils::config::WindowConfig as serde_core::de::Deserialize>::deserialize::__Visitor>>
10048f8d0: f9458be8    	ldr	x8, [sp, #0xb10]
10048f8d4: f100091f    	cmp	x8, #0x2
10048f8d8: 54009b20    	b.eq	0x100490c3c <conductor_lib::run::{closure#0}+0x1c68>
10048f8dc: 910043e0    	add	x0, sp, #0x10
10048f8e0: 912c43e1    	add	x1, sp, #0xb10
10048f8e4: 52805802    	mov	w2, #0x2c0              ; =704
10048f8e8: 943bc60a    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f8ec: 911e43e8    	add	x8, sp, #0x790
10048f8f0: 910043e1    	add	x1, sp, #0x10
10048f8f4: aa1303e0    	mov	x0, x19
10048f8f8: 94021334    	bl	0x1005145c8 <<tauri::window::WindowBuilder<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::AppHandle>>::from_config>
10048f8fc: f943cbf6    	ldr	x22, [sp, #0x790]
10048f900: 3cc08360    	ldur	q0, [x27, #0x8]
10048f904: 3cc18361    	ldur	q1, [x27, #0x18]
10048f908: 3d83d3e0    	str	q0, [sp, #0xf40]
10048f90c: 3d83d7e1    	str	q1, [sp, #0xf50]
10048f910: 3cc28360    	ldur	q0, [x27, #0x28]
10048f914: 3d83dbe0    	str	q0, [sp, #0xf60]
10048f918: f1000adf    	cmp	x22, #0x2
10048f91c: 54011b60    	b.eq	0x100491c88 <conductor_lib::run::{closure#0}+0x2cb4>
10048f920: 914007f8    	add	x24, sp, #0x1, lsl #12  ; =0x1000
10048f924: 9104c318    	add	x24, x24, #0x130
10048f928: 911e43e8    	add	x8, sp, #0x790
10048f92c: 914007f7    	add	x23, sp, #0x1, lsl #12  ; =0x1000
10048f930: 9104c2f7    	add	x23, x23, #0x130
10048f934: 9100e2e0    	add	x0, x23, #0x38
10048f938: 9100e101    	add	x1, x8, #0x38
10048f93c: 52803602    	mov	w2, #0x1b0              ; =432
10048f940: 943bc5f4    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f944: 3dc3d3e0    	ldr	q0, [sp, #0xf40]
10048f948: 3dc3d7e1    	ldr	q1, [sp, #0xf50]
10048f94c: 3c808300    	stur	q0, [x24, #0x8]
10048f950: 3c818301    	stur	q1, [x24, #0x18]
10048f954: 3dc3dbe0    	ldr	q0, [sp, #0xf60]
10048f958: 3c828300    	stur	q0, [x24, #0x28]
10048f95c: f9089bf6    	str	x22, [sp, #0x1130]
10048f960: 911e43e8    	add	x8, sp, #0x790
10048f964: 910043e0    	add	x0, sp, #0x10
10048f968: 9401f69d    	bl	0x10050d3dc <<tauri::webview::WebviewBuilder<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::from_config>
10048f96c: 913d03f8    	add	x24, sp, #0xf40
10048f970: 3dc3d3e0    	ldr	q0, [sp, #0xf40]
10048f974: 3dc3d7e1    	ldr	q1, [sp, #0xf50]
10048f978: 3d81bfe0    	str	q0, [sp, #0x6f0]
10048f97c: 3d81c3e1    	str	q1, [sp, #0x700]
10048f980: 3dc3dbe0    	ldr	q0, [sp, #0xf60]
10048f984: 3d81c7e0    	str	q0, [sp, #0x710]
10048f988: 912c43f9    	add	x25, sp, #0xb10
10048f98c: 912c43e0    	add	x0, sp, #0xb10
10048f990: 9100e2e1    	add	x1, x23, #0x38
10048f994: 52803602    	mov	w2, #0x1b0              ; =432
10048f998: 943bc5de    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f99c: 9106c320    	add	x0, x25, #0x1b0
10048f9a0: 911e43e1    	add	x1, sp, #0x790
10048f9a4: 52804a02    	mov	w2, #0x250              ; =592
10048f9a8: 943bc5da    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f9ac: 910bc3f7    	add	x23, sp, #0x2f0
10048f9b0: 910bc3e0    	add	x0, sp, #0x2f0
10048f9b4: 912c43e1    	add	x1, sp, #0xb10
10048f9b8: 52808002    	mov	w2, #0x400              ; =1024
10048f9bc: 943bc5d5    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f9c0: f907a3f6    	str	x22, [sp, #0xf40]
10048f9c4: 3dc1bfe0    	ldr	q0, [sp, #0x6f0]
10048f9c8: 3dc1c3e1    	ldr	q1, [sp, #0x700]
10048f9cc: 3c808300    	stur	q0, [x24, #0x8]
10048f9d0: 3c818301    	stur	q1, [x24, #0x18]
10048f9d4: 3dc1c7e0    	ldr	q0, [sp, #0x710]
10048f9d8: 3c828300    	stur	q0, [x24, #0x28]
10048f9dc: 913d03e8    	add	x8, sp, #0xf40
10048f9e0: 9100e100    	add	x0, x8, #0x38
10048f9e4: 910bc3e1    	add	x1, sp, #0x2f0
10048f9e8: 52803602    	mov	w2, #0x1b0              ; =432
10048f9ec: 943bc5c9    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048f9f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10048f9f4: 9104c000    	add	x0, x0, #0x130
10048f9f8: 9106c2e1    	add	x1, x23, #0x1b0
10048f9fc: 52804a02    	mov	w2, #0x250              ; =592
10048fa00: 943bc5c4    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fa04: 912c43e8    	add	x8, sp, #0xb10
10048fa08: 913d03e0    	add	x0, sp, #0xf40
10048fa0c: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10048fa10: 9104c021    	add	x1, x1, #0x130
10048fa14: 94021436    	bl	0x100514aec <<tauri::window::WindowBuilder<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::AppHandle>>::with_webview>
10048fa18: f9458bf7    	ldr	x23, [sp, #0xb10]
10048fa1c: 3cc08340    	ldur	q0, [x26, #0x8]
10048fa20: 3cc18341    	ldur	q1, [x26, #0x18]
10048fa24: 3d83c7e0    	str	q0, [sp, #0xf10]
10048fa28: 3d83cbe1    	str	q1, [sp, #0xf20]
10048fa2c: 3cc28340    	ldur	q0, [x26, #0x28]
10048fa30: 3d83cfe0    	str	q0, [sp, #0xf30]
10048fa34: b10006ff    	cmn	x23, #0x1
10048fa38: 540113c0    	b.eq	0x100491cb0 <conductor_lib::run::{closure#0}+0x2cdc>
10048fa3c: 912c43f6    	add	x22, sp, #0xb10
10048fa40: 911e43f8    	add	x24, sp, #0x790
10048fa44: 911e43e0    	add	x0, sp, #0x790
10048fa48: 9100e2c1    	add	x1, x22, #0x38
10048fa4c: 52806902    	mov	w2, #0x348              ; =840
10048fa50: 943bc5b0    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fa54: 3dc3c7e0    	ldr	q0, [sp, #0xf10]
10048fa58: 3dc3cbe1    	ldr	q1, [sp, #0xf20]
10048fa5c: 3d844fe0    	str	q0, [sp, #0x1130]
10048fa60: 3d8453e1    	str	q1, [sp, #0x1140]
10048fa64: 3dc3cfe0    	ldr	q0, [sp, #0xf30]
10048fa68: 3d8457e0    	str	q0, [sp, #0x1150]
10048fa6c: 9100e2c0    	add	x0, x22, #0x38
10048fa70: 911e43e1    	add	x1, sp, #0x790
10048fa74: 52803c02    	mov	w2, #0x1e0              ; =480
10048fa78: 943bc5a6    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fa7c: 910862c0    	add	x0, x22, #0x218
10048fa80: 91078301    	add	x1, x24, #0x1e0
10048fa84: 52802d02    	mov	w2, #0x168              ; =360
10048fa88: 943bc5a2    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fa8c: f9058bf7    	str	x23, [sp, #0xb10]
10048fa90: 3dc44fe0    	ldr	q0, [sp, #0x1130]
10048fa94: 3dc453e1    	ldr	q1, [sp, #0x1140]
10048fa98: 3c808340    	stur	q0, [x26, #0x8]
10048fa9c: 3c818341    	stur	q1, [x26, #0x18]
10048faa0: 3dc457e0    	ldr	q0, [sp, #0x1150]
10048faa4: 3c828340    	stur	q0, [x26, #0x28]
10048faa8: 912c43e0    	add	x0, sp, #0xb10
10048faac: 97ff715e    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
10048fab0: 910862c0    	add	x0, x22, #0x218
10048fab4: 97ff7230    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
10048fab8: 910043e0    	add	x0, sp, #0x10
10048fabc: 97ff67a4    	bl	0x10046994c <core::ptr::drop_glue::<tauri_utils::config::WindowConfig>>
10048fac0: b40000b5    	cbz	x21, 0x10048fad4 <conductor_lib::run::{closure#0}+0xb00>
10048fac4: aa1403e0    	mov	x0, x20
10048fac8: aa1503e1    	mov	x1, x21
10048facc: 52800022    	mov	w2, #0x1                ; =1
10048fad0: 97edc6e1    	bl	0x100001654 <__rustc::__rust_dealloc>
10048fad4: f940a668    	ldr	x8, [x19, #0x148]
10048fad8: f9496508    	ldr	x8, [x8, #0x12c8]
10048fadc: 91004100    	add	x0, x8, #0x10
10048fae0: 97fef926    	bl	0x10044df78 <<tauri::state::StateManager>::try_get::<tauri::path::desktop::PathResolver<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>
10048fae4: b4008c40    	cbz	x0, 0x100490c6c <conductor_lib::run::{closure#0}+0x1c98>
10048fae8: aa0003f4    	mov	x20, x0
10048faec: 90008400    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048faf0: 91374800    	add	x0, x0, #0xdd2
10048faf4: 912c43f5    	add	x21, sp, #0xb10
10048faf8: 912c43e8    	add	x8, sp, #0xb10
10048fafc: 52800021    	mov	w1, #0x1                ; =1
10048fb00: 943955ce    	bl	0x1012e5238 <<std::path::Path>::to_path_buf>
10048fb04: 911e43e8    	add	x8, sp, #0x790
10048fb08: 912c43e2    	add	x2, sp, #0xb10
10048fb0c: aa1403e0    	mov	x0, x20
10048fb10: 528001c1    	mov	w1, #0xe                ; =14
10048fb14: 9403038d    	bl	0x100550948 <tauri::path::resolve_path::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>
10048fb18: f943cbe8    	ldr	x8, [sp, #0x790]
10048fb1c: b100051f    	cmn	x8, #0x1
10048fb20: 54000360    	b.eq	0x10048fb8c <conductor_lib::run::{closure#0}+0xbb8>
10048fb24: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10048fb28: 3dc1ebe1    	ldr	q1, [sp, #0x7a0]
10048fb2c: 3d82c7e0    	str	q0, [sp, #0xb10]
10048fb30: 3d82cbe1    	str	q1, [sp, #0xb20]
10048fb34: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10048fb38: 3d82cfe0    	str	q0, [sp, #0xb30]
10048fb3c: 900061c8    	adrp	x8, 0x1010c7000 <<plist::stream::binary_reader::BinaryReader<std::io::buffered::bufreader::BufReader<std::fs::File>> as core::iter::traits::iterator::Iterator>::next+0x44>
10048fb40: 913e2108    	add	x8, x8, #0xf88
10048fb44: f907a3f5    	str	x21, [sp, #0xf40]
10048fb48: f907a7e8    	str	x8, [sp, #0xf48]
10048fb4c: f0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
10048fb50: 91213400    	add	x0, x0, #0x84d
10048fb54: 910043e8    	add	x8, sp, #0x10
10048fb58: 913d03e1    	add	x1, sp, #0xf40
10048fb5c: 943a07c6    	bl	0x101311a74 <alloc::fmt::format::format_inner>
10048fb60: 912c43e0    	add	x0, sp, #0xb10
10048fb64: 97ff7088    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10048fb68: 3dc007e0    	ldr	q0, [sp, #0x10]
10048fb6c: 3d844fe0    	str	q0, [sp, #0x1130]
10048fb70: f94013e8    	ldr	x8, [sp, #0x20]
10048fb74: 3d81cbe0    	str	q0, [sp, #0x720]
10048fb78: f9039be8    	str	x8, [sp, #0x730]
10048fb7c: 911c83e0    	add	x0, sp, #0x720
10048fb80: 943a09e3    	bl	0x10131230c <<alloc::boxed::Box<dyn core::error::Error> as core::convert::From<alloc::string::String>>::from>
10048fb84: aa0003f3    	mov	x19, x0
10048fb88: 1400027b    	b	0x100490574 <conductor_lib::run::{closure#0}+0x15a0>
10048fb8c: f943d7f6    	ldr	x22, [sp, #0x7a8]
10048fb90: 3cc08360    	ldur	q0, [x27, #0x8]
10048fb94: 3d81cbe0    	str	q0, [sp, #0x720]
10048fb98: f9039bf6    	str	x22, [sp, #0x730]
10048fb9c: f94393f4    	ldr	x20, [sp, #0x720]
10048fba0: f94397f5    	ldr	x21, [sp, #0x728]
10048fba4: f940a668    	ldr	x8, [x19, #0x148]
10048fba8: f9496508    	ldr	x8, [x8, #0x12c8]
10048fbac: 91004100    	add	x0, x8, #0x10
10048fbb0: 97fef8f2    	bl	0x10044df78 <<tauri::state::StateManager>::try_get::<tauri::path::desktop::PathResolver<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>
10048fbb4: aa0003f7    	mov	x23, x0
10048fbb8: b400a9e0    	cbz	x0, 0x1004910f4 <conductor_lib::run::{closure#0}+0x2120>
10048fbbc: 90008400    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048fbc0: 91374c00    	add	x0, x0, #0xdd3
10048fbc4: 912c43e8    	add	x8, sp, #0xb10
10048fbc8: 52800061    	mov	w1, #0x3                ; =3
10048fbcc: 9439559b    	bl	0x1012e5238 <<std::path::Path>::to_path_buf>
10048fbd0: 911e43e8    	add	x8, sp, #0x790
10048fbd4: 912c43e2    	add	x2, sp, #0xb10
10048fbd8: aa1703e0    	mov	x0, x23
10048fbdc: 52800161    	mov	w1, #0xb                ; =11
10048fbe0: 9403035a    	bl	0x100550948 <tauri::path::resolve_path::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>
10048fbe4: f943cbe8    	ldr	x8, [sp, #0x790]
10048fbe8: b100051f    	cmn	x8, #0x1
10048fbec: 5400aa61    	b.ne	0x100491138 <conductor_lib::run::{closure#0}+0x2164>
10048fbf0: 3cc08360    	ldur	q0, [x27, #0x8]
10048fbf4: 3d81d3e0    	str	q0, [sp, #0x740]
10048fbf8: f943d7e8    	ldr	x8, [sp, #0x7a8]
10048fbfc: f903abe8    	str	x8, [sp, #0x750]
10048fc00: 90008402    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048fc04: 91374c42    	add	x2, x2, #0xdd3
10048fc08: 913c43e8    	add	x8, sp, #0xf10
10048fc0c: aa1503e0    	mov	x0, x21
10048fc10: aa1603e1    	mov	x1, x22
10048fc14: 52800063    	mov	w3, #0x3                ; =3
10048fc18: 94395749    	bl	0x1012e593c <<std::path::Path>::_join>
10048fc1c: 90008402    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048fc20: 9137e442    	add	x2, x2, #0xdf9
10048fc24: 913d03e8    	add	x8, sp, #0xf40
10048fc28: aa1503e0    	mov	x0, x21
10048fc2c: aa1603e1    	mov	x1, x22
10048fc30: 52800303    	mov	w3, #0x18               ; =24
10048fc34: 94395742    	bl	0x1012e593c <<std::path::Path>::_join>
10048fc38: f943a7e0    	ldr	x0, [sp, #0x748]
10048fc3c: f943abe1    	ldr	x1, [sp, #0x750]
10048fc40: 912c43e8    	add	x8, sp, #0xb10
10048fc44: 9439a630    	bl	0x1012f9504 <std::sys::fs::metadata>
10048fc48: b94b13e8    	ldr	w8, [sp, #0xb10]
10048fc4c: 370114e8    	tbnz	w8, #0x0, 0x100491ee8 <conductor_lib::run::{closure#0}+0x2f14>
10048fc50: 911e43e0    	add	x0, sp, #0x790
10048fc54: aa1303e1    	mov	x1, x19
10048fc58: 9400c8ce    	bl	0x1004c1f90 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone>
10048fc5c: f9404668    	ldr	x8, [x19, #0x88]
10048fc60: 52800029    	mov	w9, #0x1                ; =1
10048fc64: f8290109    	ldadd	x9, x9, [x8]
10048fc68: b7f91d09    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048fc6c: f9404a69    	ldr	x9, [x19, #0x90]
10048fc70: 5280002a    	mov	w10, #0x1               ; =1
10048fc74: f82a012a    	ldadd	x10, x10, [x9]
10048fc78: b7f91c8a    	tbnz	x10, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048fc7c: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10048fc80: 3dc203e1    	ldr	q1, [sp, #0x800]
10048fc84: 3d82dfe0    	str	q0, [sp, #0xb70]
10048fc88: 3d82e3e1    	str	q1, [sp, #0xb80]
10048fc8c: f9440bea    	ldr	x10, [sp, #0x810]
10048fc90: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10048fc94: 3dc1f3e1    	ldr	q1, [sp, #0x7c0]
10048fc98: 3d82cfe0    	str	q0, [sp, #0xb30]
10048fc9c: 3d82d3e1    	str	q1, [sp, #0xb40]
10048fca0: 3dc1fbe0    	ldr	q0, [sp, #0x7e0]
10048fca4: 3dc1f7e1    	ldr	q1, [sp, #0x7d0]
10048fca8: 3d82dbe0    	str	q0, [sp, #0xb60]
10048fcac: 3d82d7e1    	str	q1, [sp, #0xb50]
10048fcb0: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
10048fcb4: 3dc1e7e1    	ldr	q1, [sp, #0x790]
10048fcb8: 3d82cbe0    	str	q0, [sp, #0xb20]
10048fcbc: 3d82c7e1    	str	q1, [sp, #0xb10]
10048fcc0: f905cbea    	str	x10, [sp, #0xb90]
10048fcc4: f905cfe8    	str	x8, [sp, #0xb98]
10048fcc8: f905d3e9    	str	x9, [sp, #0xba0]
10048fccc: f943a3f8    	ldr	x24, [sp, #0x740]
10048fcd0: f943a7fa    	ldr	x26, [sp, #0x748]
10048fcd4: f94793f7    	ldr	x23, [sp, #0xf20]
10048fcd8: b6f800d7    	tbz	x23, #0x3f, 0x10048fcf0 <conductor_lib::run::{closure#0}+0xd1c>
10048fcdc: d280001c    	mov	x28, #0x0               ; =0
10048fce0: aa1c03e0    	mov	x0, x28
10048fce4: aa1703e1    	mov	x1, x23
10048fce8: 943bc072    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
10048fcec: 140008c7    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048fcf0: f9478ff9    	ldr	x25, [sp, #0xf18]
10048fcf4: b4000197    	cbz	x23, 0x10048fd24 <conductor_lib::run::{closure#0}+0xd50>
10048fcf8: 97edc65a    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048fcfc: 5280003c    	mov	w28, #0x1               ; =1
10048fd00: aa1703e0    	mov	x0, x23
10048fd04: 52800021    	mov	w1, #0x1                ; =1
10048fd08: 97edc652    	bl	0x100001650 <__rustc::__rust_alloc>
10048fd0c: b4fffea0    	cbz	x0, 0x10048fce0 <conductor_lib::run::{closure#0}+0xd0c>
10048fd10: aa0003fb    	mov	x27, x0
10048fd14: aa1903e1    	mov	x1, x25
10048fd18: aa1703e2    	mov	x2, x23
10048fd1c: 943bc4fd    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fd20: 14000002    	b	0x10048fd28 <conductor_lib::run::{closure#0}+0xd54>
10048fd24: 5280003b    	mov	w27, #0x1               ; =1
10048fd28: f903cbf7    	str	x23, [sp, #0x790]
10048fd2c: f903cffb    	str	x27, [sp, #0x798]
10048fd30: f903d3f7    	str	x23, [sp, #0x7a0]
10048fd34: 912c43e0    	add	x0, sp, #0xb10
10048fd38: 911d03e1    	add	x1, sp, #0x740
10048fd3c: 911e43e2    	add	x2, sp, #0x790
10048fd40: 913d03e3    	add	x3, sp, #0xf40
10048fd44: 94095c52    	bl	0x1006e6e8c <conductor_lib::start_binary_preparation>
10048fd48: d0008418    	adrp	x24, 0x101511000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.1315+0x86e>
10048fd4c: 91326318    	add	x24, x24, #0xc98
10048fd50: 912c43e8    	add	x8, sp, #0xb10
10048fd54: aa1803e0    	mov	x0, x24
10048fd58: 52800081    	mov	w1, #0x4                ; =4
10048fd5c: 9439c14c    	bl	0x10130028c <std::env::var::inner>
10048fd60: b94b13e8    	ldr	w8, [sp, #0xb10]
10048fd64: 360001a8    	tbz	w8, #0x0, 0x10048fd98 <conductor_lib::run::{closure#0}+0xdc4>
10048fd68: 52800028    	mov	w8, #0x1                ; =1
10048fd6c: f9089bff    	str	xzr, [sp, #0x1130]
10048fd70: f9089fe8    	str	x8, [sp, #0x1138]
10048fd74: f908a3ff    	str	xzr, [sp, #0x1140]
10048fd78: f9458fe1    	ldr	x1, [sp, #0xb18]
10048fd7c: b100043f    	cmn	x1, #0x1
10048fd80: 54000160    	b.eq	0x10048fdac <conductor_lib::run::{closure#0}+0xdd8>
10048fd84: b4000141    	cbz	x1, 0x10048fdac <conductor_lib::run::{closure#0}+0xdd8>
10048fd88: f94593e0    	ldr	x0, [sp, #0xb20]
10048fd8c: 52800022    	mov	w2, #0x1                ; =1
10048fd90: 97edc631    	bl	0x100001654 <__rustc::__rust_dealloc>
10048fd94: 14000006    	b	0x10048fdac <conductor_lib::run::{closure#0}+0xdd8>
10048fd98: 912c43e8    	add	x8, sp, #0xb10
10048fd9c: 3cc08100    	ldur	q0, [x8, #0x8]
10048fda0: 3d844fe0    	str	q0, [sp, #0x1130]
10048fda4: f94597e8    	ldr	x8, [sp, #0xb28]
10048fda8: f908a3e8    	str	x8, [sp, #0x1140]
10048fdac: 911e43fa    	add	x26, sp, #0x790
10048fdb0: 911e43e8    	add	x8, sp, #0x790
10048fdb4: aa1903e0    	mov	x0, x25
10048fdb8: aa1703e1    	mov	x1, x23
10048fdbc: 943a0101    	bl	0x1013101c0 <<alloc::string::String>::from_utf8_lossy>
10048fdc0: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10048fdc4: 9104c108    	add	x8, x8, #0x130
10048fdc8: f0000189    	adrp	x9, 0x1004c2000 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone+0x70>
10048fdcc: 91269129    	add	x9, x9, #0x9a4
10048fdd0: f9058be8    	str	x8, [sp, #0xb10]
10048fdd4: f9058fe9    	str	x9, [sp, #0xb18]
10048fdd8: d0001428    	adrp	x8, 0x100715000 <<core::str::pattern::CharSearcher as core::str::pattern::Searcher>::next_match+0x6c>
10048fddc: 9105e108    	add	x8, x8, #0x178
10048fde0: f90593fa    	str	x26, [sp, #0xb20]
10048fde4: f90597e8    	str	x8, [sp, #0xb28]
10048fde8: f0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
10048fdec: 91224000    	add	x0, x0, #0x890
10048fdf0: 910043e8    	add	x8, sp, #0x10
10048fdf4: 912c43e1    	add	x1, sp, #0xb10
10048fdf8: 943a071f    	bl	0x101311a74 <alloc::fmt::format::format_inner>
10048fdfc: f943cbe1    	ldr	x1, [sp, #0x790]
10048fe00: b100043f    	cmn	x1, #0x1
10048fe04: 540000a0    	b.eq	0x10048fe18 <conductor_lib::run::{closure#0}+0xe44>
10048fe08: b4000081    	cbz	x1, 0x10048fe18 <conductor_lib::run::{closure#0}+0xe44>
10048fe0c: f943cfe0    	ldr	x0, [sp, #0x798]
10048fe10: 52800022    	mov	w2, #0x1                ; =1
10048fe14: 97edc610    	bl	0x100001654 <__rustc::__rust_dealloc>
10048fe18: a94167f7    	ldp	x23, x25, [sp, #0x10]
10048fe1c: f94013e3    	ldr	x3, [sp, #0x20]
10048fe20: 52800088    	mov	w8, #0x4                ; =4
10048fe24: f903cbf8    	str	x24, [sp, #0x790]
10048fe28: f903cfe8    	str	x8, [sp, #0x798]
10048fe2c: f9058bf9    	str	x25, [sp, #0xb10]
10048fe30: f9058fe3    	str	x3, [sp, #0xb18]
10048fe34: aa1803e0    	mov	x0, x24
10048fe38: 52800081    	mov	w1, #0x4                ; =4
10048fe3c: aa1903e2    	mov	x2, x25
10048fe40: 9439b473    	bl	0x1012fd00c <std::sys::env::unix::setenv>
10048fe44: aa0003e2    	mov	x2, x0
10048fe48: b5010da0    	cbnz	x0, 0x100491ffc <conductor_lib::run::{closure#0}+0x3028>
10048fe4c: 90008400    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048fe50: 91384400    	add	x0, x0, #0xe11
10048fe54: 528008e1    	mov	w1, #0x47               ; =71
10048fe58: 9439a1a7    	bl	0x1012f84f4 <std::io::stdio::_print>
10048fe5c: b40000b7    	cbz	x23, 0x10048fe70 <conductor_lib::run::{closure#0}+0xe9c>
10048fe60: aa1903e0    	mov	x0, x25
10048fe64: aa1703e1    	mov	x1, x23
10048fe68: 52800022    	mov	w2, #0x1                ; =1
10048fe6c: 97edc5fa    	bl	0x100001654 <__rustc::__rust_dealloc>
10048fe70: f9489be1    	ldr	x1, [sp, #0x1130]
10048fe74: b4000081    	cbz	x1, 0x10048fe84 <conductor_lib::run::{closure#0}+0xeb0>
10048fe78: f9489fe0    	ldr	x0, [sp, #0x1138]
10048fe7c: 52800022    	mov	w2, #0x1                ; =1
10048fe80: 97edc5f5    	bl	0x100001654 <__rustc::__rust_dealloc>
10048fe84: 90008402    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10048fe88: 9138d042    	add	x2, x2, #0xe34
10048fe8c: 910043e8    	add	x8, sp, #0x10
10048fe90: aa1503e0    	mov	x0, x21
10048fe94: aa1603e1    	mov	x1, x22
10048fe98: 528001c3    	mov	w3, #0xe                ; =14
10048fe9c: 943956a8    	bl	0x1012e593c <<std::path::Path>::_join>
10048fea0: 911e43e8    	add	x8, sp, #0x790
10048fea4: 910043e0    	add	x0, sp, #0x10
10048fea8: 94098791    	bl	0x1006f1cec <<conductor_lib::binary_manager::BinaryManager>::new>
10048feac: 52800028    	mov	w8, #0x1                ; =1
10048feb0: 4e080d00    	dup.2d	v0, x8
10048feb4: 3d82c7e0    	str	q0, [sp, #0xb10]
10048feb8: 912c43e8    	add	x8, sp, #0xb10
10048febc: 91004100    	add	x0, x8, #0x10
10048fec0: 911e43e1    	add	x1, sp, #0x790
10048fec4: 52805902    	mov	w2, #0x2c8              ; =712
10048fec8: 943bc492    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fecc: 97edc5e5    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10048fed0: 52805b00    	mov	w0, #0x2d8              ; =728
10048fed4: 52800101    	mov	w1, #0x8                ; =8
10048fed8: 97edc5de    	bl	0x100001650 <__rustc::__rust_alloc>
10048fedc: b40099c0    	cbz	x0, 0x100491214 <conductor_lib::run::{closure#0}+0x2240>
10048fee0: aa0003f6    	mov	x22, x0
10048fee4: 912c43e1    	add	x1, sp, #0xb10
10048fee8: 52805b02    	mov	w2, #0x2d8              ; =728
10048feec: 943bc489    	bl	0x101381110 <dyld_stub_binder+0x101381110>
10048fef0: f903c7f6    	str	x22, [sp, #0x788]
10048fef4: 52800028    	mov	w8, #0x1                ; =1
10048fef8: f82802c8    	ldadd	x8, x8, [x22]
10048fefc: b7f90868    	tbnz	x8, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048ff00: f940a668    	ldr	x8, [x19, #0x148]
10048ff04: f9496509    	ldr	x9, [x8, #0x12c8]
10048ff08: 5280002a    	mov	w10, #0x1               ; =1
10048ff0c: f82a0129    	ldadd	x10, x9, [x9]
10048ff10: b7f907c9    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10048ff14: f949651c    	ldr	x28, [x8, #0x12c8]
10048ff18: f9089bfc    	str	x28, [sp, #0x1130]
10048ff1c: 91004397    	add	x23, x28, #0x10
10048ff20: f903cbf6    	str	x22, [sp, #0x790]
10048ff24: d9410380    	ldapur	x0, [x28, #0x10]
10048ff28: b40097e0    	cbz	x0, 0x100491224 <conductor_lib::run::{closure#0}+0x2250>
10048ff2c: 94394fb1    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
10048ff30: f001673b    	adrp	x27, 0x103176000 <crossbeam_utils::atomic::atomic_cell::lock::LOCKS+0x1b00>
10048ff34: 9125e37b    	add	x27, x27, #0x978
10048ff38: f9400368    	ldr	x8, [x27]
10048ff3c: f240f91f    	tst	x8, #0x7fffffffffffffff
10048ff40: 54009781    	b.ne	0x100491230 <conductor_lib::run::{closure#0}+0x225c>
10048ff44: 52800018    	mov	w24, #0x0               ; =0
10048ff48: 39406388    	ldrb	w8, [x28, #0x18]
10048ff4c: 350097a8    	cbnz	w8, 0x100491240 <conductor_lib::run::{closure#0}+0x226c>
10048ff50: f9401f88    	ldr	x8, [x28, #0x38]
10048ff54: b4000588    	cbz	x8, 0x100490004 <conductor_lib::run::{closure#0}+0x1030>
10048ff58: d2800008    	mov	x8, #0x0                ; =0
10048ff5c: a942278a    	ldp	x10, x9, [x28, #0x20]
10048ff60: d299e3eb    	mov	x11, #0xcf1f            ; =53023
10048ff64: f2a7e42b    	movk	x11, #0x3f21, lsl #16
10048ff68: f2c51f4b    	movk	x11, #0x28fa, lsl #32
10048ff6c: f2f5a42b    	movk	x11, #0xad21, lsl #48
10048ff70: 0f02e6c0    	movi.8b	v0, #0x56
10048ff74: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10048ff78: d2849acc    	mov	x12, #0x24d6            ; =9430
10048ff7c: f2a8ae6c    	movk	x12, #0x4573, lsl #16
10048ff80: f2ce1fcc    	movk	x12, #0x70fe, lsl #32
10048ff84: f2f614ec    	movk	x12, #0xb0a7, lsl #48
10048ff88: 8a09016d    	and	x13, x11, x9
10048ff8c: fc6d6942    	ldr	d2, [x10, x13]
10048ff90: 2e208c43    	cmeq.8b	v3, v2, v0
10048ff94: 9e66006e    	fmov	x14, d3
10048ff98: f201c1ce    	ands	x14, x14, #0x8080808080808080
10048ff9c: 540001a0    	b.eq	0x10048ffd0 <conductor_lib::run::{closure#0}+0xffc>
10048ffa0: dac001cf    	rbit	x15, x14
10048ffa4: dac011ef    	clz	x15, x15
10048ffa8: 8b4f0daf    	add	x15, x13, x15, lsr #3
10048ffac: 8a0901ef    	and	x15, x15, x9
10048ffb0: cb0f154f    	sub	x15, x10, x15, lsl #5
10048ffb4: a97e3df0    	ldp	x16, x15, [x15, #-0x20]
10048ffb8: eb0b01ff    	cmp	x15, x11
10048ffbc: fa4c0200    	ccmp	x16, x12, #0x0, eq
10048ffc0: 540006a0    	b.eq	0x100490094 <conductor_lib::run::{closure#0}+0x10c0>
10048ffc4: d10005cf    	sub	x15, x14, #0x1
10048ffc8: ea0e01ee    	ands	x14, x15, x14
10048ffcc: 54fffea1    	b.ne	0x10048ffa0 <conductor_lib::run::{closure#0}+0xfcc>
10048ffd0: 2e218c42    	cmeq.8b	v2, v2, v1
10048ffd4: 2e30a842    	umaxv.8b	b2, v2
10048ffd8: 1e26004e    	fmov	w14, s2
10048ffdc: 3700014e    	tbnz	w14, #0x0, 0x100490004 <conductor_lib::run::{closure#0}+0x1030>
10048ffe0: 91002108    	add	x8, x8, #0x8
10048ffe4: 8b0801ad    	add	x13, x13, x8
10048ffe8: 8a0901ad    	and	x13, x13, x9
10048ffec: fc6d6942    	ldr	d2, [x10, x13]
10048fff0: 2e208c43    	cmeq.8b	v3, v2, v0
10048fff4: 9e66006e    	fmov	x14, d3
10048fff8: f201c1ce    	ands	x14, x14, #0x8080808080808080
10048fffc: 54fffd21    	b.ne	0x10048ffa0 <conductor_lib::run::{closure#0}+0xfcc>
100490000: 17fffff4    	b	0x10048ffd0 <conductor_lib::run::{closure#0}+0xffc>
100490004: f9058bf6    	str	x22, [sp, #0xb10]
100490008: 97edc596    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
10049000c: 52800100    	mov	w0, #0x8                ; =8
100490010: 52800101    	mov	w1, #0x8                ; =8
100490014: 97edc58f    	bl	0x100001650 <__rustc::__rust_alloc>
100490018: b40092c0    	cbz	x0, 0x100491270 <conductor_lib::run::{closure#0}+0x229c>
10049001c: aa0003e2    	mov	x2, x0
100490020: f9000016    	str	x22, [x0]
100490024: f00083c8    	adrp	x8, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100490028: 913d0108    	add	x8, x8, #0xf40
10049002c: 3dc00100    	ldr	q0, [x8]
100490030: 3d82c7e0    	str	q0, [sp, #0xb10]
100490034: 90015f43    	adrp	x3, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
100490038: 91290063    	add	x3, x3, #0xa40
10049003c: 91008380    	add	x0, x28, #0x20
100490040: 912c43e1    	add	x1, sp, #0xb10
100490044: 940a8e01    	bl	0x100733848 <<hashbrown::map::HashMap<core::any::TypeId, core::pin::Pin<alloc::boxed::Box<dyn core::any::Any + core::marker::Sync + core::marker::Send>>, core::hash::BuildHasherDefault<tauri::state::IdentHash>>>::insert>
100490048: aa0003f9    	mov	x25, x0
10049004c: b4000160    	cbz	x0, 0x100490078 <conductor_lib::run::{closure#0}+0x10a4>
100490050: aa0103fa    	mov	x26, x1
100490054: f9400028    	ldr	x8, [x1]
100490058: b4000068    	cbz	x8, 0x100490064 <conductor_lib::run::{closure#0}+0x1090>
10049005c: aa1903e0    	mov	x0, x25
100490060: d63f0100    	blr	x8
100490064: f9400741    	ldr	x1, [x26, #0x8]
100490068: b4000081    	cbz	x1, 0x100490078 <conductor_lib::run::{closure#0}+0x10a4>
10049006c: f9400b42    	ldr	x2, [x26, #0x10]
100490070: aa1903e0    	mov	x0, x25
100490074: 97edc578    	bl	0x100001654 <__rustc::__rust_dealloc>
100490078: 37000098    	tbnz	w24, #0x0, 0x100490088 <conductor_lib::run::{closure#0}+0x10b4>
10049007c: f9400368    	ldr	x8, [x27]
100490080: f240f91f    	tst	x8, #0x7fffffffffffffff
100490084: 5400ab41    	b.ne	0x1004915ec <conductor_lib::run::{closure#0}+0x2618>
100490088: f94002e0    	ldr	x0, [x23]
10049008c: 94394f60    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100490090: 1400000e    	b	0x1004900c8 <conductor_lib::run::{closure#0}+0x10f4>
100490094: 37000098    	tbnz	w24, #0x0, 0x1004900a4 <conductor_lib::run::{closure#0}+0x10d0>
100490098: f9400368    	ldr	x8, [x27]
10049009c: f240f91f    	tst	x8, #0x7fffffffffffffff
1004900a0: 5400b9e1    	b.ne	0x1004917dc <conductor_lib::run::{closure#0}+0x2808>
1004900a4: f94002e0    	ldr	x0, [x23]
1004900a8: 94394f59    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1004900ac: 92800008    	mov	x8, #-0x1               ; =-1
1004900b0: f86802c8    	ldaddl	x8, x8, [x22]
1004900b4: f100051f    	cmp	x8, #0x1
1004900b8: 54000081    	b.ne	0x1004900c8 <conductor_lib::run::{closure#0}+0x10f4>
1004900bc: d50339bf    	dmb	ishld
1004900c0: 911e43e0    	add	x0, sp, #0x790
1004900c4: 9409cfbe    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
1004900c8: f9489be8    	ldr	x8, [sp, #0x1130]
1004900cc: 92800009    	mov	x9, #-0x1               ; =-1
1004900d0: f8690108    	ldaddl	x9, x8, [x8]
1004900d4: f100051f    	cmp	x8, #0x1
1004900d8: 540000a1    	b.ne	0x1004900ec <conductor_lib::run::{closure#0}+0x1118>
1004900dc: d50339bf    	dmb	ishld
1004900e0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1004900e4: 9104c000    	add	x0, x0, #0x130
1004900e8: 94308c0d    	bl	0x1010b311c <<alloc::sync::Arc<tauri::state::StateManager>>::drop_slow>
1004900ec: f9478fe1    	ldr	x1, [sp, #0xf18]
1004900f0: f94793e2    	ldr	x2, [sp, #0xf20]
1004900f4: 911e43e8    	add	x8, sp, #0x790
1004900f8: 910042c0    	add	x0, x22, #0x10
1004900fc: 940984d3    	bl	0x1006f1448 <<conductor_lib::binary_manager::BinaryManager>::stage_path_symlinks>
100490100: f943cbe8    	ldr	x8, [sp, #0x790]
100490104: b100051f    	cmn	x8, #0x1
100490108: 54000280    	b.eq	0x100490158 <conductor_lib::run::{closure#0}+0x1184>
10049010c: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100490110: 3d82c7e0    	str	q0, [sp, #0xb10]
100490114: f943d3e8    	ldr	x8, [sp, #0x7a0]
100490118: f90593e8    	str	x8, [sp, #0xb20]
10049011c: 912c43e8    	add	x8, sp, #0xb10
100490120: f9089be8    	str	x8, [sp, #0x1130]
100490124: d0000188    	adrp	x8, 0x1004c2000 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone+0x70>
100490128: 91269108    	add	x8, x8, #0x9a4
10049012c: f9089fe8    	str	x8, [sp, #0x1138]
100490130: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100490134: 91225400    	add	x0, x0, #0x895
100490138: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10049013c: 9104c021    	add	x1, x1, #0x130
100490140: 9439a131    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490144: f9458be1    	ldr	x1, [sp, #0xb10]
100490148: b4000081    	cbz	x1, 0x100490158 <conductor_lib::run::{closure#0}+0x1184>
10049014c: f9458fe0    	ldr	x0, [sp, #0xb18]
100490150: 52800022    	mov	w2, #0x1                ; =1
100490154: 97edc540    	bl	0x100001654 <__rustc::__rust_dealloc>
100490158: 52800028    	mov	w8, #0x1                ; =1
10049015c: f82802c8    	ldadd	x8, x8, [x22]
100490160: b7f8f548    	tbnz	x8, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490164: aa1603e0    	mov	x0, x22
100490168: 9409860c    	bl	0x1006f1998 <<conductor_lib::binary_manager::BinaryManager>::spawn_garbage_collection>
10049016c: 52800028    	mov	w8, #0x1                ; =1
100490170: f82802c8    	ldadd	x8, x8, [x22]
100490174: b7f8f4a8    	tbnz	x8, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490178: f9089bf6    	str	x22, [sp, #0x1130]
10049017c: 911e43e0    	add	x0, sp, #0x790
100490180: aa1303e1    	mov	x1, x19
100490184: 9400c783    	bl	0x1004c1f90 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone>
100490188: f9404668    	ldr	x8, [x19, #0x88]
10049018c: 52800029    	mov	w9, #0x1                ; =1
100490190: f8290109    	ldadd	x9, x9, [x8]
100490194: b7f8f3a9    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490198: f9404a69    	ldr	x9, [x19, #0x90]
10049019c: 5280002a    	mov	w10, #0x1               ; =1
1004901a0: f82a012a    	ldadd	x10, x10, [x9]
1004901a4: b7f8f32a    	tbnz	x10, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004901a8: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
1004901ac: 3dc203e1    	ldr	q1, [sp, #0x800]
1004901b0: 3d82dfe0    	str	q0, [sp, #0xb70]
1004901b4: 3d82e3e1    	str	q1, [sp, #0xb80]
1004901b8: f9440bea    	ldr	x10, [sp, #0x810]
1004901bc: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
1004901c0: 3dc1f3e1    	ldr	q1, [sp, #0x7c0]
1004901c4: 3d82cfe0    	str	q0, [sp, #0xb30]
1004901c8: 3d82d3e1    	str	q1, [sp, #0xb40]
1004901cc: 3dc1fbe0    	ldr	q0, [sp, #0x7e0]
1004901d0: 3dc1f7e1    	ldr	q1, [sp, #0x7d0]
1004901d4: 3d82dbe0    	str	q0, [sp, #0xb60]
1004901d8: 3d82d7e1    	str	q1, [sp, #0xb50]
1004901dc: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
1004901e0: 3dc1e7e1    	ldr	q1, [sp, #0x790]
1004901e4: 3d82cbe0    	str	q0, [sp, #0xb20]
1004901e8: 3d82c7e1    	str	q1, [sp, #0xb10]
1004901ec: f905cbea    	str	x10, [sp, #0xb90]
1004901f0: f905cfe8    	str	x8, [sp, #0xb98]
1004901f4: f905d3e9    	str	x9, [sp, #0xba0]
1004901f8: 912c43e1    	add	x1, sp, #0xb10
1004901fc: aa1603e0    	mov	x0, x22
100490200: 94098622    	bl	0x1006f1a88 <<conductor_lib::binary_manager::BinaryManager>::spawn_background_downloads>
100490204: 92800008    	mov	x8, #-0x1               ; =-1
100490208: f86802c8    	ldaddl	x8, x8, [x22]
10049020c: f100051f    	cmp	x8, #0x1
100490210: 54000081    	b.ne	0x100490220 <conductor_lib::run::{closure#0}+0x124c>
100490214: d50339bf    	dmb	ishld
100490218: 911e23e0    	add	x0, sp, #0x788
10049021c: 9409cf68    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
100490220: f9478be1    	ldr	x1, [sp, #0xf10]
100490224: b4000081    	cbz	x1, 0x100490234 <conductor_lib::run::{closure#0}+0x1260>
100490228: f9478fe0    	ldr	x0, [sp, #0xf18]
10049022c: 52800022    	mov	w2, #0x1                ; =1
100490230: 97edc509    	bl	0x100001654 <__rustc::__rust_dealloc>
100490234: b40000b4    	cbz	x20, 0x100490248 <conductor_lib::run::{closure#0}+0x1274>
100490238: aa1503e0    	mov	x0, x21
10049023c: aa1403e1    	mov	x1, x20
100490240: 52800022    	mov	w2, #0x1                ; =1
100490244: 97edc504    	bl	0x100001654 <__rustc::__rust_dealloc>
100490248: 911e43e8    	add	x8, sp, #0x790
10049024c: aa1303e0    	mov	x0, x19
100490250: 9401fbf1    	bl	0x10050f214 <<tauri::menu::Menu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::default>
100490254: f943cbe9    	ldr	x9, [sp, #0x790]
100490258: f943cfe8    	ldr	x8, [sp, #0x798]
10049025c: b100053f    	cmn	x9, #0x1
100490260: 54000200    	b.eq	0x1004902a0 <conductor_lib::run::{closure#0}+0x12cc>
100490264: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100490268: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
10049026c: 3d82cbe0    	str	q0, [sp, #0xb20]
100490270: 3d82cfe1    	str	q1, [sp, #0xb30]
100490274: f9058be9    	str	x9, [sp, #0xb10]
100490278: f9058fe8    	str	x8, [sp, #0xb18]
10049027c: 97edc4f9    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100490280: 52800600    	mov	w0, #0x30               ; =48
100490284: 52800101    	mov	w1, #0x8                ; =8
100490288: 97edc4f2    	bl	0x100001650 <__rustc::__rust_alloc>
10049028c: b5001640    	cbnz	x0, 0x100490554 <conductor_lib::run::{closure#0}+0x1580>
100490290: 52800100    	mov	w0, #0x8                ; =8
100490294: 52800601    	mov	w1, #0x30               ; =48
100490298: 943bbf00    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
10049029c: 1400075b    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004902a0: f9078be8    	str	x8, [sp, #0xf10]
1004902a4: f940a676    	ldr	x22, [x19, #0x148]
1004902a8: 52824808    	mov	w8, #0x1240             ; =4672
1004902ac: 8b0802d4    	add	x20, x22, x8
1004902b0: f8bfc280    	ldapr	x0, [x20]
1004902b4: b4009640    	cbz	x0, 0x10049157c <conductor_lib::run::{closure#0}+0x25a8>
1004902b8: 94394ece    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
1004902bc: f9400368    	ldr	x8, [x27]
1004902c0: f240f91f    	tst	x8, #0x7fffffffffffffff
1004902c4: 54009621    	b.ne	0x100491588 <conductor_lib::run::{closure#0}+0x25b4>
1004902c8: 52800008    	mov	w8, #0x0                ; =0
1004902cc: 52824917    	mov	w23, #0x1248            ; =4680
1004902d0: 38776ac9    	ldrb	w9, [x22, x23]
1004902d4: 35009649    	cbnz	w9, 0x10049159c <conductor_lib::run::{closure#0}+0x25c8>
1004902d8: f9492ac9    	ldr	x9, [x22, #0x1250]
1004902dc: b4000109    	cbz	x9, 0x1004902fc <conductor_lib::run::{closure#0}+0x1328>
1004902e0: 5280002a    	mov	w10, #0x1               ; =1
1004902e4: f82a0129    	ldadd	x10, x9, [x9]
1004902e8: b7f8e909    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004902ec: f9492ad8    	ldr	x24, [x22, #0x1250]
1004902f0: f9089bf8    	str	x24, [sp, #0x1130]
1004902f4: 360000a8    	tbz	w8, #0x0, 0x100490308 <conductor_lib::run::{closure#0}+0x1334>
1004902f8: 14000007    	b	0x100490314 <conductor_lib::run::{closure#0}+0x1340>
1004902fc: d2800018    	mov	x24, #0x0               ; =0
100490300: f9089bf8    	str	x24, [sp, #0x1130]
100490304: 37000088    	tbnz	w8, #0x0, 0x100490314 <conductor_lib::run::{closure#0}+0x1340>
100490308: f9400368    	ldr	x8, [x27]
10049030c: f240f91f    	tst	x8, #0x7fffffffffffffff
100490310: 5400a701    	b.ne	0x1004917f0 <conductor_lib::run::{closure#0}+0x281c>
100490314: f9400280    	ldr	x0, [x20]
100490318: 52800039    	mov	w25, #0x1               ; =1
10049031c: 94394ebc    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100490320: f100031f    	cmp	x24, #0x0
100490324: 1a9f17f5    	cset	w21, eq
100490328: b4000338    	cbz	x24, 0x10049038c <conductor_lib::run::{closure#0}+0x13b8>
10049032c: f9058bf8    	str	x24, [sp, #0xb10]
100490330: 97edc4cc    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100490334: 52800100    	mov	w0, #0x8                ; =8
100490338: 52800101    	mov	w1, #0x8                ; =8
10049033c: 97edc4c5    	bl	0x100001650 <__rustc::__rust_alloc>
100490340: b4009460    	cbz	x0, 0x1004915cc <conductor_lib::run::{closure#0}+0x25f8>
100490344: f9000018    	str	x24, [x0]
100490348: d0015f48    	adrp	x8, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
10049034c: 910bc108    	add	x8, x8, #0x2f0
100490350: f9058fe0    	str	x0, [sp, #0xb18]
100490354: f90593e8    	str	x8, [sp, #0xb20]
100490358: 52800408    	mov	w8, #0x20               ; =32
10049035c: 392c43e8    	strb	w8, [sp, #0xb10]
100490360: 52800019    	mov	w25, #0x0               ; =0
100490364: 910043e8    	add	x8, sp, #0x10
100490368: 912c43e1    	add	x1, sp, #0xb10
10049036c: aa1303e0    	mov	x0, x19
100490370: 97fe6faa    	bl	0x10042c218 <tauri_runtime_wry::send_user_message::<tauri::EventLoopMessage>>
100490374: f9400bf8    	ldr	x24, [sp, #0x10]
100490378: b100071f    	cmn	x24, #0x1
10049037c: 54000080    	b.eq	0x10049038c <conductor_lib::run::{closure#0}+0x13b8>
100490380: 3cc183e0    	ldur	q0, [sp, #0x18]
100490384: 3d81e7e0    	str	q0, [sp, #0x790]
100490388: 1400005f    	b	0x100490504 <conductor_lib::run::{closure#0}+0x1530>
10049038c: f8bfc280    	ldapr	x0, [x20]
100490390: b4009c20    	cbz	x0, 0x100491714 <conductor_lib::run::{closure#0}+0x2740>
100490394: aa1503f9    	mov	x25, x21
100490398: 94394e96    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
10049039c: f9400368    	ldr	x8, [x27]
1004903a0: f240f91f    	tst	x8, #0x7fffffffffffffff
1004903a4: 54009c01    	b.ne	0x100491724 <conductor_lib::run::{closure#0}+0x2750>
1004903a8: 38776ac8    	ldrb	w8, [x22, x23]
1004903ac: 35009ce8    	cbnz	w8, 0x100491748 <conductor_lib::run::{closure#0}+0x2774>
1004903b0: f9492ad8    	ldr	x24, [x22, #0x1250]
1004903b4: f9058bf8    	str	x24, [sp, #0xb10]
1004903b8: f9092adf    	str	xzr, [x22, #0x1250]
1004903bc: f9400368    	ldr	x8, [x27]
1004903c0: f240f91f    	tst	x8, #0x7fffffffffffffff
1004903c4: 5400a021    	b.ne	0x1004917c8 <conductor_lib::run::{closure#0}+0x27f4>
1004903c8: f9400280    	ldr	x0, [x20]
1004903cc: 94394e90    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1004903d0: 9102a308    	add	x8, x24, #0xa8
1004903d4: f100031f    	cmp	x24, #0x0
1004903d8: 9a8803e1    	csel	x1, xzr, x8, eq
1004903dc: 910042c0    	add	x0, x22, #0x10
1004903e0: 94006ea0    	bl	0x1004abe60 <<tauri::manager::AppManager>::remove_menu_from_stash_by_id>
1004903e4: f907a3f8    	str	x24, [sp, #0xf40]
1004903e8: 52824708    	mov	w8, #0x1238             ; =4664
1004903ec: 8b0802c0    	add	x0, x22, x8
1004903f0: 913c43e1    	add	x1, sp, #0xf10
1004903f4: 94005f5b    	bl	0x1004a8160 <<tauri::manager::menu::MenuManager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert_menu_into_stash>
1004903f8: f8bfc280    	ldapr	x0, [x20]
1004903fc: b4009c00    	cbz	x0, 0x10049177c <conductor_lib::run::{closure#0}+0x27a8>
100490400: 94394e7c    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
100490404: f9400368    	ldr	x8, [x27]
100490408: f240f91f    	tst	x8, #0x7fffffffffffffff
10049040c: 54009be1    	b.ne	0x100491788 <conductor_lib::run::{closure#0}+0x27b4>
100490410: 52800015    	mov	w21, #0x0               ; =0
100490414: 38776ac8    	ldrb	w8, [x22, x23]
100490418: 35009c08    	cbnz	w8, 0x100491798 <conductor_lib::run::{closure#0}+0x27c4>
10049041c: f9478be8    	ldr	x8, [sp, #0xf10]
100490420: 52800029    	mov	w9, #0x1                ; =1
100490424: f8290108    	ldadd	x9, x8, [x8]
100490428: b7f8df08    	tbnz	x8, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10049042c: f9478be9    	ldr	x9, [sp, #0xf10]
100490430: f9492ac8    	ldr	x8, [x22, #0x1250]
100490434: f9058be8    	str	x8, [sp, #0xb10]
100490438: f9092ac9    	str	x9, [x22, #0x1250]
10049043c: b4000108    	cbz	x8, 0x10049045c <conductor_lib::run::{closure#0}+0x1488>
100490440: 92800009    	mov	x9, #-0x1               ; =-1
100490444: f8690108    	ldaddl	x9, x8, [x8]
100490448: f100051f    	cmp	x8, #0x1
10049044c: 54000081    	b.ne	0x10049045c <conductor_lib::run::{closure#0}+0x1488>
100490450: d50339bf    	dmb	ishld
100490454: 912c43e0    	add	x0, sp, #0xb10
100490458: 94308a9a    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
10049045c: 37000095    	tbnz	w21, #0x0, 0x10049046c <conductor_lib::run::{closure#0}+0x1498>
100490460: f9400368    	ldr	x8, [x27]
100490464: f240f91f    	tst	x8, #0x7fffffffffffffff
100490468: 5400a181    	b.ne	0x100491898 <conductor_lib::run::{closure#0}+0x28c4>
10049046c: f9400280    	ldr	x0, [x20]
100490470: 94394e67    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100490474: f9478be8    	ldr	x8, [sp, #0xf10]
100490478: 52800029    	mov	w9, #0x1                ; =1
10049047c: f8290108    	ldadd	x9, x8, [x8]
100490480: b7f8dc48    	tbnz	x8, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490484: f9478bf4    	ldr	x20, [sp, #0xf10]
100490488: f9058bf4    	str	x20, [sp, #0xb10]
10049048c: 97edc475    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100490490: 52800100    	mov	w0, #0x8                ; =8
100490494: 52800101    	mov	w1, #0x8                ; =8
100490498: 97edc46e    	bl	0x100001650 <__rustc::__rust_alloc>
10049049c: b4008a00    	cbz	x0, 0x1004915dc <conductor_lib::run::{closure#0}+0x2608>
1004904a0: f9000014    	str	x20, [x0]
1004904a4: d0015f48    	adrp	x8, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004904a8: 910c4108    	add	x8, x8, #0x310
1004904ac: f9058fe0    	str	x0, [sp, #0xb18]
1004904b0: f90593e8    	str	x8, [sp, #0xb20]
1004904b4: 52800408    	mov	w8, #0x20               ; =32
1004904b8: 392c43e8    	strb	w8, [sp, #0xb10]
1004904bc: 910043e8    	add	x8, sp, #0x10
1004904c0: 912c43e1    	add	x1, sp, #0xb10
1004904c4: aa1303e0    	mov	x0, x19
1004904c8: 97fe6f54    	bl	0x10042c218 <tauri_runtime_wry::send_user_message::<tauri::EventLoopMessage>>
1004904cc: f9400bf8    	ldr	x24, [sp, #0x10]
1004904d0: b100071f    	cmn	x24, #0x1
1004904d4: 54000640    	b.eq	0x10049059c <conductor_lib::run::{closure#0}+0x15c8>
1004904d8: 3cc183e0    	ldur	q0, [sp, #0x18]
1004904dc: 3d81e7e0    	str	q0, [sp, #0x790]
1004904e0: f947a3e8    	ldr	x8, [sp, #0xf40]
1004904e4: b4000108    	cbz	x8, 0x100490504 <conductor_lib::run::{closure#0}+0x1530>
1004904e8: 92800009    	mov	x9, #-0x1               ; =-1
1004904ec: f8690108    	ldaddl	x9, x8, [x8]
1004904f0: f100051f    	cmp	x8, #0x1
1004904f4: 54000081    	b.ne	0x100490504 <conductor_lib::run::{closure#0}+0x1530>
1004904f8: d50339bf    	dmb	ishld
1004904fc: 913d03e0    	add	x0, sp, #0xf40
100490500: 94308a70    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100490504: f9478be8    	ldr	x8, [sp, #0xf10]
100490508: 92800009    	mov	x9, #-0x1               ; =-1
10049050c: f8690108    	ldaddl	x9, x8, [x8]
100490510: f100051f    	cmp	x8, #0x1
100490514: 54000081    	b.ne	0x100490524 <conductor_lib::run::{closure#0}+0x1550>
100490518: d50339bf    	dmb	ishld
10049051c: 913c43e0    	add	x0, sp, #0xf10
100490520: 94308a68    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100490524: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100490528: 3dc1ebe1    	ldr	q1, [sp, #0x7a0]
10049052c: 3d82cbe0    	str	q0, [sp, #0xb20]
100490530: 3d82cfe1    	str	q1, [sp, #0xb30]
100490534: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
100490538: f9058be8    	str	x8, [sp, #0xb10]
10049053c: f9058ff8    	str	x24, [sp, #0xb18]
100490540: 97edc448    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
100490544: 52800600    	mov	w0, #0x30               ; =48
100490548: 52800101    	mov	w1, #0x8                ; =8
10049054c: 97edc441    	bl	0x100001650 <__rustc::__rust_alloc>
100490550: b40080e0    	cbz	x0, 0x10049156c <conductor_lib::run::{closure#0}+0x2598>
100490554: aa0003f3    	mov	x19, x0
100490558: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10049055c: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100490560: ad000400    	stp	q0, q1, [x0]
100490564: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100490568: 3d800800    	str	q0, [x0, #0x20]
10049056c: f0015f41    	adrp	x1, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100490570: 91070021    	add	x1, x1, #0x1c0
100490574: aa1303e0    	mov	x0, x19
100490578: 914007ff    	add	sp, sp, #0x1, lsl #12   ; =0x1000
10049057c: 910e43ff    	add	sp, sp, #0x390
100490580: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100490584: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100490588: a94357f6    	ldp	x22, x21, [sp, #0x30]
10049058c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100490590: a94167fa    	ldp	x26, x25, [sp, #0x10]
100490594: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100490598: d65f03c0    	ret
10049059c: f947a3f4    	ldr	x20, [sp, #0xf40]
1004905a0: f9478be8    	ldr	x8, [sp, #0xf10]
1004905a4: 92800009    	mov	x9, #-0x1               ; =-1
1004905a8: f8690108    	ldaddl	x9, x8, [x8]
1004905ac: f100051f    	cmp	x8, #0x1
1004905b0: 54000081    	b.ne	0x1004905c0 <conductor_lib::run::{closure#0}+0x15ec>
1004905b4: d50339bf    	dmb	ishld
1004905b8: 913c43e0    	add	x0, sp, #0xf10
1004905bc: 94308a41    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
1004905c0: f903a3f4    	str	x20, [sp, #0x740]
1004905c4: b4000114    	cbz	x20, 0x1004905e4 <conductor_lib::run::{closure#0}+0x1610>
1004905c8: 92800008    	mov	x8, #-0x1               ; =-1
1004905cc: f8680288    	ldaddl	x8, x8, [x20]
1004905d0: f100051f    	cmp	x8, #0x1
1004905d4: 54000081    	b.ne	0x1004905e4 <conductor_lib::run::{closure#0}+0x1610>
1004905d8: d50339bf    	dmb	ishld
1004905dc: 911d03e0    	add	x0, sp, #0x740
1004905e0: 94308a38    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
1004905e4: f940a675    	ldr	x21, [x19, #0x148]
1004905e8: 52824808    	mov	w8, #0x1240             ; =4672
1004905ec: 8b0802b4    	add	x20, x21, x8
1004905f0: f8bfc280    	ldapr	x0, [x20]
1004905f4: b4009c80    	cbz	x0, 0x100491984 <conductor_lib::run::{closure#0}+0x29b0>
1004905f8: 94394dfe    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
1004905fc: f9400368    	ldr	x8, [x27]
100490600: f240f91f    	tst	x8, #0x7fffffffffffffff
100490604: 54009cc1    	b.ne	0x10049199c <conductor_lib::run::{closure#0}+0x29c8>
100490608: 52800008    	mov	w8, #0x0                ; =0
10049060c: 52824916    	mov	w22, #0x1248            ; =4680
100490610: 38766aa9    	ldrb	w9, [x21, x22]
100490614: 35009ce9    	cbnz	w9, 0x1004919b0 <conductor_lib::run::{closure#0}+0x29dc>
100490618: f9492aa9    	ldr	x9, [x21, #0x1250]
10049061c: b40000c9    	cbz	x9, 0x100490634 <conductor_lib::run::{closure#0}+0x1660>
100490620: 5280002a    	mov	w10, #0x1               ; =1
100490624: f82a0129    	ldadd	x10, x9, [x9]
100490628: b7f8cf09    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10049062c: f9492ab7    	ldr	x23, [x21, #0x1250]
100490630: 14000002    	b	0x100490638 <conductor_lib::run::{closure#0}+0x1664>
100490634: d2800017    	mov	x23, #0x0               ; =0
100490638: 37000088    	tbnz	w8, #0x0, 0x100490648 <conductor_lib::run::{closure#0}+0x1674>
10049063c: f9400368    	ldr	x8, [x27]
100490640: f240f91f    	tst	x8, #0x7fffffffffffffff
100490644: 5400a241    	b.ne	0x100491a8c <conductor_lib::run::{closure#0}+0x2ab8>
100490648: f9400280    	ldr	x0, [x20]
10049064c: 94394df0    	bl	0x1012e3e0c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100490650: b4000297    	cbz	x23, 0x1004906a0 <conductor_lib::run::{closure#0}+0x16cc>
100490654: f903aff7    	str	x23, [sp, #0x758]
100490658: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10049065c: 9104c108    	add	x8, x8, #0x130
100490660: 911d63e0    	add	x0, sp, #0x758
100490664: 9401f83b    	bl	0x10050e750 <<tauri::menu::Menu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::items>
100490668: f9489be8    	ldr	x8, [sp, #0x1130]
10049066c: b100051f    	cmn	x8, #0x1
100490670: 540007a0    	b.eq	0x100490764 <conductor_lib::run::{closure#0}+0x1790>
100490674: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100490678: 9104c000    	add	x0, x0, #0x130
10049067c: 97ff28d4    	bl	0x10045a9cc <core::ptr::drop_glue::<core::result::Result<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>, tauri::error::Error>>>
100490680: f943afe8    	ldr	x8, [sp, #0x758]
100490684: 92800009    	mov	x9, #-0x1               ; =-1
100490688: f8690108    	ldaddl	x9, x8, [x8]
10049068c: f100051f    	cmp	x8, #0x1
100490690: 54000081    	b.ne	0x1004906a0 <conductor_lib::run::{closure#0}+0x16cc>
100490694: d50339bf    	dmb	ishld
100490698: 911d63e0    	add	x0, sp, #0x758
10049069c: 94308a09    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
1004906a0: 943bc362    	bl	0x101381428 <dyld_stub_binder+0x101381428>
1004906a4: 7100041f    	cmp	w0, #0x1
1004906a8: 540035e1    	b.ne	0x100490d64 <conductor_lib::run::{closure#0}+0x1d90>
1004906ac: 94340ade    	bl	0x101193224 <<objc2_app_kit::generated::__NSApplication::NSApplication>::sharedApplication>
1004906b0: aa0003f4    	mov	x20, x0
1004906b4: 94340c1a    	bl	0x10119371c <<objc2_app_kit::generated::__NSApplication::NSApplication>::mainMenu>
1004906b8: aa0003f5    	mov	x21, x0
1004906bc: b4003500    	cbz	x0, 0x100490d5c <conductor_lib::run::{closure#0}+0x1d88>
1004906c0: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004906c4: 9107c800    	add	x0, x0, #0x1f2
1004906c8: 52800181    	mov	w1, #0xc                ; =12
1004906cc: 94341ad0    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
1004906d0: aa0003fc    	mov	x28, x0
1004906d4: 52800020    	mov	w0, #0x1                ; =1
1004906d8: d2800001    	mov	x1, #0x0                ; =0
1004906dc: 94341acc    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
1004906e0: f90007e0    	str	x0, [sp, #0x8]
1004906e4: b0008400    	adrp	x0, 0x101511000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.1315+0x86e>
1004906e8: 91329000    	add	x0, x0, #0xca4
1004906ec: 52800088    	mov	w8, #0x4                ; =4
1004906f0: f903cbe0    	str	x0, [sp, #0x790]
1004906f4: f903cfe8    	str	x8, [sp, #0x798]
1004906f8: 52800081    	mov	w1, #0x4                ; =4
1004906fc: 94341ac4    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
100490700: aa0003f8    	mov	x24, x0
100490704: aa1503e0    	mov	x0, x21
100490708: aa1803e1    	mov	x1, x24
10049070c: 9434097d    	bl	0x101192d00 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemWithTitle>
100490710: aa0003fa    	mov	x26, x0
100490714: b4000ec0    	cbz	x0, 0x1004908ec <conductor_lib::run::{closure#0}+0x1918>
100490718: aa1a03e0    	mov	x0, x26
10049071c: 943417ad    	bl	0x1011965d0 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::submenu>
100490720: aa0003f9    	mov	x25, x0
100490724: aa1a03e0    	mov	x0, x26
100490728: 943bc2cb    	bl	0x101381254 <dyld_stub_binder+0x101381254>
10049072c: b4000e19    	cbz	x25, 0x1004908ec <conductor_lib::run::{closure#0}+0x1918>
100490730: aa1903e0    	mov	x0, x25
100490734: aa1c03e1    	mov	x1, x28
100490738: 94340972    	bl	0x101192d00 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemWithTitle>
10049073c: aa0003fa    	mov	x26, x0
100490740: aa1903e0    	mov	x0, x25
100490744: 943bc2c4    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490748: b4000d3a    	cbz	x26, 0x1004908ec <conductor_lib::run::{closure#0}+0x1918>
10049074c: aa1a03e0    	mov	x0, x26
100490750: f94007e1    	ldr	x1, [sp, #0x8]
100490754: 9434174b    	bl	0x101196480 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::setKeyEquivalent>
100490758: aa1a03e0    	mov	x0, x26
10049075c: 943bc2be    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490760: 1400006c    	b	0x100490910 <conductor_lib::run::{closure#0}+0x193c>
100490764: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100490768: 9104c108    	add	x8, x8, #0x130
10049076c: 3cc08100    	ldur	q0, [x8, #0x8]
100490770: 3d83c7e0    	str	q0, [sp, #0xf10]
100490774: f948a7f5    	ldr	x21, [sp, #0x1148]
100490778: f90793f5    	str	x21, [sp, #0xf20]
10049077c: f9478fe8    	ldr	x8, [sp, #0xf18]
100490780: b4001675    	cbz	x21, 0x100490a4c <conductor_lib::run::{closure#0}+0x1a78>
100490784: aa0803f4    	mov	x20, x8
100490788: f8408689    	ldr	x9, [x20], #0x8
10049078c: f100053f    	cmp	x9, #0x1
100490790: 912c43f8    	add	x24, sp, #0xb10
100490794: 911e43f9    	add	x25, sp, #0x790
100490798: 540015c1    	b.ne	0x100490a50 <conductor_lib::run::{closure#0}+0x1a7c>
10049079c: 92800008    	mov	x8, #-0x1               ; =-1
1004907a0: f9058be8    	str	x8, [sp, #0xb10]
1004907a4: f90597e8    	str	x8, [sp, #0xb28]
1004907a8: f905a3e8    	str	x8, [sp, #0xb40]
1004907ac: f905afe8    	str	x8, [sp, #0xb58]
1004907b0: f905bbe8    	str	x8, [sp, #0xb70]
1004907b4: f905c7e8    	str	x8, [sp, #0xb88]
1004907b8: f905d3e8    	str	x8, [sp, #0xba0]
1004907bc: f905dfe8    	str	x8, [sp, #0xbb8]
1004907c0: f905ebe8    	str	x8, [sp, #0xbd0]
1004907c4: f905f7e8    	str	x8, [sp, #0xbe8]
1004907c8: 92800028    	mov	x8, #-0x2               ; =-2
1004907cc: f90603e8    	str	x8, [sp, #0xc00]
1004907d0: 52822908    	mov	w8, #0x1148             ; =4424
1004907d4: f940a675    	ldr	x21, [x19, #0x148]
1004907d8: 911e43e0    	add	x0, sp, #0x790
1004907dc: 8b0802a1    	add	x1, x21, x8
1004907e0: 9400c5a9    	bl	0x1004c1e84 <<semver::Version as alloc::string::SpecToString>::spec_to_string>
1004907e4: 3dc1e7e0    	ldr	q0, [sp, #0x790]
1004907e8: 3d83d3e0    	str	q0, [sp, #0xf40]
1004907ec: f943d3e8    	ldr	x8, [sp, #0x7a0]
1004907f0: f907abe8    	str	x8, [sp, #0xf50]
1004907f4: 911e43e8    	add	x8, sp, #0x790
1004907f8: 912c43e0    	add	x0, sp, #0xb10
1004907fc: 913d03e1    	add	x1, sp, #0xf40
100490800: 94011e37    	bl	0x1004d80dc <<tauri::menu::AboutMetadataBuilder>::version::<alloc::string::String>>
100490804: f00083e1    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490808: 91390821    	add	x1, x1, #0xe42
10049080c: 912c43e8    	add	x8, sp, #0xb10
100490810: 911e43e0    	add	x0, sp, #0x790
100490814: 52800142    	mov	w2, #0xa                ; =10
100490818: 94011df4    	bl	0x1004d7fe8 <<tauri::menu::AboutMetadataBuilder>::short_version::<&str>>
10049081c: 52822608    	mov	w8, #0x1130             ; =4400
100490820: 8b0802b5    	add	x21, x21, x8
100490824: 910043e0    	add	x0, sp, #0x10
100490828: 912c43e1    	add	x1, sp, #0xb10
10049082c: 52802202    	mov	w2, #0x110              ; =272
100490830: 943bc238    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490834: f907a3f5    	str	x21, [sp, #0xf40]
100490838: d0000188    	adrp	x8, 0x1004c2000 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone+0x70>
10049083c: 91269108    	add	x8, x8, #0x9a4
100490840: f907a7e8    	str	x8, [sp, #0xf48]
100490844: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100490848: 91231800    	add	x0, x0, #0x8c6
10049084c: 912c43e8    	add	x8, sp, #0xb10
100490850: 913d03e1    	add	x1, sp, #0xf40
100490854: 943a0488    	bl	0x101311a74 <alloc::fmt::format::format_inner>
100490858: f9458bf5    	ldr	x21, [sp, #0xb10]
10049085c: f9458ff6    	ldr	x22, [sp, #0xb18]
100490860: f94593f7    	ldr	x23, [sp, #0xb20]
100490864: 912c43e0    	add	x0, sp, #0xb10
100490868: 910043e1    	add	x1, sp, #0x10
10049086c: 52802202    	mov	w2, #0x110              ; =272
100490870: 943bc228    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490874: 911e43e8    	add	x8, sp, #0x790
100490878: 912c43e3    	add	x3, sp, #0xb10
10049087c: aa1303e0    	mov	x0, x19
100490880: aa1603e1    	mov	x1, x22
100490884: aa1703e2    	mov	x2, x23
100490888: 9400f6dc    	bl	0x1004ce3f8 <<tauri::menu::PredefinedMenuItem<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::about::<tauri::app::App>>
10049088c: f943cbe9    	ldr	x9, [sp, #0x790]
100490890: f943cfe8    	ldr	x8, [sp, #0x798]
100490894: b100053f    	cmn	x9, #0x1
100490898: 54002080    	b.eq	0x100490ca8 <conductor_lib::run::{closure#0}+0x1cd4>
10049089c: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
1004908a0: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
1004908a4: 3d82cbe0    	str	q0, [sp, #0xb20]
1004908a8: 3d82cfe1    	str	q1, [sp, #0xb30]
1004908ac: f9058be9    	str	x9, [sp, #0xb10]
1004908b0: f9058fe8    	str	x8, [sp, #0xb18]
1004908b4: 52800600    	mov	w0, #0x30               ; =48
1004908b8: 9400aa10    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004908bc: aa0003f3    	mov	x19, x0
1004908c0: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
1004908c4: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
1004908c8: ad000400    	stp	q0, q1, [x0]
1004908cc: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
1004908d0: 3d800800    	str	q0, [x0, #0x20]
1004908d4: b4001095    	cbz	x21, 0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
1004908d8: aa1603e0    	mov	x0, x22
1004908dc: aa1503e1    	mov	x1, x21
1004908e0: 52800022    	mov	w2, #0x1                ; =1
1004908e4: 97edc35c    	bl	0x100001654 <__rustc::__rust_dealloc>
1004908e8: 1400007f    	b	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
1004908ec: 911e43e8    	add	x8, sp, #0x790
1004908f0: b0001589    	adrp	x9, 0x100741000 <<&tungstenite::protocol::message::Message as core::fmt::Debug>::fmt+0xb8>
1004908f4: 9107b129    	add	x9, x9, #0x1ec
1004908f8: f9058be8    	str	x8, [sp, #0xb10]
1004908fc: f9058fe9    	str	x9, [sp, #0xb18]
100490900: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100490904: 91233c00    	add	x0, x0, #0x8cf
100490908: 912c43e1    	add	x1, sp, #0xb10
10049090c: 94399f3e    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490910: aa1803e0    	mov	x0, x24
100490914: 943bc250    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490918: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
10049091c: 9107f800    	add	x0, x0, #0x1fe
100490920: 528000c8    	mov	w8, #0x6                ; =6
100490924: f903cbe0    	str	x0, [sp, #0x790]
100490928: f903cfe8    	str	x8, [sp, #0x798]
10049092c: 528000c1    	mov	w1, #0x6                ; =6
100490930: 94341a37    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
100490934: aa0003f8    	mov	x24, x0
100490938: aa1503e0    	mov	x0, x21
10049093c: aa1803e1    	mov	x1, x24
100490940: 943408f0    	bl	0x101192d00 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemWithTitle>
100490944: aa0003fa    	mov	x26, x0
100490948: b4000280    	cbz	x0, 0x100490998 <conductor_lib::run::{closure#0}+0x19c4>
10049094c: aa1a03e0    	mov	x0, x26
100490950: 94341720    	bl	0x1011965d0 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::submenu>
100490954: aa0003f9    	mov	x25, x0
100490958: aa1a03e0    	mov	x0, x26
10049095c: 943bc23e    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490960: b40001d9    	cbz	x25, 0x100490998 <conductor_lib::run::{closure#0}+0x19c4>
100490964: aa1903e0    	mov	x0, x25
100490968: aa1c03e1    	mov	x1, x28
10049096c: 943408e5    	bl	0x101192d00 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemWithTitle>
100490970: aa0003fa    	mov	x26, x0
100490974: aa1903e0    	mov	x0, x25
100490978: 943bc237    	bl	0x101381254 <dyld_stub_binder+0x101381254>
10049097c: b40000fa    	cbz	x26, 0x100490998 <conductor_lib::run::{closure#0}+0x19c4>
100490980: aa1a03e0    	mov	x0, x26
100490984: f94007e1    	ldr	x1, [sp, #0x8]
100490988: 943416be    	bl	0x101196480 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::setKeyEquivalent>
10049098c: aa1a03e0    	mov	x0, x26
100490990: 943bc231    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490994: 1400000a    	b	0x1004909bc <conductor_lib::run::{closure#0}+0x19e8>
100490998: 911e43e8    	add	x8, sp, #0x790
10049099c: b0001589    	adrp	x9, 0x100741000 <<&tungstenite::protocol::message::Message as core::fmt::Debug>::fmt+0xb8>
1004909a0: 9107b129    	add	x9, x9, #0x1ec
1004909a4: f9058be8    	str	x8, [sp, #0xb10]
1004909a8: f9058fe9    	str	x9, [sp, #0xb18]
1004909ac: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
1004909b0: 91233c00    	add	x0, x0, #0x8cf
1004909b4: 912c43e1    	add	x1, sp, #0xb10
1004909b8: 94399f13    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004909bc: aa1803e0    	mov	x0, x24
1004909c0: 943bc225    	bl	0x101381254 <dyld_stub_binder+0x101381254>
1004909c4: aa1503e0    	mov	x0, x21
1004909c8: d2800001    	mov	x1, #0x0                ; =0
1004909cc: 943408a1    	bl	0x101192c50 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemAtIndex>
1004909d0: aa0003f8    	mov	x24, x0
1004909d4: b4001b80    	cbz	x0, 0x100490d44 <conductor_lib::run::{closure#0}+0x1d70>
1004909d8: aa1803e0    	mov	x0, x24
1004909dc: 943416fd    	bl	0x1011965d0 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::submenu>
1004909e0: aa0003f9    	mov	x25, x0
1004909e4: b4001ac0    	cbz	x0, 0x100490d3c <conductor_lib::run::{closure#0}+0x1d68>
1004909e8: f00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004909ec: 913ab800    	add	x0, x0, #0xeae
1004909f0: 52800161    	mov	w1, #0xb                ; =11
1004909f4: 94341a06    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
1004909f8: aa0003fa    	mov	x26, x0
1004909fc: aa1903e0    	mov	x0, x25
100490a00: aa1a03e1    	mov	x1, x26
100490a04: 943408bf    	bl	0x101192d00 <<objc2_app_kit::generated::__NSMenu::NSMenu>::itemWithTitle>
100490a08: aa0003fb    	mov	x27, x0
100490a0c: b4000de0    	cbz	x0, 0x100490bc8 <conductor_lib::run::{closure#0}+0x1bf4>
100490a10: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490a14: 91081000    	add	x0, x0, #0x204
100490a18: 52800121    	mov	w1, #0x9                ; =9
100490a1c: 943419fc    	bl	0x10119720c <<objc2_foundation::generated::__NSString::NSString>::from_str>
100490a20: aa0003f6    	mov	x22, x0
100490a24: d2800001    	mov	x1, #0x0                ; =0
100490a28: 94341512    	bl	0x101195e70 <<objc2_app_kit::generated::__NSImage::NSImage>::imageWithSystemSymbolName_accessibilityDescription>
100490a2c: aa0003f7    	mov	x23, x0
100490a30: b40016e0    	cbz	x0, 0x100490d0c <conductor_lib::run::{closure#0}+0x1d38>
100490a34: aa1b03e0    	mov	x0, x27
100490a38: aa1703e1    	mov	x1, x23
100490a3c: 943416fa    	bl	0x101196624 <<objc2_app_kit::generated::__NSMenuItem::NSMenuItem>::setImage>
100490a40: aa1703e0    	mov	x0, x23
100490a44: 943bc204    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490a48: 140000b5    	b	0x100490d1c <conductor_lib::run::{closure#0}+0x1d48>
100490a4c: 911e43f9    	add	x25, sp, #0x790
100490a50: 8b151109    	add	x9, x8, x21, lsl #4
100490a54: f907a3e8    	str	x8, [sp, #0xf40]
100490a58: f907a7e9    	str	x9, [sp, #0xf48]
100490a5c: 913d03e0    	add	x0, sp, #0xf40
100490a60: 97ff9393    	bl	0x1004758ac <<core::slice::iter::Iter<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>> as core::iter::traits::iterator::Iterator>::find_map::<&tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>, conductor_lib::run::{closure#0}::{closure#3}>>
100490a64: aa0003f4    	mov	x20, x0
100490a68: b40047e0    	cbz	x0, 0x100491364 <conductor_lib::run::{closure#0}+0x2390>
100490a6c: f00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490a70: 913bf800    	add	x0, x0, #0xefe
100490a74: f00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490a78: 913c4442    	add	x2, x2, #0xf11
100490a7c: 912c43e8    	add	x8, sp, #0xb10
100490a80: 52800261    	mov	w1, #0x13               ; =19
100490a84: 52800263    	mov	w3, #0x13               ; =19
100490a88: 94011c74    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100490a8c: 911e43e8    	add	x8, sp, #0x790
100490a90: 912c43e0    	add	x0, sp, #0xb10
100490a94: aa1303e1    	mov	x1, x19
100490a98: 940115dd    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100490a9c: f943cbe9    	ldr	x9, [sp, #0x790]
100490aa0: f943cfe8    	ldr	x8, [sp, #0x798]
100490aa4: b100053f    	cmn	x9, #0x1
100490aa8: 54000400    	b.eq	0x100490b28 <conductor_lib::run::{closure#0}+0x1b54>
100490aac: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100490ab0: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100490ab4: 3d82cbe0    	str	q0, [sp, #0xb20]
100490ab8: 3d82cfe1    	str	q1, [sp, #0xb30]
100490abc: f9058be9    	str	x9, [sp, #0xb10]
100490ac0: f9058fe8    	str	x8, [sp, #0xb18]
100490ac4: 52800600    	mov	w0, #0x30               ; =48
100490ac8: 9400a98c    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100490acc: aa0003f3    	mov	x19, x0
100490ad0: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100490ad4: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100490ad8: ad000400    	stp	q0, q1, [x0]
100490adc: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100490ae0: 3d800800    	str	q0, [x0, #0x20]
100490ae4: 913c43e0    	add	x0, sp, #0xf10
100490ae8: 97ff2fd7    	bl	0x10045ca44 <core::ptr::drop_glue::<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>>
100490aec: f9489be8    	ldr	x8, [sp, #0x1130]
100490af0: b100051f    	cmn	x8, #0x1
100490af4: 54000080    	b.eq	0x100490b04 <conductor_lib::run::{closure#0}+0x1b30>
100490af8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100490afc: 9104c000    	add	x0, x0, #0x130
100490b00: 97ff27b3    	bl	0x10045a9cc <core::ptr::drop_glue::<core::result::Result<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>, tauri::error::Error>>>
100490b04: f943afe8    	ldr	x8, [sp, #0x758]
100490b08: 92800009    	mov	x9, #-0x1               ; =-1
100490b0c: f8690108    	ldaddl	x9, x8, [x8]
100490b10: f100051f    	cmp	x8, #0x1
100490b14: 54ffd2c1    	b.ne	0x10049056c <conductor_lib::run::{closure#0}+0x1598>
100490b18: d50339bf    	dmb	ishld
100490b1c: 911d63e0    	add	x0, sp, #0x758
100490b20: 943088e8    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100490b24: 17fffe92    	b	0x10049056c <conductor_lib::run::{closure#0}+0x1598>
100490b28: f903c7e8    	str	x8, [sp, #0x788]
100490b2c: f00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490b30: 913c9000    	add	x0, x0, #0xf24
100490b34: f00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490b38: 913ce042    	add	x2, x2, #0xf38
100490b3c: 912c43e8    	add	x8, sp, #0xb10
100490b40: 52800281    	mov	w1, #0x14               ; =20
100490b44: 52800283    	mov	w3, #0x14               ; =20
100490b48: 94011c44    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100490b4c: 911e43e8    	add	x8, sp, #0x790
100490b50: 912c43e0    	add	x0, sp, #0xb10
100490b54: aa1303e1    	mov	x1, x19
100490b58: 940115ad    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100490b5c: f943cbe9    	ldr	x9, [sp, #0x790]
100490b60: f943cfe8    	ldr	x8, [sp, #0x798]
100490b64: b100053f    	cmn	x9, #0x1
100490b68: 540027e0    	b.eq	0x100491064 <conductor_lib::run::{closure#0}+0x2090>
100490b6c: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100490b70: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100490b74: 3d82cbe0    	str	q0, [sp, #0xb20]
100490b78: 3d82cfe1    	str	q1, [sp, #0xb30]
100490b7c: f9058be9    	str	x9, [sp, #0xb10]
100490b80: f9058fe8    	str	x8, [sp, #0xb18]
100490b84: 52800600    	mov	w0, #0x30               ; =48
100490b88: 9400a95c    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100490b8c: aa0003f3    	mov	x19, x0
100490b90: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100490b94: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100490b98: ad000400    	stp	q0, q1, [x0]
100490b9c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100490ba0: 3d800800    	str	q0, [x0, #0x20]
100490ba4: f943c7e8    	ldr	x8, [sp, #0x788]
100490ba8: 92800009    	mov	x9, #-0x1               ; =-1
100490bac: f8690108    	ldaddl	x9, x8, [x8]
100490bb0: f100051f    	cmp	x8, #0x1
100490bb4: 54fff981    	b.ne	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100490bb8: d50339bf    	dmb	ishld
100490bbc: 911e23e0    	add	x0, sp, #0x788
100490bc0: 9409cfe2    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100490bc4: 17ffffc8    	b	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100490bc8: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490bcc: 9108e400    	add	x0, x0, #0x239
100490bd0: 52800ba1    	mov	w1, #0x5d               ; =93
100490bd4: 94399e8c    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490bd8: 14000055    	b	0x100490d2c <conductor_lib::run::{closure#0}+0x1d58>
100490bdc: f9458fe8    	ldr	x8, [sp, #0xb18]
100490be0: f903cbe8    	str	x8, [sp, #0x790]
100490be4: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490be8: 91137400    	add	x0, x0, #0x4dd
100490bec: f0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100490bf0: 91134063    	add	x3, x3, #0x4d0
100490bf4: d0015f44    	adrp	x4, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100490bf8: 912c6084    	add	x4, x4, #0xb18
100490bfc: 911e43e2    	add	x2, sp, #0x790
100490c00: 52800561    	mov	w1, #0x2b               ; =43
100490c04: 943bbd2a    	bl	0x1013800ac <core::result::unwrap_failed>
100490c08: 14000500    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490c0c: f9458fe8    	ldr	x8, [sp, #0xb18]
100490c10: f903cbe8    	str	x8, [sp, #0x790]
100490c14: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490c18: 91137400    	add	x0, x0, #0x4dd
100490c1c: f0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100490c20: 91134063    	add	x3, x3, #0x4d0
100490c24: d0015f44    	adrp	x4, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100490c28: 912c6084    	add	x4, x4, #0xb18
100490c2c: 911e43e2    	add	x2, sp, #0x790
100490c30: 52800561    	mov	w1, #0x2b               ; =43
100490c34: 943bbd1e    	bl	0x1013800ac <core::result::unwrap_failed>
100490c38: 140004f4    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490c3c: f9458fe8    	ldr	x8, [sp, #0xb18]
100490c40: f903cbe8    	str	x8, [sp, #0x790]
100490c44: f00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490c48: 91365000    	add	x0, x0, #0xd94
100490c4c: f0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100490c50: 91134063    	add	x3, x3, #0x4d0
100490c54: f0015f44    	adrp	x4, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100490c58: 91050084    	add	x4, x4, #0x140
100490c5c: 911e43e2    	add	x2, sp, #0x790
100490c60: 52800441    	mov	w1, #0x22               ; =34
100490c64: 943bbd12    	bl	0x1013800ac <core::result::unwrap_failed>
100490c68: 140004e8    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490c6c: f00083e8    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100490c70: 91027508    	add	x8, x8, #0x9d
100490c74: 52800a69    	mov	w9, #0x53               ; =83
100490c78: a90127e8    	stp	x8, x9, [sp, #0x10]
100490c7c: 910043e8    	add	x8, sp, #0x10
100490c80: b0001589    	adrp	x9, 0x100741000 <<&tungstenite::protocol::message::Message as core::fmt::Debug>::fmt+0xb8>
100490c84: 9107b129    	add	x9, x9, #0x1ec
100490c88: f9058be8    	str	x8, [sp, #0xb10]
100490c8c: f9058fe9    	str	x9, [sp, #0xb18]
100490c90: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100490c94: 91136000    	add	x0, x0, #0x4d8
100490c98: d0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100490c9c: 91194042    	add	x2, x2, #0x650
100490ca0: 912c43e1    	add	x1, sp, #0xb10
100490ca4: 943bbd7e    	bl	0x10138029c <core::panicking::panic_fmt>
100490ca8: f903a3e8    	str	x8, [sp, #0x740]
100490cac: b40000b5    	cbz	x21, 0x100490cc0 <conductor_lib::run::{closure#0}+0x1cec>
100490cb0: aa1603e0    	mov	x0, x22
100490cb4: aa1503e1    	mov	x1, x21
100490cb8: 52800022    	mov	w2, #0x1                ; =1
100490cbc: 97edc266    	bl	0x100001654 <__rustc::__rust_dealloc>
100490cc0: 911e43e8    	add	x8, sp, #0x790
100490cc4: aa1403e0    	mov	x0, x20
100490cc8: d2800001    	mov	x1, #0x0                ; =0
100490ccc: 9402097b    	bl	0x1005132b8 <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::remove_at>
100490cd0: f943cbea    	ldr	x10, [sp, #0x790]
100490cd4: f943cfe8    	ldr	x8, [sp, #0x798]
100490cd8: f943d3e9    	ldr	x9, [sp, #0x7a0]
100490cdc: b100055f    	cmn	x10, #0x1
100490ce0: 540024c0    	b.eq	0x100491178 <conductor_lib::run::{closure#0}+0x21a4>
100490ce4: 3cc18320    	ldur	q0, [x25, #0x18]
100490ce8: 3c818300    	stur	q0, [x24, #0x18]
100490cec: f943dfeb    	ldr	x11, [sp, #0x7b8]
100490cf0: f9058bea    	str	x10, [sp, #0xb10]
100490cf4: f9058fe8    	str	x8, [sp, #0xb18]
100490cf8: f9059feb    	str	x11, [sp, #0xb38]
100490cfc: f90593e9    	str	x9, [sp, #0xb20]
100490d00: 52800600    	mov	w0, #0x30               ; =48
100490d04: 9400a8fd    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100490d08: 14000134    	b	0x1004911d8 <conductor_lib::run::{closure#0}+0x2204>
100490d0c: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490d10: 91083400    	add	x0, x0, #0x20d
100490d14: 52800b21    	mov	w1, #0x59               ; =89
100490d18: 94399e3b    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490d1c: aa1603e0    	mov	x0, x22
100490d20: 943bc14d    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d24: aa1b03e0    	mov	x0, x27
100490d28: 943bc14b    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d2c: aa1a03e0    	mov	x0, x26
100490d30: 943bc149    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d34: aa1903e0    	mov	x0, x25
100490d38: 943bc147    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d3c: aa1803e0    	mov	x0, x24
100490d40: 943bc145    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d44: f94007e0    	ldr	x0, [sp, #0x8]
100490d48: 943bc143    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d4c: aa1c03e0    	mov	x0, x28
100490d50: 943bc141    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d54: aa1503e0    	mov	x0, x21
100490d58: 943bc13f    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d5c: aa1403e0    	mov	x0, x20
100490d60: 943bc13d    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100490d64: f940a668    	ldr	x8, [x19, #0x148]
100490d68: f9496508    	ldr	x8, [x8, #0x12c8]
100490d6c: 91004100    	add	x0, x8, #0x10
100490d70: 97fefc20    	bl	0x10044fdf0 <<tauri::state::StateManager>::try_get::<conductor_lib::sidecar::SidecarProcessState>>
100490d74: b40067e0    	cbz	x0, 0x100491a70 <conductor_lib::run::{closure#0}+0x2a9c>
100490d78: aa0003f4    	mov	x20, x0
100490d7c: 911e43e0    	add	x0, sp, #0x790
100490d80: aa1303e1    	mov	x1, x19
100490d84: 9400c483    	bl	0x1004c1f90 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone>
100490d88: f9404668    	ldr	x8, [x19, #0x88]
100490d8c: 52800029    	mov	w9, #0x1                ; =1
100490d90: f8290109    	ldadd	x9, x9, [x8]
100490d94: b7f893a9    	tbnz	x9, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490d98: f9404a69    	ldr	x9, [x19, #0x90]
100490d9c: 5280002a    	mov	w10, #0x1               ; =1
100490da0: f82a012a    	ldadd	x10, x10, [x9]
100490da4: b7f8932a    	tbnz	x10, #0x3f, 0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100490da8: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
100490dac: 3dc203e1    	ldr	q1, [sp, #0x800]
100490db0: 3d82dfe0    	str	q0, [sp, #0xb70]
100490db4: 3d82e3e1    	str	q1, [sp, #0xb80]
100490db8: f9440bea    	ldr	x10, [sp, #0x810]
100490dbc: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100490dc0: 3dc1f3e1    	ldr	q1, [sp, #0x7c0]
100490dc4: 3d82cfe0    	str	q0, [sp, #0xb30]
100490dc8: 3d82d3e1    	str	q1, [sp, #0xb40]
100490dcc: 3dc1fbe0    	ldr	q0, [sp, #0x7e0]
100490dd0: 3dc1f7e1    	ldr	q1, [sp, #0x7d0]
100490dd4: 3d82dbe0    	str	q0, [sp, #0xb60]
100490dd8: 3d82d7e1    	str	q1, [sp, #0xb50]
100490ddc: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100490de0: 3dc1e7e1    	ldr	q1, [sp, #0x790]
100490de4: 3d82cbe0    	str	q0, [sp, #0xb20]
100490de8: 3d82c7e1    	str	q1, [sp, #0xb10]
100490dec: f905cbea    	str	x10, [sp, #0xb90]
100490df0: f905cfe8    	str	x8, [sp, #0xb98]
100490df4: f905d3e9    	str	x9, [sp, #0xba0]
100490df8: 912c43e1    	add	x1, sp, #0xb10
100490dfc: aa1403e0    	mov	x0, x20
100490e00: 940b90d4    	bl	0x100775150 <<conductor_lib::sidecar::SidecarProcessState>::set_app_handle>
100490e04: aa1303e0    	mov	x0, x19
100490e08: 9405ea95    	bl	0x10060b85c <conductor_lib::notifications::init>
100490e0c: f940a669    	ldr	x9, [x19, #0x148]
100490e10: f00083c1    	adrp	x1, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
100490e14: 9122e021    	add	x1, x1, #0x8b8
100490e18: 913d03e8    	add	x8, sp, #0xf40
100490e1c: 91004120    	add	x0, x9, #0x10
100490e20: 52800082    	mov	w2, #0x4                ; =4
100490e24: 940065ba    	bl	0x1004aa50c <<tauri::manager::AppManager>::get_webview>
100490e28: f947a3e8    	ldr	x8, [sp, #0xf40]
100490e2c: b100051f    	cmn	x8, #0x1
100490e30: 54000780    	b.eq	0x100490f20 <conductor_lib::run::{closure#0}+0x1f4c>
100490e34: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100490e38: 9104c000    	add	x0, x0, #0x130
100490e3c: 913d03e1    	add	x1, sp, #0xf40
100490e40: 52802d02    	mov	w2, #0x168              ; =360
100490e44: 943bc0b3    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490e48: 910043e8    	add	x8, sp, #0x10
100490e4c: 913d03e0    	add	x0, sp, #0xf40
100490e50: 940256a2    	bl	0x1005268d8 <<tauri::webview::Webview>::window>
100490e54: 910043e0    	add	x0, sp, #0x10
100490e58: 94025a48    	bl	0x100527778 <<tauri::window::Window>::is_webview_window>
100490e5c: 36000580    	tbz	w0, #0x0, 0x100490f0c <conductor_lib::run::{closure#0}+0x1f38>
100490e60: f9400bf4    	ldr	x20, [sp, #0x10]
100490e64: 910043e8    	add	x8, sp, #0x10
100490e68: 912c43f5    	add	x21, sp, #0xb10
100490e6c: 912c43e0    	add	x0, sp, #0xb10
100490e70: 91002101    	add	x1, x8, #0x8
100490e74: 52804202    	mov	w2, #0x210              ; =528
100490e78: 943bc0a6    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490e7c: 910842a0    	add	x0, x21, #0x210
100490e80: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100490e84: 9104c021    	add	x1, x1, #0x130
100490e88: 52802d02    	mov	w2, #0x168              ; =360
100490e8c: 943bc0a1    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490e90: 911e43e0    	add	x0, sp, #0x790
100490e94: 912c43e1    	add	x1, sp, #0xb10
100490e98: 52806f02    	mov	w2, #0x378              ; =888
100490e9c: 943bc09d    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490ea0: b100069f    	cmn	x20, #0x1
100490ea4: 540003e0    	b.eq	0x100490f20 <conductor_lib::run::{closure#0}+0x1f4c>
100490ea8: f9058bf4    	str	x20, [sp, #0xb10]
100490eac: 910022a0    	add	x0, x21, #0x8
100490eb0: 911e43e1    	add	x1, sp, #0x790
100490eb4: 52806f02    	mov	w2, #0x378              ; =888
100490eb8: 943bc096    	bl	0x101381110 <dyld_stub_binder+0x101381110>
100490ebc: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100490ec0: 9104c108    	add	x8, x8, #0x130
100490ec4: 912c43e0    	add	x0, sp, #0xb10
100490ec8: 9400d690    	bl	0x1004c6908 <<tauri_runtime_wry::WryWindowDispatcher<tauri::EventLoopMessage> as tauri_runtime::WindowDispatch<tauri::EventLoopMessage>>::theme>
100490ecc: f9489be8    	ldr	x8, [sp, #0x1130]
100490ed0: b100051f    	cmn	x8, #0x1
100490ed4: 54000320    	b.eq	0x100490f38 <conductor_lib::run::{closure#0}+0x1f64>
100490ed8: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
100490edc: 9104c129    	add	x9, x9, #0x130
100490ee0: 3cc01120    	ldur	q0, [x9, #0x1]
100490ee4: 3c8193e0    	stur	q0, [sp, #0x19]
100490ee8: f948a3e9    	ldr	x9, [sp, #0x1140]
100490eec: f90017e9    	str	x9, [sp, #0x28]
100490ef0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
100490ef4: f9000be9    	str	x9, [sp, #0x10]
100490ef8: 390063e8    	strb	w8, [sp, #0x18]
100490efc: 910043e0    	add	x0, sp, #0x10
100490f00: 97ff6ba1    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100490f04: 52800014    	mov	w20, #0x0               ; =0
100490f08: 1400000f    	b	0x100490f44 <conductor_lib::run::{closure#0}+0x1f70>
100490f0c: 910043e0    	add	x0, sp, #0x10
100490f10: 97ff6c45    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100490f14: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100490f18: 9104c000    	add	x0, x0, #0x130
100490f1c: 97ff6d16    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100490f20: 90008400    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100490f24: 91099c00    	add	x0, x0, #0x267
100490f28: 52800d61    	mov	w1, #0x6b               ; =107
100490f2c: 94399db6    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490f30: d2800013    	mov	x19, #0x0               ; =0
100490f34: 17fffd90    	b	0x100490574 <conductor_lib::run::{closure#0}+0x15a0>
100490f38: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100490f3c: 9104c108    	add	x8, x8, #0x130
100490f40: 39402114    	ldrb	w20, [x8, #0x8]
100490f44: 910043e8    	add	x8, sp, #0x10
100490f48: 912c43e0    	add	x0, sp, #0xb10
100490f4c: 94025aae    	bl	0x100527a04 <<tauri::window::Window>::ns_window>
100490f50: f9400be8    	ldr	x8, [sp, #0x10]
100490f54: b100051f    	cmn	x8, #0x1
100490f58: 540003c1    	b.ne	0x100490fd0 <conductor_lib::run::{closure#0}+0x1ffc>
100490f5c: f9400fe0    	ldr	x0, [sp, #0x18]
100490f60: 913d03e8    	add	x8, sp, #0xf40
100490f64: 12000281    	and	w1, w20, #0x1
100490f68: 940953ac    	bl	0x1006e5e18 <conductor_lib::set_window_appearance>
100490f6c: f947a3e8    	ldr	x8, [sp, #0xf40]
100490f70: b100051f    	cmn	x8, #0x1
100490f74: 54000280    	b.eq	0x100490fc4 <conductor_lib::run::{closure#0}+0x1ff0>
100490f78: 3dc3d3e0    	ldr	q0, [sp, #0xf40]
100490f7c: 3d844fe0    	str	q0, [sp, #0x1130]
100490f80: f947abe8    	ldr	x8, [sp, #0xf50]
100490f84: f908a3e8    	str	x8, [sp, #0x1140]
100490f88: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100490f8c: 9104c108    	add	x8, x8, #0x130
100490f90: f9078be8    	str	x8, [sp, #0xf10]
100490f94: d0000188    	adrp	x8, 0x1004c2000 <<tauri_runtime_wry::Context<tauri::EventLoopMessage> as core::clone::Clone>::clone+0x70>
100490f98: 91269108    	add	x8, x8, #0x9a4
100490f9c: f9078fe8    	str	x8, [sp, #0xf18]
100490fa0: d0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100490fa4: 91241800    	add	x0, x0, #0x906
100490fa8: 913c43e1    	add	x1, sp, #0xf10
100490fac: 94399d96    	bl	0x1012f8604 <std::io::stdio::_eprint>
100490fb0: f9489be1    	ldr	x1, [sp, #0x1130]
100490fb4: b4000081    	cbz	x1, 0x100490fc4 <conductor_lib::run::{closure#0}+0x1ff0>
100490fb8: f9489fe0    	ldr	x0, [sp, #0x1138]
100490fbc: 52800022    	mov	w2, #0x1                ; =1
100490fc0: 97edc1a5    	bl	0x100001654 <__rustc::__rust_dealloc>
100490fc4: f9400be8    	ldr	x8, [sp, #0x10]
100490fc8: b100051f    	cmn	x8, #0x1
100490fcc: 54000060    	b.eq	0x100490fd8 <conductor_lib::run::{closure#0}+0x2004>
100490fd0: 910043e0    	add	x0, sp, #0x10
100490fd4: 97ff6b6c    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100490fd8: aa1303e0    	mov	x0, x19
100490fdc: 94095836    	bl	0x1006e70b4 <conductor_lib::startup_sidebar_transparency_enabled>
100490fe0: 34000340    	cbz	w0, 0x100491048 <conductor_lib::run::{closure#0}+0x2074>
100490fe4: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100490fe8: 9104c108    	add	x8, x8, #0x130
100490fec: 912c43e0    	add	x0, sp, #0xb10
100490ff0: 528000e1    	mov	w1, #0x7                ; =7
100490ff4: 92800002    	mov	x2, #-0x1               ; =-1
100490ff8: d2800003    	mov	x3, #0x0                ; =0
100490ffc: 940a15ef    	bl	0x1007167b8 <window_vibrancy::apply_vibrancy::<&tauri::webview::webview_window::WebviewWindow>>
100491000: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100491004: 9104c108    	add	x8, x8, #0x130
100491008: 39400108    	ldrb	w8, [x8]
10049100c: 7103fd1f    	cmp	w8, #0xff
100491010: 540001c0    	b.eq	0x100491048 <conductor_lib::run::{closure#0}+0x2074>
100491014: 3dc44fe0    	ldr	q0, [sp, #0x1130]
100491018: 3d8007e0    	str	q0, [sp, #0x10]
10049101c: f948a3e8    	ldr	x8, [sp, #0x1140]
100491020: f90013e8    	str	x8, [sp, #0x20]
100491024: 910043e8    	add	x8, sp, #0x10
100491028: b0006649    	adrp	x9, 0x10115a000 <<unicode_segmentation::grapheme::GraphemeCursor>::grapheme_category+0xd0>
10049102c: 91283129    	add	x9, x9, #0xa0c
100491030: f907a3e8    	str	x8, [sp, #0xf40]
100491034: f907a7e9    	str	x9, [sp, #0xf48]
100491038: b0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
10049103c: 9124d400    	add	x0, x0, #0x935
100491040: 913d03e1    	add	x1, sp, #0xf40
100491044: 94399d70    	bl	0x1012f8604 <std::io::stdio::_eprint>
100491048: 912c43f4    	add	x20, sp, #0xb10
10049104c: 912c43e0    	add	x0, sp, #0xb10
100491050: 97ff6bf5    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100491054: 91086280    	add	x0, x20, #0x218
100491058: 97ff6cc7    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
10049105c: d2800013    	mov	x19, #0x0               ; =0
100491060: 17fffd45    	b	0x100490574 <conductor_lib::run::{closure#0}+0x15a0>
100491064: 912c43f5    	add	x21, sp, #0xb10
100491068: f903a3e8    	str	x8, [sp, #0x740]
10049106c: 911e43e8    	add	x8, sp, #0x790
100491070: aa1403e0    	mov	x0, x20
100491074: 9402049d    	bl	0x1005122e8 <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::items>
100491078: 3cc08320    	ldur	q0, [x25, #0x8]
10049107c: 3d8007e0    	str	q0, [sp, #0x10]
100491080: f943cbe8    	ldr	x8, [sp, #0x790]
100491084: f943d7e9    	ldr	x9, [sp, #0x7a8]
100491088: f90013e9    	str	x9, [sp, #0x20]
10049108c: b100051f    	cmn	x8, #0x1
100491090: 54000f80    	b.eq	0x100491280 <conductor_lib::run::{closure#0}+0x22ac>
100491094: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100491098: 3d82cfe0    	str	q0, [sp, #0xb30]
10049109c: 3dc007e0    	ldr	q0, [sp, #0x10]
1004910a0: 3c8082a0    	stur	q0, [x21, #0x8]
1004910a4: f94013e9    	ldr	x9, [sp, #0x20]
1004910a8: f90597e9    	str	x9, [sp, #0xb28]
1004910ac: f9058be8    	str	x8, [sp, #0xb10]
1004910b0: 52800600    	mov	w0, #0x30               ; =48
1004910b4: 9400a811    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004910b8: aa0003f3    	mov	x19, x0
1004910bc: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
1004910c0: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
1004910c4: ad000400    	stp	q0, q1, [x0]
1004910c8: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
1004910cc: 3d800800    	str	q0, [x0, #0x20]
1004910d0: f943a3e8    	ldr	x8, [sp, #0x740]
1004910d4: 92800009    	mov	x9, #-0x1               ; =-1
1004910d8: f8690108    	ldaddl	x9, x8, [x8]
1004910dc: f100051f    	cmp	x8, #0x1
1004910e0: 54ffd621    	b.ne	0x100490ba4 <conductor_lib::run::{closure#0}+0x1bd0>
1004910e4: d50339bf    	dmb	ishld
1004910e8: 911d03e0    	add	x0, sp, #0x740
1004910ec: 9409ce97    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004910f0: 17fffead    	b	0x100490ba4 <conductor_lib::run::{closure#0}+0x1bd0>
1004910f4: d00083e8    	adrp	x8, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004910f8: 91027508    	add	x8, x8, #0x9d
1004910fc: 52800a69    	mov	w9, #0x53               ; =83
100491100: f903cbe8    	str	x8, [sp, #0x790]
100491104: f903cfe9    	str	x9, [sp, #0x798]
100491108: 911e43e8    	add	x8, sp, #0x790
10049110c: 90001589    	adrp	x9, 0x100741000 <<&tungstenite::protocol::message::Message as core::fmt::Debug>::fmt+0xb8>
100491110: 9107b129    	add	x9, x9, #0x1ec
100491114: f9058be8    	str	x8, [sp, #0xb10]
100491118: f9058fe9    	str	x9, [sp, #0xb18]
10049111c: b0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100491120: 91136000    	add	x0, x0, #0x4d8
100491124: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491128: 91194042    	add	x2, x2, #0x650
10049112c: 912c43e1    	add	x1, sp, #0xb10
100491130: 943bbc5b    	bl	0x10138029c <core::panicking::panic_fmt>
100491134: 140003b5    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491138: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10049113c: 3dc1ebe1    	ldr	q1, [sp, #0x7a0]
100491140: 3d82c7e0    	str	q0, [sp, #0xb10]
100491144: 3d82cbe1    	str	q1, [sp, #0xb20]
100491148: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10049114c: 3d82cfe0    	str	q0, [sp, #0xb30]
100491150: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491154: 91375800    	add	x0, x0, #0xdd6
100491158: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
10049115c: 91244063    	add	x3, x3, #0x910
100491160: d0015f44    	adrp	x4, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491164: 9105c084    	add	x4, x4, #0x170
100491168: 912c43e2    	add	x2, sp, #0xb10
10049116c: 52800461    	mov	w1, #0x23               ; =35
100491170: 943bbbcf    	bl	0x1013800ac <core::result::unwrap_failed>
100491174: 140003a5    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491178: f907a3e8    	str	x8, [sp, #0xf40]
10049117c: f907a7e9    	str	x9, [sp, #0xf48]
100491180: b100051f    	cmn	x8, #0x1
100491184: 54000060    	b.eq	0x100491190 <conductor_lib::run::{closure#0}+0x21bc>
100491188: 913d03e0    	add	x0, sp, #0xf40
10049118c: 97ff37c6    	bl	0x10045f0a4 <core::ptr::drop_glue::<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>
100491190: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491194: 91296042    	add	x2, x2, #0xa58
100491198: 911e43e8    	add	x8, sp, #0x790
10049119c: 911d03e1    	add	x1, sp, #0x740
1004911a0: aa1403e0    	mov	x0, x20
1004911a4: d2800003    	mov	x3, #0x0                ; =0
1004911a8: 94020595    	bl	0x1005127fc <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert>
1004911ac: f943cbe8    	ldr	x8, [sp, #0x790]
1004911b0: b100051f    	cmn	x8, #0x1
1004911b4: 54001560    	b.eq	0x100491460 <conductor_lib::run::{closure#0}+0x248c>
1004911b8: 3dc1e7e0    	ldr	q0, [sp, #0x790]
1004911bc: 3dc1ebe1    	ldr	q1, [sp, #0x7a0]
1004911c0: 3d82c7e0    	str	q0, [sp, #0xb10]
1004911c4: 3d82cbe1    	str	q1, [sp, #0xb20]
1004911c8: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
1004911cc: 3d82cfe0    	str	q0, [sp, #0xb30]
1004911d0: 52800600    	mov	w0, #0x30               ; =48
1004911d4: 9400a7c9    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004911d8: aa0003f3    	mov	x19, x0
1004911dc: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
1004911e0: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
1004911e4: ad000400    	stp	q0, q1, [x0]
1004911e8: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
1004911ec: 3d800800    	str	q0, [x0, #0x20]
1004911f0: f943a3e8    	ldr	x8, [sp, #0x740]
1004911f4: 92800009    	mov	x9, #-0x1               ; =-1
1004911f8: f8690108    	ldaddl	x9, x8, [x8]
1004911fc: f100051f    	cmp	x8, #0x1
100491200: 54ffc721    	b.ne	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491204: d50339bf    	dmb	ishld
100491208: 911d03e0    	add	x0, sp, #0x740
10049120c: 9409cec1    	bl	0x100704d10 <<alloc::sync::Arc<tauri::menu::PredefinedMenuItemInner>>::drop_slow>
100491210: 17fffe35    	b	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491214: 52800100    	mov	w0, #0x8                ; =8
100491218: 52805b01    	mov	w1, #0x2d8              ; =728
10049121c: 943bbb1f    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
100491220: 1400037a    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491224: 91004380    	add	x0, x28, #0x10
100491228: 943a62b0    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
10049122c: 17fffb40    	b	0x10048ff2c <conductor_lib::run::{closure#0}+0xf58>
100491230: 943bba04    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
100491234: 52000018    	eor	w24, w0, #0x1
100491238: 39406388    	ldrb	w8, [x28, #0x18]
10049123c: 34ff68a8    	cbz	w8, 0x10048ff50 <conductor_lib::run::{closure#0}+0xf7c>
100491240: f9058bf7    	str	x23, [sp, #0xb10]
100491244: 392c63f8    	strb	w24, [sp, #0xb18]
100491248: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
10049124c: 91137400    	add	x0, x0, #0x4dd
100491250: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491254: 9119c063    	add	x3, x3, #0x670
100491258: f0015f24    	adrp	x4, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
10049125c: 91182084    	add	x4, x4, #0x608
100491260: 912c43e2    	add	x2, sp, #0xb10
100491264: 52800561    	mov	w1, #0x2b               ; =43
100491268: 943bbb91    	bl	0x1013800ac <core::result::unwrap_failed>
10049126c: 14000367    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491270: 52800100    	mov	w0, #0x8                ; =8
100491274: 52800101    	mov	w1, #0x8                ; =8
100491278: 943bbb08    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
10049127c: 14000363    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491280: f94013f5    	ldr	x21, [sp, #0x20]
100491284: 910043e0    	add	x0, sp, #0x10
100491288: 97ff2def    	bl	0x10045ca44 <core::ptr::drop_glue::<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>>
10049128c: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491290: 9127e042    	add	x2, x2, #0x9f8
100491294: 912c43e8    	add	x8, sp, #0xb10
100491298: 911e23e1    	add	x1, sp, #0x788
10049129c: aa1403e0    	mov	x0, x20
1004912a0: aa1503e3    	mov	x3, x21
1004912a4: 94020556    	bl	0x1005127fc <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert>
1004912a8: f9458be8    	ldr	x8, [sp, #0xb10]
1004912ac: b100051f    	cmn	x8, #0x1
1004912b0: 54000140    	b.eq	0x1004912d8 <conductor_lib::run::{closure#0}+0x2304>
1004912b4: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004912b8: 913d3000    	add	x0, x0, #0xf4c
1004912bc: 52800d61    	mov	w1, #0x6b               ; =107
1004912c0: 94399cd1    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004912c4: f9458be8    	ldr	x8, [sp, #0xb10]
1004912c8: b100051f    	cmn	x8, #0x1
1004912cc: 54000060    	b.eq	0x1004912d8 <conductor_lib::run::{closure#0}+0x2304>
1004912d0: 912c43e0    	add	x0, sp, #0xb10
1004912d4: 97ff6aac    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004912d8: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004912dc: 9127e042    	add	x2, x2, #0x9f8
1004912e0: 912c43e8    	add	x8, sp, #0xb10
1004912e4: 911d03e1    	add	x1, sp, #0x740
1004912e8: 910006a3    	add	x3, x21, #0x1
1004912ec: aa1403e0    	mov	x0, x20
1004912f0: 94020543    	bl	0x1005127fc <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert>
1004912f4: f9458be8    	ldr	x8, [sp, #0xb10]
1004912f8: b100051f    	cmn	x8, #0x1
1004912fc: 540000a0    	b.eq	0x100491310 <conductor_lib::run::{closure#0}+0x233c>
100491300: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491304: 913e0400    	add	x0, x0, #0xf81
100491308: 52800da1    	mov	w1, #0x6d               ; =109
10049130c: 94399cbe    	bl	0x1012f8604 <std::io::stdio::_eprint>
100491310: f943a3e8    	ldr	x8, [sp, #0x740]
100491314: 92800014    	mov	x20, #-0x1              ; =-1
100491318: f8740108    	ldaddl	x20, x8, [x8]
10049131c: f100051f    	cmp	x8, #0x1
100491320: 54000081    	b.ne	0x100491330 <conductor_lib::run::{closure#0}+0x235c>
100491324: d50339bf    	dmb	ishld
100491328: 911d03e0    	add	x0, sp, #0x740
10049132c: 9409ce07    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491330: f943c7e8    	ldr	x8, [sp, #0x788]
100491334: f8740108    	ldaddl	x20, x8, [x8]
100491338: f100051f    	cmp	x8, #0x1
10049133c: 54000081    	b.ne	0x10049134c <conductor_lib::run::{closure#0}+0x2378>
100491340: d50339bf    	dmb	ishld
100491344: 911e23e0    	add	x0, sp, #0x788
100491348: 9409ce00    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
10049134c: f9458be8    	ldr	x8, [sp, #0xb10]
100491350: b100051f    	cmn	x8, #0x1
100491354: 54000060    	b.eq	0x100491360 <conductor_lib::run::{closure#0}+0x238c>
100491358: 912c43e0    	add	x0, sp, #0xb10
10049135c: 97ff6a8a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100491360: f94793f5    	ldr	x21, [sp, #0xf20]
100491364: b4008215    	cbz	x21, 0x1004923a4 <conductor_lib::run::{closure#0}+0x33d0>
100491368: f9478fe8    	ldr	x8, [sp, #0xf18]
10049136c: 8b151114    	add	x20, x8, x21, lsl #4
100491370: f85f0288    	ldur	x8, [x20, #-0x10]
100491374: f100051f    	cmp	x8, #0x1
100491378: 54008161    	b.ne	0x1004923a4 <conductor_lib::run::{closure#0}+0x33d0>
10049137c: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491380: 913edc00    	add	x0, x0, #0xfb7
100491384: d00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491388: 913f2442    	add	x2, x2, #0xfc9
10049138c: 912c43e8    	add	x8, sp, #0xb10
100491390: 52800241    	mov	w1, #0x12               ; =18
100491394: 52800243    	mov	w3, #0x12               ; =18
100491398: 94011a30    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
10049139c: 911e43e8    	add	x8, sp, #0x790
1004913a0: 912c43e0    	add	x0, sp, #0xb10
1004913a4: aa1303e1    	mov	x1, x19
1004913a8: 94011399    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
1004913ac: f943cbe9    	ldr	x9, [sp, #0x790]
1004913b0: f943cfe8    	ldr	x8, [sp, #0x798]
1004913b4: b100053f    	cmn	x9, #0x1
1004913b8: 54000140    	b.eq	0x1004913e0 <conductor_lib::run::{closure#0}+0x240c>
1004913bc: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
1004913c0: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
1004913c4: 3d82cbe0    	str	q0, [sp, #0xb20]
1004913c8: 3d82cfe1    	str	q1, [sp, #0xb30]
1004913cc: f9058be9    	str	x9, [sp, #0xb10]
1004913d0: f9058fe8    	str	x8, [sp, #0xb18]
1004913d4: 52800600    	mov	w0, #0x30               ; =48
1004913d8: 9400a748    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004913dc: 17fffdbc    	b	0x100490acc <conductor_lib::run::{closure#0}+0x1af8>
1004913e0: f903b3e8    	str	x8, [sp, #0x760]
1004913e4: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004913e8: 913f6c00    	add	x0, x0, #0xfdb
1004913ec: 90008402    	adrp	x2, 0x101511000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.1315+0x86e>
1004913f0: 91328042    	add	x2, x2, #0xca0
1004913f4: 912c43e8    	add	x8, sp, #0xb10
1004913f8: 528001a1    	mov	w1, #0xd                ; =13
1004913fc: 52800083    	mov	w3, #0x4                ; =4
100491400: 94011a16    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491404: 911e43e8    	add	x8, sp, #0x790
100491408: 912c43e0    	add	x0, sp, #0xb10
10049140c: aa1303e1    	mov	x1, x19
100491410: 9401137f    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491414: f943cbe9    	ldr	x9, [sp, #0x790]
100491418: f943cfe8    	ldr	x8, [sp, #0x798]
10049141c: b100053f    	cmn	x9, #0x1
100491420: 54000660    	b.eq	0x1004914ec <conductor_lib::run::{closure#0}+0x2518>
100491424: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100491428: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
10049142c: 3d82cbe0    	str	q0, [sp, #0xb20]
100491430: 3d82cfe1    	str	q1, [sp, #0xb30]
100491434: f9058be9    	str	x9, [sp, #0xb10]
100491438: f9058fe8    	str	x8, [sp, #0xb18]
10049143c: 52800600    	mov	w0, #0x30               ; =48
100491440: 9400a72e    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491444: aa0003f3    	mov	x19, x0
100491448: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10049144c: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491450: ad000400    	stp	q0, q1, [x0]
100491454: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491458: 3d800800    	str	q0, [x0, #0x20]
10049145c: 14000272    	b	0x100491e24 <conductor_lib::run::{closure#0}+0x2e50>
100491460: f943a3e8    	ldr	x8, [sp, #0x740]
100491464: 92800009    	mov	x9, #-0x1               ; =-1
100491468: f8690108    	ldaddl	x9, x8, [x8]
10049146c: f100051f    	cmp	x8, #0x1
100491470: 54000081    	b.ne	0x100491480 <conductor_lib::run::{closure#0}+0x24ac>
100491474: d50339bf    	dmb	ishld
100491478: 911d03e0    	add	x0, sp, #0x740
10049147c: 9409ce25    	bl	0x100704d10 <<alloc::sync::Arc<tauri::menu::PredefinedMenuItemInner>>::drop_slow>
100491480: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491484: 91214000    	add	x0, x0, #0x850
100491488: d00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
10049148c: 9139a842    	add	x2, x2, #0xe6a
100491490: 912c43e8    	add	x8, sp, #0xb10
100491494: 52800221    	mov	w1, #0x11               ; =17
100491498: 52800223    	mov	w3, #0x11               ; =17
10049149c: 940119ef    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
1004914a0: 911e43e8    	add	x8, sp, #0x790
1004914a4: 912c43e0    	add	x0, sp, #0xb10
1004914a8: aa1303e1    	mov	x1, x19
1004914ac: 94011358    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
1004914b0: 911e43f7    	add	x23, sp, #0x790
1004914b4: 912c43f6    	add	x22, sp, #0xb10
1004914b8: f943cbe9    	ldr	x9, [sp, #0x790]
1004914bc: f943cfe8    	ldr	x8, [sp, #0x798]
1004914c0: b100053f    	cmn	x9, #0x1
1004914c4: 540009e0    	b.eq	0x100491600 <conductor_lib::run::{closure#0}+0x262c>
1004914c8: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
1004914cc: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
1004914d0: 3d82cbe0    	str	q0, [sp, #0xb20]
1004914d4: 3d82cfe1    	str	q1, [sp, #0xb30]
1004914d8: f9058be9    	str	x9, [sp, #0xb10]
1004914dc: f9058fe8    	str	x8, [sp, #0xb18]
1004914e0: 52800600    	mov	w0, #0x30               ; =48
1004914e4: 9400a705    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004914e8: 17fffd79    	b	0x100490acc <conductor_lib::run::{closure#0}+0x1af8>
1004914ec: f903b7e8    	str	x8, [sp, #0x768]
1004914f0: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004914f4: 913fa000    	add	x0, x0, #0xfe8
1004914f8: d00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004914fc: 913fd842    	add	x2, x2, #0xff6
100491500: 912c43e8    	add	x8, sp, #0xb10
100491504: 528001c1    	mov	w1, #0xe                ; =14
100491508: 528001c3    	mov	w3, #0xe                ; =14
10049150c: 940119d3    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491510: 911e43e8    	add	x8, sp, #0x790
100491514: 912c43e0    	add	x0, sp, #0xb10
100491518: aa1303e1    	mov	x1, x19
10049151c: 9401133c    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491520: f943cbe9    	ldr	x9, [sp, #0x790]
100491524: f943cfe8    	ldr	x8, [sp, #0x798]
100491528: b100053f    	cmn	x9, #0x1
10049152c: 540016e0    	b.eq	0x100491808 <conductor_lib::run::{closure#0}+0x2834>
100491530: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100491534: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100491538: 3d82cbe0    	str	q0, [sp, #0xb20]
10049153c: 3d82cfe1    	str	q1, [sp, #0xb30]
100491540: f9058be9    	str	x9, [sp, #0xb10]
100491544: f9058fe8    	str	x8, [sp, #0xb18]
100491548: 52800600    	mov	w0, #0x30               ; =48
10049154c: 9400a6eb    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491550: aa0003f3    	mov	x19, x0
100491554: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491558: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
10049155c: ad000400    	stp	q0, q1, [x0]
100491560: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491564: 3d800800    	str	q0, [x0, #0x20]
100491568: 14000227    	b	0x100491e04 <conductor_lib::run::{closure#0}+0x2e30>
10049156c: 52800100    	mov	w0, #0x8                ; =8
100491570: 52800601    	mov	w1, #0x30               ; =48
100491574: 943bba49    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
100491578: 140002a4    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10049157c: aa1403e0    	mov	x0, x20
100491580: 943a61da    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
100491584: 17fffb4d    	b	0x1004902b8 <conductor_lib::run::{closure#0}+0x12e4>
100491588: 943bb92e    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
10049158c: 52000008    	eor	w8, w0, #0x1
100491590: 52824917    	mov	w23, #0x1248            ; =4680
100491594: 38776ac9    	ldrb	w9, [x22, x23]
100491598: 34ff6a09    	cbz	w9, 0x1004902d8 <conductor_lib::run::{closure#0}+0x1304>
10049159c: f9058bf4    	str	x20, [sp, #0xb10]
1004915a0: 392c63e8    	strb	w8, [sp, #0xb18]
1004915a4: f00083c0    	adrp	x0, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
1004915a8: 91175c00    	add	x0, x0, #0x5d7
1004915ac: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
1004915b0: 9115c063    	add	x3, x3, #0x570
1004915b4: f0015f24    	adrp	x4, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
1004915b8: 9100a084    	add	x4, x4, #0x28
1004915bc: 912c43e2    	add	x2, sp, #0xb10
1004915c0: 52800261    	mov	w1, #0x13               ; =19
1004915c4: 943bbaba    	bl	0x1013800ac <core::result::unwrap_failed>
1004915c8: 14000290    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004915cc: 52800100    	mov	w0, #0x8                ; =8
1004915d0: 52800101    	mov	w1, #0x8                ; =8
1004915d4: 943bba31    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
1004915d8: 1400028c    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004915dc: 52800100    	mov	w0, #0x8                ; =8
1004915e0: 52800101    	mov	w1, #0x8                ; =8
1004915e4: 943bba2d    	bl	0x10137fe98 <alloc::alloc::handle_alloc_error>
1004915e8: 14000288    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004915ec: 943bb915    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1004915f0: 370754c0    	tbnz	w0, #0x0, 0x100490088 <conductor_lib::run::{closure#0}+0x10b4>
1004915f4: 52800028    	mov	w8, #0x1                ; =1
1004915f8: 39006388    	strb	w8, [x28, #0x18]
1004915fc: 17fffaa3    	b	0x100490088 <conductor_lib::run::{closure#0}+0x10b4>
100491600: f903c7e8    	str	x8, [sp, #0x788]
100491604: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491608: 9127e042    	add	x2, x2, #0x9f8
10049160c: 911e43e8    	add	x8, sp, #0x790
100491610: 911e23e1    	add	x1, sp, #0x788
100491614: aa1403e0    	mov	x0, x20
100491618: 52800023    	mov	w3, #0x1                ; =1
10049161c: 94020478    	bl	0x1005127fc <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert>
100491620: f943cbe8    	ldr	x8, [sp, #0x790]
100491624: b100051f    	cmn	x8, #0x1
100491628: 54000300    	b.eq	0x100491688 <conductor_lib::run::{closure#0}+0x26b4>
10049162c: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491630: 9127e042    	add	x2, x2, #0x9f8
100491634: 912c43e8    	add	x8, sp, #0xb10
100491638: 911e23e1    	add	x1, sp, #0x788
10049163c: aa1403e0    	mov	x0, x20
100491640: 940203bb    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100491644: f9458be8    	ldr	x8, [sp, #0xb10]
100491648: b100051f    	cmn	x8, #0x1
10049164c: 54000140    	b.eq	0x100491674 <conductor_lib::run::{closure#0}+0x26a0>
100491650: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491654: 9139ec00    	add	x0, x0, #0xe7b
100491658: 52800ce1    	mov	w1, #0x67               ; =103
10049165c: 94399bea    	bl	0x1012f8604 <std::io::stdio::_eprint>
100491660: f9458be8    	ldr	x8, [sp, #0xb10]
100491664: b100051f    	cmn	x8, #0x1
100491668: 54000060    	b.eq	0x100491674 <conductor_lib::run::{closure#0}+0x26a0>
10049166c: 912c43e0    	add	x0, sp, #0xb10
100491670: 97ff69c5    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100491674: f943cbe8    	ldr	x8, [sp, #0x790]
100491678: b100051f    	cmn	x8, #0x1
10049167c: 54000060    	b.eq	0x100491688 <conductor_lib::run::{closure#0}+0x26b4>
100491680: 911e43e0    	add	x0, sp, #0x790
100491684: 97ff69c0    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100491688: d00083c0    	adrp	x0, 0x10150b000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0x9335>
10049168c: 912e0000    	add	x0, x0, #0xb80
100491690: d00083e2    	adrp	x2, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491694: 913ab842    	add	x2, x2, #0xeae
100491698: 912c43e8    	add	x8, sp, #0xb10
10049169c: 52800101    	mov	w1, #0x8                ; =8
1004916a0: 52800163    	mov	w3, #0xb                ; =11
1004916a4: 9401196d    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
1004916a8: d00083e1    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
1004916ac: 913ae421    	add	x1, x1, #0xeb9
1004916b0: 911e43e8    	add	x8, sp, #0x790
1004916b4: 912c43e0    	add	x0, sp, #0xb10
1004916b8: 52800162    	mov	w2, #0xb                ; =11
1004916bc: 9401129a    	bl	0x1004d6124 <<tauri::menu::builders::normal::MenuItemBuilder>::accelerator::<&str>>
1004916c0: 910043e8    	add	x8, sp, #0x10
1004916c4: 911e43e0    	add	x0, sp, #0x790
1004916c8: aa1303e1    	mov	x1, x19
1004916cc: 940112d0    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
1004916d0: a94123e9    	ldp	x9, x8, [sp, #0x10]
1004916d4: b100053f    	cmn	x9, #0x1
1004916d8: 54000ea0    	b.eq	0x1004918ac <conductor_lib::run::{closure#0}+0x28d8>
1004916dc: ad4107e0    	ldp	q0, q1, [sp, #0x20]
1004916e0: 3d82cbe0    	str	q0, [sp, #0xb20]
1004916e4: 3d82cfe1    	str	q1, [sp, #0xb30]
1004916e8: f9058be9    	str	x9, [sp, #0xb10]
1004916ec: f9058fe8    	str	x8, [sp, #0xb18]
1004916f0: 52800600    	mov	w0, #0x30               ; =48
1004916f4: 9400a681    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
1004916f8: aa0003f3    	mov	x19, x0
1004916fc: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491700: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491704: ad000400    	stp	q0, q1, [x0]
100491708: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
10049170c: 3d800800    	str	q0, [x0, #0x20]
100491710: 14000151    	b	0x100491c54 <conductor_lib::run::{closure#0}+0x2c80>
100491714: aa1503f9    	mov	x25, x21
100491718: aa1403e0    	mov	x0, x20
10049171c: 943a6173    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
100491720: 17fffb1d    	b	0x100490394 <conductor_lib::run::{closure#0}+0x13c0>
100491724: aa1503f9    	mov	x25, x21
100491728: 943bb8c6    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
10049172c: 38776ac8    	ldrb	w8, [x22, x23]
100491730: 35006468    	cbnz	w8, 0x1004923bc <conductor_lib::run::{closure#0}+0x33e8>
100491734: f9492ad8    	ldr	x24, [x22, #0x1250]
100491738: f9058bf8    	str	x24, [sp, #0xb10]
10049173c: f9092adf    	str	xzr, [x22, #0x1250]
100491740: 35ff63e0    	cbnz	w0, 0x1004903bc <conductor_lib::run::{closure#0}+0x13e8>
100491744: 17fffb21    	b	0x1004903c8 <conductor_lib::run::{closure#0}+0x13f4>
100491748: 52800008    	mov	w8, #0x0                ; =0
10049174c: f9058bf4    	str	x20, [sp, #0xb10]
100491750: 392c63e8    	strb	w8, [sp, #0xb18]
100491754: f00083c0    	adrp	x0, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
100491758: 91175c00    	add	x0, x0, #0x5d7
10049175c: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491760: 9115c063    	add	x3, x3, #0x570
100491764: f0015f24    	adrp	x4, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
100491768: 9100a084    	add	x4, x4, #0x28
10049176c: 912c43e2    	add	x2, sp, #0xb10
100491770: 52800261    	mov	w1, #0x13               ; =19
100491774: 943bba4e    	bl	0x1013800ac <core::result::unwrap_failed>
100491778: 14000224    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
10049177c: aa1403e0    	mov	x0, x20
100491780: 943a615a    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
100491784: 17fffb1f    	b	0x100490400 <conductor_lib::run::{closure#0}+0x142c>
100491788: 943bb8ae    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
10049178c: 52000015    	eor	w21, w0, #0x1
100491790: 38776ac8    	ldrb	w8, [x22, x23]
100491794: 34ff6448    	cbz	w8, 0x10049041c <conductor_lib::run::{closure#0}+0x1448>
100491798: f9058bf4    	str	x20, [sp, #0xb10]
10049179c: 392c63f5    	strb	w21, [sp, #0xb18]
1004917a0: f00083c0    	adrp	x0, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
1004917a4: 91175c00    	add	x0, x0, #0x5d7
1004917a8: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
1004917ac: 9115c063    	add	x3, x3, #0x570
1004917b0: f0015f24    	adrp	x4, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
1004917b4: 9100a084    	add	x4, x4, #0x28
1004917b8: 912c43e2    	add	x2, sp, #0xb10
1004917bc: 52800261    	mov	w1, #0x13               ; =19
1004917c0: 943bba3b    	bl	0x1013800ac <core::result::unwrap_failed>
1004917c4: 14000211    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004917c8: 943bb89e    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1004917cc: 37075fe0    	tbnz	w0, #0x0, 0x1004903c8 <conductor_lib::run::{closure#0}+0x13f4>
1004917d0: 52800028    	mov	w8, #0x1                ; =1
1004917d4: 38376ac8    	strb	w8, [x22, x23]
1004917d8: 17fffafc    	b	0x1004903c8 <conductor_lib::run::{closure#0}+0x13f4>
1004917dc: 943bb899    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1004917e0: 37074620    	tbnz	w0, #0x0, 0x1004900a4 <conductor_lib::run::{closure#0}+0x10d0>
1004917e4: 52800028    	mov	w8, #0x1                ; =1
1004917e8: 39006388    	strb	w8, [x28, #0x18]
1004917ec: 17fffa2e    	b	0x1004900a4 <conductor_lib::run::{closure#0}+0x10d0>
1004917f0: 52800039    	mov	w25, #0x1               ; =1
1004917f4: 943bb893    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1004917f8: 370758e0    	tbnz	w0, #0x0, 0x100490314 <conductor_lib::run::{closure#0}+0x1340>
1004917fc: 52800028    	mov	w8, #0x1                ; =1
100491800: 38376ac8    	strb	w8, [x22, x23]
100491804: 17fffac4    	b	0x100490314 <conductor_lib::run::{closure#0}+0x1340>
100491808: f903bbe8    	str	x8, [sp, #0x770]
10049180c: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491810: 91001000    	add	x0, x0, #0x4
100491814: f00083e2    	adrp	x2, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491818: 91003442    	add	x2, x2, #0xd
10049181c: 912c43e8    	add	x8, sp, #0xb10
100491820: 52800121    	mov	w1, #0x9                ; =9
100491824: 52800123    	mov	w3, #0x9                ; =9
100491828: 9401190c    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
10049182c: 911e43e8    	add	x8, sp, #0x790
100491830: 912c43e0    	add	x0, sp, #0xb10
100491834: aa1303e1    	mov	x1, x19
100491838: 94011275    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
10049183c: f943cbe9    	ldr	x9, [sp, #0x790]
100491840: f943cfe8    	ldr	x8, [sp, #0x798]
100491844: b100053f    	cmn	x9, #0x1
100491848: 54000cc0    	b.eq	0x1004919e0 <conductor_lib::run::{closure#0}+0x2a0c>
10049184c: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100491850: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100491854: 3d82cbe0    	str	q0, [sp, #0xb20]
100491858: 3d82cfe1    	str	q1, [sp, #0xb30]
10049185c: f9058be9    	str	x9, [sp, #0xb10]
100491860: f9058fe8    	str	x8, [sp, #0xb18]
100491864: 52800600    	mov	w0, #0x30               ; =48
100491868: 9400a624    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
10049186c: aa0003f3    	mov	x19, x0
100491870: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491874: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491878: ad000400    	stp	q0, q1, [x0]
10049187c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491880: 3d800800    	str	q0, [x0, #0x20]
100491884: 14000158    	b	0x100491de4 <conductor_lib::run::{closure#0}+0x2e10>
100491888: 52800020    	mov	w0, #0x1                ; =1
10049188c: aa1803e1    	mov	x1, x24
100491890: 943bb988    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491894: 140001dd    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491898: 943bb86a    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
10049189c: 37075e80    	tbnz	w0, #0x0, 0x10049046c <conductor_lib::run::{closure#0}+0x1498>
1004918a0: 52800028    	mov	w8, #0x1                ; =1
1004918a4: 38376ac8    	strb	w8, [x22, x23]
1004918a8: 17fffaf1    	b	0x10049046c <conductor_lib::run::{closure#0}+0x1498>
1004918ac: f903a3e8    	str	x8, [sp, #0x740]
1004918b0: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004918b4: 9127e042    	add	x2, x2, #0x9f8
1004918b8: 911e43e8    	add	x8, sp, #0x790
1004918bc: 911d03e1    	add	x1, sp, #0x740
1004918c0: aa1403e0    	mov	x0, x20
1004918c4: 52800063    	mov	w3, #0x3                ; =3
1004918c8: 940203cd    	bl	0x1005127fc <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::insert>
1004918cc: f943cbe8    	ldr	x8, [sp, #0x790]
1004918d0: b100051f    	cmn	x8, #0x1
1004918d4: 54000300    	b.eq	0x100491934 <conductor_lib::run::{closure#0}+0x2960>
1004918d8: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004918dc: 9127e042    	add	x2, x2, #0x9f8
1004918e0: 912c43e8    	add	x8, sp, #0xb10
1004918e4: 911d03e1    	add	x1, sp, #0x740
1004918e8: aa1403e0    	mov	x0, x20
1004918ec: 94020310    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
1004918f0: f9458be8    	ldr	x8, [sp, #0xb10]
1004918f4: b100051f    	cmn	x8, #0x1
1004918f8: 54000140    	b.eq	0x100491920 <conductor_lib::run::{closure#0}+0x294c>
1004918fc: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491900: 913b1000    	add	x0, x0, #0xec4
100491904: 52800aa1    	mov	w1, #0x55               ; =85
100491908: 94399b3f    	bl	0x1012f8604 <std::io::stdio::_eprint>
10049190c: f9458be8    	ldr	x8, [sp, #0xb10]
100491910: b100051f    	cmn	x8, #0x1
100491914: 54000060    	b.eq	0x100491920 <conductor_lib::run::{closure#0}+0x294c>
100491918: 912c43e0    	add	x0, sp, #0xb10
10049191c: 97ff691a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100491920: f943cbe8    	ldr	x8, [sp, #0x790]
100491924: b100051f    	cmn	x8, #0x1
100491928: 54000060    	b.eq	0x100491934 <conductor_lib::run::{closure#0}+0x2960>
10049192c: 911e43e0    	add	x0, sp, #0x790
100491930: 97ff6915    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100491934: 911e43e8    	add	x8, sp, #0x790
100491938: aa1403e0    	mov	x0, x20
10049193c: 9402026b    	bl	0x1005122e8 <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::items>
100491940: 3cc082e0    	ldur	q0, [x23, #0x8]
100491944: 3d8007e0    	str	q0, [sp, #0x10]
100491948: f943cbe8    	ldr	x8, [sp, #0x790]
10049194c: f943d7e9    	ldr	x9, [sp, #0x7a8]
100491950: f90013e9    	str	x9, [sp, #0x20]
100491954: b100051f    	cmn	x8, #0x1
100491958: 54000a40    	b.eq	0x100491aa0 <conductor_lib::run::{closure#0}+0x2acc>
10049195c: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100491960: 3d82cfe0    	str	q0, [sp, #0xb30]
100491964: 3dc007e0    	ldr	q0, [sp, #0x10]
100491968: 3c8082c0    	stur	q0, [x22, #0x8]
10049196c: f94013e9    	ldr	x9, [sp, #0x20]
100491970: f90597e9    	str	x9, [sp, #0xb28]
100491974: f9058be8    	str	x8, [sp, #0xb10]
100491978: 52800600    	mov	w0, #0x30               ; =48
10049197c: 9400a5df    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491980: 140000a7    	b	0x100491c1c <conductor_lib::run::{closure#0}+0x2c48>
100491984: aa1403e0    	mov	x0, x20
100491988: 943a60d8    	bl	0x101329ce8 <<std::sys::sync::once_box::OnceBox<std::sys::pal::unix::sync::mutex::Mutex>>::initialize::<<std::sys::sync::mutex::pthread::Mutex>::get::{closure#0}>>
10049198c: 94394919    	bl	0x1012e3df0 <<std::sys::pal::unix::sync::mutex::Mutex>::lock>
100491990: f9400368    	ldr	x8, [x27]
100491994: f240f91f    	tst	x8, #0x7fffffffffffffff
100491998: 54ff6380    	b.eq	0x100490608 <conductor_lib::run::{closure#0}+0x1634>
10049199c: 943bb829    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
1004919a0: 52000008    	eor	w8, w0, #0x1
1004919a4: 52824916    	mov	w22, #0x1248            ; =4680
1004919a8: 38766aa9    	ldrb	w9, [x21, x22]
1004919ac: 34ff6369    	cbz	w9, 0x100490618 <conductor_lib::run::{closure#0}+0x1644>
1004919b0: f9058bf4    	str	x20, [sp, #0xb10]
1004919b4: 392c63e8    	strb	w8, [sp, #0xb18]
1004919b8: f00083c0    	adrp	x0, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
1004919bc: 91175c00    	add	x0, x0, #0x5d7
1004919c0: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
1004919c4: 9115c063    	add	x3, x3, #0x570
1004919c8: f0015f24    	adrp	x4, 0x103078000 <_anon.81fa206408a01f88150d6a7769a779aa.2+0x928>
1004919cc: 9100a084    	add	x4, x4, #0x28
1004919d0: 912c43e2    	add	x2, sp, #0xb10
1004919d4: 52800261    	mov	w1, #0x13               ; =19
1004919d8: 943bb9b5    	bl	0x1013800ac <core::result::unwrap_failed>
1004919dc: 1400018b    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
1004919e0: f903bfe8    	str	x8, [sp, #0x778]
1004919e4: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004919e8: 91005800    	add	x0, x0, #0x16
1004919ec: f00083c2    	adrp	x2, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
1004919f0: 91018042    	add	x2, x2, #0x60
1004919f4: 912c43e8    	add	x8, sp, #0xb10
1004919f8: 528001a1    	mov	w1, #0xd                ; =13
1004919fc: 52800203    	mov	w3, #0x10               ; =16
100491a00: 94011896    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491a04: f00083e1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491a08: 91008c21    	add	x1, x1, #0x23
100491a0c: 911e43e8    	add	x8, sp, #0x790
100491a10: 912c43e0    	add	x0, sp, #0xb10
100491a14: 528001e2    	mov	w2, #0xf                ; =15
100491a18: 940111c3    	bl	0x1004d6124 <<tauri::menu::builders::normal::MenuItemBuilder>::accelerator::<&str>>
100491a1c: 910043e8    	add	x8, sp, #0x10
100491a20: 911e43e0    	add	x0, sp, #0x790
100491a24: aa1303e1    	mov	x1, x19
100491a28: 940111f9    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491a2c: a94123e9    	ldp	x9, x8, [sp, #0x10]
100491a30: b100053f    	cmn	x9, #0x1
100491a34: 54000620    	b.eq	0x100491af8 <conductor_lib::run::{closure#0}+0x2b24>
100491a38: ad4107e0    	ldp	q0, q1, [sp, #0x20]
100491a3c: 3d82cbe0    	str	q0, [sp, #0xb20]
100491a40: 3d82cfe1    	str	q1, [sp, #0xb30]
100491a44: f9058be9    	str	x9, [sp, #0xb10]
100491a48: f9058fe8    	str	x8, [sp, #0xb18]
100491a4c: 52800600    	mov	w0, #0x30               ; =48
100491a50: 9400a5aa    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491a54: aa0003f3    	mov	x19, x0
100491a58: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491a5c: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491a60: ad000400    	stp	q0, q1, [x0]
100491a64: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491a68: 3d800800    	str	q0, [x0, #0x20]
100491a6c: 140000d6    	b	0x100491dc4 <conductor_lib::run::{closure#0}+0x2df0>
100491a70: b00083e8    	adrp	x8, 0x10150e000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.321+0x12d8>
100491a74: 912aad08    	add	x8, x8, #0xaab
100491a78: 52800569    	mov	w9, #0x2b               ; =43
100491a7c: f903cbe8    	str	x8, [sp, #0x790]
100491a80: f903cfe9    	str	x9, [sp, #0x798]
100491a84: 911e43e8    	add	x8, sp, #0x790
100491a88: 17fffc7e    	b	0x100490c80 <conductor_lib::run::{closure#0}+0x1cac>
100491a8c: 943bb7ed    	bl	0x10137fa40 <std::panicking::panic_count::is_zero_slow_path>
100491a90: 37075dc0    	tbnz	w0, #0x0, 0x100490648 <conductor_lib::run::{closure#0}+0x1674>
100491a94: 52800028    	mov	w8, #0x1                ; =1
100491a98: 38366aa8    	strb	w8, [x21, x22]
100491a9c: 17fffaeb    	b	0x100490648 <conductor_lib::run::{closure#0}+0x1674>
100491aa0: f94013f5    	ldr	x21, [sp, #0x20]
100491aa4: 910043e0    	add	x0, sp, #0x10
100491aa8: 97ff2be7    	bl	0x10045ca44 <core::ptr::drop_glue::<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>>
100491aac: d10006a1    	sub	x1, x21, #0x1
100491ab0: 911e43e8    	add	x8, sp, #0x790
100491ab4: aa1403e0    	mov	x0, x20
100491ab8: 94020600    	bl	0x1005132b8 <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::remove_at>
100491abc: f943cbea    	ldr	x10, [sp, #0x790]
100491ac0: f943cfe8    	ldr	x8, [sp, #0x798]
100491ac4: f943d3e9    	ldr	x9, [sp, #0x7a0]
100491ac8: b100055f    	cmn	x10, #0x1
100491acc: 54000660    	b.eq	0x100491b98 <conductor_lib::run::{closure#0}+0x2bc4>
100491ad0: 3cc182e0    	ldur	q0, [x23, #0x18]
100491ad4: 3c8182c0    	stur	q0, [x22, #0x18]
100491ad8: f943dfeb    	ldr	x11, [sp, #0x7b8]
100491adc: f9058bea    	str	x10, [sp, #0xb10]
100491ae0: f9058fe8    	str	x8, [sp, #0xb18]
100491ae4: f9059feb    	str	x11, [sp, #0xb38]
100491ae8: f90593e9    	str	x9, [sp, #0xb20]
100491aec: 52800600    	mov	w0, #0x30               ; =48
100491af0: 9400a582    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491af4: 1400004a    	b	0x100491c1c <conductor_lib::run::{closure#0}+0x2c48>
100491af8: f903c3e8    	str	x8, [sp, #0x780]
100491afc: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491b00: 9100c800    	add	x0, x0, #0x32
100491b04: f00083e2    	adrp	x2, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491b08: 91010442    	add	x2, x2, #0x41
100491b0c: 912c43e8    	add	x8, sp, #0xb10
100491b10: 528001e1    	mov	w1, #0xf                ; =15
100491b14: 52800243    	mov	w3, #0x12               ; =18
100491b18: 94011850    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491b1c: 911e43e8    	add	x8, sp, #0x790
100491b20: 912c43e0    	add	x0, sp, #0xb10
100491b24: aa1303e1    	mov	x1, x19
100491b28: 940111b9    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491b2c: f943cbe9    	ldr	x9, [sp, #0x790]
100491b30: f943cfe8    	ldr	x8, [sp, #0x798]
100491b34: b100053f    	cmn	x9, #0x1
100491b38: 54000e80    	b.eq	0x100491d08 <conductor_lib::run::{closure#0}+0x2d34>
100491b3c: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100491b40: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100491b44: 3d82cbe0    	str	q0, [sp, #0xb20]
100491b48: 3d82cfe1    	str	q1, [sp, #0xb30]
100491b4c: f9058be9    	str	x9, [sp, #0xb10]
100491b50: f9058fe8    	str	x8, [sp, #0xb18]
100491b54: 52800600    	mov	w0, #0x30               ; =48
100491b58: 9400a568    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491b5c: aa0003f3    	mov	x19, x0
100491b60: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491b64: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491b68: ad000400    	stp	q0, q1, [x0]
100491b6c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491b70: 3d800800    	str	q0, [x0, #0x20]
100491b74: 1400008c    	b	0x100491da4 <conductor_lib::run::{closure#0}+0x2dd0>
100491b78: 52800020    	mov	w0, #0x1                ; =1
100491b7c: 52800081    	mov	w1, #0x4                ; =4
100491b80: 943bb8cc    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491b84: 14000121    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491b88: 52800020    	mov	w0, #0x1                ; =1
100491b8c: 52800021    	mov	w1, #0x1                ; =1
100491b90: 943bb8c8    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491b94: 1400011d    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491b98: a90127e8    	stp	x8, x9, [sp, #0x10]
100491b9c: b100051f    	cmn	x8, #0x1
100491ba0: 54000060    	b.eq	0x100491bac <conductor_lib::run::{closure#0}+0x2bd8>
100491ba4: 910043e0    	add	x0, sp, #0x10
100491ba8: 97ff353f    	bl	0x10045f0a4 <core::ptr::drop_glue::<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>
100491bac: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491bb0: 913bb800    	add	x0, x0, #0xeee
100491bb4: 90008402    	adrp	x2, 0x101511000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.1315+0x86e>
100491bb8: 91327042    	add	x2, x2, #0xc9c
100491bbc: 912c43e8    	add	x8, sp, #0xb10
100491bc0: 52800161    	mov	w1, #0xb                ; =11
100491bc4: 52800083    	mov	w3, #0x4                ; =4
100491bc8: 94011824    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491bcc: d00083e1    	adrp	x1, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491bd0: 913be421    	add	x1, x1, #0xef9
100491bd4: 911e43e8    	add	x8, sp, #0x790
100491bd8: 912c43e0    	add	x0, sp, #0xb10
100491bdc: 528000a2    	mov	w2, #0x5                ; =5
100491be0: 94011151    	bl	0x1004d6124 <<tauri::menu::builders::normal::MenuItemBuilder>::accelerator::<&str>>
100491be4: 910043e8    	add	x8, sp, #0x10
100491be8: 911e43e0    	add	x0, sp, #0x790
100491bec: aa1303e1    	mov	x1, x19
100491bf0: 94011187    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491bf4: a94123e9    	ldp	x9, x8, [sp, #0x10]
100491bf8: b100053f    	cmn	x9, #0x1
100491bfc: 54001340    	b.eq	0x100491e64 <conductor_lib::run::{closure#0}+0x2e90>
100491c00: ad4107e0    	ldp	q0, q1, [sp, #0x20]
100491c04: 3d82cbe0    	str	q0, [sp, #0xb20]
100491c08: 3d82cfe1    	str	q1, [sp, #0xb30]
100491c0c: f9058be9    	str	x9, [sp, #0xb10]
100491c10: f9058fe8    	str	x8, [sp, #0xb18]
100491c14: 52800600    	mov	w0, #0x30               ; =48
100491c18: 9400a538    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491c1c: aa0003f3    	mov	x19, x0
100491c20: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491c24: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491c28: ad000400    	stp	q0, q1, [x0]
100491c2c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491c30: 3d800800    	str	q0, [x0, #0x20]
100491c34: f943a3e8    	ldr	x8, [sp, #0x740]
100491c38: 92800009    	mov	x9, #-0x1               ; =-1
100491c3c: f8690108    	ldaddl	x9, x8, [x8]
100491c40: f100051f    	cmp	x8, #0x1
100491c44: 54000081    	b.ne	0x100491c54 <conductor_lib::run::{closure#0}+0x2c80>
100491c48: d50339bf    	dmb	ishld
100491c4c: 911d03e0    	add	x0, sp, #0x740
100491c50: 9409cbbe    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491c54: f943c7e8    	ldr	x8, [sp, #0x788]
100491c58: 92800009    	mov	x9, #-0x1               ; =-1
100491c5c: f8690108    	ldaddl	x9, x8, [x8]
100491c60: f100051f    	cmp	x8, #0x1
100491c64: 54ff7401    	b.ne	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491c68: d50339bf    	dmb	ishld
100491c6c: 911e23e0    	add	x0, sp, #0x788
100491c70: 9409cbb6    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491c74: 17fffb9c    	b	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491c78: 52800020    	mov	w0, #0x1                ; =1
100491c7c: 528000e1    	mov	w1, #0x7                ; =7
100491c80: 943bb88c    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491c84: 140000e1    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491c88: 3dc3d3e0    	ldr	q0, [sp, #0xf40]
100491c8c: 3dc3d7e1    	ldr	q1, [sp, #0xf50]
100491c90: 3d81bfe0    	str	q0, [sp, #0x6f0]
100491c94: 3d81c3e1    	str	q1, [sp, #0x700]
100491c98: 3dc3dbe2    	ldr	q2, [sp, #0xf60]
100491c9c: 3d81c7e2    	str	q2, [sp, #0x710]
100491ca0: 3d844fe0    	str	q0, [sp, #0x1130]
100491ca4: 3d8453e1    	str	q1, [sp, #0x1140]
100491ca8: 3d8457e2    	str	q2, [sp, #0x1150]
100491cac: 14000007    	b	0x100491cc8 <conductor_lib::run::{closure#0}+0x2cf4>
100491cb0: 3dc3c7e0    	ldr	q0, [sp, #0xf10]
100491cb4: 3dc3cbe1    	ldr	q1, [sp, #0xf20]
100491cb8: 3d844fe0    	str	q0, [sp, #0x1130]
100491cbc: 3d8453e1    	str	q1, [sp, #0x1140]
100491cc0: 3dc3cfe0    	ldr	q0, [sp, #0xf30]
100491cc4: 3d8457e0    	str	q0, [sp, #0x1150]
100491cc8: 3dc44fe0    	ldr	q0, [sp, #0x1130]
100491ccc: 3dc453e1    	ldr	q1, [sp, #0x1140]
100491cd0: 3d82c7e0    	str	q0, [sp, #0xb10]
100491cd4: 3d82cbe1    	str	q1, [sp, #0xb20]
100491cd8: 3dc457e0    	ldr	q0, [sp, #0x1150]
100491cdc: 3d82cfe0    	str	q0, [sp, #0xb30]
100491ce0: d00083e0    	adrp	x0, 0x10150f000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.451+0x7>
100491ce4: 9136d800    	add	x0, x0, #0xdb6
100491ce8: d0015f43    	adrp	x3, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491cec: 91244063    	add	x3, x3, #0x910
100491cf0: d0015f44    	adrp	x4, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491cf4: 91056084    	add	x4, x4, #0x158
100491cf8: 912c43e2    	add	x2, sp, #0xb10
100491cfc: 52800381    	mov	w1, #0x1c               ; =28
100491d00: 943bb8eb    	bl	0x1013800ac <core::result::unwrap_failed>
100491d04: 140000c1    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491d08: f903c7e8    	str	x8, [sp, #0x788]
100491d0c: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491d10: 91014c00    	add	x0, x0, #0x53
100491d14: f00083e2    	adrp	x2, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491d18: 91017842    	add	x2, x2, #0x5e
100491d1c: 912c43e8    	add	x8, sp, #0xb10
100491d20: 52800161    	mov	w1, #0xb                ; =11
100491d24: 528001c3    	mov	w3, #0xe                ; =14
100491d28: 940117cc    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491d2c: 911e43e8    	add	x8, sp, #0x790
100491d30: 912c43e0    	add	x0, sp, #0xb10
100491d34: aa1303e1    	mov	x1, x19
100491d38: 94011135    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491d3c: f943cbe9    	ldr	x9, [sp, #0x790]
100491d40: f943cfe8    	ldr	x8, [sp, #0x798]
100491d44: b100053f    	cmn	x9, #0x1
100491d48: 54001020    	b.eq	0x100491f4c <conductor_lib::run::{closure#0}+0x2f78>
100491d4c: 3dc1ebe0    	ldr	q0, [sp, #0x7a0]
100491d50: 3dc1efe1    	ldr	q1, [sp, #0x7b0]
100491d54: 3d82cbe0    	str	q0, [sp, #0xb20]
100491d58: 3d82cfe1    	str	q1, [sp, #0xb30]
100491d5c: f9058be9    	str	x9, [sp, #0xb10]
100491d60: f9058fe8    	str	x8, [sp, #0xb18]
100491d64: 52800600    	mov	w0, #0x30               ; =48
100491d68: 9400a4e4    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491d6c: aa0003f3    	mov	x19, x0
100491d70: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491d74: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491d78: ad000400    	stp	q0, q1, [x0]
100491d7c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491d80: 3d800800    	str	q0, [x0, #0x20]
100491d84: f943c7e8    	ldr	x8, [sp, #0x788]
100491d88: 92800009    	mov	x9, #-0x1               ; =-1
100491d8c: f8690108    	ldaddl	x9, x8, [x8]
100491d90: f100051f    	cmp	x8, #0x1
100491d94: 54000081    	b.ne	0x100491da4 <conductor_lib::run::{closure#0}+0x2dd0>
100491d98: d50339bf    	dmb	ishld
100491d9c: 911e23e0    	add	x0, sp, #0x788
100491da0: 9409cb6a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491da4: f943c3e8    	ldr	x8, [sp, #0x780]
100491da8: 92800009    	mov	x9, #-0x1               ; =-1
100491dac: f8690108    	ldaddl	x9, x8, [x8]
100491db0: f100051f    	cmp	x8, #0x1
100491db4: 54000081    	b.ne	0x100491dc4 <conductor_lib::run::{closure#0}+0x2df0>
100491db8: d50339bf    	dmb	ishld
100491dbc: 911e03e0    	add	x0, sp, #0x780
100491dc0: 9409cb62    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491dc4: f943bfe8    	ldr	x8, [sp, #0x778]
100491dc8: 92800009    	mov	x9, #-0x1               ; =-1
100491dcc: f8690108    	ldaddl	x9, x8, [x8]
100491dd0: f100051f    	cmp	x8, #0x1
100491dd4: 54000081    	b.ne	0x100491de4 <conductor_lib::run::{closure#0}+0x2e10>
100491dd8: d50339bf    	dmb	ishld
100491ddc: 911de3e0    	add	x0, sp, #0x778
100491de0: 9409cb5a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491de4: f943bbe8    	ldr	x8, [sp, #0x770]
100491de8: 92800009    	mov	x9, #-0x1               ; =-1
100491dec: f8690108    	ldaddl	x9, x8, [x8]
100491df0: f100051f    	cmp	x8, #0x1
100491df4: 54000081    	b.ne	0x100491e04 <conductor_lib::run::{closure#0}+0x2e30>
100491df8: d50339bf    	dmb	ishld
100491dfc: 911dc3e0    	add	x0, sp, #0x770
100491e00: 9409cb52    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491e04: f943b7e8    	ldr	x8, [sp, #0x768]
100491e08: 92800009    	mov	x9, #-0x1               ; =-1
100491e0c: f8690108    	ldaddl	x9, x8, [x8]
100491e10: f100051f    	cmp	x8, #0x1
100491e14: 54000081    	b.ne	0x100491e24 <conductor_lib::run::{closure#0}+0x2e50>
100491e18: d50339bf    	dmb	ishld
100491e1c: 911da3e0    	add	x0, sp, #0x768
100491e20: 9409cb4a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491e24: f943b3e8    	ldr	x8, [sp, #0x760]
100491e28: 92800009    	mov	x9, #-0x1               ; =-1
100491e2c: f8690108    	ldaddl	x9, x8, [x8]
100491e30: f100051f    	cmp	x8, #0x1
100491e34: 54ff6581    	b.ne	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491e38: d50339bf    	dmb	ishld
100491e3c: 911d83e0    	add	x0, sp, #0x760
100491e40: 9409cb42    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491e44: 17fffb28    	b	0x100490ae4 <conductor_lib::run::{closure#0}+0x1b10>
100491e48: 52800020    	mov	w0, #0x1                ; =1
100491e4c: 52800121    	mov	w1, #0x9                ; =9
100491e50: 943bb818    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491e54: 52800020    	mov	w0, #0x1                ; =1
100491e58: 528000e1    	mov	w1, #0x7                ; =7
100491e5c: 943bb815    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
100491e60: 1400006a    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491e64: f907a3e8    	str	x8, [sp, #0xf40]
100491e68: b0015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100491e6c: 9127e042    	add	x2, x2, #0x9f8
100491e70: 911e43e8    	add	x8, sp, #0x790
100491e74: 913d03e1    	add	x1, sp, #0xf40
100491e78: aa1403e0    	mov	x0, x20
100491e7c: 940201ac    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100491e80: f943cbe8    	ldr	x8, [sp, #0x790]
100491e84: b100051f    	cmn	x8, #0x1
100491e88: 54000c20    	b.eq	0x10049200c <conductor_lib::run::{closure#0}+0x3038>
100491e8c: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100491e90: 3dc1ebe1    	ldr	q1, [sp, #0x7a0]
100491e94: 3d82c7e0    	str	q0, [sp, #0xb10]
100491e98: 3d82cbe1    	str	q1, [sp, #0xb20]
100491e9c: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100491ea0: 3d82cfe0    	str	q0, [sp, #0xb30]
100491ea4: 52800600    	mov	w0, #0x30               ; =48
100491ea8: 9400a494    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491eac: aa0003f3    	mov	x19, x0
100491eb0: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491eb4: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491eb8: ad000400    	stp	q0, q1, [x0]
100491ebc: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491ec0: 3d800800    	str	q0, [x0, #0x20]
100491ec4: f947a3e8    	ldr	x8, [sp, #0xf40]
100491ec8: 92800009    	mov	x9, #-0x1               ; =-1
100491ecc: f8690108    	ldaddl	x9, x8, [x8]
100491ed0: f100051f    	cmp	x8, #0x1
100491ed4: 54ffeb01    	b.ne	0x100491c34 <conductor_lib::run::{closure#0}+0x2c60>
100491ed8: d50339bf    	dmb	ishld
100491edc: 913d03e0    	add	x0, sp, #0xf40
100491ee0: 9409cb1a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491ee4: 17ffff54    	b	0x100491c34 <conductor_lib::run::{closure#0}+0x2c60>
100491ee8: f9458fe8    	ldr	x8, [sp, #0xb18]
100491eec: 92400509    	and	x9, x8, #0x3
100491ef0: d100092a    	sub	x10, x9, #0x2
100491ef4: f100095f    	cmp	x10, #0x2
100491ef8: 54000123    	b.lo	0x100491f1c <conductor_lib::run::{closure#0}+0x2f48>
100491efc: b4000109    	cbz	x9, 0x100491f1c <conductor_lib::run::{closure#0}+0x2f48>
100491f00: d1000508    	sub	x8, x8, #0x1
100491f04: 912c43e9    	add	x9, sp, #0xb10
100491f08: f9058fe8    	str	x8, [sp, #0xb18]
100491f0c: 52800068    	mov	w8, #0x3                ; =3
100491f10: 392c43e8    	strb	w8, [sp, #0xb10]
100491f14: 91002120    	add	x0, x9, #0x8
100491f18: 943a3fec    	bl	0x101321ec8 <<core::io::error::CustomOwner as core::ops::drop::Drop>::drop>
100491f1c: 90007388    	adrp	x8, 0x101301000 <<std::panicking::begin_panic::Payload<&str> as core::panic::PanicPayload>::take_box+0x44>
100491f20: 911b8108    	add	x8, x8, #0x6e0
100491f24: 911d03e9    	add	x9, sp, #0x740
100491f28: f9058be9    	str	x9, [sp, #0xb10]
100491f2c: f9058fe8    	str	x8, [sp, #0xb18]
100491f30: b0014140    	adrp	x0, 0x102cba000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.158+0x145>
100491f34: 9121c800    	add	x0, x0, #0x872
100491f38: d0015f42    	adrp	x2, 0x10307b000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.630+0x9b0>
100491f3c: 91062042    	add	x2, x2, #0x188
100491f40: 912c43e1    	add	x1, sp, #0xb10
100491f44: 943bb8d6    	bl	0x10138029c <core::panicking::panic_fmt>
100491f48: 14000030    	b	0x100492008 <conductor_lib::run::{closure#0}+0x3034>
100491f4c: f903a3e8    	str	x8, [sp, #0x740]
100491f50: f00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491f54: 9101b000    	add	x0, x0, #0x6c
100491f58: f00083c2    	adrp	x2, 0x10150c000 <_anon.dfaadf50359b6dc611e2f8074053fec3.998+0xa335>
100491f5c: 9101c042    	add	x2, x2, #0x70
100491f60: 912c43e8    	add	x8, sp, #0xb10
100491f64: 528000a1    	mov	w1, #0x5                ; =5
100491f68: 52800203    	mov	w3, #0x10               ; =16
100491f6c: 9401173b    	bl	0x1004d7c58 <<tauri::menu::builders::normal::MenuItemBuilder>::with_id::<&str, &str>>
100491f70: f00083e1    	adrp	x1, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100491f74: 9101c421    	add	x1, x1, #0x71
100491f78: 911e43e8    	add	x8, sp, #0x790
100491f7c: 912c43e0    	add	x0, sp, #0xb10
100491f80: 528001e2    	mov	w2, #0xf                ; =15
100491f84: 94011068    	bl	0x1004d6124 <<tauri::menu::builders::normal::MenuItemBuilder>::accelerator::<&str>>
100491f88: 910043e8    	add	x8, sp, #0x10
100491f8c: 911e43e0    	add	x0, sp, #0x790
100491f90: aa1303e1    	mov	x1, x19
100491f94: 9401109e    	bl	0x1004d620c <<tauri::menu::builders::normal::MenuItemBuilder>::build::<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::App>>
100491f98: a94123e9    	ldp	x9, x8, [sp, #0x10]
100491f9c: b100053f    	cmn	x9, #0x1
100491fa0: 540006c0    	b.eq	0x100492078 <conductor_lib::run::{closure#0}+0x30a4>
100491fa4: ad4107e0    	ldp	q0, q1, [sp, #0x20]
100491fa8: 3d82cbe0    	str	q0, [sp, #0xb20]
100491fac: 3d82cfe1    	str	q1, [sp, #0xb30]
100491fb0: f9058be9    	str	x9, [sp, #0xb10]
100491fb4: f9058fe8    	str	x8, [sp, #0xb18]
100491fb8: 52800600    	mov	w0, #0x30               ; =48
100491fbc: 9400a44f    	bl	0x1004bb0f8 <alloc::boxed::box_new_uninit>
100491fc0: aa0003f3    	mov	x19, x0
100491fc4: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
100491fc8: 3dc2cbe1    	ldr	q1, [sp, #0xb20]
100491fcc: ad000400    	stp	q0, q1, [x0]
100491fd0: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
100491fd4: 3d800800    	str	q0, [x0, #0x20]
100491fd8: f943a3e8    	ldr	x8, [sp, #0x740]
100491fdc: 92800009    	mov	x9, #-0x1               ; =-1
100491fe0: f8690108    	ldaddl	x9, x8, [x8]
100491fe4: f100051f    	cmp	x8, #0x1
100491fe8: 54ffece1    	b.ne	0x100491d84 <conductor_lib::run::{closure#0}+0x2db0>
100491fec: d50339bf    	dmb	ishld
100491ff0: 911d03e0    	add	x0, sp, #0x740
100491ff4: 9409cad5    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100491ff8: 17ffff63    	b	0x100491d84 <conductor_lib::run::{closure#0}+0x2db0>
100491ffc: 911e43e0    	add	x0, sp, #0x790
100492000: 912c43e1    	add	x1, sp, #0xb10
100492004: 943a98f8    	bl	0x1013383e4 <std::env::set_var::<&str, &alloc::string::String>::{closure#0}>
100492008: d4200020    	brk	#0x1
10049200c: f947a3e8    	ldr	x8, [sp, #0xf40]
100492010: 92800014    	mov	x20, #-0x1              ; =-1
100492014: f8740108    	ldaddl	x20, x8, [x8]
100492018: f100051f    	cmp	x8, #0x1
10049201c: 54000081    	b.ne	0x10049202c <conductor_lib::run::{closure#0}+0x3058>
100492020: d50339bf    	dmb	ishld
100492024: 913d03e0    	add	x0, sp, #0xf40
100492028: 9409cac8    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
10049202c: f943a3e8    	ldr	x8, [sp, #0x740]
100492030: f8740108    	ldaddl	x20, x8, [x8]
100492034: f100051f    	cmp	x8, #0x1
100492038: 54000081    	b.ne	0x100492048 <conductor_lib::run::{closure#0}+0x3074>
10049203c: d50339bf    	dmb	ishld
100492040: 911d03e0    	add	x0, sp, #0x740
100492044: 9409cac1    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492048: f943c7e8    	ldr	x8, [sp, #0x788]
10049204c: 92800009    	mov	x9, #-0x1               ; =-1
100492050: f8690108    	ldaddl	x9, x8, [x8]
100492054: f100051f    	cmp	x8, #0x1
100492058: 911e43f9    	add	x25, sp, #0x790
10049205c: 54000081    	b.ne	0x10049206c <conductor_lib::run::{closure#0}+0x3098>
100492060: d50339bf    	dmb	ishld
100492064: 911e23e0    	add	x0, sp, #0x788
100492068: 9409cab8    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
10049206c: f9478fe8    	ldr	x8, [sp, #0xf18]
100492070: f94793f5    	ldr	x21, [sp, #0xf20]
100492074: 17fffa77    	b	0x100490a50 <conductor_lib::run::{closure#0}+0x1a7c>
100492078: d1002294    	sub	x20, x20, #0x8
10049207c: f907a3e8    	str	x8, [sp, #0xf40]
100492080: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100492084: 9127e042    	add	x2, x2, #0x9f8
100492088: 912c43e8    	add	x8, sp, #0xb10
10049208c: 911d83e1    	add	x1, sp, #0x760
100492090: aa1403e0    	mov	x0, x20
100492094: 94020126    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492098: f9458be8    	ldr	x8, [sp, #0xb10]
10049209c: b100051f    	cmn	x8, #0x1
1004920a0: 54000140    	b.eq	0x1004920c8 <conductor_lib::run::{closure#0}+0x30f4>
1004920a4: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004920a8: 91020000    	add	x0, x0, #0x80
1004920ac: 52800d21    	mov	w1, #0x69               ; =105
1004920b0: 94399955    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004920b4: f9458be8    	ldr	x8, [sp, #0xb10]
1004920b8: b100051f    	cmn	x8, #0x1
1004920bc: 54000060    	b.eq	0x1004920c8 <conductor_lib::run::{closure#0}+0x30f4>
1004920c0: 912c43e0    	add	x0, sp, #0xb10
1004920c4: 97ff6730    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004920c8: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004920cc: 9127e042    	add	x2, x2, #0x9f8
1004920d0: 912c43e8    	add	x8, sp, #0xb10
1004920d4: 911da3e1    	add	x1, sp, #0x768
1004920d8: aa1403e0    	mov	x0, x20
1004920dc: 94020114    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
1004920e0: f9458be8    	ldr	x8, [sp, #0xb10]
1004920e4: b100051f    	cmn	x8, #0x1
1004920e8: 54000140    	b.eq	0x100492110 <conductor_lib::run::{closure#0}+0x313c>
1004920ec: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004920f0: 9102d000    	add	x0, x0, #0xb4
1004920f4: 52800be1    	mov	w1, #0x5f               ; =95
1004920f8: 94399943    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004920fc: f9458be8    	ldr	x8, [sp, #0xb10]
100492100: b100051f    	cmn	x8, #0x1
100492104: 54000060    	b.eq	0x100492110 <conductor_lib::run::{closure#0}+0x313c>
100492108: 912c43e0    	add	x0, sp, #0xb10
10049210c: 97ff671e    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492110: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100492114: 9127e042    	add	x2, x2, #0x9f8
100492118: 912c43e8    	add	x8, sp, #0xb10
10049211c: 911dc3e1    	add	x1, sp, #0x770
100492120: aa1403e0    	mov	x0, x20
100492124: 94020102    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492128: f9458be8    	ldr	x8, [sp, #0xb10]
10049212c: b100051f    	cmn	x8, #0x1
100492130: 54000140    	b.eq	0x100492158 <conductor_lib::run::{closure#0}+0x3184>
100492134: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100492138: 91038c00    	add	x0, x0, #0xe3
10049213c: 52800c21    	mov	w1, #0x61               ; =97
100492140: 94399931    	bl	0x1012f8604 <std::io::stdio::_eprint>
100492144: f9458be8    	ldr	x8, [sp, #0xb10]
100492148: b100051f    	cmn	x8, #0x1
10049214c: 54000060    	b.eq	0x100492158 <conductor_lib::run::{closure#0}+0x3184>
100492150: 912c43e0    	add	x0, sp, #0xb10
100492154: 97ff670c    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492158: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
10049215c: 9127e042    	add	x2, x2, #0x9f8
100492160: 912c43e8    	add	x8, sp, #0xb10
100492164: 911de3e1    	add	x1, sp, #0x778
100492168: aa1403e0    	mov	x0, x20
10049216c: 940200f0    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492170: f9458be8    	ldr	x8, [sp, #0xb10]
100492174: b100051f    	cmn	x8, #0x1
100492178: 54000140    	b.eq	0x1004921a0 <conductor_lib::run::{closure#0}+0x31cc>
10049217c: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100492180: 91044c00    	add	x0, x0, #0x113
100492184: 52800ae1    	mov	w1, #0x57               ; =87
100492188: 9439991f    	bl	0x1012f8604 <std::io::stdio::_eprint>
10049218c: f9458be8    	ldr	x8, [sp, #0xb10]
100492190: b100051f    	cmn	x8, #0x1
100492194: 54000060    	b.eq	0x1004921a0 <conductor_lib::run::{closure#0}+0x31cc>
100492198: 912c43e0    	add	x0, sp, #0xb10
10049219c: 97ff66fa    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004921a0: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004921a4: 9127e042    	add	x2, x2, #0x9f8
1004921a8: 912c43e8    	add	x8, sp, #0xb10
1004921ac: 911e03e1    	add	x1, sp, #0x780
1004921b0: aa1403e0    	mov	x0, x20
1004921b4: 940200de    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
1004921b8: f9458be8    	ldr	x8, [sp, #0xb10]
1004921bc: b100051f    	cmn	x8, #0x1
1004921c0: 54000140    	b.eq	0x1004921e8 <conductor_lib::run::{closure#0}+0x3214>
1004921c4: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004921c8: 9104f800    	add	x0, x0, #0x13e
1004921cc: 52800be1    	mov	w1, #0x5f               ; =95
1004921d0: 9439990d    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004921d4: f9458be8    	ldr	x8, [sp, #0xb10]
1004921d8: b100051f    	cmn	x8, #0x1
1004921dc: 54000060    	b.eq	0x1004921e8 <conductor_lib::run::{closure#0}+0x3214>
1004921e0: 912c43e0    	add	x0, sp, #0xb10
1004921e4: 97ff66e8    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004921e8: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
1004921ec: 9127e042    	add	x2, x2, #0x9f8
1004921f0: 912c43e8    	add	x8, sp, #0xb10
1004921f4: 911e23e1    	add	x1, sp, #0x788
1004921f8: aa1403e0    	mov	x0, x20
1004921fc: 940200cc    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492200: f9458be8    	ldr	x8, [sp, #0xb10]
100492204: b100051f    	cmn	x8, #0x1
100492208: 54000140    	b.eq	0x100492230 <conductor_lib::run::{closure#0}+0x325c>
10049220c: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100492210: 9105b400    	add	x0, x0, #0x16d
100492214: 52800c61    	mov	w1, #0x63               ; =99
100492218: 943998fb    	bl	0x1012f8604 <std::io::stdio::_eprint>
10049221c: f9458be8    	ldr	x8, [sp, #0xb10]
100492220: b100051f    	cmn	x8, #0x1
100492224: 54000060    	b.eq	0x100492230 <conductor_lib::run::{closure#0}+0x325c>
100492228: 912c43e0    	add	x0, sp, #0xb10
10049222c: 97ff66d6    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492230: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
100492234: 9127e042    	add	x2, x2, #0x9f8
100492238: 912c43e8    	add	x8, sp, #0xb10
10049223c: 911d03e1    	add	x1, sp, #0x740
100492240: aa1403e0    	mov	x0, x20
100492244: 940200ba    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492248: f9458be8    	ldr	x8, [sp, #0xb10]
10049224c: b100051f    	cmn	x8, #0x1
100492250: 54000140    	b.eq	0x100492278 <conductor_lib::run::{closure#0}+0x32a4>
100492254: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
100492258: 91067800    	add	x0, x0, #0x19e
10049225c: 52800b61    	mov	w1, #0x5b               ; =91
100492260: 943998e9    	bl	0x1012f8604 <std::io::stdio::_eprint>
100492264: f9458be8    	ldr	x8, [sp, #0xb10]
100492268: b100051f    	cmn	x8, #0x1
10049226c: 54000060    	b.eq	0x100492278 <conductor_lib::run::{closure#0}+0x32a4>
100492270: 912c43e0    	add	x0, sp, #0xb10
100492274: 97ff66c4    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492278: 90015f42    	adrp	x2, 0x10307a000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.574+0x10>
10049227c: 9127e042    	add	x2, x2, #0x9f8
100492280: 912c43e8    	add	x8, sp, #0xb10
100492284: 913d03e1    	add	x1, sp, #0xf40
100492288: aa1403e0    	mov	x0, x20
10049228c: 940200a8    	bl	0x10051252c <<tauri::menu::Submenu<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::append>
100492290: f9458be8    	ldr	x8, [sp, #0xb10]
100492294: b100051f    	cmn	x8, #0x1
100492298: 540000a0    	b.eq	0x1004922ac <conductor_lib::run::{closure#0}+0x32d8>
10049229c: d00083e0    	adrp	x0, 0x101510000 <_anon.86817a6948f8e6ebbccaf2d97b4fe6e4.645+0xc44>
1004922a0: 91072c00    	add	x0, x0, #0x1cb
1004922a4: 528009e1    	mov	w1, #0x4f               ; =79
1004922a8: 943998d7    	bl	0x1012f8604 <std::io::stdio::_eprint>
1004922ac: f947a3e8    	ldr	x8, [sp, #0xf40]
1004922b0: 92800014    	mov	x20, #-0x1              ; =-1
1004922b4: f8740108    	ldaddl	x20, x8, [x8]
1004922b8: f100051f    	cmp	x8, #0x1
1004922bc: 54000081    	b.ne	0x1004922cc <conductor_lib::run::{closure#0}+0x32f8>
1004922c0: d50339bf    	dmb	ishld
1004922c4: 913d03e0    	add	x0, sp, #0xf40
1004922c8: 9409ca20    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004922cc: f943a3e8    	ldr	x8, [sp, #0x740]
1004922d0: f8740108    	ldaddl	x20, x8, [x8]
1004922d4: f100051f    	cmp	x8, #0x1
1004922d8: 54000081    	b.ne	0x1004922e8 <conductor_lib::run::{closure#0}+0x3314>
1004922dc: d50339bf    	dmb	ishld
1004922e0: 911d03e0    	add	x0, sp, #0x740
1004922e4: 9409ca19    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004922e8: f943c7e8    	ldr	x8, [sp, #0x788]
1004922ec: f8740108    	ldaddl	x20, x8, [x8]
1004922f0: f100051f    	cmp	x8, #0x1
1004922f4: 54000081    	b.ne	0x100492304 <conductor_lib::run::{closure#0}+0x3330>
1004922f8: d50339bf    	dmb	ishld
1004922fc: 911e23e0    	add	x0, sp, #0x788
100492300: 9409ca12    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492304: f943c3e8    	ldr	x8, [sp, #0x780]
100492308: f8740108    	ldaddl	x20, x8, [x8]
10049230c: f100051f    	cmp	x8, #0x1
100492310: 54000081    	b.ne	0x100492320 <conductor_lib::run::{closure#0}+0x334c>
100492314: d50339bf    	dmb	ishld
100492318: 911e03e0    	add	x0, sp, #0x780
10049231c: 9409ca0b    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492320: f943bfe8    	ldr	x8, [sp, #0x778]
100492324: f8740108    	ldaddl	x20, x8, [x8]
100492328: f100051f    	cmp	x8, #0x1
10049232c: 54000081    	b.ne	0x10049233c <conductor_lib::run::{closure#0}+0x3368>
100492330: d50339bf    	dmb	ishld
100492334: 911de3e0    	add	x0, sp, #0x778
100492338: 9409ca04    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
10049233c: f943bbe8    	ldr	x8, [sp, #0x770]
100492340: f8740108    	ldaddl	x20, x8, [x8]
100492344: f100051f    	cmp	x8, #0x1
100492348: 54000081    	b.ne	0x100492358 <conductor_lib::run::{closure#0}+0x3384>
10049234c: d50339bf    	dmb	ishld
100492350: 911dc3e0    	add	x0, sp, #0x770
100492354: 9409c9fd    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492358: f943b7e8    	ldr	x8, [sp, #0x768]
10049235c: f8740108    	ldaddl	x20, x8, [x8]
100492360: f100051f    	cmp	x8, #0x1
100492364: 54000081    	b.ne	0x100492374 <conductor_lib::run::{closure#0}+0x33a0>
100492368: d50339bf    	dmb	ishld
10049236c: 911da3e0    	add	x0, sp, #0x768
100492370: 9409c9f6    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492374: f943b3e8    	ldr	x8, [sp, #0x760]
100492378: f8740108    	ldaddl	x20, x8, [x8]
10049237c: f100051f    	cmp	x8, #0x1
100492380: 54000081    	b.ne	0x100492390 <conductor_lib::run::{closure#0}+0x33bc>
100492384: d50339bf    	dmb	ishld
100492388: 911d83e0    	add	x0, sp, #0x760
10049238c: 9409c9ef    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492390: f9458be8    	ldr	x8, [sp, #0xb10]
100492394: b100051f    	cmn	x8, #0x1
100492398: 54000060    	b.eq	0x1004923a4 <conductor_lib::run::{closure#0}+0x33d0>
10049239c: 912c43e0    	add	x0, sp, #0xb10
1004923a0: 97ff6679    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004923a4: 913c43e0    	add	x0, sp, #0xf10
1004923a8: 97ff29a7    	bl	0x10045ca44 <core::ptr::drop_glue::<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>>
1004923ac: f9489be8    	ldr	x8, [sp, #0x1130]
1004923b0: b100051f    	cmn	x8, #0x1
1004923b4: 54ff1601    	b.ne	0x100490674 <conductor_lib::run::{closure#0}+0x16a0>
1004923b8: 17fff8b2    	b	0x100490680 <conductor_lib::run::{closure#0}+0x16ac>
1004923bc: 52000008    	eor	w8, w0, #0x1
1004923c0: 17fffce3    	b	0x10049174c <conductor_lib::run::{closure#0}+0x2778>
1004923c4: aa0003f3    	mov	x19, x0
1004923c8: 14000050    	b	0x100492508 <conductor_lib::run::{closure#0}+0x3534>
1004923cc: aa0003f3    	mov	x19, x0
1004923d0: 14000046    	b	0x1004924e8 <conductor_lib::run::{closure#0}+0x3514>
1004923d4: aa0003f3    	mov	x19, x0
1004923d8: 1400003c    	b	0x1004924c8 <conductor_lib::run::{closure#0}+0x34f4>
1004923dc: aa0003f3    	mov	x19, x0
1004923e0: 14000032    	b	0x1004924a8 <conductor_lib::run::{closure#0}+0x34d4>
1004923e4: aa0003f3    	mov	x19, x0
1004923e8: 14000028    	b	0x100492488 <conductor_lib::run::{closure#0}+0x34b4>
1004923ec: aa0003f3    	mov	x19, x0
1004923f0: 1400001e    	b	0x100492468 <conductor_lib::run::{closure#0}+0x3494>
1004923f4: aa0003f3    	mov	x19, x0
1004923f8: 14000014    	b	0x100492448 <conductor_lib::run::{closure#0}+0x3474>
1004923fc: aa0003f3    	mov	x19, x0
100492400: 1400000a    	b	0x100492428 <conductor_lib::run::{closure#0}+0x3454>
100492404: aa0003f3    	mov	x19, x0
100492408: f947a3e8    	ldr	x8, [sp, #0xf40]
10049240c: 92800009    	mov	x9, #-0x1               ; =-1
100492410: f8690108    	ldaddl	x9, x8, [x8]
100492414: f100051f    	cmp	x8, #0x1
100492418: 54000081    	b.ne	0x100492428 <conductor_lib::run::{closure#0}+0x3454>
10049241c: d50339bf    	dmb	ishld
100492420: 913d03e0    	add	x0, sp, #0xf40
100492424: 9409c9c9    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492428: f943a3e8    	ldr	x8, [sp, #0x740]
10049242c: 92800009    	mov	x9, #-0x1               ; =-1
100492430: f8690108    	ldaddl	x9, x8, [x8]
100492434: f100051f    	cmp	x8, #0x1
100492438: 54000081    	b.ne	0x100492448 <conductor_lib::run::{closure#0}+0x3474>
10049243c: d50339bf    	dmb	ishld
100492440: 911d03e0    	add	x0, sp, #0x740
100492444: 9409c9c1    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492448: f943c7e8    	ldr	x8, [sp, #0x788]
10049244c: 92800009    	mov	x9, #-0x1               ; =-1
100492450: f8690108    	ldaddl	x9, x8, [x8]
100492454: f100051f    	cmp	x8, #0x1
100492458: 54000081    	b.ne	0x100492468 <conductor_lib::run::{closure#0}+0x3494>
10049245c: d50339bf    	dmb	ishld
100492460: 911e23e0    	add	x0, sp, #0x788
100492464: 9409c9b9    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492468: f943c3e8    	ldr	x8, [sp, #0x780]
10049246c: 92800009    	mov	x9, #-0x1               ; =-1
100492470: f8690108    	ldaddl	x9, x8, [x8]
100492474: f100051f    	cmp	x8, #0x1
100492478: 54000081    	b.ne	0x100492488 <conductor_lib::run::{closure#0}+0x34b4>
10049247c: d50339bf    	dmb	ishld
100492480: 911e03e0    	add	x0, sp, #0x780
100492484: 9409c9b1    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492488: f943bfe8    	ldr	x8, [sp, #0x778]
10049248c: 92800009    	mov	x9, #-0x1               ; =-1
100492490: f8690108    	ldaddl	x9, x8, [x8]
100492494: f100051f    	cmp	x8, #0x1
100492498: 54000081    	b.ne	0x1004924a8 <conductor_lib::run::{closure#0}+0x34d4>
10049249c: d50339bf    	dmb	ishld
1004924a0: 911de3e0    	add	x0, sp, #0x778
1004924a4: 9409c9a9    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004924a8: f943bbe8    	ldr	x8, [sp, #0x770]
1004924ac: 92800009    	mov	x9, #-0x1               ; =-1
1004924b0: f8690108    	ldaddl	x9, x8, [x8]
1004924b4: f100051f    	cmp	x8, #0x1
1004924b8: 54000081    	b.ne	0x1004924c8 <conductor_lib::run::{closure#0}+0x34f4>
1004924bc: d50339bf    	dmb	ishld
1004924c0: 911dc3e0    	add	x0, sp, #0x770
1004924c4: 9409c9a1    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004924c8: f943b7e8    	ldr	x8, [sp, #0x768]
1004924cc: 92800009    	mov	x9, #-0x1               ; =-1
1004924d0: f8690108    	ldaddl	x9, x8, [x8]
1004924d4: f100051f    	cmp	x8, #0x1
1004924d8: 54000081    	b.ne	0x1004924e8 <conductor_lib::run::{closure#0}+0x3514>
1004924dc: d50339bf    	dmb	ishld
1004924e0: 911da3e0    	add	x0, sp, #0x768
1004924e4: 9409c999    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004924e8: f943b3e8    	ldr	x8, [sp, #0x760]
1004924ec: 92800009    	mov	x9, #-0x1               ; =-1
1004924f0: f8690108    	ldaddl	x9, x8, [x8]
1004924f4: f100051f    	cmp	x8, #0x1
1004924f8: 54000081    	b.ne	0x100492508 <conductor_lib::run::{closure#0}+0x3534>
1004924fc: d50339bf    	dmb	ishld
100492500: 911d83e0    	add	x0, sp, #0x760
100492504: 9409c991    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492508: f9458be8    	ldr	x8, [sp, #0xb10]
10049250c: b100051f    	cmn	x8, #0x1
100492510: 540039c0    	b.eq	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492514: 912c43e0    	add	x0, sp, #0xb10
100492518: 97ff661b    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10049251c: 140001cb    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492520: aa0003f3    	mov	x19, x0
100492524: f9458be8    	ldr	x8, [sp, #0xb10]
100492528: b100051f    	cmn	x8, #0x1
10049252c: 540009e0    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492530: 912c43e0    	add	x0, sp, #0xb10
100492534: 97ff6614    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492538: 1400004c    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
10049253c: aa0003f3    	mov	x19, x0
100492540: f9458be8    	ldr	x8, [sp, #0xb10]
100492544: b100051f    	cmn	x8, #0x1
100492548: 54000900    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
10049254c: 912c43e0    	add	x0, sp, #0xb10
100492550: 97ff660d    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492554: 14000045    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492558: aa0003f3    	mov	x19, x0
10049255c: f9458be8    	ldr	x8, [sp, #0xb10]
100492560: b100051f    	cmn	x8, #0x1
100492564: 54000820    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492568: 912c43e0    	add	x0, sp, #0xb10
10049256c: 97ff6606    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492570: 1400003e    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492574: aa0003f3    	mov	x19, x0
100492578: f9458be8    	ldr	x8, [sp, #0xb10]
10049257c: b100051f    	cmn	x8, #0x1
100492580: 54000740    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492584: 912c43e0    	add	x0, sp, #0xb10
100492588: 97ff65ff    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10049258c: 14000037    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
100492590: aa0003f3    	mov	x19, x0
100492594: f9458be8    	ldr	x8, [sp, #0xb10]
100492598: b100051f    	cmn	x8, #0x1
10049259c: 54000660    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925a0: 912c43e0    	add	x0, sp, #0xb10
1004925a4: 97ff65f8    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004925a8: 14000030    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925ac: aa0003f3    	mov	x19, x0
1004925b0: f9458be8    	ldr	x8, [sp, #0xb10]
1004925b4: b100051f    	cmn	x8, #0x1
1004925b8: 54000580    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925bc: 912c43e0    	add	x0, sp, #0xb10
1004925c0: 97ff65f1    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004925c4: 14000029    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925c8: aa0003f3    	mov	x19, x0
1004925cc: f9458be8    	ldr	x8, [sp, #0xb10]
1004925d0: b100051f    	cmn	x8, #0x1
1004925d4: 540004a0    	b.eq	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925d8: 912c43e0    	add	x0, sp, #0xb10
1004925dc: 97ff65ea    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004925e0: 14000022    	b	0x100492668 <conductor_lib::run::{closure#0}+0x3694>
1004925e4: aa0003f3    	mov	x19, x0
1004925e8: 912c43e0    	add	x0, sp, #0xb10
1004925ec: 97ff65e6    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004925f0: 14000026    	b	0x100492688 <conductor_lib::run::{closure#0}+0x36b4>
1004925f4: 943bb6c8    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004925f8: aa0003f3    	mov	x19, x0
1004925fc: 912c43e0    	add	x0, sp, #0xb10
100492600: 97ff65e1    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492604: 14000003    	b	0x100492610 <conductor_lib::run::{closure#0}+0x363c>
100492608: 943bb6c3    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049260c: aa0003f3    	mov	x19, x0
100492610: f947a3e8    	ldr	x8, [sp, #0xf40]
100492614: 92800009    	mov	x9, #-0x1               ; =-1
100492618: f8690108    	ldaddl	x9, x8, [x8]
10049261c: f100051f    	cmp	x8, #0x1
100492620: 54001021    	b.ne	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492624: d50339bf    	dmb	ishld
100492628: 913d03e0    	add	x0, sp, #0xf40
10049262c: 9409c947    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492630: 1400007d    	b	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492634: aa0003f3    	mov	x19, x0
100492638: 912c43e0    	add	x0, sp, #0xb10
10049263c: 97ff65d2    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492640: 14000021    	b	0x1004926c4 <conductor_lib::run::{closure#0}+0x36f0>
100492644: 943bb6b4    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492648: aa0003f3    	mov	x19, x0
10049264c: 912c43e0    	add	x0, sp, #0xb10
100492650: 97ff65cd    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492654: 14000074    	b	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492658: 943bb6af    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049265c: aa0003f3    	mov	x19, x0
100492660: 1400000a    	b	0x100492688 <conductor_lib::run::{closure#0}+0x36b4>
100492664: aa0003f3    	mov	x19, x0
100492668: f947a3e8    	ldr	x8, [sp, #0xf40]
10049266c: 92800009    	mov	x9, #-0x1               ; =-1
100492670: f8690108    	ldaddl	x9, x8, [x8]
100492674: f100051f    	cmp	x8, #0x1
100492678: 54000081    	b.ne	0x100492688 <conductor_lib::run::{closure#0}+0x36b4>
10049267c: d50339bf    	dmb	ishld
100492680: 913d03e0    	add	x0, sp, #0xf40
100492684: 9409c931    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492688: f943a3e8    	ldr	x8, [sp, #0x740]
10049268c: 92800009    	mov	x9, #-0x1               ; =-1
100492690: f8690108    	ldaddl	x9, x8, [x8]
100492694: f100051f    	cmp	x8, #0x1
100492698: 54000161    	b.ne	0x1004926c4 <conductor_lib::run::{closure#0}+0x36f0>
10049269c: d50339bf    	dmb	ishld
1004926a0: 911d03e0    	add	x0, sp, #0x740
1004926a4: 9409c929    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004926a8: 14000007    	b	0x1004926c4 <conductor_lib::run::{closure#0}+0x36f0>
1004926ac: aa0003f3    	mov	x19, x0
1004926b0: 912c43e0    	add	x0, sp, #0xb10
1004926b4: 97ff65b4    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004926b8: 1400001e    	b	0x100492730 <conductor_lib::run::{closure#0}+0x375c>
1004926bc: 943bb696    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004926c0: aa0003f3    	mov	x19, x0
1004926c4: f943c7e8    	ldr	x8, [sp, #0x788]
1004926c8: 92800009    	mov	x9, #-0x1               ; =-1
1004926cc: f8690108    	ldaddl	x9, x8, [x8]
1004926d0: f100051f    	cmp	x8, #0x1
1004926d4: 540002e1    	b.ne	0x100492730 <conductor_lib::run::{closure#0}+0x375c>
1004926d8: d50339bf    	dmb	ishld
1004926dc: 911e23e0    	add	x0, sp, #0x788
1004926e0: 9409c91a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004926e4: 14000013    	b	0x100492730 <conductor_lib::run::{closure#0}+0x375c>
1004926e8: aa0003f3    	mov	x19, x0
1004926ec: 912c43e0    	add	x0, sp, #0xb10
1004926f0: 97ff65a5    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004926f4: 1400004c    	b	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
1004926f8: 943bb687    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004926fc: aa0003f3    	mov	x19, x0
100492700: f9458be8    	ldr	x8, [sp, #0xb10]
100492704: b100051f    	cmn	x8, #0x1
100492708: 54000320    	b.eq	0x10049276c <conductor_lib::run::{closure#0}+0x3798>
10049270c: 912c43e0    	add	x0, sp, #0xb10
100492710: 97ff659d    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492714: 14000016    	b	0x10049276c <conductor_lib::run::{closure#0}+0x3798>
100492718: aa0003f3    	mov	x19, x0
10049271c: 912c43e0    	add	x0, sp, #0xb10
100492720: 97ff6599    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492724: 14000031    	b	0x1004927e8 <conductor_lib::run::{closure#0}+0x3814>
100492728: 943bb67b    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049272c: aa0003f3    	mov	x19, x0
100492730: f943c3e8    	ldr	x8, [sp, #0x780]
100492734: 92800009    	mov	x9, #-0x1               ; =-1
100492738: f8690108    	ldaddl	x9, x8, [x8]
10049273c: f100051f    	cmp	x8, #0x1
100492740: 54000541    	b.ne	0x1004927e8 <conductor_lib::run::{closure#0}+0x3814>
100492744: d50339bf    	dmb	ishld
100492748: 911e03e0    	add	x0, sp, #0x780
10049274c: 9409c8ff    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492750: 14000026    	b	0x1004927e8 <conductor_lib::run::{closure#0}+0x3814>
100492754: aa0003f3    	mov	x19, x0
100492758: 912c43e0    	add	x0, sp, #0xb10
10049275c: 97ff658a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492760: 14000031    	b	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492764: 943bb66c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492768: aa0003f3    	mov	x19, x0
10049276c: f943cbe8    	ldr	x8, [sp, #0x790]
100492770: b100051f    	cmn	x8, #0x1
100492774: 54000580    	b.eq	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492778: 911e43e0    	add	x0, sp, #0x790
10049277c: 97ff6582    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492780: 14000029    	b	0x100492824 <conductor_lib::run::{closure#0}+0x3850>
100492784: aa0003f3    	mov	x19, x0
100492788: f9458be8    	ldr	x8, [sp, #0xb10]
10049278c: b100051f    	cmn	x8, #0x1
100492790: 540001e0    	b.eq	0x1004927cc <conductor_lib::run::{closure#0}+0x37f8>
100492794: 912c43e0    	add	x0, sp, #0xb10
100492798: 97ff657b    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10049279c: 1400000c    	b	0x1004927cc <conductor_lib::run::{closure#0}+0x37f8>
1004927a0: aa0003f3    	mov	x19, x0
1004927a4: 912c43e0    	add	x0, sp, #0xb10
1004927a8: 97ff6577    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004927ac: 14000028    	b	0x10049284c <conductor_lib::run::{closure#0}+0x3878>
1004927b0: 943bb659    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004927b4: aa0003f3    	mov	x19, x0
1004927b8: 912c43e0    	add	x0, sp, #0xb10
1004927bc: 97ff6572    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004927c0: 14000068    	b	0x100492960 <conductor_lib::run::{closure#0}+0x398c>
1004927c4: 943bb654    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004927c8: aa0003f3    	mov	x19, x0
1004927cc: f943cbe8    	ldr	x8, [sp, #0x790]
1004927d0: b100051f    	cmn	x8, #0x1
1004927d4: 54000c60    	b.eq	0x100492960 <conductor_lib::run::{closure#0}+0x398c>
1004927d8: 911e43e0    	add	x0, sp, #0x790
1004927dc: 97ff656a    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004927e0: 14000060    	b	0x100492960 <conductor_lib::run::{closure#0}+0x398c>
1004927e4: aa0003f3    	mov	x19, x0
1004927e8: f943bfe8    	ldr	x8, [sp, #0x778]
1004927ec: 92800009    	mov	x9, #-0x1               ; =-1
1004927f0: f8690108    	ldaddl	x9, x8, [x8]
1004927f4: f100051f    	cmp	x8, #0x1
1004927f8: 540002a1    	b.ne	0x10049284c <conductor_lib::run::{closure#0}+0x3878>
1004927fc: d50339bf    	dmb	ishld
100492800: 911de3e0    	add	x0, sp, #0x778
100492804: 9409c8d1    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492808: 14000011    	b	0x10049284c <conductor_lib::run::{closure#0}+0x3878>
10049280c: aa0003f3    	mov	x19, x0
100492810: 912c43e0    	add	x0, sp, #0xb10
100492814: 97ff655c    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492818: 14000043    	b	0x100492924 <conductor_lib::run::{closure#0}+0x3950>
10049281c: 943bb63e    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492820: aa0003f3    	mov	x19, x0
100492824: f943a3e8    	ldr	x8, [sp, #0x740]
100492828: 92800009    	mov	x9, #-0x1               ; =-1
10049282c: f8690108    	ldaddl	x9, x8, [x8]
100492830: f100051f    	cmp	x8, #0x1
100492834: 54000961    	b.ne	0x100492960 <conductor_lib::run::{closure#0}+0x398c>
100492838: d50339bf    	dmb	ishld
10049283c: 911d03e0    	add	x0, sp, #0x740
100492840: 9409c8c2    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492844: 14000047    	b	0x100492960 <conductor_lib::run::{closure#0}+0x398c>
100492848: aa0003f3    	mov	x19, x0
10049284c: f943bbe8    	ldr	x8, [sp, #0x770]
100492850: 92800009    	mov	x9, #-0x1               ; =-1
100492854: f8690108    	ldaddl	x9, x8, [x8]
100492858: f100051f    	cmp	x8, #0x1
10049285c: 54000641    	b.ne	0x100492924 <conductor_lib::run::{closure#0}+0x3950>
100492860: d50339bf    	dmb	ishld
100492864: 911dc3e0    	add	x0, sp, #0x770
100492868: 9409c8b8    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
10049286c: 1400002e    	b	0x100492924 <conductor_lib::run::{closure#0}+0x3950>
100492870: aa0003f3    	mov	x19, x0
100492874: 912c43e0    	add	x0, sp, #0xb10
100492878: 97ff6543    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10049287c: 140000f3    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492880: 943bb625    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492884: aa0003f3    	mov	x19, x0
100492888: 14000014    	b	0x1004928d8 <conductor_lib::run::{closure#0}+0x3904>
10049288c: aa0003f3    	mov	x19, x0
100492890: 1400000a    	b	0x1004928b8 <conductor_lib::run::{closure#0}+0x38e4>
100492894: aa0003f3    	mov	x19, x0
100492898: f943a3e8    	ldr	x8, [sp, #0x740]
10049289c: 92800009    	mov	x9, #-0x1               ; =-1
1004928a0: f8690108    	ldaddl	x9, x8, [x8]
1004928a4: f100051f    	cmp	x8, #0x1
1004928a8: 54000081    	b.ne	0x1004928b8 <conductor_lib::run::{closure#0}+0x38e4>
1004928ac: d50339bf    	dmb	ishld
1004928b0: 911d03e0    	add	x0, sp, #0x740
1004928b4: 9409c8a5    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004928b8: f943c7e8    	ldr	x8, [sp, #0x788]
1004928bc: 92800009    	mov	x9, #-0x1               ; =-1
1004928c0: f8690108    	ldaddl	x9, x8, [x8]
1004928c4: f100051f    	cmp	x8, #0x1
1004928c8: 54000081    	b.ne	0x1004928d8 <conductor_lib::run::{closure#0}+0x3904>
1004928cc: d50339bf    	dmb	ishld
1004928d0: 911e23e0    	add	x0, sp, #0x788
1004928d4: 9409c89d    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004928d8: f9458be8    	ldr	x8, [sp, #0xb10]
1004928dc: b100051f    	cmn	x8, #0x1
1004928e0: 54001b40    	b.eq	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
1004928e4: 912c43e0    	add	x0, sp, #0xb10
1004928e8: 97ff6527    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004928ec: 140000d7    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
1004928f0: aa0003f3    	mov	x19, x0
1004928f4: f9458be8    	ldr	x8, [sp, #0xb10]
1004928f8: b100051f    	cmn	x8, #0x1
1004928fc: 54000840    	b.eq	0x100492a04 <conductor_lib::run::{closure#0}+0x3a30>
100492900: 912c43e0    	add	x0, sp, #0xb10
100492904: 97ff6520    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492908: 1400003f    	b	0x100492a04 <conductor_lib::run::{closure#0}+0x3a30>
10049290c: aa0003f3    	mov	x19, x0
100492910: 912c43e0    	add	x0, sp, #0xb10
100492914: 97ff651c    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492918: 14000027    	b	0x1004929b4 <conductor_lib::run::{closure#0}+0x39e0>
10049291c: 943bb5fe    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492920: aa0003f3    	mov	x19, x0
100492924: f943b7e8    	ldr	x8, [sp, #0x768]
100492928: 92800009    	mov	x9, #-0x1               ; =-1
10049292c: f8690108    	ldaddl	x9, x8, [x8]
100492930: f100051f    	cmp	x8, #0x1
100492934: 54000401    	b.ne	0x1004929b4 <conductor_lib::run::{closure#0}+0x39e0>
100492938: d50339bf    	dmb	ishld
10049293c: 911da3e0    	add	x0, sp, #0x768
100492940: 9409c882    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492944: 1400001c    	b	0x1004929b4 <conductor_lib::run::{closure#0}+0x39e0>
100492948: aa0003f3    	mov	x19, x0
10049294c: 912c43e0    	add	x0, sp, #0xb10
100492950: 97ff650d    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492954: 14000041    	b	0x100492a58 <conductor_lib::run::{closure#0}+0x3a84>
100492958: 943bb5ef    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049295c: aa0003f3    	mov	x19, x0
100492960: f943c7e8    	ldr	x8, [sp, #0x788]
100492964: 92800009    	mov	x9, #-0x1               ; =-1
100492968: f8690108    	ldaddl	x9, x8, [x8]
10049296c: f100051f    	cmp	x8, #0x1
100492970: 540016c1    	b.ne	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492974: d50339bf    	dmb	ishld
100492978: 911e23e0    	add	x0, sp, #0x788
10049297c: 9409c873    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492980: 140000b2    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492984: aa0003f3    	mov	x19, x0
100492988: 912c43e0    	add	x0, sp, #0xb10
10049298c: 97ff64fe    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492990: 1400001d    	b	0x100492a04 <conductor_lib::run::{closure#0}+0x3a30>
100492994: 943bb5e0    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492998: aa0003f3    	mov	x19, x0
10049299c: 912c43e0    	add	x0, sp, #0xb10
1004929a0: 97ff64f9    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004929a4: 140000a9    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
1004929a8: 943bb5db    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004929ac: 140000a6    	b	0x100492c44 <conductor_lib::run::{closure#0}+0x3c70>
1004929b0: aa0003f3    	mov	x19, x0
1004929b4: f943b3e8    	ldr	x8, [sp, #0x760]
1004929b8: 92800009    	mov	x9, #-0x1               ; =-1
1004929bc: f8690108    	ldaddl	x9, x8, [x8]
1004929c0: f100051f    	cmp	x8, #0x1
1004929c4: 54001421    	b.ne	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
1004929c8: d50339bf    	dmb	ishld
1004929cc: 911d83e0    	add	x0, sp, #0x760
1004929d0: 9409c85e    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
1004929d4: 1400009d    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
1004929d8: aa0003f3    	mov	x19, x0
1004929dc: 912c43e0    	add	x0, sp, #0xb10
1004929e0: 97ff64e9    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004929e4: 1400001d    	b	0x100492a58 <conductor_lib::run::{closure#0}+0x3a84>
1004929e8: 943bb5cb    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004929ec: aa0003f3    	mov	x19, x0
1004929f0: 912c43e0    	add	x0, sp, #0xb10
1004929f4: 97ff64e4    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004929f8: 1400004a    	b	0x100492b20 <conductor_lib::run::{closure#0}+0x3b4c>
1004929fc: 943bb5c6    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492a00: aa0003f3    	mov	x19, x0
100492a04: f943a3e8    	ldr	x8, [sp, #0x740]
100492a08: 92800009    	mov	x9, #-0x1               ; =-1
100492a0c: f8690108    	ldaddl	x9, x8, [x8]
100492a10: f100051f    	cmp	x8, #0x1
100492a14: 54000861    	b.ne	0x100492b20 <conductor_lib::run::{closure#0}+0x3b4c>
100492a18: d50339bf    	dmb	ishld
100492a1c: 911d03e0    	add	x0, sp, #0x740
100492a20: 9409c84a    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492a24: 1400003f    	b	0x100492b20 <conductor_lib::run::{closure#0}+0x3b4c>
100492a28: aa0003f3    	mov	x19, x0
100492a2c: f9489be1    	ldr	x1, [sp, #0x1130]
100492a30: b4000321    	cbz	x1, 0x100492a94 <conductor_lib::run::{closure#0}+0x3ac0>
100492a34: f9489fe0    	ldr	x0, [sp, #0x1138]
100492a38: 52800022    	mov	w2, #0x1                ; =1
100492a3c: 97edbb06    	bl	0x100001654 <__rustc::__rust_dealloc>
100492a40: 14000015    	b	0x100492a94 <conductor_lib::run::{closure#0}+0x3ac0>
100492a44: aa0003f3    	mov	x19, x0
100492a48: aa1703e0    	mov	x0, x23
100492a4c: 943bba02    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492a50: 14000018    	b	0x100492ab0 <conductor_lib::run::{closure#0}+0x3adc>
100492a54: aa0003f3    	mov	x19, x0
100492a58: f943a3e8    	ldr	x8, [sp, #0x740]
100492a5c: 92800009    	mov	x9, #-0x1               ; =-1
100492a60: f8690108    	ldaddl	x9, x8, [x8]
100492a64: f100051f    	cmp	x8, #0x1
100492a68: 54000f01    	b.ne	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492a6c: d50339bf    	dmb	ishld
100492a70: 911d03e0    	add	x0, sp, #0x740
100492a74: 9409c8a7    	bl	0x100704d10 <<alloc::sync::Arc<tauri::menu::PredefinedMenuItemInner>>::drop_slow>
100492a78: 14000074    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492a7c: aa0003f3    	mov	x19, x0
100492a80: 912c43e0    	add	x0, sp, #0xb10
100492a84: 97ff64c0    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492a88: 14000017    	b	0x100492ae4 <conductor_lib::run::{closure#0}+0x3b10>
100492a8c: 943bb5a2    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492a90: aa0003f3    	mov	x19, x0
100492a94: f9400be8    	ldr	x8, [sp, #0x10]
100492a98: b100051f    	cmn	x8, #0x1
100492a9c: 54001000    	b.eq	0x100492c9c <conductor_lib::run::{closure#0}+0x3cc8>
100492aa0: 910043e0    	add	x0, sp, #0x10
100492aa4: 97ff64b8    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492aa8: 1400007d    	b	0x100492c9c <conductor_lib::run::{closure#0}+0x3cc8>
100492aac: aa0003f3    	mov	x19, x0
100492ab0: aa1603e0    	mov	x0, x22
100492ab4: 943bb9e8    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492ab8: 1400002a    	b	0x100492b60 <conductor_lib::run::{closure#0}+0x3b8c>
100492abc: aa0003f3    	mov	x19, x0
100492ac0: aa1603e0    	mov	x0, x22
100492ac4: 943bb9e4    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492ac8: 14000026    	b	0x100492b60 <conductor_lib::run::{closure#0}+0x3b8c>
100492acc: aa0003f3    	mov	x19, x0
100492ad0: 912c43e0    	add	x0, sp, #0xb10
100492ad4: 97ff64ac    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492ad8: 1400005c    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492adc: 943bb58e    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492ae0: aa0003f3    	mov	x19, x0
100492ae4: b4000b35    	cbz	x21, 0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492ae8: aa1603e0    	mov	x0, x22
100492aec: aa1503e1    	mov	x1, x21
100492af0: 52800022    	mov	w2, #0x1                ; =1
100492af4: 97edbad8    	bl	0x100001654 <__rustc::__rust_dealloc>
100492af8: 14000054    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492afc: aa0003f3    	mov	x19, x0
100492b00: 910043e0    	add	x0, sp, #0x10
100492b04: 14000004    	b	0x100492b14 <conductor_lib::run::{closure#0}+0x3b40>
100492b08: 1400004f    	b	0x100492c44 <conductor_lib::run::{closure#0}+0x3c70>
100492b0c: aa0003f3    	mov	x19, x0
100492b10: 912c43e0    	add	x0, sp, #0xb10
100492b14: 97ff6425    	bl	0x10046bba8 <core::ptr::drop_glue::<tauri::menu::AboutMetadata>>
100492b18: 1400004c    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492b1c: aa0003f3    	mov	x19, x0
100492b20: f943c7e8    	ldr	x8, [sp, #0x788]
100492b24: 92800009    	mov	x9, #-0x1               ; =-1
100492b28: f8690108    	ldaddl	x9, x8, [x8]
100492b2c: f100051f    	cmp	x8, #0x1
100492b30: 540008c1    	b.ne	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492b34: d50339bf    	dmb	ishld
100492b38: 911e23e0    	add	x0, sp, #0x788
100492b3c: 9409c803    	bl	0x100704b48 <<alloc::sync::Arc<tauri::menu::MenuItemInner>>::drop_slow>
100492b40: 14000042    	b	0x100492c48 <conductor_lib::run::{closure#0}+0x3c74>
100492b44: aa0003f3    	mov	x19, x0
100492b48: 14000008    	b	0x100492b68 <conductor_lib::run::{closure#0}+0x3b94>
100492b4c: aa0003f3    	mov	x19, x0
100492b50: aa1a03e0    	mov	x0, x26
100492b54: 943bb9c0    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492b58: 14000013    	b	0x100492ba4 <conductor_lib::run::{closure#0}+0x3bd0>
100492b5c: aa0003f3    	mov	x19, x0
100492b60: aa1b03e0    	mov	x0, x27
100492b64: 943bb9bc    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492b68: aa1a03e0    	mov	x0, x26
100492b6c: 943bb9ba    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492b70: 1400000d    	b	0x100492ba4 <conductor_lib::run::{closure#0}+0x3bd0>
100492b74: aa0003f3    	mov	x19, x0
100492b78: aa1a03e0    	mov	x0, x26
100492b7c: 943bb9b6    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492b80: 14000057    	b	0x100492cdc <conductor_lib::run::{closure#0}+0x3d08>
100492b84: aa0003f3    	mov	x19, x0
100492b88: 91086280    	add	x0, x20, #0x218
100492b8c: 97ff65fa    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100492b90: 140001b6    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492b94: 943bb560    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492b98: aa0003f3    	mov	x19, x0
100492b9c: 14000016    	b	0x100492bf4 <conductor_lib::run::{closure#0}+0x3c20>
100492ba0: aa0003f3    	mov	x19, x0
100492ba4: aa1903e0    	mov	x0, x25
100492ba8: 943bb9ab    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492bac: 14000010    	b	0x100492bec <conductor_lib::run::{closure#0}+0x3c18>
100492bb0: aa0003f3    	mov	x19, x0
100492bb4: aa1903e0    	mov	x0, x25
100492bb8: 943bb9a7    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492bbc: 14000048    	b	0x100492cdc <conductor_lib::run::{closure#0}+0x3d08>
100492bc0: 943bb555    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492bc4: aa0003f3    	mov	x19, x0
100492bc8: 14000022    	b	0x100492c50 <conductor_lib::run::{closure#0}+0x3c7c>
100492bcc: aa0003f3    	mov	x19, x0
100492bd0: 1400004b    	b	0x100492cfc <conductor_lib::run::{closure#0}+0x3d28>
100492bd4: aa0003f3    	mov	x19, x0
100492bd8: 14000009    	b	0x100492bfc <conductor_lib::run::{closure#0}+0x3c28>
100492bdc: 14000033    	b	0x100492ca8 <conductor_lib::run::{closure#0}+0x3cd4>
100492be0: aa0003f3    	mov	x19, x0
100492be4: 14000042    	b	0x100492cec <conductor_lib::run::{closure#0}+0x3d18>
100492be8: aa0003f3    	mov	x19, x0
100492bec: aa1803e0    	mov	x0, x24
100492bf0: 943bb999    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492bf4: f94007e0    	ldr	x0, [sp, #0x8]
100492bf8: 943bb997    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492bfc: aa1c03e0    	mov	x0, x28
100492c00: 943bb995    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492c04: 1400003c    	b	0x100492cf4 <conductor_lib::run::{closure#0}+0x3d20>
100492c08: aa0003f3    	mov	x19, x0
100492c0c: aa1a03e0    	mov	x0, x26
100492c10: 943bb991    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492c14: 14000032    	b	0x100492cdc <conductor_lib::run::{closure#0}+0x3d08>
100492c18: 943bb53f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492c1c: aa0003f3    	mov	x19, x0
100492c20: aa1403e0    	mov	x0, x20
100492c24: 943bb98c    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492c28: 14000190    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492c2c: aa0003f3    	mov	x19, x0
100492c30: 910043e0    	add	x0, sp, #0x10
100492c34: 97ff64fc    	bl	0x10046c024 <core::ptr::drop_glue::<tauri::window::Window>>
100492c38: 1400000e    	b	0x100492c70 <conductor_lib::run::{closure#0}+0x3c9c>
100492c3c: aa0003f3    	mov	x19, x0
100492c40: 1400002d    	b	0x100492cf4 <conductor_lib::run::{closure#0}+0x3d20>
100492c44: aa0003f3    	mov	x19, x0
100492c48: 913c43e0    	add	x0, sp, #0xf10
100492c4c: 97ff277e    	bl	0x10045ca44 <core::ptr::drop_glue::<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>>>
100492c50: f9489be8    	ldr	x8, [sp, #0x1130]
100492c54: b100051f    	cmn	x8, #0x1
100492c58: 540002e0    	b.eq	0x100492cb4 <conductor_lib::run::{closure#0}+0x3ce0>
100492c5c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100492c60: 9104c000    	add	x0, x0, #0x130
100492c64: 97ff1f5a    	bl	0x10045a9cc <core::ptr::drop_glue::<core::result::Result<alloc::vec::Vec<tauri::menu::MenuItemKind<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>, tauri::error::Error>>>
100492c68: 14000013    	b	0x100492cb4 <conductor_lib::run::{closure#0}+0x3ce0>
100492c6c: aa0003f3    	mov	x19, x0
100492c70: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100492c74: 9104c000    	add	x0, x0, #0x130
100492c78: 97ff65bf    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100492c7c: 1400017b    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492c80: 943bb525    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492c84: aa0003f3    	mov	x19, x0
100492c88: aa1403e0    	mov	x0, x20
100492c8c: aa1503e1    	mov	x1, x21
100492c90: 97ff3ac3    	bl	0x10046179c <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<core::option::Option<alloc::vec::Vec<alloc::string::String>>>>>
100492c94: 140000d0    	b	0x100492fd4 <conductor_lib::run::{closure#0}+0x4000>
100492c98: aa0003f3    	mov	x19, x0
100492c9c: 912c43e0    	add	x0, sp, #0xb10
100492ca0: 97ff6dc0    	bl	0x10046e3a0 <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
100492ca4: 14000171    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492ca8: aa0003f3    	mov	x19, x0
100492cac: 1400000e    	b	0x100492ce4 <conductor_lib::run::{closure#0}+0x3d10>
100492cb0: aa0003f3    	mov	x19, x0
100492cb4: f943afe8    	ldr	x8, [sp, #0x758]
100492cb8: 92800009    	mov	x9, #-0x1               ; =-1
100492cbc: f8690108    	ldaddl	x9, x8, [x8]
100492cc0: f100051f    	cmp	x8, #0x1
100492cc4: 54002d21    	b.ne	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492cc8: d50339bf    	dmb	ishld
100492ccc: 911d63e0    	add	x0, sp, #0x758
100492cd0: 9430807c    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100492cd4: 14000165    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492cd8: aa0003f3    	mov	x19, x0
100492cdc: aa1803e0    	mov	x0, x24
100492ce0: 943bb95d    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492ce4: f94007e0    	ldr	x0, [sp, #0x8]
100492ce8: 943bb95b    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492cec: aa1c03e0    	mov	x0, x28
100492cf0: 943bb959    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492cf4: aa1503e0    	mov	x0, x21
100492cf8: 943bb957    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492cfc: aa1403e0    	mov	x0, x20
100492d00: 943bb955    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492d04: 14000159    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492d08: aa0003f3    	mov	x19, x0
100492d0c: f9400741    	ldr	x1, [x26, #0x8]
100492d10: b4001c21    	cbz	x1, 0x100493094 <conductor_lib::run::{closure#0}+0x40c0>
100492d14: f9400b42    	ldr	x2, [x26, #0x10]
100492d18: aa1903e0    	mov	x0, x25
100492d1c: 97edba4e    	bl	0x100001654 <__rustc::__rust_dealloc>
100492d20: 140000dd    	b	0x100493094 <conductor_lib::run::{closure#0}+0x40c0>
100492d24: aa0003f3    	mov	x19, x0
100492d28: 140000c3    	b	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492d2c: aa0003f3    	mov	x19, x0
100492d30: b4001238    	cbz	x24, 0x100492f74 <conductor_lib::run::{closure#0}+0x3fa0>
100492d34: 92800008    	mov	x8, #-0x1               ; =-1
100492d38: f8680308    	ldaddl	x8, x8, [x24]
100492d3c: f100051f    	cmp	x8, #0x1
100492d40: 540011a1    	b.ne	0x100492f74 <conductor_lib::run::{closure#0}+0x3fa0>
100492d44: d50339bf    	dmb	ishld
100492d48: 912c43e0    	add	x0, sp, #0xb10
100492d4c: 9430805d    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100492d50: 14000089    	b	0x100492f74 <conductor_lib::run::{closure#0}+0x3fa0>
100492d54: aa0003f3    	mov	x19, x0
100492d58: 140000cf    	b	0x100493094 <conductor_lib::run::{closure#0}+0x40c0>
100492d5c: aa0003f3    	mov	x19, x0
100492d60: f9458be1    	ldr	x1, [sp, #0xb10]
100492d64: b4001d21    	cbz	x1, 0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492d68: f9458fe0    	ldr	x0, [sp, #0xb18]
100492d6c: 52800022    	mov	w2, #0x1                ; =1
100492d70: 97edba39    	bl	0x100001654 <__rustc::__rust_dealloc>
100492d74: 140000e5    	b	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492d78: aa0003f3    	mov	x19, x0
100492d7c: 140000da    	b	0x1004930e4 <conductor_lib::run::{closure#0}+0x4110>
100492d80: aa0003f3    	mov	x19, x0
100492d84: aa1903f5    	mov	x21, x25
100492d88: 1400007b    	b	0x100492f74 <conductor_lib::run::{closure#0}+0x3fa0>
100492d8c: aa0003f3    	mov	x19, x0
100492d90: 14000091    	b	0x100492fd4 <conductor_lib::run::{closure#0}+0x4000>
100492d94: aa0003f3    	mov	x19, x0
100492d98: 140000dc    	b	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492d9c: aa0003f3    	mov	x19, x0
100492da0: 92800008    	mov	x8, #-0x1               ; =-1
100492da4: f86802c8    	ldaddl	x8, x8, [x22]
100492da8: f100051f    	cmp	x8, #0x1
100492dac: 54001ae1    	b.ne	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492db0: d50339bf    	dmb	ishld
100492db4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100492db8: 9104c000    	add	x0, x0, #0x130
100492dbc: 9409c480    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
100492dc0: 140000d2    	b	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492dc4: aa0003f3    	mov	x19, x0
100492dc8: f943cbe1    	ldr	x1, [sp, #0x790]
100492dcc: f100043f    	cmp	x1, #0x1
100492dd0: 5400032b    	b.lt	0x100492e34 <conductor_lib::run::{closure#0}+0x3e60>
100492dd4: f943cfe0    	ldr	x0, [sp, #0x798]
100492dd8: 14000015    	b	0x100492e2c <conductor_lib::run::{closure#0}+0x3e58>
100492ddc: aa0003f3    	mov	x19, x0
100492de0: 14000015    	b	0x100492e34 <conductor_lib::run::{closure#0}+0x3e60>
100492de4: 14000020    	b	0x100492e64 <conductor_lib::run::{closure#0}+0x3e90>
100492de8: aa0003f3    	mov	x19, x0
100492dec: 140000b7    	b	0x1004930c8 <conductor_lib::run::{closure#0}+0x40f4>
100492df0: aa0003f3    	mov	x19, x0
100492df4: 52800036    	mov	w22, #0x1               ; =1
100492df8: 14000102    	b	0x100493200 <conductor_lib::run::{closure#0}+0x422c>
100492dfc: aa0003f3    	mov	x19, x0
100492e00: 14000106    	b	0x100493218 <conductor_lib::run::{closure#0}+0x4244>
100492e04: aa0003f3    	mov	x19, x0
100492e08: 140000c0    	b	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
100492e0c: aa0003f3    	mov	x19, x0
100492e10: aa1603e0    	mov	x0, x22
100492e14: 528001e1    	mov	w1, #0xf                ; =15
100492e18: 1400010f    	b	0x100493254 <conductor_lib::run::{closure#0}+0x4280>
100492e1c: aa0003f3    	mov	x19, x0
100492e20: b40000b7    	cbz	x23, 0x100492e34 <conductor_lib::run::{closure#0}+0x3e60>
100492e24: aa1903e0    	mov	x0, x25
100492e28: aa1703e1    	mov	x1, x23
100492e2c: 52800022    	mov	w2, #0x1                ; =1
100492e30: 97edba09    	bl	0x100001654 <__rustc::__rust_dealloc>
100492e34: f9489be1    	ldr	x1, [sp, #0x1130]
100492e38: b4001841    	cbz	x1, 0x100493140 <conductor_lib::run::{closure#0}+0x416c>
100492e3c: f9489fe0    	ldr	x0, [sp, #0x1138]
100492e40: 52800022    	mov	w2, #0x1                ; =1
100492e44: 97edba04    	bl	0x100001654 <__rustc::__rust_dealloc>
100492e48: 52800016    	mov	w22, #0x0               ; =0
100492e4c: 140000ed    	b	0x100493200 <conductor_lib::run::{closure#0}+0x422c>
100492e50: aa0003f3    	mov	x19, x0
100492e54: 912c43e0    	add	x0, sp, #0xb10
100492e58: 97ff63cb    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492e5c: 14000103    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492e60: 943bb4ad    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492e64: aa0003f3    	mov	x19, x0
100492e68: 52800016    	mov	w22, #0x0               ; =0
100492e6c: 140000e5    	b	0x100493200 <conductor_lib::run::{closure#0}+0x422c>
100492e70: aa0003f3    	mov	x19, x0
100492e74: 910862c0    	add	x0, x22, #0x218
100492e78: 97ff653f    	bl	0x10046c374 <core::ptr::drop_glue::<tauri::webview::Webview>>
100492e7c: 1400002a    	b	0x100492f24 <conductor_lib::run::{closure#0}+0x3f50>
100492e80: 943bb4a5    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492e84: aa0003f3    	mov	x19, x0
100492e88: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100492e8c: 9104c000    	add	x0, x0, #0x130
100492e90: 940a30e0    	bl	0x10071f210 <core::ptr::drop_glue::<tauri::window::WindowBuilder<tauri_runtime_wry::Wry<tauri::EventLoopMessage>, tauri::app::AppHandle>>>
100492e94: 14000024    	b	0x100492f24 <conductor_lib::run::{closure#0}+0x3f50>
100492e98: 943bb49f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492e9c: aa0003f3    	mov	x19, x0
100492ea0: 140000f1    	b	0x100493264 <conductor_lib::run::{closure#0}+0x4290>
100492ea4: 14000042    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ea8: 14000024    	b	0x100492f38 <conductor_lib::run::{closure#0}+0x3f64>
100492eac: aa0003f3    	mov	x19, x0
100492eb0: aa1803e0    	mov	x0, x24
100492eb4: 943bb8e8    	bl	0x101381254 <dyld_stub_binder+0x101381254>
100492eb8: 140000b9    	b	0x10049319c <conductor_lib::run::{closure#0}+0x41c8>
100492ebc: 943bb496    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492ec0: 1400001e    	b	0x100492f38 <conductor_lib::run::{closure#0}+0x3f64>
100492ec4: 1400001b    	b	0x100492f30 <conductor_lib::run::{closure#0}+0x3f5c>
100492ec8: 14000039    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ecc: aa0003f3    	mov	x19, x0
100492ed0: aa1603e0    	mov	x0, x22
100492ed4: 528001a1    	mov	w1, #0xd                ; =13
100492ed8: 140000df    	b	0x100493254 <conductor_lib::run::{closure#0}+0x4280>
100492edc: 14000034    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ee0: 14000033    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ee4: 14000032    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ee8: 14000031    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492eec: 14000030    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ef0: 1400002f    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ef4: 1400002e    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492ef8: aa0003f3    	mov	x19, x0
100492efc: 52800036    	mov	w22, #0x1               ; =1
100492f00: 140000bb    	b	0x1004931ec <conductor_lib::run::{closure#0}+0x4218>
100492f04: aa0003f3    	mov	x19, x0
100492f08: 912c43e0    	add	x0, sp, #0xb10
100492f0c: 97ff639e    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100492f10: 14000005    	b	0x100492f24 <conductor_lib::run::{closure#0}+0x3f50>
100492f14: 943bb480    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492f18: 14000025    	b	0x100492fac <conductor_lib::run::{closure#0}+0x3fd8>
100492f1c: 140000cb    	b	0x100493248 <conductor_lib::run::{closure#0}+0x4274>
100492f20: aa0003f3    	mov	x19, x0
100492f24: 910043e0    	add	x0, sp, #0x10
100492f28: 97ff5a89    	bl	0x10046994c <core::ptr::drop_glue::<tauri_utils::config::WindowConfig>>
100492f2c: 140000ce    	b	0x100493264 <conductor_lib::run::{closure#0}+0x4290>
100492f30: aa0003f3    	mov	x19, x0
100492f34: 1400009a    	b	0x10049319c <conductor_lib::run::{closure#0}+0x41c8>
100492f38: aa0003f3    	mov	x19, x0
100492f3c: 1400009c    	b	0x1004931ac <conductor_lib::run::{closure#0}+0x41d8>
100492f40: aa0003f3    	mov	x19, x0
100492f44: 912c43e0    	add	x0, sp, #0xb10
100492f48: 97ff3612    	bl	0x100460790 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<h2::proto::streams::streams::Inner>>>>
100492f4c: 140000c7    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100492f50: 943bb471    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492f54: aa0003f3    	mov	x19, x0
100492f58: 912c43e0    	add	x0, sp, #0xb10
100492f5c: 97ff360d    	bl	0x100460790 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<h2::proto::streams::streams::Inner>>>>
100492f60: 1400001d    	b	0x100492fd4 <conductor_lib::run::{closure#0}+0x4000>
100492f64: 943bb46c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492f68: aa0003f3    	mov	x19, x0
100492f6c: 912c43e0    	add	x0, sp, #0xb10
100492f70: 97ff3608    	bl	0x100460790 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<h2::proto::streams::streams::Inner>>>>
100492f74: 34000615    	cbz	w21, 0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492f78: f9489be8    	ldr	x8, [sp, #0x1130]
100492f7c: b40005c8    	cbz	x8, 0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492f80: 92800009    	mov	x9, #-0x1               ; =-1
100492f84: f8690108    	ldaddl	x9, x8, [x8]
100492f88: f100051f    	cmp	x8, #0x1
100492f8c: 54000541    	b.ne	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492f90: d50339bf    	dmb	ishld
100492f94: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100492f98: 9104c000    	add	x0, x0, #0x130
100492f9c: 94307fc9    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100492fa0: 14000025    	b	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492fa4: 943bb45c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492fa8: 943bb45b    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100492fac: aa0003f3    	mov	x19, x0
100492fb0: 140000ab    	b	0x10049325c <conductor_lib::run::{closure#0}+0x4288>
100492fb4: aa0003f3    	mov	x19, x0
100492fb8: 92800008    	mov	x8, #-0x1               ; =-1
100492fbc: f8680288    	ldaddl	x8, x8, [x20]
100492fc0: f100051f    	cmp	x8, #0x1
100492fc4: 54000081    	b.ne	0x100492fd4 <conductor_lib::run::{closure#0}+0x4000>
100492fc8: d50339bf    	dmb	ishld
100492fcc: 912c43e0    	add	x0, sp, #0xb10
100492fd0: 94307fbc    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100492fd4: f947a3e8    	ldr	x8, [sp, #0xf40]
100492fd8: b40002e8    	cbz	x8, 0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492fdc: 92800009    	mov	x9, #-0x1               ; =-1
100492fe0: f8690108    	ldaddl	x9, x8, [x8]
100492fe4: f100051f    	cmp	x8, #0x1
100492fe8: 54000261    	b.ne	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492fec: d50339bf    	dmb	ishld
100492ff0: 913d03e0    	add	x0, sp, #0xf40
100492ff4: 94307fb3    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100492ff8: 1400000f    	b	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100492ffc: 943bb446    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493000: aa0003f3    	mov	x19, x0
100493004: 92800008    	mov	x8, #-0x1               ; =-1
100493008: f8680308    	ldaddl	x8, x8, [x24]
10049300c: f100051f    	cmp	x8, #0x1
100493010: 54000121    	b.ne	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100493014: d50339bf    	dmb	ishld
100493018: 912c43e0    	add	x0, sp, #0xb10
10049301c: 94307fa9    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100493020: 14000005    	b	0x100493034 <conductor_lib::run::{closure#0}+0x4060>
100493024: 943bb43c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493028: aa0003f3    	mov	x19, x0
10049302c: 912c43e0    	add	x0, sp, #0xb10
100493030: 97ff35d8    	bl	0x100460790 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<h2::proto::streams::streams::Inner>>>>
100493034: f9478be8    	ldr	x8, [sp, #0xf10]
100493038: 92800009    	mov	x9, #-0x1               ; =-1
10049303c: f8690108    	ldaddl	x9, x8, [x8]
100493040: f100051f    	cmp	x8, #0x1
100493044: 54001121    	b.ne	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100493048: d50339bf    	dmb	ishld
10049304c: 913c43e0    	add	x0, sp, #0xf10
100493050: 94307f9c    	bl	0x1010b2ec0 <<alloc::sync::Arc<tauri::menu::MenuInner>>::drop_slow>
100493054: 14000085    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100493058: 943bb42f    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049305c: 943bb42e    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493060: aa0003f3    	mov	x19, x0
100493064: 912c43e0    	add	x0, sp, #0xb10
100493068: 97ff6347    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
10049306c: 1400007f    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100493070: 943bb429    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493074: aa0003f3    	mov	x19, x0
100493078: 92800008    	mov	x8, #-0x1               ; =-1
10049307c: f86802c8    	ldaddl	x8, x8, [x22]
100493080: f100051f    	cmp	x8, #0x1
100493084: 54000081    	b.ne	0x100493094 <conductor_lib::run::{closure#0}+0x40c0>
100493088: d50339bf    	dmb	ishld
10049308c: 912c43e0    	add	x0, sp, #0xb10
100493090: 9409c3cb    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
100493094: aa1703e0    	mov	x0, x23
100493098: aa1803e1    	mov	x1, x24
10049309c: 97ff39c0    	bl	0x10046179c <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<core::option::Option<alloc::vec::Vec<alloc::string::String>>>>>
1004930a0: 14000011    	b	0x1004930e4 <conductor_lib::run::{closure#0}+0x4110>
1004930a4: 943bb41c    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004930a8: aa0003f3    	mov	x19, x0
1004930ac: 912c43e0    	add	x0, sp, #0xb10
1004930b0: 97ff6335    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
1004930b4: 1400006d    	b	0x100493268 <conductor_lib::run::{closure#0}+0x4294>
1004930b8: 943bb417    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004930bc: aa0003f3    	mov	x19, x0
1004930c0: 912c43e0    	add	x0, sp, #0xb10
1004930c4: 97ff35b3    	bl	0x100460790 <core::ptr::drop_glue::<std::sync::poison::PoisonError<std::sync::poison::mutex::MutexGuard<h2::proto::streams::streams::Inner>>>>
1004930c8: 92800008    	mov	x8, #-0x1               ; =-1
1004930cc: f86802c8    	ldaddl	x8, x8, [x22]
1004930d0: f100051f    	cmp	x8, #0x1
1004930d4: 54000081    	b.ne	0x1004930e4 <conductor_lib::run::{closure#0}+0x4110>
1004930d8: d50339bf    	dmb	ishld
1004930dc: 911e43e0    	add	x0, sp, #0x790
1004930e0: 9409c3b7    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
1004930e4: f9489be8    	ldr	x8, [sp, #0x1130]
1004930e8: 92800009    	mov	x9, #-0x1               ; =-1
1004930ec: f8690108    	ldaddl	x9, x8, [x8]
1004930f0: f100051f    	cmp	x8, #0x1
1004930f4: 540000a1    	b.ne	0x100493108 <conductor_lib::run::{closure#0}+0x4134>
1004930f8: d50339bf    	dmb	ishld
1004930fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100493100: 9104c000    	add	x0, x0, #0x130
100493104: 94308006    	bl	0x1010b311c <<alloc::sync::Arc<tauri::state::StateManager>>::drop_slow>
100493108: 92800008    	mov	x8, #-0x1               ; =-1
10049310c: f86802c8    	ldaddl	x8, x8, [x22]
100493110: f100051f    	cmp	x8, #0x1
100493114: 54000161    	b.ne	0x100493140 <conductor_lib::run::{closure#0}+0x416c>
100493118: d50339bf    	dmb	ishld
10049311c: 911e23e0    	add	x0, sp, #0x788
100493120: 9409c3a7    	bl	0x100703fbc <<alloc::sync::Arc<conductor_lib::binary_manager::BinaryManager>>::drop_slow>
100493124: 14000007    	b	0x100493140 <conductor_lib::run::{closure#0}+0x416c>
100493128: 943bb3fb    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049312c: 943bb3fa    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493130: 943bb3f9    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493134: aa0003f3    	mov	x19, x0
100493138: 912c43e0    	add	x0, sp, #0xb10
10049313c: 97ff2bc9    	bl	0x10045e060 <core::ptr::drop_glue::<alloc::sync::ArcInner<conductor_lib::binary_manager::BinaryManager>>>
100493140: 52800016    	mov	w22, #0x0               ; =0
100493144: 1400002f    	b	0x100493200 <conductor_lib::run::{closure#0}+0x422c>
100493148: 943bb3f3    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049314c: aa0003f3    	mov	x19, x0
100493150: 912c43e0    	add	x0, sp, #0xb10
100493154: 97ff630c    	bl	0x10046bd84 <core::ptr::drop_glue::<tauri::error::Error>>
100493158: 14000035    	b	0x10049322c <conductor_lib::run::{closure#0}+0x4258>
10049315c: 943bb3ee    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493160: aa0003f3    	mov	x19, x0
100493164: 14000032    	b	0x10049322c <conductor_lib::run::{closure#0}+0x4258>
100493168: aa0003f3    	mov	x19, x0
10049316c: 911e43e0    	add	x0, sp, #0x790
100493170: 97ff542d    	bl	0x100468224 <core::ptr::drop_glue::<serde_json::error::Error>>
100493174: 1400003c    	b	0x100493264 <conductor_lib::run::{closure#0}+0x4290>
100493178: 943bb3e7    	bl	0x101380114 <core::panicking::panic_in_cleanup>
10049317c: aa0003f3    	mov	x19, x0
100493180: 911e43e0    	add	x0, sp, #0x790
100493184: 97ff5428    	bl	0x100468224 <core::ptr::drop_glue::<serde_json::error::Error>>
100493188: 14000005    	b	0x10049319c <conductor_lib::run::{closure#0}+0x41c8>
10049318c: 943bb3e2    	bl	0x101380114 <core::panicking::panic_in_cleanup>
100493190: aa0003f3    	mov	x19, x0
100493194: 911e43e0    	add	x0, sp, #0x790
100493198: 97ff5423    	bl	0x100468224 <core::ptr::drop_glue::<serde_json::error::Error>>
10049319c: aa1703e0    	mov	x0, x23
1004931a0: 52800021    	mov	w1, #0x1                ; =1
1004931a4: 52800022    	mov	w2, #0x1                ; =1
1004931a8: 97edb92b    	bl	0x100001654 <__rustc::__rust_dealloc>
1004931ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1004931b0: 9104c000    	add	x0, x0, #0x130
1004931b4: 9409ef6b    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
1004931b8: aa1603e0    	mov	x0, x22
1004931bc: 52800281    	mov	w1, #0x14               ; =20
1004931c0: 14000025    	b	0x100493254 <conductor_lib::run::{closure#0}+0x4280>
1004931c4: 943bb3d4    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1004931c8: aa0003f3    	mov	x19, x0
1004931cc: b40000b8    	cbz	x24, 0x1004931e0 <conductor_lib::run::{closure#0}+0x420c>
1004931d0: aa1a03e0    	mov	x0, x26
1004931d4: aa1803e1    	mov	x1, x24
1004931d8: 52800022    	mov	w2, #0x1                ; =1
1004931dc: 97edb91e    	bl	0x100001654 <__rustc::__rust_dealloc>
1004931e0: 912c43e0    	add	x0, sp, #0xb10
1004931e4: 97ff6194    	bl	0x10046b834 <core::ptr::drop_glue::<tauri::app::AppHandle>>
1004931e8: 52800016    	mov	w22, #0x0               ; =0
1004931ec: f947a3e1    	ldr	x1, [sp, #0xf40]
1004931f0: b4000081    	cbz	x1, 0x100493200 <conductor_lib::run::{closure#0}+0x422c>
1004931f4: f947a7e0    	ldr	x0, [sp, #0xf48]
1004931f8: 52800022    	mov	w2, #0x1                ; =1
1004931fc: 97edb916    	bl	0x100001654 <__rustc::__rust_dealloc>
100493200: f9478be1    	ldr	x1, [sp, #0xf10]
100493204: b4000081    	cbz	x1, 0x100493214 <conductor_lib::run::{closure#0}+0x4240>
100493208: f9478fe0    	ldr	x0, [sp, #0xf18]
10049320c: 52800022    	mov	w2, #0x1                ; =1
100493210: 97edb911    	bl	0x100001654 <__rustc::__rust_dealloc>
100493214: 360000d6    	tbz	w22, #0x0, 0x10049322c <conductor_lib::run::{closure#0}+0x4258>
100493218: f943a3e1    	ldr	x1, [sp, #0x740]
10049321c: b4000081    	cbz	x1, 0x10049322c <conductor_lib::run::{closure#0}+0x4258>
100493220: f943a7e0    	ldr	x0, [sp, #0x748]
100493224: 52800022    	mov	w2, #0x1                ; =1
100493228: 97edb90b    	bl	0x100001654 <__rustc::__rust_dealloc>
10049322c: b40001f4    	cbz	x20, 0x100493268 <conductor_lib::run::{closure#0}+0x4294>
100493230: aa1503e0    	mov	x0, x21
100493234: aa1403e1    	mov	x1, x20
100493238: 52800022    	mov	w2, #0x1                ; =1
10049323c: 97edb906    	bl	0x100001654 <__rustc::__rust_dealloc>
100493240: aa1303e0    	mov	x0, x19
100493244: 943bb651    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
100493248: aa0003f3    	mov	x19, x0
10049324c: aa1903e0    	mov	x0, x25
100493250: 528000a1    	mov	w1, #0x5                ; =5
100493254: 52800022    	mov	w2, #0x1                ; =1
100493258: 97edb8ff    	bl	0x100001654 <__rustc::__rust_dealloc>
10049325c: 913c43e0    	add	x0, sp, #0xf10
100493260: 9409ef40    	bl	0x10070ef60 <<alloc::collections::btree::map::BTreeMap<alloc::string::String, serde_json::value::Value> as core::ops::drop::Drop>::drop>
100493264: b5000075    	cbnz	x21, 0x100493270 <conductor_lib::run::{closure#0}+0x429c>
100493268: aa1303e0    	mov	x0, x19
10049326c: 943bb647    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
100493270: aa1403e0    	mov	x0, x20
100493274: aa1503e1    	mov	x1, x21
100493278: 52800022    	mov	w2, #0x1                ; =1
10049327c: 97edb8f6    	bl	0x100001654 <__rustc::__rust_dealloc>
100493280: aa1303e0    	mov	x0, x19
100493284: 943bb641    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
100493288: 943bb3a3    	bl	0x101380114 <core::panicking::panic_in_cleanup>
