
/Applications/Conductor.app/Contents/MacOS/conductor:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006e55bc <conductor_lib::open_settings_page>:
1006e55bc: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1006e55c0: a9014ff4    	stp	x20, x19, [sp, #0x10]
1006e55c4: a9027bfd    	stp	x29, x30, [sp, #0x20]
1006e55c8: 910083fd    	add	x29, sp, #0x20
1006e55cc: d11f03ff    	sub	sp, sp, #0x7c0
1006e55d0: f90003ff    	str	xzr, [sp]
1006e55d4: aa0003f3    	mov	x19, x0
1006e55d8: aa0803f4    	mov	x20, x8
1006e55dc: 90011fe1    	adrp	x1, 0x102ae1000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.348+0x15c5523>
1006e55e0: 912d9021    	add	x1, x1, #0xb64
1006e55e4: 910003e8    	mov	x8, sp
1006e55e8: 52800082    	mov	w2, #0x4                ; =4
1006e55ec: 97f785a5    	bl	0x1004c6c80 <<tauri::app::AppHandle as tauri::Manager<tauri_runtime_wry::Wry<tauri::EventLoopMessage>>>::get_webview_window>
1006e55f0: f94003e8    	ldr	x8, [sp]
1006e55f4: b100051f    	cmn	x8, #0x1
1006e55f8: 540003c0    	b.eq	0x1006e5670 <conductor_lib::open_settings_page+0xb4>
1006e55fc: 910e03e0    	add	x0, sp, #0x380
1006e5600: 910003e1    	mov	x1, sp
1006e5604: 52807002    	mov	w2, #0x380              ; =896
1006e5608: 94326ec2    	bl	0x101381110 <dyld_stub_binder+0x101381110>
1006e560c: 90011ff5    	adrp	x21, 0x102ae1000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.348+0x15c5523>
1006e5610: 912ef2b5    	add	x21, x21, #0xbbc
1006e5614: aa1503e0    	mov	x0, x21
1006e5618: 52800241    	mov	w1, #0x12               ; =18
1006e561c: 942775f3    	bl	0x1010c2de8 <tauri::event::event_name::is_event_name_valid>
1006e5620: 36000460    	tbz	w0, #0x0, 0x1006e56ac <conductor_lib::open_settings_page+0xf0>
1006e5624: f94377e9    	ldr	x9, [sp, #0x6e8]
1006e5628: 92800008    	mov	x8, #-0x1               ; =-1
1006e562c: d10087aa    	sub	x10, x29, #0x21
1006e5630: a9372ba8    	stp	x8, x10, [x29, #-0x90]
1006e5634: 90011fe1    	adrp	x1, 0x102ae1000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.348+0x15c5523>
1006e5638: 912ef021    	add	x1, x1, #0xbbc
1006e563c: d10383a8    	sub	x8, x29, #0xe0
1006e5640: 91004120    	add	x0, x9, #0x10
1006e5644: d10243a3    	sub	x3, x29, #0x90
1006e5648: 52800242    	mov	w2, #0x12               ; =18
1006e564c: 97f58a63    	bl	0x100447fd8 <<tauri::manager::AppManager>::emit::<()>>
1006e5650: f85203a8    	ldur	x8, [x29, #-0xe0]
1006e5654: b100051f    	cmn	x8, #0x1
1006e5658: 54000461    	b.ne	0x1006e56e4 <conductor_lib::open_settings_page+0x128>
1006e565c: 910e03e0    	add	x0, sp, #0x380
1006e5660: 97ffeae3    	bl	0x1006e01ec <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
1006e5664: 92800008    	mov	x8, #-0x1               ; =-1
1006e5668: f9000288    	str	x8, [x20]
1006e566c: 1400003c    	b	0x1006e575c <conductor_lib::open_settings_page+0x1a0>
1006e5670: 97e46ffc    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1006e5674: 528002a0    	mov	w0, #0x15               ; =21
1006e5678: 52800021    	mov	w1, #0x1                ; =1
1006e567c: 97e46ff5    	bl	0x100001650 <__rustc::__rust_alloc>
1006e5680: b4000900    	cbz	x0, 0x1006e57a0 <conductor_lib::open_settings_page+0x1e4>
1006e5684: 90011fe8    	adrp	x8, 0x102ae1000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.348+0x15c5523>
1006e5688: 912f3908    	add	x8, x8, #0xbce
1006e568c: 3dc00100    	ldr	q0, [x8]
1006e5690: 3d800000    	str	q0, [x0]
1006e5694: f840d108    	ldur	x8, [x8, #0xd]
1006e5698: f800d008    	stur	x8, [x0, #0xd]
1006e569c: 528002a8    	mov	w8, #0x15               ; =21
1006e56a0: a9000288    	stp	x8, x0, [x20]
1006e56a4: f9000a88    	str	x8, [x20, #0x10]
1006e56a8: 1400002d    	b	0x1006e575c <conductor_lib::open_settings_page+0x1a0>
1006e56ac: 97e46fed    	bl	0x100001660 <__rustc::__rust_no_alloc_shim_is_unstable_v2>
1006e56b0: 52800240    	mov	w0, #0x12               ; =18
1006e56b4: 52800021    	mov	w1, #0x1                ; =1
1006e56b8: 97e46fe6    	bl	0x100001650 <__rustc::__rust_alloc>
1006e56bc: b40007a0    	cbz	x0, 0x1006e57b0 <conductor_lib::open_settings_page+0x1f4>
1006e56c0: 528cace8    	mov	w8, #0x6567             ; =25959
1006e56c4: 79002008    	strh	w8, [x0, #0x10]
1006e56c8: 3dc002a0    	ldr	q0, [x21]
1006e56cc: 3d800000    	str	q0, [x0]
1006e56d0: d2800428    	mov	x8, #0x21               ; =33
1006e56d4: f2f00008    	movk	x8, #0x8000, lsl #48
1006e56d8: 52800249    	mov	w9, #0x12               ; =18
1006e56dc: a93227a8    	stp	x8, x9, [x29, #-0xe0]
1006e56e0: a93327a0    	stp	x0, x9, [x29, #-0xd0]
1006e56e4: ad7907a0    	ldp	q0, q1, [x29, #-0xe0]
1006e56e8: ad3b87a0    	stp	q0, q1, [x29, #-0x90]
1006e56ec: 3cd403a0    	ldur	q0, [x29, #-0xc0]
1006e56f0: 3c9903a0    	stur	q0, [x29, #-0x70]
1006e56f4: 52800028    	mov	w8, #0x1                ; =1
1006e56f8: a93aa3bf    	stp	xzr, x8, [x29, #-0x58]
1006e56fc: 52800408    	mov	w8, #0x20               ; =32
1006e5700: 72ac0008    	movk	w8, #0x6000, lsl #16
1006e5704: f81d03a8    	stur	x8, [x29, #-0x30]
1006e5708: d10163a8    	sub	x8, x29, #0x58
1006e570c: 90014e29    	adrp	x9, 0x1030a9000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.8673+0x10>
1006e5710: 91104129    	add	x9, x9, #0x410
1006e5714: a93ba3bf    	stp	xzr, x8, [x29, #-0x48]
1006e5718: f81c83a9    	stur	x9, [x29, #-0x38]
1006e571c: d10243a0    	sub	x0, x29, #0x90
1006e5720: d10103a1    	sub	x1, x29, #0x40
1006e5724: 94278a19    	bl	0x1010c7f88 <<tauri::error::Error as core::fmt::Display>::fmt>
1006e5728: 35000280    	cbnz	w0, 0x1006e5778 <conductor_lib::open_settings_page+0x1bc>
1006e572c: 3cda83a0    	ldur	q0, [x29, #-0x58]
1006e5730: 3c9503a0    	stur	q0, [x29, #-0xb0]
1006e5734: f85b83a8    	ldur	x8, [x29, #-0x48]
1006e5738: f81603a8    	stur	x8, [x29, #-0xa0]
1006e573c: d10243a0    	sub	x0, x29, #0x90
1006e5740: 97ffe64c    	bl	0x1006df070 <core::ptr::drop_glue::<tauri::error::Error>>
1006e5744: 3cd503a0    	ldur	q0, [x29, #-0xb0]
1006e5748: 3d800280    	str	q0, [x20]
1006e574c: f85603a8    	ldur	x8, [x29, #-0xa0]
1006e5750: f9000a88    	str	x8, [x20, #0x10]
1006e5754: 910e03e0    	add	x0, sp, #0x380
1006e5758: 97ffeaa5    	bl	0x1006e01ec <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
1006e575c: aa1303e0    	mov	x0, x19
1006e5760: 97ffe4d1    	bl	0x1006deaa4 <core::ptr::drop_glue::<tauri::app::AppHandle>>
1006e5764: 911f03ff    	add	sp, sp, #0x7c0
1006e5768: a9427bfd    	ldp	x29, x30, [sp, #0x20]
1006e576c: a9414ff4    	ldp	x20, x19, [sp, #0x10]
1006e5770: a8c357f6    	ldp	x22, x21, [sp], #0x30
1006e5774: d65f03c0    	ret
1006e5778: 900120a0    	adrp	x0, 0x102af9000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.8678+0x391>
1006e577c: 9102d400    	add	x0, x0, #0xb5
1006e5780: f0014e03    	adrp	x3, 0x1030a8000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.349+0x21708>
1006e5784: 91240063    	add	x3, x3, #0x900
1006e5788: 90014e24    	adrp	x4, 0x1030a9000 <_anon.9ed3a39c53b9cab5b78859e56bb62607.8673+0x10>
1006e578c: 91110084    	add	x4, x4, #0x440
1006e5790: d10087a2    	sub	x2, x29, #0x21
1006e5794: 528006e1    	mov	w1, #0x37               ; =55
1006e5798: 94326a45    	bl	0x1013800ac <core::result::unwrap_failed>
1006e579c: 14000008    	b	0x1006e57bc <conductor_lib::open_settings_page+0x200>
1006e57a0: 52800020    	mov	w0, #0x1                ; =1
1006e57a4: 528002a1    	mov	w1, #0x15               ; =21
1006e57a8: 943269c2    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1006e57ac: 14000004    	b	0x1006e57bc <conductor_lib::open_settings_page+0x200>
1006e57b0: 52800020    	mov	w0, #0x1                ; =1
1006e57b4: 52800241    	mov	w1, #0x12               ; =18
1006e57b8: 943269be    	bl	0x10137feb0 <alloc::raw_vec::handle_error>
1006e57bc: d4200020    	brk	#0x1
1006e57c0: aa0003f4    	mov	x20, x0
1006e57c4: 1400000b    	b	0x1006e57f0 <conductor_lib::open_settings_page+0x234>
1006e57c8: aa0003f4    	mov	x20, x0
1006e57cc: 1400000b    	b	0x1006e57f8 <conductor_lib::open_settings_page+0x23c>
1006e57d0: aa0003f4    	mov	x20, x0
1006e57d4: f85a83a1    	ldur	x1, [x29, #-0x58]
1006e57d8: b4000081    	cbz	x1, 0x1006e57e8 <conductor_lib::open_settings_page+0x22c>
1006e57dc: f85b03a0    	ldur	x0, [x29, #-0x50]
1006e57e0: 52800022    	mov	w2, #0x1                ; =1
1006e57e4: 97e46f9c    	bl	0x100001654 <__rustc::__rust_dealloc>
1006e57e8: d10243a0    	sub	x0, x29, #0x90
1006e57ec: 97ffe621    	bl	0x1006df070 <core::ptr::drop_glue::<tauri::error::Error>>
1006e57f0: 910e03e0    	add	x0, sp, #0x380
1006e57f4: 97ffea7e    	bl	0x1006e01ec <core::ptr::drop_glue::<tauri::webview::webview_window::WebviewWindow>>
1006e57f8: aa1303e0    	mov	x0, x19
1006e57fc: 97ffe4aa    	bl	0x1006deaa4 <core::ptr::drop_glue::<tauri::app::AppHandle>>
1006e5800: aa1403e0    	mov	x0, x20
1006e5804: 94326ce1    	bl	0x101380b88 <dyld_stub_binder+0x101380b88>
1006e5808: 94326a43    	bl	0x101380114 <core::panicking::panic_in_cleanup>
1006e580c: 94326a42    	bl	0x101380114 <core::panicking::panic_in_cleanup>
