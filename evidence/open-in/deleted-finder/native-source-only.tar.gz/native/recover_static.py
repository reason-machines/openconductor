#!/usr/bin/env python3
import bisect,hashlib,json,pathlib,re,struct,subprocess,tarfile,datetime
ROOT=pathlib.Path(__file__).resolve().parent
APP=pathlib.Path('/Applications/Conductor.app/Contents/MacOS/conductor')
EXPECTED='0ba55751aea5ecf592d2c78379760af641fb912a34b2c3573d41df031ffb831d'
LLVM='/opt/homebrew/opt/llvm/bin/llvm-objdump'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,o):
 p=ROOT/n;p.write_text(json.dumps(o,indent=2)+'\n');return p
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,timeout=45);return p.returncode,p.stdout,p.stderr
data=APP.read_bytes();assert sha(data)==EXPECTED
magic,cpu,subtype,filetype,ncmds,sizeofcmds,flags,reserved=struct.unpack_from('<8I',data)
assert magic==0xfeedfacf and cpu==0x100000c
segments=[];off=32
for _ in range(ncmds):
 cmd,size=struct.unpack_from('<II',data,off)
 if cmd==0x19:
  name,vm,vmsize,fo,fs=struct.unpack_from('<16sQQQQ',data,off+8);segments.append({'name':name.rstrip(b'\0').decode(),'vm':vm,'vmsize':vmsize,'fileoff':fo,'filesize':fs})
 off+=size
def offset(a):
 for s in segments:
  if s['vm']<=a<s['vm']+s['filesize']:return a-s['vm']+s['fileoff']
 raise ValueError(hex(a))
rc,nm,err=run(['/usr/bin/nm','-nm',str(APP)]);assert rc==0
rows=[]
for l in nm.decode().splitlines():
 m=re.match(r'([0-9a-f]+) \(__TEXT,__text\).*? (\S+)$',l)
 if m:rows.append((int(m[1],16),m[2]))
rows=sorted(set(rows));addrs=[a for a,n in rows]
requested=[0x10048efd4,0x100498360,0x10049328c,0x10048d40c,0x1006e55bc]
shell=[0x1001ea8c4,0x1001f1af8,0x100533bec]
result={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary':str(APP),'binary_sha256':EXPECTED,'size':len(data),'architecture':'arm64','tool':LLVM,'segments':segments,'functions':[],'limits':['Static LLVM disassembly is not REA/Ghidra decompilation or original source.','End bounds use next distinct __TEXT,__text nm symbol, not a proof of recovered control-flow ownership.','ADRP+ADD strings are local straight-line candidate references, not a complete dataflow or length interpretation.','Indirect calls, jump-table targets, vtable semantics and reachability are not proven by this extraction.','No target process, menu action, provider, credential or OpenConductor runtime was invoked.']}
for a in requested+shell:
 i=bisect.bisect_left(addrs,a);assert addrs[i]==a
 j=bisect.bisect_right(addrs,a);end=addrs[j];name=rows[i][1]
 cmd=[LLVM,'--disassemble','--demangle','--start-address='+hex(a),'--stop-address='+hex(end),str(APP)]
 rc,out,err=run(cmd);assert rc==0,(a,err)
 text=out.decode();ins=[]
 for ln in text.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(.+)$',ln)
  if m:ins.append((int(m[1],16),m[2],m[3]))
 assert [x[0] for x in ins]==list(range(a,end,4)),(hex(a),len(ins),end-a)
 start=offset(a);raw=data[start:start+end-a]
 for pc,word,asm in ins:assert data[offset(pc):offset(pc)+4]==bytes.fromhex(word)[::-1]
 (ROOT/(hex(a)+'.s')).write_bytes(out);(ROOT/(hex(a)+'.bin')).write_bytes(raw)
 calls=[];refs=[];regs={}
 for pc,word,asm in ins:
  m=re.match(r'(bl|b|blr|br)\s+(.+)',asm)
  if m and not (m[1]=='b' and '<' in m[2] and a<=int(m[2].split()[0],16)<end):calls.append({'pc':hex(pc),'instruction':asm})
  ap=re.match(r'adrp\s+(x\d+),\s*(0x[0-9a-f]+)',asm)
  ad=re.match(r'add\s+(x\d+),\s*(x\d+),\s*#(0x[0-9a-f]+|[0-9]+)',asm)
  if ap:regs[ap[1]]=(int(ap[2],16),pc)
  elif ad and ad[2] in regs and pc-regs[ad[2]][1]<=40:
   va=regs[ad[2]][0]+int(ad[3],0)
   try:
    fo=offset(va);sample=data[fo:fo+192];printable=bytearray()
    for b in sample:
     if b==0 or b<9 or 13<b<32 or b>126:break
     printable.append(b)
    if len(printable)>=3:refs.append({'pc':hex(pc),'vm':hex(va),'file_offset':fo,'printable_prefix':printable.decode(),'prefix_sha256':sha(printable),'not_length_delimited':True})
   except ValueError:pass
   regs.pop(ad[1],None)
  elif re.match(r'(b(?:\.[a-z]+)?|bl|blr|br|ret|cbz|cbnz|tbz|tbnz)\b',asm):regs.clear()
  else:
   dest=re.match(r'\w+\s+([xw]\d+),',asm)
   if dest:regs.pop('x'+dest[1][1:],None)
 result['functions'].append({'address':hex(a),'end_exclusive':hex(end),'size':end-a,'symbol':name,'role':'requested-menu-range' if a in requested else 'execute-shell-command-binding-candidate','raw_sha256':sha(raw),'disassembly_sha256':sha(out),'instruction_count':len(ins),'all_instruction_words_match_file':True,'direct_and_indirect_branch_edges':calls,'literal_candidates':refs})
assert sha(APP.read_bytes())==EXPECTED
rc,out,err=run(['rea','inspect-macho',str(APP),'--format','json'])
(ROOT/'rea-inspect-macho.json').write_bytes(out);(ROOT/'rea-inspect-macho.stderr').write_bytes(err)
result['rea_macho']={'returncode':rc,'sha256':sha(out),'bytes':len(out)}
assert rc==0
try:
 o=json.loads(out);result['rea_macho']['evidence_id']=o.get('evidence_id');result['rea_macho']['subject']=o.get('subject')
except Exception as e:result['rea_macho']['parse_error']=str(e)
save('static-recovery.json',result)
files=[]
for p in sorted(ROOT.iterdir()):
 if p.is_file() and p.name not in ['manifest.json','static-menu-recovery.tar.gz']:files.append({'path':p.name,'size':p.stat().st_size,'sha256':sha(p.read_bytes())})
save('manifest.json',{'binary_sha256':EXPECTED,'files':files})
archive=ROOT/'static-menu-recovery.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for f in files:tf.add(ROOT/f['path'],arcname=f['path'],recursive=False)
 tf.add(ROOT/'manifest.json',arcname='manifest.json',recursive=False)
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'payloads':len(files),'functions':[(x['address'],x['instruction_count'],len(x['literal_candidates'])) for x in result['functions']],'rea_macho':result['rea_macho']},indent=2))
