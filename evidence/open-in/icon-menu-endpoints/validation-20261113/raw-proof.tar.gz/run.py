from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, re, signal, subprocess, sys, time

parser = argparse.ArgumentParser()
parser.add_argument('--admission', required=True)
args = parser.parse_args()
ROOT = Path.cwd()
OUT = ROOT / '.oc-tmp/icon-menu-endpoints-next'
PACKET = ROOT / 'evidence/open-in/icon-menu-endpoints/source-v1'
manifest = json.loads((OUT/'manifest.json').read_text())
product = ROOT/'src/features/openIn/OpenInButton.tsx'
fixture = ROOT/'src/features/openIn/iconMenuEndpoints.test.ts'
start = time.monotonic()
events, groups = [], []
passed, staged, original = False, False, None

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*argv):
    return subprocess.check_output(['git',*argv],text=True).strip()

def event(name, **details):
    row = dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(), elapsed_s=round(time.monotonic()-start,6), name=name, **details)
    events.append(row)
    (OUT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
    print(json.dumps(row),flush=True)

def phase(name, argv, ceiling):
    if time.monotonic()-start + ceiling + 60 > manifest['inclusive_seconds']:
        raise RuntimeError('Insufficient remaining inclusive time with cleanup reserve')
    event(name+'-start',argv=argv,ceiling_s=ceiling)
    with (OUT/(name+'.log')).open('wb') as output:
        proc = subprocess.Popen(argv,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        groups.append(proc.pid)
        try:
            code = proc.wait(timeout=ceiling)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.wait()
            raise RuntimeError(name+' exceeded its inclusive phase ceiling')
    content = (OUT/(name+'.log')).read_text(errors='replace')
    event(name+'-end',code=code,sha256=sha(OUT/(name+'.log')))
    return code, content

def tap(content):
    totals = {}
    for key in ('tests','pass','fail','cancelled','skipped','todo'):
        hits = re.findall(r'^# '+key+r' (\d+)$',content,re.M)
        if len(hits) != 1:
            raise RuntimeError('Missing or ambiguous TAP total '+key)
        totals[key] = int(hits[0])
    names = re.findall(r'^(?:not )?ok \d+ - (.*)$',content,re.M)
    if len(names) != totals['tests'] or any(totals[key] for key in ('cancelled','skipped','todo')):
        raise RuntimeError('Incomplete or inconsistent TAP collection')
    return totals,names

def check_pins():
    for path,expected in manifest['source_hashes'].items():
        if path == 'src/features/openIn/OpenInButton.tsx':
            continue
        if sha(ROOT/path) != expected:
            raise RuntimeError('Frozen source or prerequisite changed: '+path)
    if sha(PACKET/'iconMenuEndpoints.test.ts.txt') != manifest['frozen_fixture_sha256']:
        raise RuntimeError('Original fixture changed')
    if sha(PACKET/'candidate.diff.gz') != manifest['compressed_candidate_sha256']:
        raise RuntimeError('Original candidate changed')

command = ['timeout','-k','5s','120s','nice','-n','19','env','NODE_OPTIONS=--max-old-space-size=1024','node','--experimental-strip-types','--test','--test-concurrency=1']
try:
    event('actual-start',admission=args.admission)
    if sha(OUT/'run.py') != manifest['runner_sha256']:
        raise RuntimeError('Runner changed after source binding')
    if git('branch','--show-current') != manifest['branch'] or git('rev-parse','HEAD') != manifest['head'] or git('rev-parse','origin/main') != manifest['main']:
        raise RuntimeError('Branch or source binding changed')
    if git('status','--porcelain=v1','--untracked-files=no'):
        raise RuntimeError('Tracked source not clean')
    subprocess.run(['git','diff','--exit-code','origin/main','HEAD','--'],check=True)
    if fixture.exists():
        raise RuntimeError('Fixture path already exists; will not overwrite')
    check_pins()
    if sha(product) != manifest['product_before_sha256']:
        raise RuntimeError('Baseline product hash changed')
    original = product.read_bytes()
    fixture.write_bytes((PACKET/'iconMenuEndpoints.test.ts.txt').read_bytes())
    staged = True
    if sha(fixture) != manifest['frozen_fixture_sha256'] or time.monotonic()-start > 30:
        raise RuntimeError('Staging identity or 30-second bound failed')
    event('source-qualified',main=manifest['main'],head=manifest['head'],source_hashes=manifest['source_hashes'],fixture_sha256=sha(fixture))
    code,content = phase('baseline',command+['src/features/openIn/iconMenuEndpoints.test.ts'],125)
    totals,names = tap(content)
    failures = [int(index) for index in re.findall(r'^not ok (\d+) - ',content,re.M)]
    if code != 1 or totals != manifest['baseline_expectation'] or names != manifest['tests'] or failures != manifest['intended_failed_indices'] or content.count('code: \'ERR_ASSERTION\'') != 4:
        raise RuntimeError('Baseline is not the complete intended four assertion failures and ten controls')
    event('baseline-qualified',totals=totals,failed_indices=failures)
    patch = gzip.decompress((PACKET/'candidate.diff.gz').read_bytes())
    if hashlib.sha256(patch).hexdigest() != manifest['candidate_patch_sha256']:
        raise RuntimeError('Decompressed candidate hash mismatch')
    subprocess.run(['git','apply','--check','-'],input=patch,check=True)
    subprocess.run(['git','apply','-'],input=patch,check=True)
    if sha(product) != manifest['product_after_sha256']:
        raise RuntimeError('Applied candidate differs from sealed bytes')
    code,content = phase('candidate',command+['src/features/openIn/iconMenuEndpoints.test.ts'],125)
    green,green_names = tap(content)
    if code != 0 or green_names != names or green['tests'] != 14 or green['pass'] != 14 or green['fail']:
        raise RuntimeError('Candidate did not pass identical fourteen cases')
    event('candidate-qualified',totals=green)
    code,content = phase('adjacent',command+manifest['adjacent_files'],125)
    adjacent,_ = tap(content)
    if code != 0 or adjacent['tests'] == 0 or adjacent['pass'] != adjacent['tests'] or adjacent['fail']:
        raise RuntimeError('Adjacent controls failed')
    event('adjacent-qualified',totals=adjacent)
    code,_ = phase('typecheck',['timeout','-k','5s','180s','nice','-n','19','env','NODE_OPTIONS=--max-old-space-size=1536','npm','run','typecheck'],185)
    if code:
        raise RuntimeError('Typecheck failed')
    check_pins()
    if sha(fixture) != manifest['frozen_fixture_sha256'] or sha(product) != manifest['product_after_sha256']:
        raise RuntimeError('Executed fixture or product changed')
    subprocess.run(['git','diff','--check'],check=True)
    passed = True
except Exception as exc:
    event('STOP',reason=str(exc))
finally:
    cleanup_start = time.monotonic()
    killed,remaining = [],[]
    for group in groups:
        try:
            os.killpg(group,0)
        except ProcessLookupError:
            continue
        os.killpg(group,signal.SIGKILL)
        killed.append(group)
    for group in groups:
        try:
            os.killpg(group,0)
            remaining.append(group)
        except ProcessLookupError:
            pass
    if original is not None:
        if sha(product) in (manifest['product_before_sha256'],manifest['product_after_sha256']):
            product.write_bytes(original)
        else:
            passed = False
            event('cleanup-source-mismatch',path=str(product.relative_to(ROOT)))
    if staged:
        if sha(fixture) == manifest['frozen_fixture_sha256']:
            fixture.unlink()
        else:
            passed = False
            event('cleanup-fixture-mismatch',path=str(fixture.relative_to(ROOT)))
    dirty = git('status','--porcelain=v1','--untracked-files=no')
    if dirty or remaining or time.monotonic()-cleanup_start > 60 or time.monotonic()-start > manifest['inclusive_seconds']:
        passed = False
    event('actual-release',result='PASS' if passed else 'STOP',jobs=remaining,servers=[],ownruntime=remaining,killed_own_groups=killed,tracked_status=dirty,product_sha256=sha(product),fixture_absent=not fixture.exists())
    receipt = dict(result='PASS' if passed else 'STOP',start=events[0]['time'],release=events[-1]['time'],elapsed_s=round(time.monotonic()-start,6),events=events)
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(0 if passed else 1)
