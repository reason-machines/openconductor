import datetime
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).parent
name = sys.argv[1]
command = sys.argv[2:]
receipt = root / f"{name}.json"
log = root / f"{name}.log"
if receipt.exists() or log.exists():
    raise SystemExit(f"Refusing repeated command: {name}")
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with log.open("xb") as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
record = {"name": name, "command": command, "started_at": start,
          "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "wall_seconds": round(time.monotonic() - clock, 3), "exit_code": result.returncode}
receipt.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
sys.exit(result.returncode)
