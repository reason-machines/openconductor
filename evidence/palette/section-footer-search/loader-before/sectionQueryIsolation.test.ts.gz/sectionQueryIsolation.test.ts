import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import test from "node:test";
import { runInNewContext } from "node:vm";
import * as React from "react";
import ts from "typescript";
import * as overrides from "../keybindings/overrides.ts";
import * as shortcut from "../keybindings/shortcut.ts";
import * as workspaceNumber from "../state/workspaceNumber.ts";
import * as allWorkspaces from "../home/allWorkspaces.ts";
import * as adapter from "./fromAppState.ts";
import * as search from "./search/model.ts";
import * as state from "./state.ts";
import * as workspacesTab from "./workspacesTab.ts";
import type { AppState } from "../state/types.ts";

// Actual mounted Host, palette input and section picker. External effects are
// inert or forbidden; neither vendor JS nor browser/native input is run.
const dependencies = createRequire(import.meta.url);
const { act, create } = dependencies("react-test-renderer");
const inert = () => null;
const noop = () => {};
const forbidden = () => { throw new Error("Unexpected external operation in section-query fixture"); };
function evaluate(file: string, imports: Record<string, unknown>) {
  const output = ts.transpileModule(readFileSync(new URL(file, import.meta.url), "utf8"), {
    fileName: file,
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
  }).outputText;
  const exports: Record<string, any> = {};
  runInNewContext(output, {
    exports, console, Date,
    require(name: string) {
      if (name === "react" || name === "react/jsx-runtime") return dependencies(name);
      assert.ok(name in imports, `Unexpected ${file} import: ${name}`);
      return imports[name];
    },
  });
  return exports;
}
function loadHost(bindings: overrides.Overrides) {
  const icons = { ConductorIcon: inert };
  const sections = evaluate("./MoveToSection.tsx", { "../components/ConductorIcon": icons });
  const rows = evaluate("./WorkspacesTab.tsx", {
    "../home/allWorkspaces.ts": allWorkspaces,
    "../state/chatUnread.ts": { isWorkspaceUnread: () => false },
    "../features/chat/useWorkspaceSession.ts": { useWorkspaceAgentStatus: () => undefined },
    "../state/rowStatus.ts": { homeStatus: () => "idle", showsActivityStatus: () => false, rowStatusLabel: () => "Idle" },
    "../components/RowStatusIcon": { RowStatusIcon: inert }, "../state/workspaceNumber.ts": workspaceNumber,
    "../workspace/archivedList.ts": { ARCHIVE_FILTER_LABEL: "Archived workspaces" },
    "../components/Icons": { ArchiveIcon: inert, CheckIcon: inert, ChevronDownIcon: inert, FolderIcon: inert },
    "./workspacesTab.ts": workspacesTab,
  });
  const palette = evaluate("./CommandPalette.tsx", {
    "../keybindings/overrides.ts": overrides, "../keybindings/shortcut.ts": shortcut,
    "./search/model.ts": search, "./state.ts": state,
    "../state/workspaceNumber.ts": workspaceNumber, "./fromAppState.ts": adapter,
    "../home/allWorkspaces.ts": { ...allWorkspaces, loadFilters: () => allWorkspaces.CLEARED_FILTERS, saveFilters: noop },
    "../home/allWorkspaces": allWorkspaces, "./workspacesTab.ts": workspacesTab, "./WorkspacesTab.tsx": rows,
    "../components/Icons": { SearchIcon: inert },
    "../components/motion/dialogMotion": { useDialogMotion: () => React.useRef(null) },
    "../components/ConductorIcon": icons, "./palette.css": {},
  });
  return evaluate("./PaletteHost.tsx", {
    "./CommandPalette.tsx": palette, "./MoveToSection.tsx": sections, "./fromAppState.ts": adapter,
    "../keybindings/KeybindingsProvider.tsx": { useKeybindings: noop, useKeybindingOverrides: () => ({ overrides: bindings }) },
    "../settings/searchIndex": { buildSearchIndex: () => ["General", "Appearance", "Advanced"].map((label) => ({ id: label.toLowerCase(), label, keywords: [], icon: "settings", target: { scope: "user", page: label.toLowerCase() } })) },
    "../settings/pages": { settingsGroups: () => [] },
    "../settings/SettingsView": { AGENT_SEARCH_TABS: [], scrollToRow: forbidden, searchIcon: inert },
    "../features/chat/ChatModelPicker": { openAgentSettings: forbidden, openRepoSettingsPage: forbidden, openSettingsPage: forbidden },
    "../settings/useBoolPref.ts": { useBoolPref: () => false }, "../settings/useSettings.ts": { useSettings: () => ({}) },
    "./recentWorkspaces.ts": { loadRecentWorkspaceIds: () => [], saveRecentWorkspaceIds: noop, recordViewedWorkspace: (ids: string[]) => ids },
    "./settingsRepository.ts": { loadLastWorkspaceRoute: () => null, selectedWorkspaceRoute: () => null, saveLastWorkspaceRoute: noop, settingsRepositoryId: forbidden },
    "../workspace/archive": { listArchivedWorkspaces: async () => [] },
    "../state/nextUnread.ts": { openNextUnread: forbidden }, "./projectWorkspace.ts": { preferredProjectWorkspace: forbidden },
    "../features/openIn/OpenInButton.tsx": { AppIcon: inert, useInstalledApps: () => [] },
    "../features/openIn/apps.ts": { openInApp: forbidden },
    "../settings/appPrefs.ts": { recordOpenIn: forbidden, useAppPrefs: () => ({ default_open_in: null }) },
    "../components/Toast": { Toaster: inert, useToasts: () => ({ toasts: [], show: forbidden, dismiss: noop }) },
    "../components/ConductorIcon": icons, "./gitPanelActions.ts": { GIT_PANEL_ACTIONS: [], requestGitPanelAction: forbidden },
  }).PaletteHost;
}
const seed: AppState = {
  selection: { kind: "workspace", repoId: "repo-0", workspaceId: "ws-0-0" },
  repos: [0, 1, 2].map((r) => ({ id: `repo-${r}`, name: `Project ${r}`, path: `/synthetic/project-${r}`, defaultBranch: "main", workspaces: [0, 1, 2].map((w) => ({
    id: `ws-${r}-${w}`, name: `Workspace ${r}-${w}`, branch: `fixture-${r}-${w}`, status: "idle", diff: { added: 0, removed: 0 }, createdAt: r * 3 + w + 1,
  })) })),
  sections: [{ id: "current", name: "Current", workspaceIds: ["ws-0-0"] }, { id: "other", name: "Other", workspaceIds: [] }],
};
function textOf(node: any): string {
  if (typeof node === "string") return node;
  return (Array.isArray(node) ? node : node?.children ?? []).map(textOf).join("");
}
async function fixture() {
  const Host = loadHost({});
  const effects: unknown[] = [];
  const commands = Object.fromEntries(["addProject", "toggleTheme", "toggleLeftSidebar", "toggleRightSidebar", "toggleZenMode", "sendFeedback", "submitPrompt", "showShortcuts", "openChangelog", "openSettings", "openDocs", "quickOpen", "copyUrl", "createSection", "createSectionWithWorkspace"].map((name) => [name, () => effects.push(name)]));
  const props = {
    state: seed, collapsedSections: new Set<string>(), dispatch: (action: unknown) => effects.push(action),
    open: true, onOpenChange: (open: boolean) => effects.push(open), commands,
    onOpenDialog: forbidden, onOpenProject: forbidden,
  };
  let renderer: ReturnType<typeof create>;
  await act(async () => { renderer = create(React.createElement(Host, props)); });
  const input = () => renderer.root.findByProps({ role: "combobox" });
  const rows = () => renderer.root.findAllByProps({ role: "option" }).filter((row: any) => row.props.className?.includes("palette-item"));
  return {
    effects, rows,
    queryValue: () => input().props.value,
    inSections: () => renderer.root.findAllByProps({ "aria-label": "Back to commands" }).length === 1,
    async query(value: string) { await act(async () => { input().props.onChange({ target: { value } }); }); },
    async choose(label: string) {
      const row = rows().find((row: any) => textOf(row) === label || row.findAllByProps({ className: "palette-title" }).some((title: any) => textOf(title) === label));
      assert.ok(row, `normal visible row ${label} exists`);
      await act(async () => { row.props.onClick(); });
    },
    async back() { await act(async () => { renderer.root.findByProps({ "aria-label": "Back to commands" }).props.onClick(); }); },
    async tab(label: string) { await act(async () => { renderer.root.findAllByProps({ role: "tab" }).find((tab: any) => textOf(tab) === label).props.onClick(); }); },
    async key(key: string, modifiers: Record<string, unknown> = {}) {
      const nativeEvent = { key, metaKey: false, ctrlKey: false, altKey: false, shiftKey: false, isComposing: false, keyCode: 0, ...modifiers };
      const event = { ...nativeEvent, nativeEvent, prevented: 0, stopped: 0, preventDefault() { this.prevented++; }, stopPropagation() { this.stopped++; } };
      await act(async () => { input().props.onKeyDown(event); });
      return { prevented: event.prevented, stopped: event.stopped };
    },
    async reopen() {
      await act(async () => { renderer.update(React.createElement(Host, { ...props, open: false })); });
      await act(async () => { renderer.update(React.createElement(Host, props)); });
    },
    async close() { await act(async () => { renderer.unmount(); }); },
  };
}

for (const exit of ["button", "Escape", "Backspace"]) {
  test(`section query is isolated: ${exit} returns to the original command search`, async () => {
    const view = await fixture();
    try {
      await view.query("move");
      await view.choose("Move to section");
      assert.equal(view.inSections(), true);
      assert.equal(view.queryValue(), "", "new section picker starts with its own empty filter");
      if (exit !== "Backspace") await view.query("Other");
      if (exit === "button") await view.back();
      else assert.deepEqual(await view.key(exit), { prevented: 1, stopped: 1 });
      assert.equal(view.inSections(), false);
      assert.equal(view.queryValue(), "move", "returning must restore the retained regular query");
      assert.deepEqual(view.effects, []);
    } finally { await view.close(); }
  });
}

test("section text never leaks into an originally empty command search", async () => {
  const view = await fixture();
  try {
    await view.choose("Move to section");
    await view.query("Other"); await view.back();
    assert.equal(view.queryValue(), "", "section filter must not replace the regular query");
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("back then immediate re-entry retains commands and remounts an empty section filter", async () => {
  const view = await fixture();
  try {
    await view.query("move"); await view.choose("Move to section");
    await view.query("Other"); await view.back();
    assert.equal(view.queryValue(), "move");
    await view.choose("Move to section");
    assert.equal(view.inSections(), true);
    assert.equal(view.queryValue(), "", "a new section sub-view cannot keep the prior section query");
    assert.ok(view.rows().some((row: any) => textOf(row) === "Current"));
    assert.ok(view.rows().some((row: any) => textOf(row) === "Other"));
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("control: section filtering uses only the section query", async () => {
  const view = await fixture();
  try {
    await view.query("move"); await view.choose("Move to section");
    await view.query("Other");
    assert.equal(view.queryValue(), "Other");
    assert.deepEqual(view.rows().map(textOf), ["Other"]);
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("control: nonempty section Backspace stays in the picker and is editable", async () => {
  const view = await fixture();
  try {
    await view.choose("Move to section"); await view.query("Other");
    assert.deepEqual(await view.key("Backspace"), { prevented: 0, stopped: 0 });
    assert.equal(view.inSections(), true); assert.equal(view.queryValue(), "Other");
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("control: current section remains disabled and Enter moves to the enabled target", async () => {
  const view = await fixture();
  try {
    await view.choose("Move to section");
    const current = view.rows().find((row: any) => textOf(row) === "Current");
    assert.equal(current.props["aria-disabled"], true);
    await view.choose("Current"); assert.deepEqual(view.effects, []);
    await view.query("Other"); await view.key("Enter");
    assert.equal(view.effects.length, 1);
    const assignment = view.effects[0] as Record<string, string>;
    assert.deepEqual(Object.keys(assignment).sort(), ["sectionId", "type", "workspaceId"]);
    assert.equal(assignment.type, "assignSection");
    assert.equal(assignment.workspaceId, "ws-0-0");
    assert.equal(assignment.sectionId, "other");
  } finally { await view.close(); }
});

test("control: clearing a section filter restores its footer actions", async () => {
  const view = await fixture();
  try {
    await view.choose("Move to section"); await view.query("not-a-section");
    assert.equal(view.rows().length, 0);
    await view.query("");
    assert.ok(view.rows().some((row: any) => textOf(row) === "New section…"));
    assert.ok(view.rows().some((row: any) => textOf(row) === "Remove from section"));
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("control: regular tab changes keep the regular query", async () => {
  const view = await fixture();
  try {
    await view.query("move"); await view.tab("Actions");
    assert.equal(view.queryValue(), "move"); await view.tab("All");
    assert.equal(view.queryValue(), "move");
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

test("control: completed close and reopen clears both search lifetimes", async () => {
  const view = await fixture();
  try {
    await view.query("move"); await view.choose("Move to section"); await view.query("Other");
    await view.reopen();
    assert.equal(view.queryValue(), ""); assert.equal(view.inSections(), true);
    await view.back(); assert.equal(view.queryValue(), "");
    assert.deepEqual(view.effects, []);
  } finally { await view.close(); }
});

for (const signal of [{ isComposing: true }, { keyCode: 229 }]) {
  test(`control: composing Enter ${JSON.stringify(signal)} does not assign a section`, async () => {
    const view = await fixture();
    try {
      await view.choose("Move to section"); await view.query("Other");
      assert.deepEqual(await view.key("Enter", signal), { prevented: 0, stopped: 0 });
      assert.equal(view.inSections(), true); assert.equal(view.queryValue(), "Other");
      assert.deepEqual(view.effects, []);
    } finally { await view.close(); }
  });
}
