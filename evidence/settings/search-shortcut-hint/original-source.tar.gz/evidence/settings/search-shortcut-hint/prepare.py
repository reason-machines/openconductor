#!/usr/bin/env python3
"""Freeze source patches and expectations without executing application code."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip())
BASE = 'e6836acf258d6b526b5fb1a6d057aa8ee017dc2e'
COMPONENT = 'src/settings/SettingsSearch.tsx'
TEST = 'src/settings/settingsSearchShortcutHint.test.ts'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source(name):
    return subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=ROOT)

def diff(before, after, name):
    return ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/' + name if before else '/dev/null', tofile='b/' + name)).encode()

baseline = source(COMPONENT)
(HERE / 'baseline').mkdir(exist_ok=True)
(HERE / 'baseline/SettingsSearch.tsx.txt').write_bytes(baseline)
component = (HERE / 'candidate/SettingsSearch.tsx.txt').read_bytes()
fixture = (HERE / 'candidate/settingsSearchShortcutHint.test.ts.txt').read_bytes()
patches = {'regression.patch': diff(b'', fixture, TEST), 'fix.patch': diff(baseline, component, COMPONENT)}
for name, patch in patches.items():
    (HERE / (name + '.gz')).write_bytes(gzip.compress(patch, mtime=0))
paths = [
    COMPONENT, 'src/keybindings/KeybindingsProvider.tsx', 'src/keybindings/overrides.ts',
    'src/keybindings/shortcut.ts', 'src/keybindings/types.ts', 'src/keybindings/registry.ts',
    'src/keybindings/bind.ts', 'src/keybindings/dispatcher.ts', 'src/keybindings/listeners.ts',
    'src/keybindings/selectAll.ts', 'src/settings/searchIndex.ts', 'src/settings/routes.ts',
    'src/settings/searchRows.generated.ts', 'src/keybindings/fuzzy.ts',
    'src/settings/garryShortcutHint.test.ts', 'package.json', 'package-lock.json', 'tsconfig.json',
]
cases = re.findall(rb'^test\("([^"]+)"', fixture, re.M)
assert len(cases) == 6
failed = {1, 2, 3}
manifest = {
    'owner': 'Conductor Rebuild / SAME49', 'baseline_ref': BASE,
    'status': 'SOURCE_PREPARED_BEHAVIOR_NOT_RUN',
    'runtime_owner': 'existing ACC allocation; no new runtime entry',
    'component_path': COMPONENT, 'test_path': TEST,
    'baseline_sha256': {name: sha(source(name)) for name in paths},
    'candidate_sha256': {COMPONENT: sha(component), TEST: sha(fixture)},
    'patch_sha256': {name: sha(data) for name, data in patches.items()},
    'case_seal': [{'id': name.decode(), 'expected_baseline': 'assertion_failure' if index in failed else 'pass'} for index, name in enumerate(cases)],
    'expected_baseline': {'collected': 6, 'assertion_failures': 3, 'passing_controls': 3, 'setup_errors': 0, 'skips': 0},
    'expected_fixed': {'collected': 6, 'passed': 6, 'skips': 0},
    'command': 'node --test --test-concurrency=1 src/settings/settingsSearchShortcutHint.test.ts',
    'adjacent_command': 'node --test --test-concurrency=1 src/settings/searchIndex.test.ts src/settings/keybindingOverrides.test.ts src/settings/garryShortcutHint.test.ts',
    'typecheck_command': 'npx tsc --noEmit',
    'protected_evidence_sha256': {name: sha((ROOT / name).read_bytes()) for name in [
        'evidence/settings/scrollback-db-persistence/fix.patch.gz',
        'evidence/settings/scrollback-db-persistence/regression.patch.gz',
        'evidence/settings/repo-remote-name/fix.patch.gz',
        'evidence/settings/repo-remote-name/regression.patch.gz',
    ]},
}
(HERE / 'binding.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Prepared source only:', len(paths), 'pins;', len(cases), 'frozen case expectations. No Node or application execution.')
