#!/usr/bin/env python3
"""Verify the inert source packet and actual Git patch application, not behavior."""
from pathlib import Path
import argparse
import ast
import gzip
import hashlib
import json
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source(ref, path):
    return subprocess.check_output(['git', 'show', ref + ':' + path], cwd=ROOT)

def check(renderer=None, index=None):
    binding = json.loads((HERE / 'binding.json').read_text())
    reference = json.loads((HERE / 'reference/source.json').read_text())
    assert (renderer is None) == (index is None), 'provide both retained assets or neither'
    assets = {} if renderer is None else {'renderer': Path(renderer).read_bytes(), 'index': Path(index).read_bytes()}
    for key, data in assets.items():
        assert sha(data) == reference['asset_sha256'][key], key
    for span in reference['spans']:
        data = (HERE / 'reference' / (span['name'] + '.txt')).read_bytes()
        assert len(data) == span['bytes'] == span['end'] - span['start'], span['name']
        assert sha(data) == span['sha256'], span['name']
        if assets:
            assert assets[span['asset']][span['start']:span['end']] == data, span['name']
    if assets:
        print('PASS: both full retained asset identities and all 23 exact-offset spans')
    for path, expected in binding['baseline_sha256'].items():
        assert sha(source(binding['baseline_ref'], path)) == expected, path
        assert sha(source('origin/main', path)) == expected, 'main changed: ' + path
    for path, expected in binding['protected_evidence_sha256'].items():
        assert sha((ROOT / path).read_bytes()) == expected, path
    patches = {name: gzip.decompress((HERE / (name + '.gz')).read_bytes()) for name in binding['patch_sha256']}
    for name, expected in binding['patch_sha256'].items():
        assert sha(patches[name]) == expected, name
    fixture = (HERE / 'candidate/settingsSearchShortcutHint.test.ts.txt').read_bytes()
    cases = re.findall(rb'^test\("([^"]+)"', fixture, re.M)
    assert [name.decode() for name in cases] == [case['id'] for case in binding['case_seal']]
    assert sum(case['expected_baseline'] == 'assertion_failure' for case in binding['case_seal']) == 3
    component_path, test_path = binding['component_path'], binding['test_path']
    before = (HERE / 'baseline/SettingsSearch.tsx.txt').read_bytes()
    candidate = (HERE / 'candidate/SettingsSearch.tsx.txt').read_bytes()
    assert before == source(binding['baseline_ref'], component_path)
    render_start = b'\n  return (\n    <div'
    assert before.split(render_start, 1)[1] == candidate.split(render_start, 1)[1], 'rendered search behavior changed'
    assert before.split(b'  const [query', 1)[1].split(b'  const parts =', 1)[0] == candidate.split(b'  const [query', 1)[1].split(b'  const primaryShortcut =', 1)[0], 'query/keyboard/focus behavior changed'
    assert b'effectiveShortcuts("settings.search", overrides)[0]' in candidate
    assert b'const { overrides } = useKeybindingOverrides();' in candidate
    assert b'COMMANDS' not in candidate
    with tempfile.TemporaryDirectory(prefix='oc-search-hint-') as temp:
        directory = Path(temp)
        baseline = directory / component_path
        baseline.parent.mkdir(parents=True)
        baseline.write_bytes(before)
        subprocess.run(['git', 'init', '-q', temp], check=True, capture_output=True)
        for name in ['regression.patch', 'fix.patch']:
            subprocess.run(['git', '-C', temp, 'apply', '--check', '-'], input=patches[name], check=True, capture_output=True)
            subprocess.run(['git', '-C', temp, 'apply', '-'], input=patches[name], check=True, capture_output=True)
        for path, expected in binding['candidate_sha256'].items():
            assert sha((directory / path).read_bytes()) == expected, path
        assert (directory / test_path).read_bytes() == fixture
        broken = patches['fix.patch'].replace(b'  const parts = SEARCH_COMMAND', b'  const parts = STALE_COMMAND', 1)
        baseline.write_bytes(before)
        rejected = subprocess.run(['git', '-C', temp, 'apply', '--check', '-'], input=broken, capture_output=True)
        assert rejected.returncode != 0, 'stale context was not rejected'
    for path in HERE.glob('*.py'):
        ast.parse(path.read_text(), filename=str(path))
    print('PASS: 23 retained span hashes, 18 fresh-main pins, two patch applications, six frozen cases and stale-context rejection')
    print('NOT RUN: Node tests, typecheck, browser, native, screenshot, persistence, package and reference JavaScript')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--renderer')
    parser.add_argument('--index')
    args = parser.parse_args()
    check(args.renderer, args.index)
