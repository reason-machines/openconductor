# Keep the Settings search hint in sync with its shortcut

Conductor Rebuild prepared this isolated source correction against main `e6836acf258d6b526b5fb1a6d057aa8ee017dc2e`. The active product files are unchanged. Component tests, typecheck, browser behavior, and native parity are **NOT RUN**. The mismatch is source-derived, not a measured behavioral failure.

## Reference and counterexample

The retained Conductor 0.87.6 renderer's `a9a` reads `jde("settings.search")?.key` and converts that primary shortcut to parts with `Zj`. `jde` reads the live overrides through `Mde`, which subscribes to the override store. Its `wYe` import joins the index export `OQt`. `OQt` calls `GUt`, and `GUt` takes the first shortcut from `nh`. `nh` selects the override list when present, otherwise the command's defaults. The stored-override parser and subscription are retained too. The configurable registry entry supplies Command-F by default.

The hint displays the primary binding only. It does not concatenate additional alternatives. Logical keys use their value; physical keys use their display text. These conclusions come from the complete retained functions and cross-chunk joins, not a newly executed reference app.

At the checked main, `SettingsSearch` reads `COMMANDS.find(...).key`, even though its real keybinding handler already receives live overrides through `useKeybindings`. For a saved Command-Shift-K override, the displayed source still selects Command-F. This is the concrete source-derived counterexample.

[The source record](reference/source.json) pins 23 compiled-byte spans, half-open UTF-8 offsets, both complete asset hashes, and REA receipt `ev_410f83a50764142c952de5f040cde338700477289c1687932071bdc5427c84b2`. Both asset identities and all spans were checked against the retained originals. The earlier semantic renderer analysis exhausted its heap. No reference JavaScript or native app was executed in this inquiry; no new REA gap occurred.

## Bounded correction

[The fix patch](fix.patch.gz) changes only the imports and hint derivation in `src/settings/SettingsSearch.tsx`. It reads `useKeybindingOverrides`, resolves `effectiveShortcuts("settings.search", overrides)[0]`, and keeps the existing glyph conversion. It reuses the real shortcut model, provider subscription, and formatter rather than adding another state or helper. Laziness Protocol kept this a one-component correction. Type System Discipline kept the primary binding as the existing `Shortcut` type, with an explicit absent-value branch.

The ledger cleared this exact hint hunk and the new dedicated test. No provider, registry, shared helper, search query, ranking, dismissal, keyboard, focus, Reset, ConfigSync, remote-name, or scrollback edits are included. The verifier compares both the query-handling section and the complete rendered JSX byte-for-byte with the baseline. The remote-name and scrollback patch bytes are pinned separately.

## Frozen regression source

[The regression patch](regression.patch.gz) adds `src/settings/settingsSearchShortcutHint.test.ts`. It renders the actual `SettingsSearch` with the actual `KeybindingsProvider`, override parser, formatter, registry, and search index. The test supplies inert listener targets and empty icon components. It invokes no native bridge and does not claim DOM geometry or physical key delivery. This follows the existing Garry Mode hint fixture's TSX-loading pattern.

Test Behavior, Not Implementation shaped the assertions. They inspect the displayed glyphs through the rendered hint, not a newly added helper or a source-text match.

Six cases are frozen in [the binding](binding.json):

- Default primary binding. Expected baseline control passes.
- Saved binding hydrated after mount. Expected baseline assertion fails.
- Live remap and reset on one mounted component. Expected baseline assertion fails at the remapped hint.
- Primary physical binding with an additional alternative. Expected baseline assertion fails.
- Query hides the hint; clearing restores the default. Expected baseline control passes.
- Another command's override leaves the hint alone. Expected baseline control passes.

These are predictions, not test results. Qualification requires all six collected, exactly three intended assertion failures and three passing controls on the baseline, then all six passing with the identical fixture after the fix. Setup, import, compilation, and environment failures do not qualify as RED. No skips are accepted.

The selected focused command is:

```bash
node --test --test-concurrency=1 src/settings/settingsSearchShortcutHint.test.ts
```

The adjacent command is:

```bash
node --test --test-concurrency=1 src/settings/searchIndex.test.ts src/settings/keybindingOverrides.test.ts src/settings/garryShortcutHint.test.ts
```

Typecheck is `npx tsc --noEmit`. Execution and standalone-main publication stay with the existing ACC allocation and publisher. This source packet does not add a runtime entry or authorize another runner. All enabled exact-head workflows must pass before merge.

## Checks run on Reason Cloud computer 356

- `python3 -B evidence/settings/search-shortcut-hint/prepare.py` passed. It generated deterministic patches, eighteen source/dependency pins, and six frozen expectations.
- `python3 -B evidence/settings/search-shortcut-hint/verify_source.py --renderer <retained-renderer> --index <retained-index>` passed. Both full asset hashes, all 23 exact-offset spans, current-main pins, protected candidate hashes, and actual regression-then-fix Git patch application matched.
- The same verifier rejected a deliberately stale patch context and parsed both Python scripts successfully. Build the Lever produced this rerunnable verifier rather than a one-off integrity claim.
- `git diff --check` passed.

No Node, install, Rust, application, reference-JavaScript, browser, package, or native execution ran. There is no screenshot because this lane has no browser or native runtime allocation. The visual hint, real key delivery, persisted remap across app restart, packaging, and native parity remain unverified. Source preparation is not a completed fix.
