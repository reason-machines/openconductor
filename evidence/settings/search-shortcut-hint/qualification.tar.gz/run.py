#!/usr/bin/env python3
"""One sequential, bounded driver for the admitted SettingsSearch regression."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path.cwd()
OUT = ROOT / '.oc-tmp/search-hint-admitted-20261113T0327'
OUT.mkdir(exist_ok=False)
PACKET = ROOT / '.oc-tmp/search-hint-original/evidence/settings/search-shortcut-hint'
BINDING = json.loads((PACKET / 'binding.json').read_text())
COMPONENT = BINDING['component_path']
FIXTURE = BINDING['test_path']
START = time.monotonic()
GROUPS = []
RECEIPT = {'admission': 'ACC_49_SEARCH_HINT6_20261113T0327', 'computer': 'Reason Cloud computer 356', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'steps': [], 'status': 'RUNNING'}
ENV = dict(os.environ)
ENV['npm_config_jobs'] = '1'
ENV['npm_config_maxsockets'] = '1'
FIX = gzip.decompress((PACKET / 'fix.patch.gz').read_bytes())
assert hashlib.sha256(FIX).hexdigest() == BINDING['patch_sha256']['fix.patch']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def saved():
    RECEIPT['elapsed_seconds'] = round(time.monotonic() - START, 3)
    (OUT / 'receipt.json').write_text(json.dumps(RECEIPT, indent=2) + '\n')

def inputs(candidate=False):
    expected = dict(BINDING['baseline_sha256'])
    if candidate:
        expected[COMPONENT] = BINDING['candidate_sha256'][COMPONENT]
    for path, digest in expected.items():
        assert sha(ROOT / path) == digest, 'INPUT DRIFT: ' + path
    assert sha(ROOT / FIXTURE) == BINDING['candidate_sha256'][FIXTURE], 'FROZEN FIXTURE DRIFT'
    assert sha(ROOT / 'evidence/settings/search-shortcut-hint/original-source.tar.gz') == 'bec382f8bdf6ae2e7efe75078736f4bed20514f1df41c1f547ce9ac02036be73'
    assert git('rev-parse', 'HEAD') == RECEIPT['execution_head'], 'EXECUTION HEAD DRIFT'
    changed = set(git('diff', '--name-only', RECEIPT['execution_head']).splitlines())
    assert changed == ({COMPONENT} if candidate else set()), ('UNEXPECTED DELTA', changed)

def run(name, argv, seconds, heap=None):
    assert time.monotonic() - START < 1320, 'TOTAL BUDGET'
    env = dict(ENV)
    if heap:
        env['NODE_OPTIONS'] = f'--max-old-space-size={heap}'
    if name == 'typecheck':
        env['npm_config_offline'] = 'true'
        env['npm_config_yes'] = 'false'
    actual = ['nice', '-n', '19', *argv]
    step = {'name': name, 'argv': actual, 'cwd': '.', 'env_nonsecret': {k: env[k] for k in ['NODE_OPTIONS', 'npm_config_jobs', 'npm_config_maxsockets', 'npm_config_offline', 'npm_config_yes'] if k in env}, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'timeout_seconds': seconds, 'grace_seconds': 5}
    before = time.monotonic()
    with (OUT / f'{name}.stdout.txt').open('w') as stdout, (OUT / f'{name}.stderr.txt').open('w') as stderr:
        child = subprocess.Popen(actual, stdout=stdout, stderr=stderr, env=env, cwd=ROOT, start_new_session=True)
        GROUPS.append(child.pid)
        step['process_group'] = child.pid
        try:
            code = child.wait(timeout=min(seconds, max(1, 1320 - (time.monotonic() - START))))
        except subprocess.TimeoutExpired:
            step['timed_out'] = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
    step.update({'exit_code': code, 'elapsed_seconds': round(time.monotonic() - before, 3), 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    RECEIPT['steps'].append(step)
    saved()
    print(name, 'exit', code, 'seconds', step['elapsed_seconds'], flush=True)
    return step, (OUT / f'{name}.stdout.txt').read_text(), (OUT / f'{name}.stderr.txt').read_text()

def counts(text):
    return {name: int(value) for name, value in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', text, re.M)}

def installed():
    versions = {}
    for name, expected in [('react', '18.3.1'), ('react-test-renderer', '18.3.1'), ('typescript', '5.9.3')]:
        path = ROOT / 'node_modules' / name / 'package.json'
        assert path.is_file(), 'MISSING LOCAL DEP: ' + name
        versions[name] = json.loads(path.read_text())['version']
        assert versions[name] == expected, ('DEPENDENCY VERSION DRIFT', versions)
    assert (ROOT / 'node_modules/.bin/tsc').is_file(), 'LOCAL TSC ABSENT'
    RECEIPT['installed_versions'] = versions

qualified = False
applied = False
try:
    source_start = time.monotonic()
    RECEIPT['execution_head'] = git('rev-parse', 'HEAD')
    RECEIPT['qualified_main'] = git('rev-parse', 'origin/main')
    RECEIPT['node_version'] = subprocess.check_output(['node', '--version'], text=True).strip()
    assert git('branch', '--show-current') == 'reason/openconductor-sol-settin-49e3976d'
    allowed = {FIXTURE, 'evidence/settings/search-shortcut-hint/README.md', 'evidence/settings/search-shortcut-hint/fresh-main-binding.json', 'evidence/settings/search-shortcut-hint/original-source.tar.gz'}
    assert set(git('diff', '--name-only', RECEIPT['qualified_main'], 'HEAD').splitlines()) == allowed
    inputs()
    RECEIPT['source_pins'] = BINDING['baseline_sha256']
    RECEIPT['fixture_sha256'] = sha(ROOT / FIXTURE)
    RECEIPT['source_seconds'] = round(time.monotonic() - source_start, 3)
    assert RECEIPT['source_seconds'] <= 60
    saved()
    if not (ROOT / 'node_modules').exists():
        step, _, _ = run('setup', ['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], 600, 1024)
        assert step['exit_code'] == 0 and not step.get('timed_out'), 'SETUP FAILED'
    else:
        RECEIPT['setup'] = 'Reused own-root dependencies only; versions verified below'
    installed()
    inputs()
    step, stdout, stderr = run('red', ['node', '--test', '--test-concurrency=1', FIXTURE], 90, 768)
    step['counts'] = counts(stdout)
    expected_red = {'tests': 6, 'pass': 3, 'fail': 3, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    assert step['exit_code'] == 1 and not step.get('timed_out') and step['counts'] == expected_red, 'UNEXPECTED RED COUNTS'
    failed = re.findall(r'^not ok \d+ - (.+)$', stdout, re.M)
    intended = [case['id'] for case in BINDING['case_seal'] if case['expected_baseline'] == 'assertion_failure']
    assert failed == intended, ('UNEXPECTED RED CASES', failed)
    assert stdout.count("code: 'ERR_ASSERTION'") == 3 and stdout.count("failureType: 'testCodeFailure'") == 3, 'RED NOT ASSERTION-ONLY'
    inputs()
    qualified = True
    subprocess.run(['git', 'apply', '-'], input=FIX, check=True)
    applied = True
    inputs(True)
    step, stdout, stderr = run('green', ['node', '--test', '--test-concurrency=1', FIXTURE], 90, 768)
    step['counts'] = counts(stdout)
    assert step['exit_code'] == 0 and not step.get('timed_out') and step['counts'] == {'tests': 6, 'pass': 6, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}, 'GREEN FAILED'
    inputs(True)
    step, stdout, stderr = run('adjacent', ['node', '--test', '--test-concurrency=1', 'src/settings/searchIndex.test.ts', 'src/settings/keybindingOverrides.test.ts', 'src/settings/garryShortcutHint.test.ts'], 120, 768)
    step['counts'] = counts(stdout)
    assert step['exit_code'] == 0 and not step.get('timed_out'), 'ADJACENT FAILED'
    assert step['counts'].get('fail') == 0 and step['counts'].get('skipped') == 0 and step['counts'].get('cancelled') == 0 and step['counts'].get('todo') == 0, 'ADJACENT INCOMPLETE'
    inputs(True)
    installed()
    step, stdout, stderr = run('typecheck', ['npx', 'tsc', '--noEmit'], 180, 1536)
    assert step['exit_code'] == 0 and not step.get('timed_out'), 'TYPECHECK FAILED'
    inputs(True)
    RECEIPT['status'] = 'PASS'
except BaseException as error:
    RECEIPT['status'] = 'STOP'
    RECEIPT['error'] = str(error)
    print('STOP:', error, flush=True)
finally:
    # Leave the admitted candidate present only after its intended RED qualified.
    if qualified and not applied:
        subprocess.run(['git', 'apply', '-'], input=FIX, check=True)
        applied = True
    alive = []
    for group in GROUPS:
        try:
            os.killpg(group, 0)
        except ProcessLookupError:
            continue
        os.killpg(group, signal.SIGTERM)
        alive.append(group)
    if alive:
        RECEIPT['cleanup_signalled_groups'] = alive
    remaining = []
    for group in GROUPS:
        try:
            os.killpg(group, 0)
            remaining.append(group)
        except ProcessLookupError:
            pass
    RECEIPT['owned_groups_remaining'] = remaining
    RECEIPT['owned_groups_absent'] = not remaining
    RECEIPT['candidate_present'] = applied and sha(ROOT / COMPONENT) == BINDING['candidate_sha256'][COMPONENT]
    RECEIPT['fixture_unchanged'] = sha(ROOT / FIXTURE) == BINDING['candidate_sha256'][FIXTURE]
    RECEIPT['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    RECEIPT['explicit_release'] = not remaining
    saved()
    print(json.dumps(RECEIPT, indent=2), flush=True)
if RECEIPT['status'] != 'PASS' or not RECEIPT['owned_groups_absent']:
    raise SystemExit(1)
