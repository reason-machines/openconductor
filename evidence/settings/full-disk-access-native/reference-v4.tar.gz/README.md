# Full Disk Access native static recovery

Conductor Rebuild recovered the macOS command's registration, handler, file probe and ordinary boolean return paths from the actual Conductor 0.87.6 executable on Sven's `sven m5 max`. This is static reconstruction, not decompiler output, original Rust source or observed native execution.

## Identity and method

- Executable SHA-256 `0ba55751aea5ecf592d2c78379760af641fb912a34b2c3573d41df031ffb831d`, 70,194,640 bytes, arm64.
- REA 6.7.0 `inspect-macho` evidence `ev_0cf38b016e6c7595876a84f89c11d46541a225caf37f0317089a21ff09d2da67` binds that executable and Mach-O layout.
- REA's Ghidra, Hopper, IDA and Kuna deep-analysis providers were unavailable on this Mac. The exact observed gap is retained in `source/provider-gap.json`. No installation or provisioning occurred.
- Existing macOS `nm -n` and bounded `otool -tvV -p` provided supporting symbol and disassembly records. The target was never executed. No TCC database or permission state was read by the investigation.
- The Mac data-only extractor checked the complete executable digest before and after extracting 12 native slices. Those slices total 21,613 bytes. The complete executable is not included.
- The source-only Mac archive copied to cloud has SHA-256 `c678c694157f5e8e0445fad8350bc94eb85751af0f1e56870f2c6dffd062494c` and size 227,623 bytes.

## Recovered chain

1. Dispatch entry `0x100493640` reads the command length and data. Length 22 enters the bucket at `0x100493a24`. The preceding `get_db_version_warning` comparison fails for this input. Three immediate comparisons at `0x100493a74`, `0x100493a88` and `0x100493a9c` match the overlapping byte chunks `check_fu`, `ll_disk_` and `k_access`. The equality branch at `0x100493ab0` targets `0x100496d18`.
2. That block calls wrapper `0x10048d2b0` at `0x100496d58`. The wrapper calls `conductor_lib::check_full_disk_access` at `0x10048d304`. Its ordinary response uses the bool-specialized Tauri `InvokeResolver::respond` at `0x10048d334`.
3. The complete handler interval is `[0x1006e5f18, 0x1006e6198)`, 640 bytes and 160 instructions. It reads `HOME`, joins `Library/Application Support/com.apple.TCC/TCC.db`, opens the resulting path and attempts a one-byte read. These are decoded literal bytes and named native call anchors, not a probe of the current OS permission.
4. The error-kind classification tests discriminant 1 in all four supported error representations. The compiled `ErrorKind::Debug` lookup maps 1 to `PermissionDenied`. That branch writes false at `0x1006e60b4`. Other handled errors and successful reads write true at `0x1006e60c4`. The environment-lookup sentinel path writes true at `0x1006e600c`. The common normal return moves the boolean to `x0` at `0x1006e60f0` and returns at `0x1006e6108`.
5. The ordinary handler does not return a typed error through this bool-specialized response. Exception cleanup and unwind paths are present. They are not evidence of a live IPC rejection. The already retained renderer catches an invocation rejection and substitutes true separately.

The reconstructed predicate is a permission-denied heuristic. A true return does not establish that macOS Full Disk Access is genuinely granted, because absent environment and non-permission errors use the fail-open path.

## Current OpenConductor boundary

Fresh main `6ea86f222815a43ab12355eee2afbdcd981b2164` was fetched after the APT repair merge. The current GeneralPage, bridge and native registration are preserved under `current/` with hashes in `current-main.json`. The Full Disk Access row still only opens System Settings. A bounded tracked search over `src` and `src-tauri` found no `check_full_disk_access` command. No product edit was made.

## Verification

`python3 verify.py` passed all 15 static identity, slice, instruction-completeness, dispatch-match and return-anchor checks on Reason cloud. The verifier records its precise limits in `verification.json`. It does not execute or emulate target code and is not a product regression suite.

The original seven-case Full Disk Access fixture is unchanged. Mounted RED/GREEN, real permission prompts, native probes, visual acceptance and non-macOS behavior were not run. No native runtime admission, provider execution, install or frozen-queue change occurred.

## Ownership

This same Settings Session performed the coordinator-authorized read-only recovery. Ledger Session `ddfc6518-d50f-46a6-b83c-c3a18aa07e43` has been asked for an explicit overlapping recovery owner or NONE. Its current turn is running and no exact disposition has arrived. Forwarding is not recorded as an assignment. Product implementation has not been claimed or started without that reconciliation.

Existing #1043 and #1051 subscriptions and delivery owners remain separate. This packet is a bounded investigation artifact, not a new product PR or a native acceptance receipt.
