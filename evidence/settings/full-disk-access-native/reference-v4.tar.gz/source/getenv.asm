/Applications/Conductor.app/Contents/MacOS/conductor:
(__TEXT,__text) section
__RNvNtNtNtCs82bWklYMk3w_3std3sys3env4unix6getenv:
00000001012fcf04	sub	sp, sp, #0x1e0
00000001012fcf08	stp	x22, x21, [sp, #0x1b0]
00000001012fcf0c	stp	x20, x19, [sp, #0x1c0]
00000001012fcf10	stp	x29, x30, [sp, #0x1d0]
00000001012fcf14	add	x29, sp, #0x1d0
00000001012fcf18	mov	x20, x1
00000001012fcf1c	mov	x1, x0
00000001012fcf20	mov	x19, x8
00000001012fcf24	cmp	x20, #0x17f
00000001012fcf28	b.hi	0x1012fcfd0
00000001012fcf2c	add	x21, sp, #0x18
00000001012fcf30	add	x0, sp, #0x18
00000001012fcf34	mov	x2, x20
00000001012fcf38	bl	0x101381110 ; symbol stub for: _memcpy
00000001012fcf3c	strb	wzr, [x21, x20]
00000001012fcf40	sub	x8, x29, #0x38
00000001012fcf44	add	x0, sp, #0x18
00000001012fcf48	add	x1, x20, #0x1
00000001012fcf4c	bl	__RNvMs3_NtNtCs8Mbv00yxnRz_4core3ffi5c_strNtB5_4CStr19from_bytes_with_nul
00000001012fcf50	ldur	x8, [x29, #-0x38]
00000001012fcf54	cmp	x8, #0x1
00000001012fcf58	b.ne	0x1012fcf7c
00000001012fcf5c	adrp	x8, 7784 ; 0x103164000
00000001012fcf60	add	x8, x8, #0x568
00000001012fcf64	mov	x9, #-0x2
00000001012fcf68	stp	x9, x8, [sp]
00000001012fcf6c	ldr	x8, [sp]
00000001012fcf70	cmn	x8, #0x2
00000001012fcf74	b.eq	0x1012fcf94
00000001012fcf78	b	0x1012fcfe8
00000001012fcf7c	ldur	x1, [x29, #-0x30]
00000001012fcf80	mov	x8, sp
00000001012fcf84	bl	__RNCNvNtNtNtCs82bWklYMk3w_3std3sys3env4unix6getenv0B9_
00000001012fcf88	ldr	x8, [sp]
00000001012fcf8c	cmn	x8, #0x2
00000001012fcf90	b.ne	0x1012fcfe8
00000001012fcf94	ldr	x8, [sp, #0x8]
00000001012fcf98	and	x9, x8, #0x3
00000001012fcf9c	sub	x10, x9, #0x2
00000001012fcfa0	cmp	x10, #0x2
00000001012fcfa4	ccmp	x9, #0x0, #0x4, hs
00000001012fcfa8	b.eq	0x1012fcfc8
00000001012fcfac	sub	x8, x8, #0x1
00000001012fcfb0	add	x9, sp, #0x18
00000001012fcfb4	str	x8, [sp, #0x20]
00000001012fcfb8	mov	w8, #0x3
00000001012fcfbc	strb	w8, [sp, #0x18]
00000001012fcfc0	add	x0, x9, #0x8
00000001012fcfc4	bl	__RNvXsd_NtNtCs8Mbv00yxnRz_4core2io5errorNtB5_11CustomOwnerNtNtNtB9_3ops4drop4Drop4drop
00000001012fcfc8	mov	x8, #-0x1
00000001012fcfcc	b	0x1012fcff4
00000001012fcfd0	mov	x0, sp
00000001012fcfd4	mov	x2, x20
00000001012fcfd8	bl	__RINvNtNtNtCs82bWklYMk3w_3std3sys7helpers14small_c_string24run_with_cstr_allocatingINtNtCs8Mbv00yxnRz_4core6option6OptionNtNtNtB8_3ffi6os_str8OsStringEEB8_
00000001012fcfdc	ldr	x8, [sp]
00000001012fcfe0	cmn	x8, #0x2
00000001012fcfe4	b.eq	0x1012fcf94
00000001012fcfe8	mov	x9, sp
00000001012fcfec	ldur	q0, [x9, #0x8]
00000001012fcff0	stur	q0, [x19, #0x8]
00000001012fcff4	str	x8, [x19]
00000001012fcff8	ldp	x29, x30, [sp, #0x1d0]
00000001012fcffc	ldp	x20, x19, [sp, #0x1c0]
00000001012fd000	ldp	x22, x21, [sp, #0x1b0]
00000001012fd004	add	sp, sp, #0x1e0
00000001012fd008	ret
__RNvNtNtNtCs82bWklYMk3w_3std3sys3env4unix6setenv:
