000000010048d2b0	stp	x28, x27, [sp, #-0x50]!
000000010048d2b4	stp	x24, x23, [sp, #0x10]
000000010048d2b8	stp	x22, x21, [sp, #0x20]
000000010048d2bc	stp	x20, x19, [sp, #0x30]
000000010048d2c0	stp	x29, x30, [sp, #0x40]
000000010048d2c4	add	x29, sp, #0x40
000000010048d2c8	sub	sp, sp, #0x550
000000010048d2cc	str	xzr, [sp]
000000010048d2d0	mov	x20, x0
000000010048d2d4	add	x0, sp, #0x8
000000010048d2d8	mov	x1, x20
000000010048d2dc	mov	w2, #0x208
000000010048d2e0	bl	0x101381110 ; symbol stub for: _memcpy
000000010048d2e4	add	x0, sp, #0x210
000000010048d2e8	add	x1, x20, #0x208
000000010048d2ec	mov	w2, #0x190
000000010048d2f0	bl	0x101381110 ; symbol stub for: _memcpy
000000010048d2f4	ldr	x22, [x20, #0x398]
000000010048d2f8	ldr	x19, [x20, #0x3a0]
000000010048d2fc	mov	w24, #0x1
000000010048d300	ldr	x23, [x20, #0x3a8]
000000010048d304	bl	__RNvCs4s5yNBgRfbF_13conductor_lib22check_full_disk_access
000000010048d308	mov	x21, x0
000000010048d30c	add	x0, sp, #0x3a0
000000010048d310	add	x1, x20, #0x208
000000010048d314	mov	w2, #0x190
000000010048d318	bl	0x101381110 ; symbol stub for: _memcpy
000000010048d31c	sturb	w21, [x29, #-0x5f]
000000010048d320	mov	w8, #0xff
000000010048d324	sturb	w8, [x29, #-0x60]
000000010048d328	mov	w24, #0x0
000000010048d32c	add	x0, sp, #0x3a0
000000010048d330	sub	x1, x29, #0x60
000000010048d334	bl	__RINvMsi_NtCskIc2FNOgRlU_5tauri3ipcNtB6_14InvokeResolver7respondbECs4s5yNBgRfbF_13conductor_lib
000000010048d338	cmn	x22, #0x1
000000010048d33c	b.eq	0x10048d378
000000010048d340	add	x23, x23, #0x1
000000010048d344	mov	x0, x19
000000010048d348	subs	x23, x23, #0x1
000000010048d34c	b.eq	0x10048d360
000000010048d350	add	x21, x0, #0x60
000000010048d354	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtNtCsbNozesAPLQa_11tauri_utils3acl8resolved15ResolvedCommandECs4s5yNBgRfbF_13conductor_lib
000000010048d358	mov	x0, x21
000000010048d35c	b	0x10048d348
000000010048d360	cbz	x22, 0x10048d378
000000010048d364	add	x8, x22, x22, lsl #1
000000010048d368	lsl	x1, x8, #5
000000010048d36c	mov	x0, x19
000000010048d370	mov	w2, #0x8
000000010048d374	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
000000010048d378	add	x0, sp, #0x8
000000010048d37c	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCskIc2FNOgRlU_5tauri3ipc13InvokeMessageECs4s5yNBgRfbF_13conductor_lib
000000010048d380	add	sp, sp, #0x550
000000010048d384	ldp	x29, x30, [sp, #0x40]
000000010048d388	ldp	x20, x19, [sp, #0x30]
000000010048d38c	ldp	x22, x21, [sp, #0x20]
000000010048d390	ldp	x24, x23, [sp, #0x10]
000000010048d394	ldp	x28, x27, [sp], #0x50
000000010048d398	ret
000000010048d39c	mov	x8, x20
000000010048d3a0	mov	x20, x0
000000010048d3a4	add	x0, x8, #0x398
000000010048d3a8	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtNtCsbNozesAPLQa_11tauri_utils3acl8resolved15ResolvedCommandEEECs4s5yNBgRfbF_13conductor_lib
000000010048d3ac	tbz	w24, #0x0, 0x10048d3f4
000000010048d3b0	add	x0, sp, #0x210
000000010048d3b4	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCskIc2FNOgRlU_5tauri3ipc14InvokeResolverECs4s5yNBgRfbF_13conductor_lib
000000010048d3b8	b	0x10048d3f4
000000010048d3bc	mov	x20, x0
000000010048d3c0	subs	x23, x23, #0x1
000000010048d3c4	b.eq	0x10048d3dc
000000010048d3c8	add	x24, x21, #0x60
000000010048d3cc	mov	x0, x21
000000010048d3d0	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtNtCsbNozesAPLQa_11tauri_utils3acl8resolved15ResolvedCommandECs4s5yNBgRfbF_13conductor_lib
000000010048d3d4	mov	x21, x24
000000010048d3d8	b	0x10048d3c0
000000010048d3dc	cbz	x22, 0x10048d3f4
000000010048d3e0	add	x8, x22, x22, lsl #1
000000010048d3e4	lsl	x1, x8, #5
000000010048d3e8	mov	x0, x19
000000010048d3ec	mov	w2, #0x8
000000010048d3f0	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
000000010048d3f4	add	x0, sp, #0x8
000000010048d3f8	bl	__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCskIc2FNOgRlU_5tauri3ipc13InvokeMessageECs4s5yNBgRfbF_13conductor_lib
000000010048d3fc	mov	x0, x20
000000010048d400	bl	0x101380b88 ; symbol stub for: __Unwind_Resume
000000010048d404	bl	__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup
000000010048d408	bl	__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup
