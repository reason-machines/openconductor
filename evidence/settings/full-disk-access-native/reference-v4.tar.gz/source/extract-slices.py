import argparse, hashlib, json, pathlib, re, struct

EXPECTED = '0ba55751aea5ecf592d2c78379760af641fb912a34b2c3573d41df031ffb831d'
p = argparse.ArgumentParser()
p.add_argument('--binary', required=True)
p.add_argument('--out', required=True)
a = p.parse_args()
root = pathlib.Path(a.out)
binary = pathlib.Path(a.binary)
raw = binary.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
layout = json.loads((root / 'mapped-evidence.json').read_text())
def offset(va):
    s = next(s for s in layout['segments'] if s['va'] <= va < s['va'] + s['filesize'])
    return s['fileoff'] + va - s['va']

slices = [
    ('handler', 0x1006e5f18, 640),
    ('wrapper', 0x10048d2b0, 348),
    ('dispatcher', 0x100493640, 19744),
    ('dispatch-length-22', 0x10150c38e, 2),
    ('environment-name', 0x101513674, 4),
    ('probe-path', 0x102ae1c35, 48),
    ('error-kind-lengths', 0x102af9998, 43 * 8),
    ('error-kind-pointers', 0x1030a9a58, 43 * 8),
    ('errno-kind-table', 0x102af9868, 102),
]
for kind in [0, 1, 42]:
    length = struct.unpack_from('<Q', raw, offset(0x102af9998) + kind * 8)[0]
    ptr = struct.unpack_from('<Q', raw, offset(0x1030a9a58) + kind * 8)[0]
    slices.append(('error-kind-name-' + str(kind), ptr, length))
items = []
for name, va, size in slices:
    off = offset(va)
    data = raw[off:off + size]
    dest = 'slices/' + name + '.bin'
    path = root / dest
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(data)
    items.append({'path': dest, 'va': hex(va), 'fileoff': off, 'size': size,
                  'sha256': hashlib.sha256(data).hexdigest()})
assembly = (root / 'command-dispatcher.asm').read_text().splitlines()
for name, start, end in [('registration', 0x100493a24, 0x100493ab4),
                         ('dispatch-entry', 0x100493640, 0x1004936a4),
                         ('dispatch-to-wrapper', 0x100496d18, 0x100496d60)]:
    selected = []
    for line in assembly:
        match = re.match(r'^([0-9a-fA-F]{16})\s', line)
        if match and start <= int(match.group(1), 16) < end:
            selected.append(line)
    (root / (name + '.asm')).write_text('\n'.join(selected) + '\n')
wrapper = (root / 'handler-caller-window.asm').read_text().splitlines()
selected = []
for line in wrapper:
    match = re.match(r'^([0-9a-fA-F]{16})\s', line)
    if match and 0x10048d2b0 <= int(match.group(1), 16) < 0x10048d40c:
        selected.append(line)
(root / 'wrapper.asm').write_text('\n'.join(selected) + '\n')
record = {'binary_sha256': EXPECTED, 'artifact_bytes': len(raw),
          'rea_identity_evidence': 'ev_0cf38b016e6c7595876a84f89c11d46541a225caf37f0317089a21ff09d2da67',
          'slices': items,
          'limits': ['Only static binary bytes and platform disassembly were inspected.',
                     'No protected file, target code, native permission prompt or app was executed.',
                     'No configured REA deep-analysis provider was available on this Mac.',
                     'No cross-platform or runtime permission result is established.']}
assert hashlib.sha256(binary.read_bytes()).hexdigest() == EXPECTED
(root / 'slice-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'binary_identity_passed': True, 'slices': len(items),
                  'total_slice_bytes': sum(i['size'] for i in items)}))
