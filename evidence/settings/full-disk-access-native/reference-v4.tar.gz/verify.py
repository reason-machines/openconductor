import hashlib
import json
import pathlib
import re
import struct

ROOT = pathlib.Path(__file__).parent / 'source'
EXPECTED = '0ba55751aea5ecf592d2c78379760af641fb912a34b2c3573d41df031ffb831d'
checks = []
def check(condition, name):
    assert condition, name
    checks.append(name)

def load(name):
    return json.loads((ROOT / name).read_text())

def asm(name):
    result = {}
    for line in (ROOT / name).read_text().splitlines():
        match = re.match(r'^([0-9a-fA-F]{16})\s+(.*)', line)
        if match:
            result[int(match.group(1), 16)] = match.group(2)
    return result

files = load('files.json')
for entry in files:
    value = (ROOT / entry['path']).read_bytes()
    assert len(value) == entry['size']
    assert hashlib.sha256(value).hexdigest() == entry['sha256'], entry['path']
check(len(files) == 40, 'All 40 source records match the Mac export hashes')
identity = load('macho.json')
check(identity['subject']['digest']['sha256'] == EXPECTED,
      'REA identity binds the inspected arm64 executable')
check(identity['subject']['architecture'] == 'arm64', 'The artifact is arm64')
manifest = load('slice-manifest.json')
check(manifest['binary_sha256'] == EXPECTED, 'Slice identity matches REA identity')
for entry in manifest['slices']:
    value = (ROOT / entry['path']).read_bytes()
    assert len(value) == entry['size']
    assert hashlib.sha256(value).hexdigest() == entry['sha256']
check(len(manifest['slices']) == 12, 'All 12 native slices match their declared bounds and hashes')
handler = asm('check-full-disk-access.asm')
addresses = [pc for pc in handler if 0x1006e5f18 <= pc < 0x1006e6198]
check(addresses == list(range(0x1006e5f18, 0x1006e6198, 4)),
      'The handler interval contains every one of its 160 instructions')
check((ROOT / 'slices/environment-name.bin').read_bytes() == b'HOME'
      and (ROOT / 'slices/probe-path.bin').read_bytes()
      == b'Library/Application Support/com.apple.TCC/TCC.db',
      'The exact environment and protected-resource path bytes are retained')
check('unix6getenv' in handler[0x1006e5f40]
      and 'Path5__join' in handler[0x1006e5f68]
      and 'OpenOptions5__open' in handler[0x1006e5f98]
      and 'Read4read' in handler[0x1006e6030]
      and handler[0x1006e602c] == 'mov\tw2, #0x1',
      'The handler performs the mapped open and one-byte read sequence')

command = b'check_full_disk_access'
length_entry = struct.unpack('<H', (ROOT / 'slices/dispatch-length-22.bin').read_bytes())[0]
check(0x1004936a4 + 4 * length_entry == 0x100493a24,
      'Command length 22 selects the recorded dispatch bucket')
registration = asm('registration.asm')
def mov_bytes(start):
    value = 0
    for pc in range(start, start + 16, 4):
        match = re.fullmatch(r'(mov|movk)\tx\d+, #0x([0-9a-f]+)(?:, lsl #(\d+))?', registration[pc])
        assert match, registration[pc]
        immediate = int(match.group(2), 16)
        shift = int(match.group(3) or 0)
        value = immediate if match.group(1) == 'mov' else ((value & ~(0xffff << shift)) | (immediate << shift))
    return value.to_bytes(8, 'little')
check([mov_bytes(pc) for pc in [0x100493a74, 0x100493a88, 0x100493a9c]]
      == [command[:8], command[8:16], command[14:22]],
      'The three machine comparison constants equal check_full_disk_access')
check(mov_bytes(0x100493a2c) != command[:8]
      and registration[0x100493ab0] == 'b.eq\t0x100496d18',
      'This command falls through the preceding comparison and reaches its wrapper block')
dispatch = asm('dispatch-to-wrapper.asm')
wrapper = asm('wrapper.asm')
check('runs3_0sb_0' in dispatch[0x100496d58]
      and '22check_full_disk_access' in wrapper[0x10048d304]
      and 'InvokeResolver7respondbE' in wrapper[0x10048d334],
      'The selected block calls the handler wrapper and the bool-specialized Tauri responder')
check((ROOT / 'slices/error-kind-name-1.bin').read_bytes() == b'PermissionDenied',
      'ErrorKind discriminant 1 is identified by the compiled Debug lookup table')
check(handler[0x1006e60b4] == 'mov\tw22, #0x0'
      and handler[0x1006e60c4] == 'mov\tw22, #0x1'
      and handler[0x1006e600c] == 'mov\tw22, #0x1'
      and handler[0x1006e60f0] == 'mov\tx0, x22'
      and handler[0x1006e6108] == 'ret',
      'The false, fail-open and common boolean-return instruction anchors are intact')
check(handler[0x1006e5fd4] == 'cmp\tw8, #0x1'
      and handler[0x1006e5fd8] == 'b.eq\t0x1006e6088'
      and handler[0x1006e6080] == 'cmp\tw8, #0x1'
      and handler[0x1006e6084] == 'b.ne\t0x1006e5fdc'
      and handler[0x1006e6114] == 'cmp\tw8, #0x1'
      and handler[0x1006e611c] == 'b\t0x1006e6088'
      and handler[0x1006e6128] == 'cmp\tw8, #0x1'
      and handler[0x1006e612c] == 'b.eq\t0x1006e6088',
      'All four error-representation classification branches test the same PermissionDenied discriminant')
report = {
    'passed': checks,
    'kind': 'static byte and disassembly integrity checks, not product or native runtime tests',
    'not_run': ['Mounted seven-case product fixture', 'Native permission prompts or probes',
                'Visual parity', 'Non-macOS behavior'],
    'limits': ['The complete executable is not included in this bounded packet.',
               'The Mac extractor checked the complete executable digest before and after extracting slices.',
               'otool text is platform disassembly, not decompiler output or original source.',
               'The verifier protects evidence identity and stated instruction anchors; it is not a native execution emulator.'],
}
(pathlib.Path(__file__).parent / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'static_checks_passed': len(checks), 'failed': 0, 'not_run': report['not_run']}))
