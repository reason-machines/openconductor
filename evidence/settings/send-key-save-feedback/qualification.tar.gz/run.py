"""Single foreground driver for ACC_49_SENDKEY8_20261113T0526; no retries."""
from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time

OUT = Path('.reason-sendkey8')
START = float((OUT / 'start-epoch').read_text())
ORIGINAL = '07f2494fc0e1889c563ff8615ccb625d419a733a'
PREFIX = 'evidence/settings/send-key-save-feedback/'
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', *args])
def blob(ref, path):
    return git('show', ref + ':' + path)
receipt = {'allocation': 'ACC_49_SENDKEY8_20261113T0526', 'started_epoch': START,
           'computer': 'Cloud356 / 51335f71-877d-4db3-ba11-67b1faca30c1', 'steps': [],
           'limits': {'inclusive':1560,'source':300,'red':90,'green':90,'adjacent':120,'typecheck':180},
           'native_screenshot_package': 'NOT_RUN; existing 992/E1 route', 'reference_js': 'NOT_RUN; eight product cases only'}
active = None
candidate = None
fixture = Path('src/settings/sendKeySaveFeedback.test.ts')
def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
def run(name, argv, limit, heap, extra=None):
    global active
    assert time.time()-START < 1560, 'inclusive budget'
    env = dict(os.environ)
    env.pop('SEND_KEY_ROW_BASELINE', None)
    env.update({'NODE_OPTIONS': '--max-old-space-size='+str(heap), **(extra or {})})
    command = ['nice','-n','19', *argv]
    step = {'name':name,'argv':command,'env':{'NODE_OPTIONS':env['NODE_OPTIONS'],**(extra or {})},'start':now()}
    began = time.monotonic()
    with (OUT/(name+'.stdout.txt')).open('wb') as stdout, (OUT/(name+'.stderr.txt')).open('wb') as stderr:
        active = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=env, start_new_session=True)
        step['pid'] = active.pid
        try:
            step['exit_code'] = active.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            step['timeout'] = True
            os.killpg(active.pid, signal.SIGTERM)
            try: active.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(active.pid, signal.SIGKILL)
                active.wait()
            step['exit_code'] = active.returncode
        finally:
            try: os.killpg(active.pid, 0)
            except ProcessLookupError: step['owned_group_absent'] = True
            else:
                os.killpg(active.pid, signal.SIGKILL)
                step['owned_group_absent'] = False
            active = None
    step.update({'end':now(),'seconds':time.monotonic()-began})
    output = (OUT/(name+'.stdout.txt')).read_text()
    step['tap'] = {k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', output, re.M)}
    receipt['steps'].append(step)
    save()
    print(json.dumps(step), flush=True)
    assert not step.get('timeout') and step['owned_group_absent'], name+' timeout or leaked process group'
    return step, output

try:
    assert time.time()-START < 300, 'source300 already expired'
    rawmap = Path('.oc-tmp/send-key-current-main-map.json').read_bytes()
    assert sha(rawmap) == '329920dbc92766c1bf05f5c25f8b432b262d16051ad72bbf117b56d06fca7d84'
    mapping = json.loads(rawmap)
    assert sha(Path('.oc-tmp/send-key-save-feedback.patch').read_bytes()) == mapping['original_full_patch_sha256']
    assert git('diff','--name-only','origin/main','HEAD') == b'', 'unrelated branch delta'
    main = git('rev-parse','origin/main').decode().strip()
    assert main == 'c79a81086c3a0e5ba81f1a9a53ec63a4f4dde7ba'
    pins = {}
    for pin in mapping['current_main_pins']:
        path = pin['path']
        value = blob(main,path)
        assert sha(value) == pin['current_main_sha256'], path
        assert Path(path).read_bytes() == value, path+' checkout drift'
        pins[path] = sha(value)
    original_source = json.loads(blob(ORIGINAL, PREFIX+'source.json'))
    assets = {'renderer': Path('/home/runner/.reason/workspace/sessions/49e3976d-9553-42d8-8101-2504177fbb97/.ara-run-chat-attachments/session/conductor-retained-renderApp-D_fmY7hW.js'),
              'index':Path('.oc-tmp/settings-next/index-BGEQ8YjU.js')}
    for name, path in assets.items():
        data = path.read_bytes()
        assert sha(data) == original_source['retained_reference']['assets'][name]['sha256']
        for span in original_source['reference_spans']:
            if span['asset'] == name:
                a,b = span['utf8_half_open']
                assert sha(data[a:b]) == span['sha256']
                assert data[a:b] == blob(ORIGINAL,PREFIX+span['path'])
    frozen = {}
    for item in mapping['original_frozen_files']:
        value = blob(ORIGINAL,item['path'])
        assert sha(value) == item['sha256'], item['path']
        frozen[item['path']] = item['sha256']
    assert frozen[str(fixture)] == '9f98fe21f8731caf1533f336956c6d2f52c926af53fa41b7ce83e4913ad1c461'
    for item in mapping['protected_follow_up_dependency']['files']:
        assert sha(blob(mapping['protected_follow_up_dependency']['original_commit'],item['path'])) == item['sha256']
    baseline = Path('src/settings/GeneralPage.tsx').read_bytes()
    assert sha(baseline) == original_source['baseline_sha256']
    candidate = blob(ORIGINAL,'src/settings/GeneralPage.tsx')
    patch = git('diff',ORIGINAL+'^',ORIGINAL,'--','src/settings/GeneralPage.tsx')
    assert sha(patch) == mapping['original_product_patch_sha256']
    (OUT/'product.patch').write_bytes(patch)
    for path in [p for p in frozen if p.startswith(PREFIX)] + [PREFIX+'frozen.sha256',str(fixture)]:
        target = Path(path)
        assert not target.exists(), 'unexpected active input: '+path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(blob(ORIGINAL,path))
    assert not Path('node_modules').is_symlink(), 'borrowed node_modules'
    deps = {}
    lock = json.loads(Path('package-lock.json').read_text())
    for name, expected in [('react','18.3.1'),('react-test-renderer','18.3.1'),('typescript','5.9.3')]:
        dep = Path('node_modules')/name
        assert not dep.is_symlink(), name+' borrowed'
        version = json.loads((dep/'package.json').read_text())['version']
        assert version == expected == lock['packages']['node_modules/'+name]['version']
        deps[name] = version
    assert Path('node_modules/.bin/tsc').resolve() == (Path('node_modules/typescript/bin/tsc').resolve())
    receipt.update({'main':main,'pinned_execution_head':git('rev-parse','HEAD').decode().strip(),
                    'input_pins':pins,'original_commit':ORIGINAL,'original_map_sha256':sha(rawmap),
                    'original_patch_sha256':sha(Path('.oc-tmp/send-key-save-feedback.patch').read_bytes()),
                    'product_patch_sha256':sha(patch),'candidate_sha256':sha(candidate),'frozen':frozen,
                    'deps':deps,'deps_install':'NOT_RUN; own exact lock dependencies present',
                    'source_end':now(),'source_seconds':time.time()-START})
    assert receipt['source_seconds'] < 300, 'source300 expired'
    save()
    testargs = ['node','--experimental-strip-types','--test','--test-concurrency=1','src/settings/sendKeySaveFeedback.test.ts']
    red, text = run('red',testargs,90,768,{'SEND_KEY_ROW_BASELINE':'1'})
    assert red['exit_code'] == 1 and red['tap'] == {'tests':8,'pass':4,'fail':4,'cancelled':0,'skipped':0,'todo':0}, 'unexpected RED counts'
    failures = re.findall(r'^not ok (\d+) - (.+)$', text, re.M)
    assert [n for n,_ in failures] == ['1','2','3','5'], failures
    assert text.count("code: 'ERR_ASSERTION'") == 4, 'non-assertion failure'
    assert sha(fixture.read_bytes()) == frozen[str(fixture)]
    assert Path('src/settings/GeneralPage.tsx').read_bytes() == baseline
    subprocess.run(['git','apply',str(OUT/'product.patch')],check=True)
    assert Path('src/settings/GeneralPage.tsx').read_bytes() == candidate
    green, _ = run('green',testargs,90,768)
    assert green['exit_code'] == 0 and green['tap'] == {'tests':8,'pass':8,'fail':0,'cancelled':0,'skipped':0,'todo':0}, 'unexpected GREEN'
    adjacent, _ = run('adjacent',['node','--experimental-strip-types','--test','--test-concurrency=1','src/settings/composerSettings.test.ts','src/settings/notificationDenialFeedback.test.ts','src/settings/fullDiskAccess.test.ts'],120,768)
    assert adjacent['exit_code'] == 0 and adjacent['tap']['fail'] == 0 and all(adjacent['tap'].get(k)==0 for k in ['cancelled','skipped','todo']), 'adjacent failure'
    tsc, _ = run('typecheck',['npx','--no-install','tsc','--noEmit'],180,1536)
    assert tsc['exit_code'] == 0, 'typecheck failure'
    for path,digest in frozen.items():
        assert sha(Path(path).read_bytes()) == digest, 'frozen drift '+path
    for path,digest in pins.items():
        if path != 'src/settings/GeneralPage.tsx': assert sha(Path(path).read_bytes()) == digest, 'input drift '+path
    receipt['result'] = 'PASS'
except BaseException as exc:
    receipt['result'] = 'STOP'
    receipt['error'] = str(exc)
finally:
    if active is not None:
        os.killpg(active.pid,signal.SIGKILL)
        active.wait()
    receipt['terminal'] = now()
    receipt['inclusive_seconds'] = time.time()-START
    receipt['all_owned_groups_absent'] = all(s.get('owned_group_absent',False) for s in receipt['steps'])
    receipt['candidate_restored'] = candidate is not None and Path('src/settings/GeneralPage.tsx').read_bytes() == candidate
    save()
    print(json.dumps({'result':receipt['result'],'error':receipt.get('error'),'terminal':receipt['terminal'],'source_seconds':receipt.get('source_seconds'),'inclusive_seconds':receipt['inclusive_seconds'],'all_owned_groups_absent':receipt['all_owned_groups_absent'],'candidate_restored':receipt['candidate_restored']}),flush=True)
