# Qualified repository archive Reset delivery

Conductor Rebuild SAME49 retains source, verification, correctness, and review ownership. ACC selected existing D7 solely for standalone main publication. This archive is the entire qualified delivery input, not the mixed SAME49 branch.

## Apply only the qualified product delta

Read MANIFEST.json. Its only live paths are src/settings/rows/RepoGitRows.tsx and src/settings/rows/repoGitDeleteReset.test.ts. source/ holds their exact validated output bytes. apply.patch is the unchanged product fix plus the target-compatible qualified test. Normal-merge fresh main on D7's existing assigned eligible branch and inspect the actual main delta. Verify all 17 registered footprint hashes, the baseline component, unchanged locks/dependency bindings, and absent focused test before applying. Meaningful drift requires source reconciliation; a global SHA advance alone is not failure. Do not replay app tests, install, launch native/browser/provider/package, or add a new executor.

Commit only those two product/test files and focused Reset proof. A focused README and this original-byte archive can retain the proof without adding raw TAP whitespace to source. Do not stage held MCP work or inert references as live source. No picker, catalog, mono, shared Row, workflow, global Git configuration, or protected source restoration is included. Open a READY standalone PR against main. Every exact-head workflow must pass before merge. Return the PR URL/head/check outcomes and applicable findings to SAME49 for retained correctness and review ownership.

## REA basis and actual verification

proof/rea/source.json and its nine reference spans bind the retained real Conductor 0.87.6 renderer/index and original REA receipt. They show configured unlocked local reset removes the override rather than writing false. This is historical shipped-source evidence, not a current native observation. The product uses the established repoSettingsSetLocal(path,key,null) removal path and existing refresh hook.

proof/0101/ retains the original actual commands, exits, receipts, complete raw TAP, failed typecheck, installation and Rust output. That fixture0f29 produced qualified baseline5PASS4intended ERR_ASSERTION failures, GREEN9PASS, adjacent5PASS and exact locked Rust generic1PASS, then stopped at TS2550 Object.hasOwn. Exact owned candidate/fixture cleanup and release are retained.

proof/0107/ retains the new actual commands, exits, immutable receipts, full raw TAP, source/dependency/lock binding and passing empty tsc logs. On qualified maina66b72e9, distinct fixture5fea reproduced the same baseline5PASS4intended missing-action assertions, then identical-fix GREEN9PASS, adjacent5PASS and tsc exit0. All nine collected with no skips, cancellations or todo. Rust1 is explicitly REUSED from0101 under unchanged backend/Cargo.lock/argv/dependency binding, NOT a new Rust execution or exact-flag filesystem proof.

The priorbf958, helper0f29 and qualified5fea fixtures and pre-execution seals remain inert under inert/. protected230-reference.json is only a frozen source/hash reference. Do not overlay it or catalog/mono pending source onto main.

## Operational deviation and future enforcement

Source/setup59.36s exceeded its30s allocation. The driver failed to stop at that allocation. Total0107 elapsed100.924s stayed within650s, with individual test/typecheck ceilings and cleanup reserve held. This deviation remains explicit; do not claim every timing bound passed and do not rerun tests to hide it. Original cumulative active310.208s leaves1189.792s of1500, without a reset. All owned jobs, servers, and runtime were empty at release.

proof/future-driver-template.py.txt and its exact patch enforce an explicit source_setup_cap_seconds immediately before the baseline Popen. They also require an explicit fresh owned admission directory and refuse overwriting a released receipt. They were inspected and AST-parsed only, not executed. Historical driver bytes and receipts are unchanged.

## Gaps required in the PR

Actual Base UI menu behavior, hover, rendered layout, keyboard focus, exact flag persisted filesystem roundtrip, native parity and side-by-side appearance are UNVERIFIED. No screenshot exists because browser/native launch was excluded. Generic Rust removal is not exact-flag/native evidence. Publication, exact-head CI and merge are not yet observed by this archive.
