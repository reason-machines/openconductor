from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time

ROOT = Path.cwd()
RUN = ROOT / '.oc-tmp/same49-reset-es2021-20261113T0107'
R = json.loads((RUN / 'admission.json').read_text())
WORK = ROOT / R['worktree']
HELPER = ROOT / 'evidence/settings/repo-git-delete-reset-es2021'
ORIGINAL = ROOT / 'evidence/settings/repo-git-delete-reset'
TEST = WORK / 'src/settings/rows/repoGitDeleteReset.test.ts'
SEAL = json.loads((HELPER / 'baseline-seal.json').read_text())
SHA = lambda raw: hashlib.sha256(raw).hexdigest()
FIXED = False
CHILDREN = []
R['commands'] = []


def persist():
    (RUN / 'execution.json').write_text(json.dumps(R, indent=2) + '\n')


def guards():
    for path, expected in json.loads((RUN / 'originals.json').read_text()).items():
        assert SHA((ROOT / path).read_bytes()) == expected, 'Original changed: ' + path
    assert SHA(TEST.read_bytes()) == SEAL['executable_fixture_sha256']
    assert subprocess.check_output(['git', 'diff', '--', 'package.json', 'package-lock.json', 'Cargo.lock', 'crates/scripts/Cargo.lock'], cwd=WORK) == b'', 'Lock/version changed'


def phase(name, args, cap, heap=None, expected=0):
    guards()
    available = R['deadline_unix'] - time.time() - 60
    assert available > cap + 5, 'Insufficient remaining budget for ' + name
    env = os.environ.copy()
    if heap:
        env['NODE_OPTIONS'] = '--max-old-space-size=' + str(heap)
    env['CARGO_BUILD_JOBS'] = '1'
    env['npm_config_cache'] = str(RUN / 'npm-cache')
    command = ['nice', '-n', '19', 'timeout', '--kill-after=5s', str(cap) + 's', *args]
    entry = {'phase': name, 'command': command, 'node_options': env.get('NODE_OPTIONS'), 'cargo_build_jobs': '1', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    start = time.time()
    with (RUN / (name + '.stdout')).open('wb') as out, (RUN / (name + '.stderr')).open('wb') as err:
        process = subprocess.Popen(command, cwd=WORK, env=env, stdout=out, stderr=err, start_new_session=True)
        CHILDREN.append(process)
        entry['pid'] = process.pid
        try:
            entry['exit'] = process.wait(timeout=cap + 6)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            entry['exit'] = process.returncode
            entry['timeout'] = True
    entry['seconds'] = round(time.time() - start, 3)
    R['commands'].append(entry)
    R[name] = 'EXIT_' + str(entry['exit'])
    persist()
    assert entry['exit'] == expected, name + ' unexpected exit ' + str(entry['exit'])
    return (RUN / (name + '.stdout')).read_text()


def qualify(text, baseline):
    results = re.findall(r'^(not ok|ok) (\d+) - (.*)$', text, re.M)
    assert len(results) == 9, 'Expected exactly nine collected results'
    for item, case in zip(results, SEAL['cases']):
        status, number, name = item
        assert int(number) == case['id'] and name == case['name'], 'Case identity changed'
        expected_fail = baseline and case['expected'] == 'FAIL'
        assert (status == 'not ok') == expected_fail, 'Unexpected case result: ' + name
        if expected_fail:
            block = text[text.index(status + ' ' + number + ' - ' + name):]
            block = re.split(r'^# Subtest:|^(?:not ok|ok) \d+ - ', block[len(status + ' ' + number + ' - ' + name):], maxsplit=1, flags=re.M)[0]
            assert re.search(r"code: ['\"]?ERR_ASSERTION", block), 'Failure is not an assertion'
            assert 'operator: \'strictEqual\'' in block or 'operator: strictEqual' in block or 'operator: "strictEqual"' in block
            assert re.search(r'^\s+expected: 1$', block, re.M) and re.search(r'^\s+actual: 0$', block, re.M), 'Not missing-action count assertion'
    expected = {'tests': 9, 'pass': 5 if baseline else 9, 'fail': 4 if baseline else 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    for key, value in expected.items():
        assert re.search(r'^# ' + key + ':? ' + str(value) + r'$', text, re.M), 'Unexpected TAP summary: ' + key
    result = {'qualification': 'PASS', 'summary': expected, 'fixture_sha256': SEAL['executable_fixture_sha256']}
    (RUN / ('baseline-qualification.json' if baseline else 'green-qualification.json')).write_text(json.dumps(result, indent=2) + '\n')
    return result


try:
    guards()
    assert (WORK / 'node_modules/typescript/bin/tsc').is_file()
    baseline = phase('baseline', ['node', '--test', '--test-concurrency=1', 'src/settings/rows/repoGitDeleteReset.test.ts'], 120, 1024, expected=1)
    R['baseline_qualification'] = qualify(baseline, True)
    guards()
    subprocess.run(['git', 'apply', str(ORIGINAL / 'fix.patch')], cwd=WORK, check=True, timeout=5)
    FIXED = True
    assert SHA((WORK / 'src/settings/rows/RepoGitRows.tsx').read_bytes()) == 'df848021c3b635be54ea011775ddab9b0e4b4372baa27160bb771e816af0a9cb'
    green = phase('green', ['node', '--test', '--test-concurrency=1', 'src/settings/rows/repoGitDeleteReset.test.ts'], 120, 1024)
    R['green_qualification'] = qualify(green, False)
    phase('adjacent', ['node', '--test', '--test-concurrency=1', 'src/settings/rows/rowModel.test.ts', 'src/settings/prefs.test.ts'], 120, 1024)
    phase('typecheck', ['node', 'node_modules/typescript/bin/tsc', '--noEmit'], 180, 1536)
    guards()
    R['status'] = 'QUALIFIED_ALL_CHECKS_PASS'
except Exception as exc:
    R['status'] = 'STOP_FIRST_UNEXPECTED'
    R['error'] = str(exc)
finally:
    cleanup_errors = []
    for process in CHILDREN:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    try:
        if FIXED:
            assert SHA((WORK / 'src/settings/rows/RepoGitRows.tsx').read_bytes()) == 'df848021c3b635be54ea011775ddab9b0e4b4372baa27160bb771e816af0a9cb'
            subprocess.run(['git', 'apply', '--reverse', str(ORIGINAL / 'fix.patch')], cwd=WORK, check=True, timeout=5)
        assert SHA(TEST.read_bytes()) == SEAL['executable_fixture_sha256']
        TEST.unlink()
        for path, expected in json.loads((RUN / 'originals.json').read_text()).items():
            assert SHA((ROOT / path).read_bytes()) == expected, path
        R['clean_tree_status'] = subprocess.check_output(['git', 'status', '--short'], cwd=WORK, text=True)
        assert R['clean_tree_status'] == ''
        R['originals_unchanged'] = True
    except Exception as exc:
        cleanup_errors.append(str(exc))
    R['cleanup_errors'] = cleanup_errors
    R['ended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    R['elapsed_seconds'] = round(time.time() - R['started_unix'], 3)
    R['cumulative_active_seconds'] = round(R['prior_cumulative_active_seconds'] + R['elapsed_seconds'], 3)
    R['remaining_original_seconds'] = round(1500 - R['cumulative_active_seconds'], 3)
    R['jobs'] = [process.pid for process in CHILDREN if process.poll() is None]
    R['servers'] = []
    R['own_runtime'] = []
    R['released'] = not R['jobs'] and not cleanup_errors
    persist()
    (RUN / 'release.json').write_text(json.dumps(R, indent=2) + '\n')
    print(json.dumps(R, indent=2))
