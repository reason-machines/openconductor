// Home with workspaces: Conductor's /all-workspaces screen (`UJo`), which its
// sidebar Home row and nav.home open. Header "Home" + Create workspace, a
// search box with project and archive filters, then rows grouped by day.
// Logic and evidence: src/home/allWorkspaces.ts.

import { useEffect, useMemo, useRef, useState, type Dispatch, type ReactNode } from "react";
import type { Repo } from "../state/types";
import type { Action } from "../state/store";
import { isWorkspaceUnread } from "../state/chatUnread";
import { ArchiveIcon, ChevronDownIcon, FolderIcon, SearchIcon, SidebarIcon } from "./Icons";
import {
  ARCHIVE_FILTERS,
  ARCHIVE_FILTER_LABELS,
  CLEARED_FILTERS,
  PAGE_SIZE,
  emptyAction,
  groupByDate,
  homeRows,
  loadFilters,
  projectFilterLabel,
  reposWithWorkspaces,
  saveFilters,
  shortRelativeTime,
  showProjectFilter,
  toggleProject,
  type FieldMatch,
  type HomeFilters,
  type HomeRow,
} from "../home/allWorkspaces";
import { listArchivedWorkspaces, onArchiveEvent, type ArchivedWorkspace } from "../workspace/archive";
import { effectiveShortcuts } from "../keybindings/overrides";
import { useKeybindingOverrides } from "../keybindings/KeybindingsProvider";
import { useWorkspaceAgentStatus } from "../features/chat/useWorkspaceSession";
import { homeStatus, rowGitStatus, rowStatusColor, rowStatusLabel, showsActivityStatus } from "../state/rowStatus";
import { RowStatusIcon } from "./RowStatusIcon";
import { StatusMatrix } from "./StatusMatrix";
import { useStatusMatrix } from "../settings/useStatusMatrix";
import { glyphs } from "../keybindings/shortcut";
import { useBoolPref } from "../settings/useBoolPref";
import { workspaceNumberLabel } from "../state/workspaceNumber";
import { RepoIcon } from "./RepoIcon";
import { Tooltip } from "./Tooltip";

interface Props {
  repos: Repo[];
  loading?: boolean;
  sidebarVisible: boolean;
  dispatch: Dispatch<Action>;
  onCreateWorkspace: () => void;
}

function Highlight({ match, fallback }: { match?: FieldMatch; fallback: string }) {
  if (!match) return <>{fallback}</>;
  const marked = new Set(match.indices);
  return (
    <>
      {Array.from(match.text).map((ch, i) => (marked.has(i) ? <mark key={i} className="allws-hit">{ch}</mark> : <span key={i}>{ch}</span>))}
    </>
  );
}

function Menu({ label, icon, ariaLabel, children }: { label: string; icon: ReactNode; ariaLabel: string; children: (close: () => void) => ReactNode }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);
  return (
    <div className="allws-menu" ref={ref}>
      <button type="button" className="allws-filter" aria-label={ariaLabel} aria-haspopup="menu" aria-expanded={open} data-open={open || undefined} onClick={() => setOpen((o) => !o)}>
        {icon}
        <span className="allws-filter-label">{label}</span>
        <ChevronDownIcon size={12} />
      </button>
      {open && (
        <div className="allws-menu-pop" role="menu">
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

function MenuCheck({ checked, onClick, children }: { checked: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" role="menuitemcheckbox" aria-checked={checked} className="allws-menu-item" onClick={onClick}>
      <span className="allws-check" aria-hidden>{checked ? "✓" : ""}</span>
      {children}
    </button>
  );
}

function UnarchiveButton({ repoId, workspaceId, dispatch }: { repoId: string; workspaceId: string; dispatch: Dispatch<Action> }) {
  const pendingRef = useRef(false);
  const [pending, setPending] = useState(false);
  useEffect(() => {
    const unsubscribe = onArchiveEvent<Action>((event) => {
      if (
        (event.type === "unarchived" || event.type === "unarchive-failed") &&
        event.action.type === "unarchiveWorkspace" &&
        event.action.repoId === repoId && event.action.workspaceId === workspaceId
      ) {
        pendingRef.current = false;
        setPending(false);
      }
    });
    return () => { unsubscribe(); };
  }, [repoId, workspaceId]);
  const unarchive = () => {
    if (pendingRef.current) return;
    pendingRef.current = true;
    setPending(true);
    dispatch({ type: "unarchiveWorkspace", repoId, workspaceId });
  };
  return (
    <Tooltip content="Unarchive workspace">
      <button
        type="button"
        className="allws-unarchive"
        aria-label="Unarchive workspace"
        disabled={pending}
        onClick={(event) => {
          event.stopPropagation();
          event.preventDefault();
          unarchive();
        }}
        onKeyDown={(event) => {
          if (event.key !== "Enter") return;
          event.stopPropagation();
          event.preventDefault();
          unarchive();
        }}
      >
        <span className="allws-unarchive-idle"><ArchiveIcon size={14} /></span>
        <svg className="allws-unarchive-hover" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
          <path d="M3 3v5h5" />
        </svg>
      </button>
    </Tooltip>
  );
}

function Row({
  row,
  showRepoIcon,
  showNumber,
  active,
  now,
  onOpen,
  dispatch,
}: {
  row: HomeRow;
  showRepoIcon: boolean;
  showNumber: boolean;
  active: boolean;
  now: number;
  onOpen: () => void;
  dispatch: Dispatch<Action>;
}) {
  const { workspace: ws, repo, archived, matches } = row;
  const tone = archived ? "is-archived" : isWorkspaceUnread(ws) ? "is-unread" : "";
  const label = workspaceNumberLabel(ws.number);
  // Conductor's Home row (`vJo`): the agent's or setup's status, else the last-activity time.
  const status = homeStatus(ws.state, useWorkspaceAgentStatus(ws));
  const statusLabel = rowStatusLabel(status);
  // Workspace status matrix (Settings › Experimental): Conductor's Home row (`_Jo`) puts the
  // matrix where the repository icon goes, and the time column then always shows the time (`vJo`).
  const matrix = useStatusMatrix();
  const unstarted = ws.state === "unstarted";
  return (
    <div
      role="option"
      aria-selected={active}
      data-selected={active || undefined}
      className="allws-row"
      onClick={onOpen}
      title={row.title}
    >
      <div className="allws-row-main">
        {matrix ? (
          <span className="allws-matrix" data-testid="home-workspace-status-matrix">
            <StatusMatrix
              status={archived ? "branch" : status}
              gitStatus={unstarted ? undefined : rowGitStatus({ pr: ws.pr, hasRemote: Boolean(repo.remote) })}
              hasUnread={!archived && !unstarted && isWorkspaceUnread(ws)}
            />
          </span>
        ) : showRepoIcon && (
          <span title={repo.name} aria-hidden>
            <RepoIcon repo={repo} className="allws-repo-initial" />
          </span>
        )}
        {/* "Show workspace numbers" (Conductor's `_Jo`): a fixed-width W-<n> column, empty for unnumbered rows. */}
        {showNumber && (
          <span className={`allws-number${archived ? " is-archived" : ""}`}>
            {label !== null && <Highlight match={matches?.number} fallback={label} />}
          </span>
        )}
        <span className={`allws-name ${tone}`}>
          <Highlight match={matches?.name} fallback={row.title} />
        </span>
      </div>
      <div className="allws-row-meta">
        <span className="allws-diff">
          {(ws.diff.added > 0 || ws.diff.removed > 0) && (
            <>
              <span className="add">+{ws.diff.added}</span> <span className="del">-{ws.diff.removed}</span>
            </>
          )}
        </span>
        <span className="allws-when">
          {archived ? (
            <span className="allws-archived" aria-label="Archived">
              <UnarchiveButton repoId={repo.id} workspaceId={ws.id} dispatch={dispatch} />
            </span>
          ) : !matrix && showsActivityStatus(status) ? (
            <span className="allws-status" data-testid="home-workspace-status" data-status={status} data-color={rowStatusColor(status)} role="img" title={statusLabel} aria-label={statusLabel}>
              <RowStatusIcon status={status} />
            </span>
          ) : (
            shortRelativeTime(row.lastActiveAt, now)
          )}
        </span>
      </div>
    </div>
  );
}

export function AllWorkspaces({ repos, loading = false, sidebarVisible, dispatch, onCreateWorkspace }: Props) {
  const { overrides } = useKeybindingOverrides();
  const [query, setQuery] = useState("");
  const repoIds = useMemo(() => new Set(repos.map((r) => r.id)), [repos]);
  const [filters, setFiltersState] = useState<HomeFilters>(() => loadFilters(repoIds));
  const setFilters = (f: HomeFilters) => {
    setFiltersState(f);
    saveFilters(f);
  };
  const [limit, setLimit] = useState(PAGE_SIZE);
  const [activeKey, setActiveKey] = useState<string>();
  const sentinel = useRef<HTMLDivElement>(null);
  const now = Date.now();
  const showNumbers = useBoolPref("experimental_show_workspace_numbers");

  useEffect(() => setLimit(PAGE_SIZE), [query, filters]);

  // Project choices include archived-only repositories even while archived rows are hidden.
  const [archivedRows, setArchivedRows] = useState<ArchivedWorkspace[]>([]);
  useEffect(() => {
    let live = true;
    listArchivedWorkspaces().then(
      (rows) => live && setArchivedRows(rows),
      (err) => console.error("conductor.db: could not list archived workspaces", err),
    );
    return () => {
      live = false;
    };
  }, [repos]);

  const rows = useMemo(() => homeRows(repos, filters, query, archivedRows), [repos, filters, query, archivedRows]);
  const shown = rows.slice(0, limit);
  const hasMore = rows.length > limit;
  const groups = groupByDate(shown, now);
  const flat = groups.flatMap((g) => g.rows.map((row) => ({ row, key: `${g.bucket}:${row.workspace.id}` })));
  const activeIndex = Math.max(0, flat.findIndex((entry) => entry.key === activeKey));
  const projectChoices = reposWithWorkspaces(repos, archivedRows);
  const empty = emptyAction(repos, filters);

  useEffect(() => setActiveKey(flat[activeIndex]?.key), [activeIndex, flat]);
  useEffect(() => setActiveKey(undefined), [query]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el || !hasMore || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver((entries) => entries[0]?.isIntersecting && setLimit((n) => n + PAGE_SIZE), { threshold: 0.1 });
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore]);

  // An archived row opens the read-only archived view, as the palette's does.
  const open = (row: HomeRow) =>
    row.archived && !row.repo.workspaces.some((w) => w.id === row.workspace.id)
      ? dispatch({ type: "openArchivedWorkspace", repoId: row.repo.id, workspace: row.workspace })
      : dispatch({ type: "select", selection: { kind: "workspace", repoId: row.repo.id, workspaceId: row.workspace.id } });

  const onSearchKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.defaultPrevented || e.nativeEvent?.isComposing || e.keyCode === 229) return;
    if (e.key === "Home" || e.key === "End") {
      e.preventDefault();
      const entry = flat[e.key === "Home" ? 0 : flat.length - 1];
      if (entry) setActiveKey(entry.key);
      return;
    }
    if (flat.length === 0) {
      if (e.key === "Enter") e.preventDefault();
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveKey(flat[Math.min(activeIndex + 1, flat.length - 1)].key);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveKey(flat[Math.max(activeIndex - 1, 0)].key);
    } else if (e.key === "Enter") {
      e.preventDefault();
      const entry = flat[activeIndex];
      if (entry) open(entry.row);
    }
  };

  const toggleHint = effectiveShortcuts("view.toggleLeftSidebar", overrides).map(glyphs).join(" or ");
  let index = -1;

  return (
    <div className="allws">
      <div className="allws-top" data-tauri-drag-region>
        {!sidebarVisible && (
          <button
            type="button"
            className="home-sidebar-toggle"
            title={`Toggle left sidebar (${toggleHint})`}
            aria-label="Toggle left sidebar"
            onClick={() => dispatch({ type: "toggleSidebar" })}
          >
            <SidebarIcon size={16} />
          </button>
        )}
        <div className="allws-header">
          <h1 className="allws-title">Home</h1>
          <button type="button" className="allws-create" onClick={onCreateWorkspace}>
            Create workspace
          </button>
        </div>
        <div className="allws-toolbar">
          <div className="allws-toolbar-inner">
            <label className="allws-search">
              <SearchIcon size={14} />
              <input
                autoFocus
                placeholder="Search"
                aria-label="Search workspaces"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={onSearchKey}
              />
            </label>
            {showProjectFilter(repos, archivedRows) && (
              <Menu ariaLabel="Projects" label={projectFilterLabel(repos, filters.projects)} icon={<FolderIcon size={14} />}>
                {() => (
                  <>
                    <MenuCheck checked={filters.projects.length === 0} onClick={() => setFilters({ ...filters, projects: [] })}>
                      All projects
                    </MenuCheck>
                    {projectChoices.map((r) => (
                      <MenuCheck key={r.id} checked={filters.projects.includes(r.id)} onClick={() => setFilters({ ...filters, projects: toggleProject(filters.projects, r.id) })}>
                        <RepoIcon repo={r} className="allws-repo-initial" />
                        {r.name}
                      </MenuCheck>
                    ))}
                  </>
                )}
              </Menu>
            )}
            <Menu ariaLabel="Archived workspaces" label={ARCHIVE_FILTER_LABELS[filters.archiveFilter]} icon={<ArchiveIcon size={14} />}>
              {(close) =>
                ARCHIVE_FILTERS.map((f) => (
                  <MenuCheck
                    key={f}
                    checked={filters.archiveFilter === f}
                    onClick={() => {
                      setFilters({ ...filters, archiveFilter: f });
                      close();
                    }}
                  >
                    {ARCHIVE_FILTER_LABELS[f]}
                  </MenuCheck>
                ))
              }
            </Menu>
          </div>
        </div>
      </div>
      <div className="allws-scroll">
        <div className="allws-list" role="listbox" aria-label="Workspaces">
          {loading ? (
            <div className="allws-loading" role="status" aria-label="Loading workspaces">
              <RowStatusIcon status="working" size={16} />
            </div>
          ) : groups.length > 0 ? (
            <>
              {groups.map((g) => (
                <section key={g.bucket} className="allws-group" aria-label={g.label}>
                  <h2 className="allws-group-heading">
                    {g.label} <span className="allws-count">{g.rows.length}</span>
                  </h2>
                  {g.rows.map((row) => {
                    index += 1;
                    const i = index;
                    return (
                      <Row
                        key={row.workspace.id}
                        row={row}
                        showRepoIcon={filters.projects.length === 0}
                        showNumber={showNumbers}
                        active={i === activeIndex}
                        now={now}
                        onOpen={() => {
                          setActiveKey(flat[i].key);
                          open(row);
                        }}
                        dispatch={dispatch}
                      />
                    );
                  })}
                </section>
              ))}
              {hasMore && <div ref={sentinel} className="allws-more" role="status" aria-label="Loading more workspaces" />}
            </>
          ) : (
            <div className="allws-empty">
              <span>No matching workspaces</span>
              {empty === "create" && (
                <button type="button" className="allws-create" onClick={onCreateWorkspace}>
                  Create a workspace
                </button>
              )}
              {empty === "clear" && (
                <button type="button" className="allws-clear" onClick={() => setFilters(CLEARED_FILTERS)}>
                  Clear filters
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
